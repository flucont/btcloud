System.register(["./vue-bucket-legacy.js","./element-ui-legacy.js"],(function(e,t){"use strict";var r,s;return{setters:[e=>{r=e.a},e=>{s=e.A}],execute:function(){var t=s();e("_",r(t))}}}));
