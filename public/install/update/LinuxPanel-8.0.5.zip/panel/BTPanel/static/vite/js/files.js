import{q as s}from"./main.js";const e=()=>s.post("files/GetTaskSpeed"),a=e=>s.post("files/RemoveTask",{data:e,check:"msg"});export{e as g,a as r};
