#!/usr/bin/python
# coding: utf-8
# Date 2022/4/1
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: lkq <lkq@bt.cn>
# 网站安全扫描
#-------------------------------------------------------------------
from projectModel.base import projectBase
import sys,json, os, public, hashlib,requests,time
from BTPanel import cache
import PluginLoader



class main(projectBase):

    # __scanning=scanningModel.main()
    __count = 0
    __shell = "/www/server/panel/data/webshell_check_shell.txt"

    def GetWebInfo(self,get):
        '''
        @name 获取网站信息
        @author lkq<2022-4-12>
        @param name  网站名称
        @return
        '''
        webinfo = public.M('sites').where('project_type=? and name=?', ('PHP', get.name)).count()
        if not webinfo: return False
        webinfo = public.M('sites').where('project_type=? and name=?', ('PHP', get.name)).select()
        return webinfo[0]


    def ScanWeb(self,get):
        '''
        @name 获取当前站点漏洞扫描信息
        @author lkq<2022-4-12>
        @param name  网站名称
        @return
        '''
        if '_ws' in get:get._ws.send(public.getJson({"end": False, "ws_callback": get.ws_callback, "info": "正在扫描 %s 网站漏洞"%get.name, "type": "vulscan"}))

        # args = public.dict_obj()
        # args.module_get_object = 1
        #from projectModel import scanningModel

        scanInfo = PluginLoader.module_run("scanning", "startScanWeb", get)

        #scanInfo=self.__scanning.startScanWeb(get)
        if scanInfo['msg'][0]['is_vufix']:
            if '_ws' in get: get._ws.send(public.getJson({"end": False, "ws_callback": get.ws_callback, "info": "网站 %s 存在漏洞" % get.name, "type": "vulscan","is_error":True}))
            return scanInfo['msg'][0]['cms']
        return {}

    def WebSSlSecurity(self,webinfo,get):
        '''
        @name SSL证书安全性
        @author lkq<2022-4-12>
        @param name  网站名称
        @return Tls1.0 检测 TLS1.1
        '''
        if public.get_webserver()=='nginx':
            conf_file='/www/server/panel/vhost/nginx/{}.conf'.format(webinfo['name'])
            if os.path.exists(conf_file):
                conf_info=public.ReadFile(conf_file)
                if 'TLSv1 ' in conf_info:
                    if '_ws' in get: get._ws.send(public.getJson(
                        {"end": False, "ws_callback": get.ws_callback, "info":  "【%s】 网站启用了不安全的TLS1协议"%webinfo['name'],
                         "type": "webscan", "is_error": True,"dangerous":2}))
                    webinfo['result']['webscan'].append({"name": "【%s】 网站启用了不安全的TLS1协议"%webinfo['name'], "repair": "修复方案：打开配置文件去掉TLS1","dangerous":2})



    def WebInfoDisclosure(self,get):
        '''
        @name php/nginx/apache版本泄露
        @author lkq<2022-4-12>
        @param name  网站名称
        @return
        '''
        if '_ws' in get:get._ws.send(
            public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描 %s 网站配置安全性"%get.name, "type": "webscan"}))
        result=[]
        if public.get_webserver()=='nginx':
            nginx_path='/www/server/nginx/conf/nginx.conf'
            if os.path.exists(nginx_path):
                nginx_info=public.ReadFile(nginx_path)
                if not 'server_tokens off' in nginx_info:
                    result.append({"name":"Nginx存在版本信息泄露","repair":"打开nginx.conf配置文件，在http { }里加上： server_tokens off;","dangerous":1})
        phpversion=public.get_site_php_version(get.name)
        phpini='/www/server/php/%s/etc/php.ini'%phpversion
        if os.path.exists(phpini):
            php_info=public.ReadFile(phpini)
            if not 'expose_php = Off' in php_info:
                result.append({"name": "PHP %s 存在版本信息泄露"%phpversion, "repair": "修复方案：打开php.ini配置文件，设置expose_php = Off","dangerous":1})
        #目录和
        if '_ws' in get:get._ws.send(
            public.getJson({"end": False, "callback": get.ws_callback, "info": "扫描 %s 网站配置安全性完成"%get.name, "type": "webscan"}))
        return result


    def _send_task(self,url):
        '''
        @name 拨测发送请求
        @author lkq<2022-4-12>
        @param url  URL
        @return
        '''
        import panelAuth
        pdata = panelAuth.panelAuth().create_serverid(None)
        pdata['url'] = url
        try:
            result = public.httpPost("http://www.example.com/api/local/boce", pdata, 10)
            result = json.loads(result)
            return result
        except:
            return False


    def WebBtBoce(self,get,webinfo):
        '''
        @name 拨测
        @author lkq<2022-4-12>
        @param name  网站名称
        @return
        '''
        webinfo['result']['boce'] = []
        for url in get.url:
            if url.find('http://') == -1 and url.find('https://') == -1:continue
            if '_ws' in get: get._ws.send(public.getJson(
                {"end": False, "ws_callback": get.ws_callback, "info": "正在对URL %s 进行拨测" % url, "type": "boce"}))
            result = self._send_task(get.url)
            if '_ws' in get: get._ws.send(public.getJson(
                {"end": False, "ws_callback": get.ws_callback, "info": result, "type": "boce"}))
            if result:
                webinfo['result']['boce'].append(result)

    def WebFilePermission(self,webinfo,get):
        '''
       @name 网站权限
       @author lkq<2022-4-12>
       @param name  网站名称
       @return
       '''
        import pwd
        return_data = []
        for i in os.listdir(webinfo['path']):
            is_name=os.path.join(webinfo['path'],i)
            if os.path.isdir(is_name):
                return_data.append(is_name)
                for i2 in os.listdir(is_name):
                    is_name2=is_name+'/'+i2
                    if os.path.isdir(is_name2):
                        return_data.append(is_name2)
        if len(return_data)>=1:
            for file in return_data:
                if not os.path.exists(file):continue
                stat=os.stat(file)
                if int(oct(stat.st_mode)[-3:])==777:
                    if '_ws' in get: get._ws.send(public.getJson(
                        {"end": False, "ws_callback": get.ws_callback, "info": "  【%s】 目录权限错误"%file,"repair":"设置 【%s】 目录为755"%file,
                         "type": "webscan", "is_error": True,"dangerous":1}))
                    webinfo['result']['webscan'].append({"name":"  【%s】 目录权限错误"%file,"repair":"修复方案：设置 【%s】 目录为755"%file,"dangerous":1})
                if pwd.getpwuid(stat.st_uid).pw_name !='www':
                    if '_ws' in get: get._ws.send(public.getJson(
                        {"end": False, "ws_callback": get.ws_callback, "info": "  【%s】 目录权限错误"%file,"repair":"修复方案：设置 【%s】 目录的用户权限为www" % file,
                         "type": "webscan", "is_error": True,"dangerous":1}))
                    webinfo['result']['webscan'].append({"name": "  【%s】 目录用户权限错误" % file, "repair": "设置 【%s】 目录的用户权限为www" % file,"dangerous":1})


    def Getdir(self, path):
        '''
        @name 获取目录下的所有php文件
        @author lkq<2022-4-12>
        @param path 文件目录
        @return list
        '''
        return_data = []
        data2 = []
        [[return_data.append(os.path.join(root, file)) for file in files] for root, dirs, files in os.walk(path)]
        for i in return_data:
            if str(i.lower())[-4:] == '.php':
                data2.append(i)
        return data2

    def ReadFile(self, filename, mode='r'):
        '''
        @name 读取文件内容
        @author lkq<2022-4-12>
        @param filename 文件路径
        @return 文件内容
        '''
        import os
        if not os.path.exists(filename): return False
        try:
            fp = open(filename, mode)
            f_body = fp.read()
            fp.close()
        except Exception as ex:
            if sys.version_info[0] != 2:
                try:
                    fp = open(filename, mode, encoding="utf-8")
                    f_body = fp.read()
                    fp.close()
                except Exception as ex2:
                    return False
            else:
                return False
        return f_body

    def FileMd5(self, filename):
        '''
        @name 获取文件的md5值
        @author lkq<2022-4-12>
        @param filename 文件路径
        @return MD5
        '''
        if os.path.exists(filename):
            with open(filename, 'rb') as fp:
                data = fp.read()
            file_md5 = hashlib.md5(data).hexdigest()
            return file_md5
        else:
            return False

    def WebshellChop(self, filename, url,get):
        '''
        @name 上传到云端判断是否是webshell
        @author lkq<2022-4-12>
        @param filename 文件路径
        @param url 云端URL
        @return bool
        '''
        try:
            upload_url = url
            size = os.path.getsize(filename)
            if size > 1024000: return False
            upload_data = {'inputfile': self.ReadFile(filename),"md5":self.FileMd5(filename)}
            # public.print_log("参数: "+json.dumps(upload_data))
            # public.print_log("URL "+upload_url)
            # public.print_log(self.FileMd5(filename)+" "+filename)
            upload_res = requests.post(upload_url, upload_data, timeout=20).json()
            # public.print_log("返回:  "+json.dumps(upload_res))
            if upload_res['msg'] == 'ok':
                if (upload_res['data']['data']['level'] == 5):
                    return True
                return False
        except:
            return False

    def GetCheckUrl(self):
        '''
        @name 获取云端URL地址
        @author lkq<2022-4-12>
        @return URL
        '''
        try:
            ret = requests.get('http://www.bt.cn/checkWebShell.php').json()
            if ret['status']:
                return ret['url']
            return False
        except:
            return False

    def UploadShell(self, data,get,webinfo):
        '''
        @name 上传文件
        @author lkq<2022-4-12>
        @param data 文件路径集合
        @return 返回webshell 路径
        '''
        if len(data) == 0: return []
        url = self.GetCheckUrl()
        if not url: return []
        count = 0
        wubao=0
        shell_data=[]
        if os.path.exists(self.__shell):
            wubao=1
            try:
                shell_data = json.loads(public.ReadFile(self.__shell))
            except:
                public.WriteFile(self.__shell,[])
                wubao=0
        for i in data:
            count += 1
            if '_ws' in get: get._ws.send(
                public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描文件是否是木马%s"%i,"type": "webscan","count":self.__count,"is_count":count}))
            #判断是否是哪个误报的文件
            if wubao:
                if i in shell_data:continue
            if self.WebshellChop(i, url,get):
                if '_ws' in get: get._ws.send(
                    public.getJson({"end": False, "callback": get.ws_callback,
                                    "info": "%s 网站木马扫描发现当前文件为木马文件%s" % (get.name, len(webinfo['result']['webshell'])),
                                    "type": "webscan", "count": self.__count, "is_count": count, "is_error": True}))
                webinfo['result']['webshell'].append(i)
        if '_ws' in get: get._ws.send(
            public.getJson({"end": False, "callback": get.ws_callback, "info": "%s 网站木马扫描完成共发现 %s 个木马文件" %(get.name,len(webinfo['result']['webshell'])), "type": "webscan","count": self.__count, "is_count": count}))


    def GetDirList(self, path_data):
        '''
        @name 获取当前目录下所有PHP文件
        @author lkq<2022-4-12>
        '''
        if os.path.exists(str(path_data)):
            return self.Getdir(path_data)
        else:
            return False

    def SanDir(self, webinfo,get):
        '''
        @name 扫描webshell入口函数
        @author lkq<2022-4-12>
        @param path 需要扫描的路径
        @return  webshell 路径集合
        '''
        self.__count = 0
        file = self.GetDirList(webinfo['path'])
        if not file:
            return []
        ##进度条
        self.__count = len(file)
        return_data = self.UploadShell(file,get,webinfo)
        return return_data

    def UpdateWubao(self,filename):
        '''
        @name 更新误报文件
        @author lkq<2022-4-12>
        @param filename 误报文件
        '''
        if not os.path.exists(self.__shell):
            public.WriteFile(self.__shell, [filename.strip()])
        else:
            try:
                shell_data = json.loads(public.ReadFile(self.__shell))
                if not filename in shell_data:
                    shell_data.append(filename)
                    public.WriteFile(self.__shell, json.dumps(shell_data))
            except:
                pass

    #提交误报
    def SendWubao(self,get):
        '''
        @name 提交误报
        @author lkq<2022-4-12>
        @param get.filename 误报文件
        '''
        userInfo = json.loads(public.ReadFile('/www/server/panel/data/userInfo.json'))
        cloudUrl = 'http://www.example.com/api/bt_waf/reportTrojanError'
        self.UpdateWubao(filename=get.filename)
        pdata = {'name':get.filename,'inputfile': self.ReadFile(get.filename), "md5": self.FileMd5(get.filename),"access_key": userInfo['access_key'], "uid": userInfo['uid']}
        ret = public.httpPost(cloudUrl, pdata)
        return public.returnMsg(True, "提交误报完成")


    def WebShellKill(self,get,webinfo):
        '''
       @name 木马查杀
       @author lkq<2022-4-12>
       @param name  网站名称
       @return
       '''
        webinfo['result']['webshell']=[]
        self.SanDir(webinfo,get)


    def WebFileDisclosure(self,webinfo,get):
        '''
       @name 网站信息泄露
       @author lkq<2022-4-12>
       @param name  网站名称
       @return
       '''
        webinfo['result']['filescan']=[]
        for i in os.listdir(webinfo['path']):
            is_name=os.path.join(webinfo['path'],i)
            if os.path.isfile(is_name):
                if is_name.endswith(".sql"):
                    webinfo['result']['filescan'].append(
                        {"name": "  【%s】 网站根目录存在sql备份文件%s" % (webinfo['name'],is_name), "repair": "修复方案：转移到其他目录或者下载到本地",
                         "dangerous": 2})
                if is_name.endswith(".zip") or is_name.endswith(".gz") or is_name.endswith(".tar") or is_name.endswith(".7z"):
                    if webinfo['name'] in is_name:
                        if '_ws' in get: get._ws.send(public.getJson(
                            {"end": False, "ws_callback": get.ws_callback, "info": "  【%s】 网站根目录存在备份文件 %s" %(webinfo['name'],is_name),
                             "type": "filescan", "is_error": True,"dangerous":2}))
                        webinfo['result']['filescan'].append({"name": "  【%s】 网站根目录存在备份文件 %s" %(webinfo['name'],is_name), "repair": "修复方案：转移到其他目录或者下载到本地","dangerous":2})

    def IsBackupSite(self,webname):
        '''
       @name 判断是否存在备份
       @author lkq<2022-4-12>
       @return
       '''
        import crontab
        crontab_data = crontab.crontab()
        data = crontab_data.GetCrontab(None)
        for i in data:
            if i['sType'] == 'site':
                if i['sName']=='ALL':
                    return True
                if i['sName']==webname:
                    return True
        return False

    def WebBackup(self,webinfo,get):
        '''
       @name 是否备份重要数据
       @author lkq<2022-4-12>
       @param name  网站名称
       @return
       '''
        webinfo['result']['backup']=[]
        if not self.IsBackupSite(webinfo['name']):
            if '_ws' in get: get._ws.send(public.getJson({"end": False, "ws_callback": get.ws_callback,"info": "修复方案：【%s】 在计划任务中创建备份网站任务"%webinfo['name'],"type": "backup", "is_error": True, "dangerous": 2}))
            webinfo['result']['backup'].append({"name": "  【%s】 缺少计划任务备份" % (webinfo['name']), "repair": "修复方案：【%s】 在计划任务中创建备份网站任务"%webinfo['name'],"dangerous": 2})

    def GetLevelRule(self,get):
        result=[]
        data2=['364c2b553559697066445638', '364c2b55354c326a66445638', '3537364f3561577a66444577664f694a7375614468513d3d', '365a79793649533466444977664f694a7375614468513d3d', '36594b41364b2b3366444d7766413d3d', '353436773659655266444d77664f574e6d75573971513d3d', '63444a7766444d77664f6976694f6d716c773d3d', '354c6974357061483561325835626d5666444d77664f694a7375614468513d3d', '356232703536576f66445577664f574e6d75573971513d3d', '364c53743562327066445577664f574e6d75573971513d3d', '356f715635724f6f66445577664f574e6d75573971513d3d', '354c71613559326166445577664f574e6d75573971513d3d', '354c71613570435066445577664f574e6d75573971513d3d', '357065673536434266445977664f694a7375614468513d3d', '3570794a3536434266445977664f694a7375614468513d3d', '35594733356f754e66445977664f694a7375614468513d3d', '35705376354c755966445977664f57626d2b615775656155722b53376d413d3d', '356f6951354c713635623278364b654766446377664f694a7375614468513d3d', '356f6951354c7136353553313562327866446377664f694a7375614468513d3d', '3662754536496d79353732523536755a66446377664f694a7375614468513d3d', '3571796e3537364f3562656f354c6d7a66446377664f694a7375614468513d3d', '35367973354c6941354c7961356f6d4166446377664f694a7375614468513d3d', '36496d79356f4f4666446377664f694a7375614468513d3d', '355a7539354c716e51585a384e7a423836496d79356f4f46', '354c71613572537951585a384e7a423836496d79356f4f46', '3570656c3570797359585a384e7a423836496d79356f4f46', '354c6941357079733659475466446377664f694a7375614468513d3d', '357065683536434266446377664f694a7375614468513d3d', '354c6d463649324a66446377664f694a7375614468513d3d', '356f32563662473866446377664f574e6d75573971513d3d', '36494342364a6d4f3570793666446377664f574e6d75573971513d3d', '35714f4c35346d4d66446377664f574e6d75573971513d3d', '36492b6736492b6366446377664f574e6d75573971513d3d', '3572367a365a656f66446377664f574e6d75573971513d3d', '356f2b513534367766446377664f574e6d75573971513d3d', '35615371365a697a355a2b4f66446377664f574e6d75573971513d3d', '354c716b35706954356f6d4166446377664f6d376b656542734f533670773d3d', '354c756c35615371355a324b6644637766413d3d', '3559574e3536322b3537716d66446777664f57626d2b615775656155722b53376d413d3d', '3537712f364c657635714f413572574c6644677766413d3d', '355932613562327066446777664f574e6d75573971513d3d', '364c574d365a4b7866446777664f574e6d75573971513d3d', '35616978354c6d51355a793666446777664f574e6d75573971513d3d', '624739755a7a68384f4442383559326135623270', '3572367a365a656f35615371365a697a355a2b4f66446777664f574e6d75573971513d3d', '364a4768354c717366446731664f574e6d75573971513d3d', '3659655235724b5a66446731664f574e6d75573971513d3d', '365a4f3235724b7a66446731664f574e6d75573971513d3d', '3537712f354c694b354c694c35724f6f66446731664f574e6d75573971513d3d', '35616978354c6d51355a2b4f66446b77664f574e6d75573971513d3d', '3571796e354c7161355a7539365a6d4666446b77664f574e6d75573971513d3d', '354c715335593261355a7539365a6d4666446b77664f574e6d75573971513d3d', '354c6948364c4771355a7539365a6d4666446b77664f574e6d75573971513d3d', '354c6948354c6977355a7539365a6d4666446b77664f574e6d75573971513d3d', '354c716135593261355a7539365a6d4666446b77664f574e6d75573971513d3d', '355a75623570613535705376354c755966446b77664f57626d2b615775656155722b53376d413d3d', '35616942356243383570617666446b31664f574e6d75573971513d3d', '35706177364a4768354c717366446b35664f574e6d75573971513d3d', '364c574d355a793666446b35664f574e6d75573971513d3d', '364c574d3559326166446b35664f574e6d75573971513d3d', '35706532357065323562327066446b77664f574e6d75573971513d3d', '35595774355a43493562327066446b35664f574e6d75573971513d3d', '35616962357169433561433066446777664f574e6d75573971513d3d', '3559574e3536322b35705376354c755966446777664f57626d2b615775656155722b53376d413d3d', '364c53333571792b66446377664f6976694f6d716c773d3d', '35726958365943503572574c364b2b5666445577664f6d376b656542734f533670773d3d', '35705337365a697966445577664f6d376b656542734f533670773d3d', '35356d39356269393561325166445577664f6d376b656542734f533670773d3d', '36627552356269393561325166446377664f6d376b656542734f533670773d3d', '35377169356269393561325166445977664f6d376b656542734f533670773d3d', '3559614635373252357269583659435066445977664f6d376b656542734f533670773d3d', '3559574e3570324166446777664f6d376b656542734f533670773d3d', '35727950357253653562656c3559573366446777664f6d376b656542734f533670773d3d', '56325669357269583659435066446777664f6d376b656542734f533670773d3d', '36594347355a435266446777664f6d376b656542734f533670773d3d', '366275523561366966445977664f6d376b656542734f533670773d3d', '357036423561366966445177664f6d376b656542734f533670773d3d', '35705777356f3275355a53753559325766446377664f6d376b656542734f533670773d3d', '353665523561326d354c694b3537325266446b7766465a5154673d3d', '35372b3735614b5a66446b7766465a5154673d3d', '353732523537756335597167365943666644597766465a5154673d3d', '566c424f66446b7766465a5154673d3d', '55314e5366446b7766465a5154673d3d', '35714b763561325166446b7766465a5154673d3d', '646a4a7959586c384f544238566c424f', '3559716736594366355a6d6f6644637766465a5154673d3d', '3659573436595734354c6d7a66446b7766465a5154673d3d', '626d56306432397961794277636d3934655877334d4878575545343d', '3559364c355971623572574c364b2b5666446b77664f6d376b656542734f533670773d3d', '3572574c3559364c66445177664f6d376b656542734f533670773d3d', '35627941356f692f364b36773562325666445977664f6d376b656542734f533670773d3d', '35613661354c324e354c2b68356f477666445977664f6d376b656542734f533670773d3d', '364b36773562325635702b6c364b2b6966445177664f6d376b656542734f533670773d3d', '3659575335627158364b36773562325666446777664f6d376b656542734f533670773d3d', '355a794c365a716266444d77664f6976694f6d716c773d3d', '356f7156364c4f4866445177664f6976694f6d716c773d3d', '356f6951354c713666445977664f694a7375614468513d3d', '353665423570794e66446377664f6d376b656542734f533670773d3d', '35373252364c533366446377664f6976694f6d716c773d3d', '364c326d364c533366446377664f6976694f6d716c773d3d', '355943663571792b66446377664f6976694f6d716c773d3d', '355969473570796666446377664f6976694f6d716c773d3d', '35364342355a574766445531664f57626d2b615775656155722b53376d413d3d', '35705376354c755935626d7a35592b7766446b77664f57626d2b615775656155722b53376d413d3d', '35705376354c7559356f366c35592b6a66446b77664f57626d2b615775656155722b53376d413d3d', '51584277356271553535536f3559694735592b526644597766413d3d', '364b69383559693466445177664f6976694f6d716c773d3d', '3649324a3571613066446377664f694a7375614468513d3d', '35712b5535346d353562694266445977664f6d376b656542734f533670773d3d', '56564e45564877324d487a707535486e6762446b7571633d', '3535577135592b333537325266445977664f694a7375614468513d3d', '3535577135592b333561536e3559576f66445977664f694a7375614468513d3d', '3535577135592b333562715466445977664f694a7375614468513d3d', '3535577135592b33357043633537536966445977664f694a7375614468513d3d', '5156626c7062506c763664384e6a423836496d79356f4f46', '356136463535533335366150355969703536532b66445977664f694a7375614468513d3d']
        for i in data2:
            result.append(public.en_hexb(i).split('|'))
        return result

    def WebIndexSecurity(self,get):
        '''
        @name 首页内容风险
        @author lkq<2022-4-12>
        @param urllist  网站名称
        @return
        '''
        return_result=[]
        if 'urllist' in get:
            GetLevelRule=self.GetLevelRule(None)
            for i in get.urllist:
                try:
                    if not i.find('http://') == -1 and i.find('https://') == -1:
                        if '_ws' in get: get._ws.send(public.getJson({"end": False, "ws_callback": get.ws_callback, "info": "正在对URL %s 进行内容风险检测" % get.url, "type": "index","is_error": True}))
                        data=requests.get(url=i,verify=False)
                        info_data=data.text
                        count=0
                        result=[]
                        for i2 in GetLevelRule:
                            if i2[0] in info_data:
                                count+=int(i2[1])
                                result.append(i2[0])
                        if count>=50:
                            if '_ws' in get: get._ws.send(public.getJson(
                                {"end": False, "ws_callback": get.ws_callback, "info": "URL %s 存在内容风险" % i,
                                 "type": "index","is_error": True}))
                            return_result.append({"name":"url %s 存在内容风险 内容风险的关键词如下:【 %s 】"%(i,' , '.join(result)),"type":"index","repair":"修复方案：检查该页面是否被篡改或清理掉此关键词"})
                except: continue
            return return_result
        else:
            return []


    def GetDoamin(self,get):
        '''
        @name 获取网站的域名信息
        @author lkq<2022-4-12>
        @param name 网站名称
        @return 网站信息列表 [list]
        '''
        webinfo = self.GetWebInfo(get)
        if not webinfo: return public.returnMsg(False, '当前网站不存在')
        if public.M('domain').where("pid=?",(webinfo['id'])).count()==0:
            if not webinfo: return public.returnMsg(False, '当前网站不存在')
        return public.returnMsg(True, public.M('domain').where("pid=?",(webinfo['id'])).select())


    def __check_auth(self):
        try:
            from pluginAuth import Plugin
            plugin_obj = Plugin(False)
            plugin_list = plugin_obj.get_plugin_list()
            if int(plugin_list['ltd']) > time.time():
                return True
            return False
        except:return False

    def ScanSingleSite(self,get):
        '''
       @name 扫描单个网站
       @author lkq<2022-4-12>
       @param name  网站名称
       @param vulscan  漏洞扫描
       webscan   网站配置安全性  SSL证书安全性  php/nginx/apache版本泄露   目录和文件权限
       filescan 文件泄漏
       backuo 是否备份重要数据
       webshell 木马
       拨测 boce
       index 首页内容风险
       @param scan_list=[""]
       @return
       '''
        public.set_module_logs('webscanning', 'ScanSingleSite', 1)
        pay = self.__check_auth()
        if not pay:return public.returnMsg(False, '当前功能为企业版专享')
        webinfo=self.GetWebInfo(get)
        if not webinfo: return public.returnMsg(False, '当前网站不存在')
        webinfo['result'] = {}
        if '_ws' in get:
            #websocket
            for i in get.scan_list:
                if i == 'vulscan':
                    get._ws.send(public.getJson({"end": False,"ws_callback":get.ws_callback,"info":"正在扫描漏洞","type":"vulscan"}))
                    webinfo['result']['vulscan'] = self.ScanWeb(get)
                    get._ws.send(public.getJson({"end": False,"ws_callback":get.ws_callback,"info":"漏洞扫描完成","type":"vulscan"}))
                if i == 'webscan':
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描网站配置安全性","type":"webscan"}))
                    webinfo['result']['webscan'] = self.WebInfoDisclosure(get)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描网站权限配置","type":"webscan"}))
                    self.WebFilePermission(webinfo,get)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "网站权限配置扫描完成","type":"webscan"}))

                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描SSL安全","type":"webscan"}))
                    self.WebSSlSecurity(webinfo,get)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "网站SSL扫描完成","type":"webscan"}))

                if i == 'filescan':
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描文件泄漏","type":"filescan"}))
                    self.WebFileDisclosure(webinfo,get)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "文件泄漏扫描完成","type":"filescan"}))

                if i == 'backup':
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描备份文件","type":"backup"}))
                    self.WebBackup(webinfo,get)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "备份文件扫描完成","type":"backup"}))
                if i == 'webshell':
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "正在扫描webshell","type":"webshell"}))
                    self.WebShellKill(get,webinfo)
                    get._ws.send(public.getJson(
                        {"end": False, "callback": get.ws_callback, "info": "webshell扫描完成", "type": "webshell"}))
                if i == 'boce':
                    get._ws.send(public.getJson(
                        {"end": False, "callback": get.ws_callback, "info": "正在进行拨测", "type": "boce"}))
                    if 'url' in get:
                        self.WebBtBoce(get, webinfo)
                    get._ws.send(public.getJson({"end": False, "callback": get.ws_callback, "info": "拨测完成", "type": "boce"}))
                if i == 'index':
                    get._ws.send(public.getJson(
                        {"end": False, "callback": get.ws_callback, "info": "正在进行页内内容风险检测", "type": "index"}))
                    webinfo['result']['index']=self.WebIndexSecurity(get)
                    get._ws.send(public.getJson(
                        {"end": False, "callback": get.ws_callback, "info": "页内容风险检测完成", "type": "index"}))
                get._ws.send(public.getJson({"end": True, "ws_callback": get.ws_callback, "info": "扫描完成", "type": i,"webinfo":webinfo}))
            time_info = int(time.time())
            public.WriteFile("/www/server/panel/config/webscaning_time",str(time_info))
        else:
            if os.path.exists("/www/server/panel/config/webscaning_time"):
                try:
                    time_info=int(public.ReadFile("/www/server/panel/config/webscaning_time"))
                    return public.returnMsg(True,time_info)
                except:
                    return public.returnMsg(True, 0)
            else:
                return public.returnMsg(True,0)
        # else:
        #     for i in get.scan_list:
        #         if i=='vulscan':
        #             webinfo['result']['vulscan']=self.ScanWeb(get)
        #         if i=='webscan':
        #             webinfo['result']['webscan']=self.WebInfoDisclosure(get)
        #             self.WebFilePermission(webinfo)
        #             self.WebSSlSecurity(webinfo)
        #         if i=='filescan':
        #             self.WebFileDisclosure(webinfo)
        #         if i=='backup':
        #             self.WebBackup(webinfo)
        #         if i=='webshell':
        #             self.WebShellKill(get,webinfo)
        #         if i=='boce':
        #             if  'url' in get:
        #                 self.WebBtBoce(get,webinfo)
        #         if i=='index':
        #             pass
        #     return webinfo

    def ScanAllSite(self,get):
        '''
       @name 扫描所有网站
       @author lkq<2022-4-12>
       @param name  网站名称
       @return
       '''
        pass

    def test2(self,get):
        get._ws.send(get.ws_callback)
        get._ws.send("11111")
        return '111'
