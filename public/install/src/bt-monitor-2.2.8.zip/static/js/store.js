import{bf as s}from"./windi.js";import{s as t}from"./utils.js";function n(){const n=s();return t(n)}async function o(){const t=s();await t.getInfo()}export{o as g,n as u};
