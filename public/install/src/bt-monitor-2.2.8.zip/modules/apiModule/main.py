
import json,time,re,os
import core.include.public as public
from flask import Response, request
from core.include.monitor_helpers import basic_monitor_obj, monitor_db_manager
from core.include.monitor_exceptions import BtMonitorException
import core.include.Locker as Locker
# monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
# from core import client_data_queue

class main:
    __plugin_path = '{}/plugin/'.format(public.get_panel_path())

    def __int__(self):
        self.access_key = None
        self.secret_key = None
        self.server_id = None
        self.sid = None

    def check_update(self, args):
        '''
            @name 检查更新
            @author hwliang
            @return dict
        '''
        return public.success('没有更新')

    def aes_decrypt(self, pdata):
        '''
            @name 数据解密
            @author hwliang
            @param pdata<string> 待解密数据
            @return dict
        '''
        iv = self.access_key[:8] + self.access_key[-8:]
        import core.include.aes as aes
        aes_obj = aes.aescrypt_py3(self.secret_key,"CBC",iv.encode())

        try:
            decode_data =  aes_obj.aesdecrypt(pdata)
            result = json.loads(decode_data)
            return result
        except Exception as e:
            return None

    def aes_encrypt(self, pdata):
        '''
            @name 数据加密
            @author hwliang
            @param pdata<dict> 待加密的数据
            @return string
        '''
        iv = self.access_key[:8] + self.access_key[-8:]
        import core.include.aes as aes
        aes_obj = aes.aescrypt_py3(self.secret_key,"CBC",iv.encode())
        result = aes_obj.aesencrypt(json.dumps(pdata))
        return result

    def check_token(self, token):
        '''
            @name 检查token是否合法
            @author hwliang
            @param token<string> token
            @return bool
        '''
        # date = public.md5(public.format_date("%Y-%m-%d"))
        # hour = public.md5(public.format_date("%H"))
        # src_token = public.md5(date + self.access_key + hour)
        src_token = public.md5(self.access_key)
        return src_token == token

    def send_client(self, status, code, msg, error_msg=''):
        '''
            @name 发送消息到客户端
            @author hwliang
        '''
        pdata = public.return_data(status, msg, code, error_msg)
        if public.read_config('config')['API']['encrypt']:
            result = self.aes_encrypt(pdata)
        else:
            result = json.dumps(pdata)
        return result

    def bind(self, args):
        '''
            @name 绑定
            @author hwliang
            @return dict
        '''
        client_ip = public.get_client_ip()
        server_id = args.get('server_id', None)

        # public.print_log('>>>> Agent bind: {} {}'.format(client_ip, args.get('server_id', None)), _level='error')

        # query = basic_monitor_obj.db_easy('servers')\
        #     .where('ip=?', client_ip)\
        #     .order('sid', 'desc')
        #
        # if server_id is not None:
        #     query.where('server_id', server_id)
        #
        # sid = query.value('sid')

        with public.sqlite_easy('safety') as db:
            query = db.query().name('server_list')\
                .order('sid', 'desc')

            if server_id is not None:
                query.where('server_id', server_id)
            else:
                query.where('address', client_ip)

            sid = query.value('sid')

        result = {}
        server_info = None
        if not sid:
            # 如果不存在
            server_info = {
                "server_id": server_id or public.GetRandomString(24),
                "access_key": public.GetRandomString(48),
                "secret_key": public.GetRandomString(16),
                "address": client_ip,
                "status": 0,
                "ps": "",
                "addtime": int(time.time())
            }
            sid = public.M('server_list').insert(server_info)

        if server_info is None:
            server_info = basic_monitor_obj.db_easy('server_list', 'safety') \
                .where("sid", sid) \
                .field('server_id', 'access_key', 'secret_key') \
                .find()

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)
                insert_data = {
                    'sid': sid,
                    'ip': client_ip,
                    'remark': '{}(未命名)'.format(client_ip),
                }

                if 'type' in args:
                    insert_data['type'] = int(args.get('type', 0))

                if not db.query().name('servers').where('sid', sid).exists():
                    # 新增服务器
                    db.query()\
                        .name('servers')\
                        .insert(insert_data)

                if not db.query().name('server_details').where('sid', sid).exists():
                    # 新增服务器详情
                    db.query()\
                        .name('server_details')\
                        .insert({
                            'sid': sid,
                        })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

        # 更新主机IP
        basic_monitor_obj.db_easy('server_list', 'safety').where('sid', sid).update({'address': client_ip})

        # 返回数据
        result['server_id'] = server_info['server_id']
        result['access_key'] = server_info['access_key']
        result['secret_key'] = server_info['secret_key']
        result['server_ip'] = request.headers.get('host').split(':')[0]
        result['server_port'] = public.get_panel_port()
        result['tz'] = ''

        # from os import readlink

        # result['tz'] = readlink('/etc/localtime')

        return result

    def __check_access(self, args):
        '''
            @name 检查权限
            @author hwliang
            @return string or dict
        '''
        server_id = args.get('server_id/s','').strip()
        if len(server_id) != 24: return '-1',None
        if not re.match(r"^\w+$",server_id): return '-1',None

        token = args.get('token/s','').strip()
        # request_time = args.get('time/d',0)

        # if int(time.time()) - request_time > 86400: return '-1',None
        if len(token) != 32: return '-1',None

        # 优先从缓存中获取
        cache_key = 'BT_MONITOR_API__CHECK_ACCESS_SERVER_INFO__{}'.format(server_id)
        server_info = public.cache_get(cache_key)

        if not server_info:
            server_info = basic_monitor_obj.db_easy('server_list', 'safety').where("server_id", server_id).order('sid', 'desc').find()

            if not basic_monitor_obj.is_empty_result(server_info):
                # 从数据库获取后存入缓存
                public.cache_set(cache_key, server_info, 600)

        if not server_info: return '-1',None
        if server_info['status'] in [0,'0']: return '0',None

        self.access_key = server_info.get('access_key', '')
        self.secret_key = server_info.get('secret_key', '')
        self.server_id = server_id
        self.sid = server_info.get('sid', '')

        # 检查token是否合法
        if not self.check_token(token):
            return '-2',None

        # 解密数据
        data = args.get('pdata/s','').strip()
        if data:
            data = self.aes_decrypt(data)
            # print('{} ----decrypt data {}'.format(self.sid, data))

        return server_info,data

    def query(self, args):
        '''
            @name 查询
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info, str): return server_info

        # public.print_log('>>>>>> query - heart beat {}'.format(self.sid), _level='error')

        # 获取当前时间
        cur_time = int(time.time())

        warn_list = []

        remote_addr = None

        # self.bind(args)
        # 接收到主机心跳包
        cache_data = basic_monitor_obj.cache_server_status(self.sid)

        # 存在缓存则从缓存读取信息
        if cache_data:
            last_heartbeat_time, remote_addr, server_status = cache_data

            public.print_log("心跳包----------{} {} {} {}".format(server_status, cur_time, last_heartbeat_time,
                                                               cur_time - int(last_heartbeat_time)))

            # 仅当主机状态发生改变时，更新主机状态
            if int(server_status) == 0:
                server_info = basic_monitor_obj.db_easy('servers') \
                    .where('sid', self.sid) \
                    .where('is_authorized', 1) \
                    .field('sid', 'ip', 'remark', 'status', 'last_active_time', 'is_authorized') \
                    .find()

                if server_info is None:
                    return

                public.print_log("心跳包上次时间----------{}".format(server_info['last_active_time']))
                update_data = {}

                # 更新主机IP
                if remote_addr is not None \
                        and remote_addr != '' \
                        and remote_addr != server_info['ip'] \
                        and public.check_ip(remote_addr):
                    update_data['ip'] = remote_addr

                # 当主机上线时，更新最近一次活动时间
                if server_status == 1:
                    update_data['last_active_time'] = cur_time

                if int(server_info['is_authorized']) == 1:
                    warn_list.append({
                        'sid': server_info['sid'],
                        'server_status': 1,
                        'desc': '主机【{}{}】已上线'.format(
                            server_info['ip'],
                            '' if server_info['remark'] == '' else '({})'.format(server_info['remark']))
                    })

                # 更新数据
                update_data['status'] = 1
                update_data['update_time'] = cur_time
                basic_monitor_obj.db_easy('servers') \
                    .where('sid', self.sid) \
                    .update(update_data)

        # 更新主机状态缓存
        basic_monitor_obj.cache_server_status(self.sid, server_status=1, remote_addr=remote_addr)
        # public.cache_set('SHM_:BT_MONITOR_SERVER_LAST_HEARTBEAT_TIME_{}'.format(sid), (cur_time, remote_addr, 1))

        # 写系统日志和告警
        if len(warn_list) > 0:
            public.print_log("warn_list------{}".format(len(warn_list)))
            public.print_log("warn_list------{}".format(warn_list))

            for warn_info in warn_list:
                # 写一条系统日志
                public.WriteLog('主机管理', warn_info['desc'])

                # 主机上下线告警
                basic_monitor_obj.warn_server_status_on_off(warn_info['sid'], warn_info['server_status'])

        # 心跳包
        cache_data = basic_monitor_obj.cache_server_status(self.sid)

        # 存在缓存则从缓存读取信息
        if cache_data:
            last_heartbeat_time, remote_addr, server_status = cache_data

            # public.print_log("心跳包----------{} {} {} {}".format(server_status, cur_time, last_heartbeat_time, cur_time - int(last_heartbeat_time)))

            # 仅当主机状态发生改变时，更新主机状态
            if int(server_status) == 0:
                server_info = basic_monitor_obj.db_easy('servers') \
                    .where('sid', self.sid) \
                    .where('is_authorized', 1) \
                    .field('sid', 'ip', 'remark', 'status', 'last_active_time', 'is_authorized') \
                    .find()

                if server_info is None:
                    return

                # public.print_log("心跳包上次时间----------{}".format(server_info['last_active_time']))
                update_data = {}

                # 更新主机IP
                if remote_addr is not None \
                        and remote_addr != '' \
                        and remote_addr != server_info['ip'] \
                        and public.check_ip(remote_addr):
                    update_data['ip'] = remote_addr

                # 当主机上线时，更新最近一次活动时间
                if server_status == 1:
                    update_data['last_active_time'] = cur_time

                if int(server_info['is_authorized']) == 1:
                    warn_list.append({
                        'sid': server_info['sid'],
                        'server_status': 1,
                        'desc': '主机【{}{}】已上线'.format(
                            server_info['ip'],
                            '' if server_info['remark'] == '' else '({})'.format(server_info['remark']))
                    })

                # 更新数据
                update_data['status'] = 1
                update_data['update_time'] = cur_time
                basic_monitor_obj.db_easy('servers') \
                    .where('sid', self.sid) \
                    .update(update_data)

        # 更新主机状态缓存
        basic_monitor_obj.cache_server_status(self.sid, server_status=1, remote_addr=remote_addr)


        # 写系统日志和告警
        if len(warn_list) > 0:
            # public.print_log("warn_list------{}".format(len(warn_list)))
            # public.print_log("warn_list------{}".format(warn_list))

            for warn_info in warn_list:
                # 写一条系统日志
                public.WriteLog('主机管理', warn_info['desc'])

                # 主机上下线告警
                basic_monitor_obj.warn_server_status_on_off(warn_info['sid'], warn_info['server_status'])

        return self.send_client(True, 1, "connect")

        # 返回数据
        # return self.send_client(True,1,"padding")

    # 获取Agent版本信息存放路径
    def __get_agent_info_path(self, agent_type=0):
        return '{}/agent/{}.json'.format(public.get_panel_path(), {
            0: 'info',
            1: 'windows_info',
        }.get(int(agent_type), 'info'))

    # 获取Agent更新包存放路径
    def __get_agent_update_path(self, agent_type=0):
        return '{}/agent/{}.zip'.format(public.get_panel_path(), {
            0: 'update',
            1: 'windows_update',
        }.get(int(agent_type), 'info'))

    # 从服务器上更新Agent最新版本
    def __update_agent_info_from_server(self, agent_type=0):
        # 获取Agent最新版本号
        try:
            ret = json.loads(public.httpPost('https://api.bt.cn/bt_monitor/latest_agent_version', {
                'type': agent_type,
            }))
            latest_agent_version = tuple(map(lambda x: int(x), ret.get('version', '1.0').split('.')))
        except: return

        # 上锁
        with Locker.acquire_with_file(timeout=300):
            cur_agent_version = tuple(map(lambda x: int(x), self.__get_current_agent_version(agent_type).split('.')))

            if cur_agent_version >= latest_agent_version:
                return

            # 下载Agent安装包
            public.downloadFile('https://download.bt.cn/install/src/btmonitoragent-{}-{}.zip'.format(
                'linux' if agent_type == 0 else 'windows',
                '.'.join(map(lambda x: str(x), latest_agent_version))), self.__get_agent_update_path(agent_type), timeout=120)

            # 更新Agent版本描述文件
            public.writeFile(self.__get_agent_info_path(agent_type), json.dumps({
                'version': '.'.join(map(lambda x: str(x), latest_agent_version)),
                'name': 'agent',
                'md5': public.FileMd5(self.__get_agent_update_path(agent_type)),
            }, indent=4))

    # 获取当前Agent版本
    def __get_current_agent_version(self, agent_type=0):
        try:
            return json.loads(public.readFile(self.__get_agent_info_path(agent_type)))['version']
        except:
            return '1.0'

    # 检查当前请求过来的Windows被控版本是否为初始版本
    def __is_old_version_agent(self, agent_type=0):
        if int(agent_type) not in [1]:
            return False
        return basic_monitor_obj.get_agent_version_with_sid(self.sid or None) == '1.0'

    def get_update_info(self, args):
        '''
            @name 获取更新信息
            @author hwliang
            @return dict
        '''
        server_info, data = self.__check_access(args)
        if isinstance(server_info, str): return server_info

        agent_type = args.get('type', 0)  # Agent类型 0-Linux 1-Windows

        if self.__is_old_version_agent(agent_type):
            return self.send_client(True, 1, {
                'version': '1.0',
                'agent_md5': '',
                'plugin_list': [],
            })

        # 尝试同步云端版本
        self.__update_agent_info_from_server(agent_type)

        if not os.path.exists(self.__get_agent_info_path(agent_type)):
            agent_info = {'version': '1.0', 'name': 'agent', 'md5': ''}
        else:
            agent_info = json.loads(public.readFile(self.__get_agent_info_path(agent_type)))
            if 'md5' not in agent_info or len(agent_info['md5']) == 0:
                agent_info['md5'] = public.FileMd5(self.__get_agent_update_path(agent_type))
                public.writeFile(self.__get_agent_info_path(agent_type), json.dumps(agent_info, indent=4))

        _plugin_list = []
        # for plugin in os.listdir('{}/plugin'.format(public.get_panel_path())):
        #     plugin_info_file = '{}/plugin/{}/info.json'.format(public.get_panel_path(),plugin)
        #     plugin_update_file = '{}/plugin/{}/update.zip'.format(public.get_panel_path(),plugin)
        #     if not os.path.exists(plugin_info_file): continue
        #     if not os.path.exists(plugin_update_file): continue
        #     plugin_info = json.loads(public.readFile(plugin_info_file))
        #     if not 'md5' in plugin_info:
        #         plugin_info['md5'] = public.FileMd5(plugin_update_file)
        #         public.writeFile(plugin_info_file,json.dumps(plugin_info,indent=4))
        #     _plugin_list.append(
        #         {
        #         'name':plugin,
        #         'version':plugin_info['version'],
        #         'md5':plugin_info['md5']
        #         }
        #     )

        result = {
            "version": agent_info['version'],
            "agent_md5": agent_info['md5'],
            "plugin_list": _plugin_list,
        }

        return self.send_client(True, 1, result)

    def download_plugin(self, args):
        '''
            @name 下载插件
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        if not data: return self.send_client(False,0,"","参数: plugin_name不能为空")
        if 'plugin_name' not in data: return self.send_client(False, 0, "", "参数: plugin_name不能为空")
        plugin_name = data['plugin_name']
        if not re.match(r"^\w+$",plugin_name): return self.send_client(False,0,"","参数: plugin_name不合法")
        update_zip_file = '{}/{}/update.zip'.format(self.__plugin_path,plugin_name)
        if not os.path.exists(update_zip_file): return self.send_client(False,0,"","插件不存在")

        # from flask import send_file
        return public.send_file(update_zip_file, '{}.zip'.format(plugin_name))

    def download_agent(self, args):
        '''
            @name 下载agent
            @author hwliang
            @return dict
        '''
        server_info, data = self.__check_access(args)
        if isinstance(server_info, str): return server_info

        agent_type = args.get('type', 0)  # Agent类型 0-Linux 1-Windows

        if not os.path.exists(self.__get_agent_update_path(agent_type)):
            return self.send_client(False, 0, "", "agent不存在")
        # from flask import send_file
        return public.send_file(self.__get_agent_update_path(agent_type), 'agent.zip')

    def request_plugin(self, args):
        '''
            @name 请求插件
            @author hwliang
            @return dict
        '''
        public.print_log(args)
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        if not 'module' in data: return self.send_client(False,0,"","参数: module不能为空")
        if not 'action' in data: return self.send_client(False,0,"","参数: action不能为空")

        module = data['module']
        action = data['action']

        if not re.match(r"^\w+$",module) or not re.match(r"^\w+$",action):
            return self.send_client(False,0,"参数: module或action不合法")

        plugin_file = '{}/{}/main.py'.format(self.__plugin_path,module)
        if not os.path.exists(plugin_file): return self.send_client(False,0,"","插件不存在")
        pyobj = public.get_script_object(plugin_file)
        plugin_obj = pyobj.main()
        if not hasattr(plugin_obj,action): return self.send_client(False,0,"","指定方法不存在")
        result = getattr(plugin_obj,action)(public.to_dict_obj(data['args']))

        # 如果是响应对象
        if isinstance(result,Response):
            return result
        return self.send_client(True,1,result)

    def recv_body(self, args):
        '''
            @name 接收上报数据（通用）
            @author hwliang
            @param stype<string> 数据类型
            @param body<string> 数据内容
            @return {'status': True, 'status_code': 1, 'error_msg': '', 'data': 'OK'}
        '''
        # print('--ws connection object: {}'.format(args.get('_ws', None)))

        server_info, data = self.__check_access(args)

        if isinstance(server_info, str): return server_info

        if not 'stype' in data: return self.send_client(False,0,"","参数: stype不能为空")

        if not 'body' in data: return self.send_client(False,0,"","参数: body不能为空")

        pdata = {
            'stype': data['stype'],
            'body': json.dumps(data['body']),
            'sid': self.sid,
            'addtime': int(time.time())
        }

        # public.print_log('[接收到数据]------[{}] ---[{}]---- [{}]'.format(self.sid, data['stype'], args['remote_addr']))
        
        if not re.match(r"^\w+$",pdata['stype']): return self.send_client(False,0,"","参数: stype不合法")

        # 将数据转发到对应的处理函数进行处理
        try:
            # 云监控过期后不处理
            # if not basic_monitor_obj.check_monitor_endtime():
            #     raise BtMonitorException('云监控授权已到期，请续费后使用')

            remote_addr = args.get('remote_addr', '')
            if remote_addr[:7] == '::ffff:':
                remote_addr = remote_addr[7:]

            cache_key = 'BT_MONITOR_CLIENT_AUTHORIZATION_STATUS__{}'.format(self.sid)

            is_authorized = public.cache_get(cache_key)

            if is_authorized is None:
                # 未授权的客户端仅接收心跳包数据
                is_authorized = basic_monitor_obj.db_easy('servers')\
                    .where('sid=?', self.sid)\
                    .where_in('status', [0, 1])\
                    .where('is_authorized=1')\
                    .field('sid')\
                    .exists()

                # 缓存客户端的授权状态，减少Sqlite查询次数
                public.cache_set(cache_key, is_authorized, 60)

            if not is_authorized and data['stype'] != 'Heartbeat':
                raise BtMonitorException('客户端未授权: {}'.format(remote_addr))

            public.invoke_func('core.include.ws_recv_functions', 'recv_'+data['stype'], [{
                'remote_addr': remote_addr,
                'sid': self.sid,
                'data': data['body'],
            }])

            # pdata["remote_addr"] = remote_addr
            # if data['stype'] == "Heartbeat":
            #     basic_monitor_obj.update_servers2(self.sid, True, remote_addr)
            # else:
            #     client_data_queue.put(pdata)
            # redis_client.rpush("CLIENT_DATA", json.dumps(pdata))
            # public.print_log("puted data from: {}/type:{}".format(args.get("remote_addr"), data['stype']))
            # client_data_queue.put(pdata)
            # public.invoke_func('core.include.ws_recv_functions', 'recv_'+data['stype'], [{
            #     'remote_addr': args.get('remote_addr', ''),
            #     'sid': self.sid,
            #     'data': data['body'],
            # }])
        except BaseException as e:
            # 每隔10分钟打印一次提示信息
            cache_recv_body_key = 'BT_MONITOR_RECV_BODY_ERROR'
            if isinstance(e, BtMonitorException) and public.cache_get(cache_recv_body_key) is None:
                public.print_log(e)
                public.cache_set(cache_recv_body_key, 1, 600)
            public.print_exc_stack(e)

        '''
        if data['stype'] != 'Heartbeat':
            db_obj = public.M('collect').dbfile('data')
            db_obj.insert(pdata)
            db_obj.close()
        '''

        return self.send_client(True,1,"OK")

    def connected(self, args):
        '''
            @name 连接成功
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info


        return self.send_client(True,1,"OK1")
