import json,time,re,os
import core.include.public as public
from core import app,session
from core.include.monitor_helpers import warning_obj
# import core.include.c_loader.PluginLoader as plugin_loader
from core.include import pyotp

class main:

    __log_type = '系统设置'

    def modify_admin_path(self,args):
        '''
            @name 修改安全入口
            @author hwliang
            @param admin_path <str> 安全入口
            @return dict
        '''
        admin_path = args.get('admin_path','')
        if not admin_path:
            return public.return_data(False,'安全入口不能为空!')
        if not re.match('^[\w\/\-\.]+$',admin_path):
            return public.return_data(False,'安全入口格式不正确!')

        public.set_config_value('config','admin_path',admin_path)
        app.config['ADMIN_PATH'] = admin_path
        public.WriteLog(self.__log_type,'修改安全入口为[{}]'.format(admin_path))
        public.reload()
        return public.return_data(True,'设置成功!')

    def modify_port(self,args):
        '''
            @name 修改端口
            @author hwliang
            @param port <int> 端口
            @return dict
        '''
        port = args.get('port/d',806)
        if port < 1 or port > 65535:
            return public.return_data(False,'端口号不合法!')
        public.set_config_value('config','port',port)
        app.config['PORT'] = port
        public.WriteLog(self.__log_type,'修改端口为[{}]'.format(port))
        public.reload()
        return public.return_data(True,'修改成功!')

    def modify_debug(self,args):
        '''
            @name 修改调试模式
            @author hwliang
            @param debug <bool> 调试模式
            @return dict
        '''
        debug = True if args.get('debug/d',False) else False
        public.set_config_value('config','debug',debug)
        app.config['DEBUG'] = debug
        status_msg = '开启' if debug else '关闭'
        public.WriteLog(self.__log_type,'{}修改调试模式'.format(status_msg))
        public.reload()
        return public.return_data(True,'修改成功!')

    def modify_session_timeout(self,args):
        '''
            @name 修改会话超时时间
            @author hwliang
            @param session_timeout <int> 会话超时时间
            @return dict
        '''
        session_timeout = args.get('session_timeout/d',0)
        if session_timeout < 0:
            return public.return_data(False,'会话超时时间不合法!')

        public.set_config_value('config','session_timeout',session_timeout)
        app.config['SESSION_TIMEOUT'] = session_timeout
        public.WriteLog(self.__log_type,'修改会话超时时间为[{}]秒'.format(session_timeout))
        return public.return_data(True,'修改成功!')

    def modify_password_complexity(self,args):
        '''
            @name 修改密码复杂度
            @author hwliang
            @param password_complexity <int> 密码复杂度
            @return dict
        '''
        password_complexity = True if args.get('password_complexity/d',0) else False
        public.set_config_value('config','password_complexity',password_complexity)
        app.config['PASSWORD_COMPLEXITY'] = password_complexity
        status_msg = '开启' if password_complexity else '关闭'
        public.WriteLog(self.__log_type,'{}密码复杂度验证'.format(status_msg))
        return public.return_data(True,'修改成功!')

    def modify_password_expire(self,args):
        '''
            @name 修改密码过期时间
            @author hwliang
            @param password_expire <int> 密码过期时间
            @return dict
        '''
        password_expire = args.get('password_expire/d',0)
        if password_expire < 0:
            return public.return_data(False,'密码过期时间不合法!')

        public.set_config_value('config','password_expire',password_expire)
        app.config['PASSWORD_EXPIRE'] = password_expire
        public.WriteLog(self.__log_type,'修改密码过期时间为[{}]天'.format(password_expire))
        return public.return_data(True,'修改成功!')

    def modify_accept_domain(self,args):
        '''
            @name 修改授权域名
            @author hwliang
            @param bind_domain <str> 授权域名
            @return dict
        '''
        accept_domain = args.get('bind_domain','')
        if accept_domain:
            if not public.is_domain(accept_domain):
                return public.return_data(False,'域名格式不正确!')
        public.set_config_value('config','accept_domain',accept_domain)
        app.config['ACCEPT_DOMAIN'] = accept_domain
        public.WriteLog(self.__log_type,'修改授权域名为[{}]'.format(accept_domain))
        public.reload()
        return public.return_data(True,'修改成功!')

    def modify_accept_ip(self,args):
        '''
            @name 修改授权IP
            @author hwliang
            @param bind_ip <str> 授权IP，多个用换行分隔
            @return dict
        '''
        bind_ip = args.get('accept_ip','')
        accept_ip = []
        for ip in bind_ip.split(','):
            ip = ip.strip()
            if not public.check_ip(ip):
                continue
            accept_ip.append(ip)

        public.set_config_value('config','accept_ip',accept_ip)
        app.config['ACCEPT_IP'] = accept_ip
        public.WriteLog(self.__log_type,'修改授权IP为{}'.format(accept_ip))
        public.reload()
        return public.return_data(True,'修改成功!')

    def get_config(self, args):
        '''
            @name 获取配置
            @author hwliang
            @return dict
        '''
        config_name = args.get('config_name', None)

        config = public.read_config('config')
        try:
            config['basic_auth'] = public.read_config('basic_auth')
        except:
            config['basic_auth'] = {"open": False, "username": "", "password": ""}

        # 获取服务器当前时间
        config['cur_time'] = int(time.time())

        # 计算密码到期时间
        if 'password_expire' in config:
            with public.sqlite_easy('safety') as db:
                pwd_update_time = db.query()\
                    .name('users')\
                    .where('uid', public.bt_auth('uid'))\
                    .value('pwd_update_time')

            config['password_expire_time'] = int(pwd_update_time) + (int(config['password_expire']) * 86400)

        # 异地登录提醒设置(默认)
        if 'warn_place_other' not in config:
            config['warn_place_other'] = 0

        if 'warn_place_other_push_methods' not in config:
            config['warn_place_other_push_methods'] = ''

        # 消息推送通道
        if 'push_methods' not in config:
            config['push_methods'] = warning_obj.get_push_methods()

        # 二次认证
        if 'two_step_auth' not in config:
            two_step_auth_file = '{}/config/two_step_auth.json'.format(public.get_panel_path())
            if not os.path.exists(two_step_auth_file):
                with open(two_step_auth_file, 'w') as fp:
                    fp.write(json.dumps({
                        'open': False,
                    }, ensure_ascii=False))
            config['two_step_auth'] = public.read_config('two_step_auth')

        if config_name is not None and config_name in config:
            return public.success(config[config_name])

        # 病毒扫描—自动扫描
        if 'automatic_scan' not in config:
            config['automatic_scan'] = False

        if 'scan_now_exe' not in config:
            config['scan_now_exe'] = False
        
        return public.success(config)

    #获取BasicAuth状态
    def get_basic_auth_stat(self,get):
        '''
            @name 获取HTTP认证配置
            @author hwliang
            @return dict
        '''
        path = '{}/config/basic_auth.json'.format(public.get_panel_path())
        is_install = True
        result = {"basic_user":"","basic_pwd":"","open":False,"is_install":is_install}
        if not os.path.exists(path): return result
        try:
            ba_conf = json.loads(public.readFile(path))
        except:
            os.remove(path)
            return result
        ba_conf['is_install'] = is_install
        return public.return_data(True,ba_conf)

    #设置BasicAuth
    def modify_basic_auth(self,get):
        '''
            @name 修改HTTP认证配置
            @author hwliang
            @param basic_user <str> 用户名
            @param basic_pwd <str> 密码
            @param open <bool> 是否开启
            @return dict
        '''
        is_open = False
        if get.open == 'True' or int(get.open) == 1: is_open = True
        tips = '_bt.cn'
        path = '{}/config/basic_auth.json'.format(public.get_panel_path())
        ba_conf = None
        if is_open:
            if not get.basic_user.strip() or not get.basic_pwd.strip(): return public.returnMsg(False,'BasicAuth认证用户名和密码不能为空!')
        if os.path.exists(path):
            try:
                ba_conf = json.loads(public.readFile(path))
            except:
                os.remove(path)

        if not ba_conf:
            ba_conf = {"basic_user":public.md5(get.basic_user.strip() + tips),"basic_pwd":public.md5(get.basic_pwd.strip() + tips),"open":is_open}
        else:
            if get.basic_user: ba_conf['basic_user'] = public.md5(get.basic_user.strip() + tips)
            if get.basic_pwd: ba_conf['basic_pwd'] = public.md5(get.basic_pwd.strip() + tips)
            ba_conf['open'] = is_open

        public.writeFile(path,json.dumps(ba_conf))
        os.chmod(path,384)
        public.WriteLog('面板设置','设置BasicAuth状态为: %s' % is_open)
        public.reload()
        return public.return_data(True,"设置成功!")

    # 检查动态口令是否通过验证
    def get_two_step_auth_status(self, args):
        '''
            @name 获取动态口令认证状态
            @return boole False 未认证  True 已认证
        '''
        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())

        if not os.path.exists(path): # 动态口令文件不存在 没有设置
            return public.success(True)

        two_auth_conf = json.loads(public.readFile(path))
        if two_auth_conf.get("open", False) == False:
            is_auth = True
        else:
            _uid = public.bt_auth('uid')
            # if int(_uid) == 1:
            #     return public.success(True)

            cache_key = "TWO_STEP_AUTH_" + str(_uid)
            cached_data = public.cache_get(cache_key)
            is_auth = cached_data == True

        return public.success(is_auth)

    # 验证动态口令
    def check_two_step_auth(self, args):
        '''
            @name 认证动态口令认证
            @param vcode <str> 动态口令
            @return boole False 未认证  True 已认证
        '''
        vcode = args.get("vcode", None)

        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())
        if not os.path.exists(path):  # 动态口令文件不存在 没有设置
            return public.return_data(True, True)

        if vcode is None:
            return public.return_data(False, '缺少参数：vcode')

        two_auth_conf = json.loads(public.readFile(path))
        otp = pyotp.TOTP(two_auth_conf["secret_key"])
        is_auth = otp.verify(vcode)
        if not is_auth:
            if public.sync_date(): is_auth = otp.verify(vcode)

        # 缓存键名
        if is_auth == True:
            _uid = session.get('uid', 0)
            cache_key = "TWO_STEP_AUTH_" + str(_uid)
            public.cache_set(cache_key, True, 7200)
            msg = "认证成功！"
        else:
            msg = "认证失败！"
        return public.return_data(is_auth, msg)

    def modify_two_step_auth(self, args):
        '''
            @name 设置动态口令认证
            @param two_auth_status <bool> 是否开启
            @return dict
        '''
        two_auth_status = args.get("two_auth_status",None)
        if two_auth_status is None:
            return public.error('缺少参数：two_auth_status')

        if int(two_auth_status) not in [0,1]:
            return public.error('参数 two_auth_status 格式不正确')

        path = '{}/config/two_step_auth.json'.format(public.get_panel_path())

        if os.path.exists(path):
            two_auth_conf = json.loads(public.readFile(path))
            if "username" not in two_auth_conf or "secret_key" not in two_auth_conf or "qrcode_url" not in two_auth_conf:
                username, secret_key, qrcode_url = self._create_key()
                two_auth_conf["username"] = username
                two_auth_conf["secret_key"] = secret_key
                two_auth_conf["qrcode_url"] = qrcode_url
        else:
            username, secret_key, qrcode_url = self._create_key()
            two_auth_conf = {
                "open": False,
                "username": username,
                "secret_key": secret_key,
                "qrcode_url": qrcode_url
            }


        two_auth_conf["open"] = int(two_auth_status) == 1
        public.writeFile(path, json.dumps(two_auth_conf))
        os.chmod(path, 384)
        public.WriteLog('面板设置', '设置动态口令状态: %s' % two_auth_conf["open"])
        return public.return_data(True, "设置成功!")

    def _create_key(self):
        username = self.get_random()
        secret_key = pyotp.random_base32()

        # 二维码链接
        local_ip = public.GetLocalIp()
        qrcode_url = pyotp.totp.TOTP(secret_key).provisioning_uri(username, issuer_name='宝塔云监控--{}'.format(local_ip))

        return username,secret_key,qrcode_url

    def get_random(self):
        import random
        seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        sa = []
        for _ in range(8):
            sa.append(random.choice(seed))
        salt = ''.join(sa)
        return salt

    def get_version_history(self, args):
        '''
            @name 获取版本历史更新记录
            @author Zhj<2022-07-20>
            @param  args<dict>  参数列表
            @return dict
        '''
        # 默认版本更新记录
        version_history = []

        try:
            ret = json.loads(public.httpPost('http://www.example.com/bt_monitor/update_history', {}))

            for version_info in ret:
                version_history.append({
                    'version': version_info.get('version', '1.0.0'),
                    'desc': version_info.get('description', ''),
                    'date': version_info.get('create_time')[:10].replace('-', '/'),
                })

        except: pass

        return public.success(version_history)

    def get_version_info_from_server(self, args=None):
        '''
            @name 获取云监控最新版本信息
            @param  args<?dict> 请求参数列表
            @return dict
        '''
        version_info = None

        # 尝试从云端获取最新版本信息
        try:
            ret = json.loads(public.httpPost('http://www.example.com/bt_monitor/latest_version', {}))
            version_info = {
                'version': ret.get('version', '1.0.0'),
                'desc': ret.get('description', ''),
                'date': int(ret.get('create_time')[:10].replace('-', '')),
            }
        except: pass

        # 请求参数列表为空说明是直接调用
        # 直接返回
        if args is None:
            return version_info

        return public.success(version_info)

    def update(self, args):
        """ 从云端获取版本信息 
        
        1. 默认调用获取版本信息:
        {
            "version": "1.1.1",  #  服务端版本信息
            "desc": "test",  # 更新描述
            "date": 20220719,  #  更新发布日期
            "cur": "1.0.1"  #  本地版本
        }

        2. 主动检测最新版本信息
        携带参数: check

        3. 执行更新动作
        携带参数: toUpdate
        """

        base_path = public.get_panel_path()
        update_dir = '{}/update'.format(base_path)
        if not os.path.exists(update_dir):
            os.mkdir(update_dir)
        update_cache_file = '{}/last.pl'.format(update_dir)
        cache_data = public.readFile(update_cache_file)
        now = int(time.time())
        cache_change_time = now

        if cache_data:
            cache_change_time = os.stat(update_cache_file).st_mtime

        version_info = {}
        # 没有缓存/主动检查/缓存一天未更新
        if not cache_data or hasattr(args, "check") or (now-cache_change_time) > 86400:
            version_info = self.get_version_info_from_server()

            if version_info is None:
                return public.error('获取版本信息失败，请检查服务器网络后重试~')

            date = version_info["date"]
            date = time.strptime(str(date), "%Y%m%d")
            _d = time.mktime((date.tm_year, date.tm_mon, date.tm_mday, 0,0,0,0,0,0))
            version_info["date"] = _d
            public.writeFile(update_cache_file, json.dumps(version_info))
        else:
            version_info = json.loads(cache_data)

        local_version = public.readFile('{}/version.pl'.format(base_path))

        # 版本更新
        if hasattr(args, "toUpdate"):
            if warning_obj.in_demo():
                # DEMO
                return public.error('DEMO不支持此操作')

            try:
                download_url = "http://www.example.com/install/src/bt-monitor-{}.zip".format(version_info["version"])
                new_version_file = '{}/update-{}.zip'.format(update_dir, version_info["version"])
                # new_version_file = '{}/bt-monitor-{}.zip'.format(base_path, version_info["version"])
                public.downloadFile(download_url, new_version_file)
                if not os.path.exists(new_version_file) or os.path.getsize(new_version_file) < 100:
                    return public.return_data(False, "文件下载失败!")
                old_version_file = '{}/update-{}.zip'.format(update_dir, local_version)
                if os.path.exists(old_version_file):
                    os.remove(old_version_file)
                public.ExecShell('unzip -o {} -d {} > /dev/null'.format(new_version_file, base_path))
                public.ExecShell('chmod +x {}/tools.py'.format(base_path))
                public.ExecShell('chmod +x {}/init.sh'.format(base_path))
                public.ExecShell('chmod +x {}/BT-MONITOR'.format(base_path))
                public.ExecShell('chmod +x {}/crontab_tasks/*.py'.format(base_path))
                public.ExecShell('rm -rf /etc/init.d/btm')
                public.ExecShell(r'\cp -r /www/server/bt-monitor/init.sh /etc/init.d/btm')
                public.ExecShell('chmod +x /etc/init.d/btm')
                public.ExecShell('ln -sf /etc/init.d/btm /usr/bin/btm')

                # 重启云监控服务
                def reload_handler():
                    time.sleep(1)


                    # 重启云监控服务
                    # public.ExecShell('{}/init.sh reload > /dev/null'.format(base_path))

                    # 停止SQLITE-SERVER服务
                    os.system('chmod +x {}/sqlite-server.sh'.format(base_path))
                    os.system('{}/sqlite-server.sh stop > /dev/null'.format(base_path))
                    os.system('chmod +x {}/init.sh'.format(base_path))
                    os.system('{}/init.sh reload > /dev/null'.format(base_path))

                import threading
                threading.Thread(target=reload_handler).start()

                return public.success("恭喜！更新成功！")
            except Exception as e:
                print("更新异常: {}".format(str(e)))
                return public.error(str(e))

        if not local_version:
            version_info["cur"] = "Unknown"
            return public.success(version_info)
        version_info["cur"] = local_version.strip()
        return public.success(version_info)

    def modify_login_place_other(self, args):
        '''
            @name 设置异地登录提醒
            @author Zhj<2022-10-12>
            @arg    warn_place_other<integer>               启用状态
            @arg    warn_place_other_push_methods<string>   推送方式
            @return dict
        '''
        warn_status = args.get('warn_place_other', None)
        push_methods = args.get('warn_place_other_push_methods', None)

        if warn_status is None:
            return public.error('缺少参数：warn_place_other')

        if int(warn_status) not in [0,1]:
            return public.error('参数 warn_place_other 格式不正确')

        if int(warn_status) == 1:
            if push_methods is None:
                return public.error('缺少参数：warn_place_other_push_methods')

            if not re.match(r'^\w+(?:,\w+)*$', str(push_methods)):
                return public.error('参数 warn_place_other_push_methods 格式不正确')

        # 设置异地登录告警提醒
        public.set_config_value('config', 'warn_place_other', int(warn_status))

        # 设置异地登录告警推送方式
        public.set_config_value('config', 'warn_place_other_push_methods', push_methods if push_methods is not None else '')

        return public.success('操作成功')

    def get_ssl_cert(self, args):
        '''
            @name 获取SSL证书信息
            @author Zhj<2022-11-11>
            @return dict
        '''
        # DEMO
        if warning_obj.in_demo():
            # DEMO
            return public.error('DEMO不支持此操作')

        return public.success({
            'cert_pem': public.readFile('{}/ssl/certificate.pem'.format(public.get_panel_path())) or '',
            'key_pem': public.readFile('{}/ssl/privateKey.pem'.format(public.get_panel_path())) or '',
        })

    def set_ssl_cert(self, args):
        '''
            @name 设置ssl证书
            @author Zhj<2022-11-10>
            @arg    cert<string> 证书
            @arg    key<string> 证书私钥
            @return dict
        '''
        # DEMO
        if warning_obj.in_demo():
            # DEMO
            return public.error('DEMO不支持此操作')

        cert_content = args.get('cert', None)
        key_content = args.get('key', None)

        if cert_content is None:
            return public.error('缺少参数：cert_content')

        if cert_content == '':
            return public.error('请输入证书内容')

        if key_content is None:
            return public.error('缺少参数：key_content')

        if key_content == '':
            return public.error('请输入证书私钥')

        public.writeFile('{}/ssl/certificate.pem'.format(public.get_panel_path()), cert_content)
        public.writeFile('{}/ssl/privateKey.pem'.format(public.get_panel_path()), key_content)

        public.reload()

        return public.success('证书设置成功')

    def modify_sampling_global(self, args):
        '''
            @name 设置全局数据采样
            @author Zhj<2023-01-06>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sampling_opened = args.get('open', None)

        if sampling_opened is None:
            return public.error('缺少参数：open')

        public.set_config_value('config', 'sampling_global', True if int(sampling_opened) == 1 else False)

        return public.success('设置成功')

    #   病毒扫描-自动扫描设置 （自动扫描固定的几个目录 /www、/root、/tmp、/home）
    def modify_automatic_scan(self, args={}):
        '''
            @name 病毒自动扫描
            @author law
            @param
            @return dict
        '''
        automatic_scan = True if args.get('automatic_scan/d',0) else False
        public.set_config_value('config','automatic_scan',automatic_scan)
        app.config['AUTOMATIC_SCAN'] = automatic_scan
        status_msg = '开启' if automatic_scan else '关闭'
        public.WriteLog(self.__log_type,'{}病毒自动扫描'.format(status_msg))
        return public.return_data(True,'修改成功!')