# encoding: utf-8
import json, os, sys, re, time, random
import socket

from core import g
import requests
from concurrent.futures import ThreadPoolExecutor
from functools import reduce

# 禁用requests安全请求警告
# from requests.packages import urllib3
# urllib3.disable_warnings()

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
# from core.include.rbac import AccessIntersection
from core.include.monitor_helpers import basic_monitor_obj, warning_obj

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
MsgModule = public.import_via_loader('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main


class main():
    '''
        @name 业务监控
        @author Law Lt <2023-02-24>
    '''
    __PING_PACKET_REG_OBJ = re.compile(r"(\d+(?:\.\d+)?)% packet loss")  # 匹配Ping丢包率的正则表达式
    __PING_PACKET_DELAY_AVG_REG_OBJ = re.compile(r"\d+(?:\.\d+)?/(\d+(?:\.\d+)?)")  # 匹配Ping平均延迟的正则表达式
    __WARNING_THRESHOLD_RULES = (
        (12, 840),
        (11, 600),
        (10, 540),
        (9, 480),
        (8, 420),
        (7, 360),
        (6, 300),
        (5, 240),
        (4, 120),
        (3, 60),
        (2, 30),
        (1, 10),
    )  # 告警推送限流规则

    def data_check(self, result, format):
        '''
            @name 域名/ip/端口格式验证
            @param result<string> 要校验的数据 域名 端口 ip
            @param format<string> 要校验的数据类型 'u/i'  'url'  'ip'  'port'
            @return True/False , 错误信息
        '''
        # if not re.match(r"^(https?)://[\w\-\.]+$", domain):
        # if not re.match(r"^(https?)://[^\s/$.?#].[^\s]*$", domain):
        # if not re.match(r"^(http(s)?:\/\/)\w+[^\s]+(\.[^\s]+){1,}$", domain):
        if format == 'u/i':  # 可能域名,可能ip
            u = 1
            i = 1
            # 校验域名
            regex = re.compile(
                r'^((?:http|ftp)s?://)?'
                r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                r'localhost|'
                r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                r'(?::\d+)?'
                r'(?:/?|[/?]\S+)$', re.IGNORECASE)
            if not re.match(regex, result):
                u = 0
            if not public.is_ipv4(result) and not public.is_ipv6(result):
                i = 0
            if u == 0 and i == 0:
                return False, '域名/ip格式错误'

        elif format == 'url':
            regex = re.compile(
                r'^(?:http|ftp)s?://'
                r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0 -9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                r'localhost|'
                r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                r'(?::\d+)?'
                r'(?:/?|[/?]\S+)$', re.IGNORECASE)
            if not re.match(regex, result):
                return False, 'url格式错误'
        elif format == 'ip':
            if not public.is_ipv4(result) and not public.is_ipv6(result):
                return False, '要求正确的ipv4/ipv6地址'
        elif format == 'port':
            if not re.match("^\d+$", result):
                return False, '端口应为纯数字'
            intport = int(result)
            if intport < 1 or intport > 65535:
                return False, '超出范围,端口号为0-65535'

        return True, '符合校验'

    def get_task_wanrning_log(self, args):
        """
            @name   获取任务告警信息
            @author lt <2023-03-29>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @arg    id<integer> 任务id
            @arg    type<string> 任务类型 'http' 'port' 'ping'
            @return dict
        """
        keyword = args.get('keyword', None)
        id_ = args.get('id')
        type_ = args.get('type')
        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)
        # 数据库查询
        query = basic_monitor_obj.db_easy('availability_wanrning_log') \
            .where('task_id=?', id_) \
            .where('type=?', type_) \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        if keyword is not None:
            query.where('create_time like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        # 分页查询
        ret = public.simple_page(query, args)

        return public.success(ret)

    def get_server_list(self, args):
        '''
            @name   获取服务器列表 只有 sid,ip,remark  去掉windows服务器
            @return list
        '''
        server_list = self.__get_servers()
        # server_list = warning_obj.db_easy('servers').field('sid', 'ip', 'remark', 'status').select()
        # 获取当前服务器内外网IP
        internal_ips, published_ip = basic_monitor_obj.get_server_ip()
        s_list = [i for i in server_list if not i["ip"] == '127.0.0.1']
        # 修复备注为空的情况
        s_list = [{**i, **{'remark': i['ip']}} if i['remark'] == '' else i for i in s_list]

        s_list.append({
            "ip": internal_ips[0],
            "remark": '主控',
            "sid": 0,
            "status": 1
        })
        return public.success(s_list)

    def get_port_task(self, args):
        '''
            @name 获取port监控任务列表
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        keyword = args.get('keyword', None)
        uid = public.bt_auth('uid')
        query = basic_monitor_obj.db_easy('availability_port') \
            .order('create_time', 'desc')

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid=?', uid)

        if keyword is not None:
            query.where('port like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        ret = query.select()
        servers = self.__get_servers_by_tasks(ret)
        nodes = self.__get_nodes_by_tasks(ret, servers)
        results = self.__get_latest_results('availability_port_info', 'port_id', extra_fields=('is_connect', 'delay'))
        on_line, off_line = self.__summary_latest_results('availability_port_info', 'port_id', 'is_connect', len(ret))
        for i in ret:
            # 补充节点信息
            i['nodes_info'] = nodes.get(i['id'], [])
            i['nodes_num'] = len(i['nodes_info'])

            port_result = results.get(i['id'], [])

            # 最近一次
            port_info = port_result[0] if len(port_result) > 0 else None
            i['available_rate'] = self.__calculate_avg(port_result, 'is_connect') * 100
            if port_info is not None:
                i['is_ok'] = port_info['is_connect']
                i['port_result'] = port_result
            else:
                i['is_ok'] = 2
                i['port_result'] = []

        # 列表排序
        for sort_key, sort_reverse in public.get_sort_params(args).items():
            ret.sort(key=lambda x: x.get(sort_key, 0), reverse=sort_reverse)

        # # 分页查询
        # ret = public.simple_page(query, args)
        # servers = self.__get_servers_by_tasks(ret['list'])
        # nodes = self.__get_nodes_by_tasks(ret['list'], servers)
        # results = self.__get_half_hour_last_results('availability_port_info', 'port_id', extra_fields=('is_connect', 'delay'))
        # ret['on_line'], ret['off_line'] = self.__summary_half_hour_last_results(results, 'is_connect', ret['total'])
        #
        # for i in ret['list']:
        #     # 补充节点信息
        #     i['nodes_info'] = nodes.get(i['id'], [])
        #     i['nodes_num'] = len(i['nodes_info'])
        #
        #     port_result = results.get(i['id'], [])
        #
        #     # 最近一次
        #     port_info = port_result[0] if len(port_result) > 0 else None
        #
        #     if port_info is not None:
        #         i['is_ok'] = port_info['is_connect']
        #         i['port_result'] = port_result
        #     else:
        #         i['is_ok'] = 2
        #         i['port_result'] = []

        # return public.success(ret)

        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(ret),
            'list': ret[(p - 1) * p_size:p * p_size],
            'on_line': on_line,
            'off_line': off_line
        })

    def get_port_result(self, args):
        """
            @name 获取port监控任务结果
            @author Law Lt <2023-03-01>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        """
        # keyword = args.get('keyword', None)
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        query = basic_monitor_obj.db_easy('availability_port') \
            .where('id=?', id_)

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid', uid)

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        servers = self.__get_servers_by_tasks([task])
        nodes = self.__get_nodes_by_tasks([task], servers)
        task['nodes_info'] = nodes[task['id']]
        task['nodes_num'] = len(task['nodes_info'])
        results = self.__get_latest_results('availability_port_info', 'port_id',
                                                    extra_fields=('is_connect', 'delay'), task_ids=(task['id'],)).get(task['id'], [])
        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        port_info = basic_monitor_obj.db_easy('availability_port_info') \
            .where('port_id', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # 检查区间内是否有执行结果
        if not port_info.fork().exists():
            return public.success({
                'total': 0,
                'list': [],
                'task': task,
                'available_rate': 0,
                'avg_delay': 0,
                'last_offline_duration': None,
                'last_offline_time': None,
            })

        # 获取端口连接成功率 除法需要转浮点数才能计算
        # rate = port_info.fork().value(
        #     'ROUND(1.0 * SUM(CASE `is_connect` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')

        # # 上次离线时长
        # cur_time = int(time.time())
        # if port_info.fork().where('is_connect=1').exists():
        #     # 最新的失败状态
        #     last_off = port_info.fork().where('is_connect=0').find()
        #
        #     # 存在失败状态 计算时间
        #     if last_off:
        #         last_offline_time = last_off['create_time']
        #         # 失败是最新一条    当前时间-最新的成功时间
        #         if last_off['id'] == port_info.fork().value('id'):
        #             last_offline_duration = cur_time - port_info.fork().where('is_connect=1').value('create_time')
        #         # 不是最新的
        #         else:
        #             end_time = port_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
        #             last_on_line = port_info.fork().where('id<? ', last_off['id']).where('is_connect=1').find()
        #             # 失败前没有在线状态
        #             if last_on_line is None:
        #                 start_time = port_info.fork().value('min(create_time)')
        #             else:
        #                 start_time = port_info.fork().where('id > ?', last_on_line['id']).where('is_connect', 0).value(
        #                     'min(create_time)')
        #
        #             last_offline_duration = end_time - start_time
        #
        #     else:
        #         last_offline_time = None
        #         last_offline_duration = 0
        # else:
        #     last_offline_duration = None
        #     last_offline_time = port_info.fork().where('is_connect=0').value('max(create_time)')

        # 分页查询
        ret = public.simple_page(port_info, args)

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                # server = warning_obj.db_easy('servers').field('ip', 'remark', 'status').where('sid=?', i['node']).find()
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        ret['available_rate'] = self.__calculate_avg(results, 'is_connect') * 100
        ret['task'] = task

        # 上次离线时间
        ret['last_offline_time'] = 0

        # 上次离线时长
        ret['last_offline_duration'] = self.__calculate_last_offline_time(results, 'is_connect')

        # 平均延迟
        # ret['avg_delay'] = "%.2f" % (port_info.fork().avg('delay'))
        ret['avg_delay'] = self.__calculate_avg(results, 'delay')

        return public.success(ret)

     # 端口连通测试 -> bool, int
    def __test_port_connection_retry(self, host, port, max_retry=5):
        for _ in range(max_retry):
            is_connect, delay = self.test_port_connection(host, port)

            # 连接成功 构造数据 跳出循环
            if is_connect:
                return True, delay

        return False, 0

    # 图表数据 结果
    def get_port_result_simple(self, args):
        """
            @name 获取port监控任务结果 简单数据 展示图表用
            @author  <2023-05-29>
            @arg    query_data<string> 时间
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        query = basic_monitor_obj.db_easy('availability_port') \
            .where('id=?', id_)

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid', uid)

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        servers = self.__get_servers_by_tasks([task])
        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        # 查询时间
        query_date = args.get('query_date', 'l1')
        # 判断是否是最近一小时
        if query_date == '1hour':
            query_date = self.__get_query_onehour()

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        port_info = basic_monitor_obj.db_easy('availability_port_info') \
            .where('port_id', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            # .order('create_time', 'desc')

        # 检查区间内是否有执行结果
        if not port_info.fork().exists():
            return public.success({
                'total': 0,
                'list': [],
            })
        port_info = port_info.select()
        ret = {
            'total': len(port_info),
            'list': port_info,
        }

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        return public.success(ret)

    # 执行port 改累计
    def __port_task_help(self, temp):
        """
            @name 执行port
            @author  <2023-03-22>
            @arg    temp 判断告警的条件
            @return dict
        """
        cur_time = int(time.time())
        # 跳过没到时间的
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id']):
            return None

        lst = []
        nodes = temp['nodes'].split(',')

        # 没有设置主控节点，跳过
        if '0' not in nodes:
            self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id'], cur_time)
            return None

        # 测试端口连通性
        flag, delay = self.__test_port_connection_retry(temp['ip'], int(temp['port']))

        lst.append({
            'uid': temp['uid'],
            'port_id': temp['id'],
            'node': 0,
            'is_connect': int(flag),
            'delay': delay,
            'create_time': cur_time,
        })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id'], cur_time)

        # 开启了告警  成功告警  失败告警
        if temp['warning']:
            # # 扫描添加
            # if temp['add_type'] == 0:
            #     public.print_log('》》》》》》》》》》》》SERVER WARNING《《《《《《《《《《《', _level='error')
            #     warning_rules = warning_obj.get_warning_rules(temp['sid'], 'port', 'port_[]', 'connection')
            #     for warning_rule in warning_rules:
            #         bool_ = warning_obj.warn(warning_rule, 'success' if flag else 'fail')
            #         if bool_:
            #             # 更新上一次告警时间
            #             basic_monitor_obj.db_easy('availability_port') \
            #                 .where('id', temp['id']) \
            #                 .update({'last_warning_time': cur_time})
            #
            # # 自定义添加
            # if temp['add_type'] == 1:
            warning_type = 'port监控告警'

            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, task_type='port')

            # public.print_log('@@@@@@@@@@@@@@@@@@@@@@@@@@ 端口累计次数 {}'.format(retries), _level='error')
            # # 失败时告警  设置了失败且失败
            # if temp['warning_mode'] == 0 and int(flag) == 0:
            #     notify_content = '匹配失败'
            #     temp['retries'] += 1
            #
            # # 成功时告警 设置了成功且成功
            # if temp['warning_mode'] == 1 and int(flag) == 1:
            #     notify_content = '匹配成功'
            #     temp['retries'] += 1
            # # 满足告警条件 进行告警
            # if temp['retries'] >= temp['count']:
            if can_do_warning:
                # public.print_log(
                #     f'$$$$$$$$$$$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$$$$$$$$$$', _level='error')
                times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 告警端口: {temp["ip"]}:{temp["port"]}',
                    f'> 告警消息：{notify_content}',
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]
                option = {'mail_title': f'业务监控-端口告警: {temp["ip"]}:{temp["port"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','),options=option)

                res['warning_logs'] = {
                    'task_id': temp['id'],
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'告警端口: {temp["ip"]}:{temp["port"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('port', temp['id'], retries=retries, can_do_warning=can_do_warning, cur_time=cur_time)

        return res

    def execute_port_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取检测监控列表          暂停   .where('suspend=?', 0) \
        ports = basic_monitor_obj.db_easy('availability_port') \
            .where('suspend=?', 0) \
            .field('nodes', 'id') \
            .order('update_time', 'desc') \
            .select()

        # 包含主控的任务
        port_id_list = []
        # 找到节点含0的
        for i in ports:
            node_list = i['nodes'].split(',')
            if '0' in node_list:
                port_id_list .append(i['id'])

        # 获取有主控的http监控任务
        port_list = basic_monitor_obj.db_easy('availability_port') \
            .where_in("id", port_id_list) \
            .order('create_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in port_list:
                f = t.submit(self.__port_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录端口监控结果
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_port_info') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port_info') \
                        .insert_all(insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("availability_wanrning_log") \
                        .insert_all(warning_logs)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        return True

    # 执行被控服务器任务 改累计
    def __port_task_controlled_help(self, temp):
        """
            @name 执行port
            @author  <2023-03-22>
            @arg    temp 判断告警的条件
            @return dict
        """
        cur_time = int(time.time())
        # 跳过没到时间的
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id'], execute_type='controlled'):
            return None

        flag = False
        lst = []
        nodes = temp['nodes'].split(',')
        node_list = [int(num) for num in nodes]

        # 仅主控节点时，跳过
        if len(node_list) == 1 and node_list[0] == 0:
            # 缓存执行完的时间
            self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id'], cur_time, execute_type='controlled')
            return None

        servers = warning_obj.db_easy('servers').field('sid').where('status=1').select()
        server_list = [int(i['sid']) for i in servers]
        for q in node_list:
            # 判断当前sid是否存在 不存在跳过
            if q not in server_list:
                continue
            # public.print_log(f'^^^^^^%%%%%%%%%%%%%%%%port 被控执行{q}')
            # ip = temp['ip']
            # port = temp['port']
            # public.print_log(f'))))))))))))))))))))))))))))))-ip::{ip} -port:::{port}')

            resp = None
            delay = 0
            flag = False
            m = 0
            while m < temp['count']:
                m += 1
                key_ = public.GetRandomString(6)
                resp = public.send_agent_msg(
                    public.get_serverid_bysid(q),
                    'vocationalwork',
                    'GetPortInfoByServer',
                    callback='recv/vocationalwork/GetPortInfoByServer/{}/{}/{}'.format(q, temp['id'], key_),
                    pdata=public.g_pdata({
                        'ip': temp['ip'],
                        'port': str(temp['port']),
                        'key': key_,
                    }))
                if not resp:
                    flag = False
                    continue
                else:
                    public.print_log('|------{} {}:{} {}'.format(key_, temp['ip'], temp['port'], resp))
                    if not isinstance(resp.get('body', {}).get('body'), dict):
                        flag = False
                        continue
                    # 判断当前是否是对应任务的值
                    if key_ != resp.get('body', {}).get('body', {}).get('keystr', 0):
                        flag = False
                        continue
                    is_connect = resp.get('body', {}).get('body', {}).get('is_connect', False)

                    if is_connect:
                        flag = True
                        break
                    else:
                        flag = False
                        continue

            resp = resp if resp and isinstance(resp.get('body', {}).get('body'), dict) else {
                'body': {'body': {'delay': 0, 'is_connect': False, 'keystr': 0}}, }

            # public.print_log(
            #     '****************************{}:{}被控resp结果:::{}'.format(temp['ip'], temp['port'], resp))

            delay = resp.get('body', {}).get('body', {}).get('delay', 0)

            lst.append({
                'uid': temp['uid'],
                'port_id': temp['id'],
                'node': q,
                'is_connect': int(flag),
                'delay': "%.2f" % (float(delay)),
                'create_time': cur_time,
            })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_port_info', 'port_id', temp['id'], cur_time,
                                         execute_type='controlled')

        # 开启了告警  成功告警  失败告警
        if temp['warning']:

            # # 扫描添加
            # if temp['add_type'] == 0:
            #     warning_rules = warning_obj.get_warning_rules(temp['sid'], 'port', 'port_[]', 'connection')
            #
            #     for warning_rule in warning_rules:
            #         bool_ = warning_obj.warn(warning_rule, 'success' if flag else 'fail')
            #         if bool_:
            #             # 更新上一次告警时间
            #             basic_monitor_obj.db_easy('availability_port') \
            #                 .where('id', temp['id']) \
            #                 .update({'last_warning_time': cur_time})
            #
            # # 自定义添加
            # if temp['add_type'] == 1:
            warning_type = 'port监控告警'

            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, task_type='port')
            # public.print_log('@@@@@@@@@@@@@@@@@@@@@@@@@@ 端口累计次数 {}'.format(retries), _level='error')
            # # 失败时告警  设置了失败且失败
            # if temp['warning_mode'] == 0 and int(flag) == 0:
            #     notify_content = '匹配失败'
            #     temp['retries'] += 1
            #
            # # 成功时告警 设置了成功且成功
            # if temp['warning_mode'] == 1 and int(flag) == 1:
            #     notify_content = '匹配成功'
            #     temp['retries'] += 1
            # # 满足告警条件 进行告警
            # if temp['retries'] >= temp['count']:
            if can_do_warning:
                # public.print_log(f'$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$', _level='error')
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 告警端口: {temp["ip"]}:{temp["port"]}',
                    f'> 告警消息：{notify_content}',
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]
                option = {'mail_title': f'业务监控-端口告警: {temp["ip"]}:{temp["port"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','),options=option)

                res['warning_logs'] = {
                    'task_id': temp['id'],
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'告警端口: {temp["ip"]}:{temp["port"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('port', temp['id'], retries=retries, can_do_warning=can_do_warning, cur_time=cur_time)

        return res

    # 执行被控服务器任务
    def execute_port_task_controlled(self, args=None):

        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取检测监控列表          暂停   .where('suspend=?', 0) \
        port_list = basic_monitor_obj.db_easy('availability_port') \
            .where('suspend=?', 0) \
            .order('update_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in port_list:
                f = t.submit(self.__port_task_controlled_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录端口监控结果
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_port_info') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port_info') \
                        .insert_all(insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("availability_wanrning_log") \
                        .insert_all(warning_logs)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        return True

    def add_port_task(self, args):
        '''
        @name 添加port监控任务
        @author Law Lt <2023-02-24>
        @return dict
        '''

        # 扫描和添加两种方式 扫描
        uid = public.bt_auth('uid')
        add_type = int(args.get('add_type', 1))  # 0扫描 1自定义
        sid = args.get('sid', None)
        nodes = args.get('nodes', '0')  # 不选节点 默认当前节点测试 0
        task_name = args.get('task_name', '')
        frequency = args.get('frequency', 20)
        count = args.get('count', 2)
        # protocol = args.get('protocol', 0)  # 0tcp 1udp
        warning = args.get('warning', 0)  # 0 不开启
        warning_mode = args.get("warning_mode", 0)
        push_methods = args.get("push_methods", '')
        # 添加的ip和端口
        ip_port_list = args.get('ip_port_list', '')
        # public.print_log(f'p99999{ip_port_list}')
        if not uid:
            return public.error('请先登录')

        if add_type not in [0, 1]:
            return public.error('add_type参数不正确')

        if warning == '1' and len(push_methods) < 1:
            return public.error('请选择告警推送方式')

        cur_time = int(time.time())

        # 组织添加数据
        port_data = []
        server_port_data = []
        # 添加不成功的任务
        fail_task = []
        # 扫描添加
        if add_type == 0:
            if not ip_port_list:
                return public.error('缺少参数：ip_port_list')
            ip_port_list = ip_port_list.split(';')  # port_list:  'ip,port;ip,port; ...'

            # 选中的主机端口数据
            for i in ip_port_list:
                # i : 'ip,port'
                ip_port = i.split(',')  # [ip, port]

                # "hash(主机ID|监听IP|端口号|通信协议)":
                key = "{}|{}|{}|{}".format(str(sid), str(ip_port[0]), str(ip_port[1]), str(0))
                port_hash = public.mmh3_hash64(key)
                # task_name = task_name if n == 1 else task_name + str(n)

                task_n = str(ip_port[0]) + ':' + str(ip_port[1])
                # 重复的跳过
                if basic_monitor_obj.db_easy('availability_port').where("uid=? AND task_name=?",
                                                                        [uid, task_n]).exists():
                    fail_task.append(task_n)
                    continue

                port_data.append({
                    'uid': uid,
                    'sid': sid,
                    'ip': str(ip_port[0]),
                    'port': int(ip_port[1]),
                    'task_name': task_n,
                    'frequency': frequency,
                    'count': count,
                    'protocol': 0,
                    'warning': int(warning),
                    'nodes': nodes,
                    'port_hash': port_hash,
                    'create_time': cur_time,
                    'add_type': 0,
                })

                server_port_data.append({
                    'id': port_hash,
                    'sid': sid,
                    'create_time': cur_time,
                })

            # 添加 服务器端口连接测试表
            with monitor_db_manager.db_mgr('server_port_connection_test') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('server_port_connection_test') \
                        .insert_all(server_port_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 添加 端口配置表
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .insert_all(port_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 自定义添加  单个 或 多个
        if add_type == 1:
            if not ip_port_list:
                return public.error('缺少参数：ip_port_list')
            ip_port_list = ip_port_list.split(';')  # port_list:  'ip,port;ip,port; ...'

            # 选中的主机端口数据
            n = len(ip_port_list)

            for i in ip_port_list:
                # i : 'ip,port'
                ip_port = i.split(',')  # [ip, port]

                # task_name = task_name if n == 1 else task_name + str(n)
                task_n = str(ip_port[0]) + ':' + str(ip_port[1]) if n > 1 else task_name
                # 重复的跳过
                if basic_monitor_obj.db_easy('availability_port').where("uid=? AND task_name=?",
                                                                        [uid, task_n]).exists():
                    fail_task.append(task_n)
                    continue

                # 域名或ip检测
                boou, data2 = self.data_check(ip_port[0], 'u/i')
                # 端口检测
                boop, data1 = self.data_check(ip_port[1], 'port')
                if boou is False or boop is False:
                    public.print_log('^^^^^^^^域名或ip校验不通过的跳过^^^^^^^^^^^^^^')
                    fail_task.append(task_n)
                    continue

                port_data.append({
                    'uid': uid,
                    'ip': str(ip_port[0]),
                    'port': int(ip_port[1]),
                    'task_name': task_n,
                    'frequency': frequency,
                    'count': count,
                    'protocol': 0,
                    'warning': int(warning),
                    'nodes': nodes,
                    'create_time': cur_time,
                    'add_type': 1,
                    'warning_mode': int(warning_mode),
                    'push_methods': push_methods,
                })
                # n += 1
            # public.print_log('port_data')
            # public.print_log(f'port_data{port_data}')
            # 添加 端口配置表
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .insert_all(port_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e
        public.WriteLog('业务监控', '添加[%s]端口监控任务成功' % task_name)
        if len(fail_task) > 0:
            return public.success("添加端口监控任务  部分任务添加失败: {} 可能原因:重名或不规范".format(fail_task))
        return public.success('添加端口监控任务')

    def remove_port_task(self, args):
        '''
        @name 删除port监控任务
        @author Law Lt <2023-02-24>
        @return dict
        '''
        # 接收任务id     ids = '1,2,3,4,5'
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')  # ['1','2','3','4','5']
        for i in id_list:
            port_info = basic_monitor_obj.db_easy('availability_port').where('id=?', int(i)).find()

            # 删除任务
            basic_monitor_obj.db_easy('availability_port') \
                .where('id=?', int(i)) \
                .delete()

            if port_info['sid'] is not None:
                key = "{}|{}|{}|{}".format(str(port_info['sid']), str(port_info['ip']), str(port_info['port']),
                                           str(port_info['protocol']))
                server_port_id = public.mmh3_hash64(key)
                # 删除主机端口连接表
                basic_monitor_obj.db_easy('server_port_connection_test') \
                    .where('id=?', server_port_id) \
                    .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_port_info') \
                .where('port_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('type', 'port监控告警')\
                .where('task_id', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除端口监控任务[%s] 成功' % (port_info['task_name']))

        return public.success('删除端口监控任务成功')

    def update_port_task(self, args):
        '''
        @name 编辑/修改端口监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''

        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')

        old = basic_monitor_obj.db_easy('availability_port').where("id=?", id_).find()
        dicts = {}
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_port') \
                            .where("uid=? AND task_name=?", [uid, ta_name]) \
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')
        if "warning_mode" in args:
            new_data["warning_mode"] = args.get('warning_mode')

        if len(new_data) > 0:
            new_data["update_time"] = int(time.time())
        if len(new_data['nodes']) < 1:
            return public.error('请选择节点')

        # 自定义添加的 可以改端口和ip
        if old['add_type'] == 1:
            # public.print_log(f'*********************')
            # public.print_log(f'自定义添加的 可以改端口和ip')
            if "ip" in args:
                new_data["ip"] = args.get('ip')
                if old['ip'] != new_data["ip"]:
                    dicts['IP修改为'] = new_data["ip"]

            if "port" in args:
                new_data["port"] = int(args.get('port'))
                if old['port'] != new_data["port"]:
                    dicts['端口修改为'] = new_data["port"]

            if "protocol" in args:
                new_data["protocol"] = args.get('protocol')
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", id_) \
                        .update(new_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 扫描添加的 不可以改端口和ip
        if old['add_type'] == 0:
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", id_) \
                        .update(new_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 修改过后的
        info = basic_monitor_obj.db_easy('availability_port') \
            .where("id=?", id_) \
            .find()
        # IP 端口 被修改
        if dicts:
            public.WriteLog('业务监控', '修改端口监控任务成功!  原名[%s] 现为[%s]  %s' % (
            old['task_name'], info['task_name'], dicts))
        else:
            public.WriteLog('业务监控', '修改端口监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改端口监控任务成功')

    def suspend_port_task(self, args):
        '''
        @name 批量暂停port监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_port').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停端口监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停端口监控任务成功')

    def get_server_host_port(self, args):
        '''
            @name 获取主机监听端口列表
            @return list
        '''
        # 获取主机端口列表
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        server_host_port_ = public.cache_get(f"get_server_host_port")
        if server_host_port_:
            # public.print_log(f'有缓存 从缓存取')
            server_host_port = json.loads(server_host_port_)
        else:
            # public.print_log(f' 无缓存 查数据库')
            sid_list = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').select()
            server_host_port = []
            for i in sid_list:

                port_info_str = basic_monitor_obj.db_easy('server_details') \
                    .field('id', 'port_info') \
                    .where('sid', i['sid']) \
                    .value('port_info')
                if port_info_str is None:
                    continue

                try:
                    port_info_str = json.loads(port_info_str)
                except:
                    pass
                # 结果集(处理前)
                raw_ret = []

                for k, v in port_info_str.items():
                    ip = v.get('ip', '')
                    port = v.get('port', None)
                    protocol = v.get('protocol', '')

                    if protocol == 'udp':
                        continue
                    if ip not in ['0.0.0.0', '::']:
                        continue

                    tmp = {
                        'id': k,
                        'ip': ip,
                        'port': port,
                        'protocol': protocol,
                    }
                    raw_ret.append(tmp)

                host_port_info = {'sid': i['sid'],
                                  's_ip': i['ip'],
                                  's_remark': i['remark'],
                                  "port_list": raw_ret}

                server_host_port.append(host_port_info)

            server_host_port = [item for item in server_host_port if item['port_list'] != []]

        # 缓存执行完的时间
        server_host_port_ = json.dumps(server_host_port, ensure_ascii=False)
        public.cache_set("get_server_host_port", server_host_port_, 600)

        return public.success(server_host_port)

    def test_port_connection_socket(self, ip, port):
        '''
            @name    socket测试端口连通性
            @author  lt<2023-03-28>
            @param   ip<string>  IP|域名
            @param   port<integer>    端口号
            @return (端口是否连通<bool>,任务执行时间<float>)
        '''
        start_time = time.time()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.2)
        try:
            result = sock.connect_ex((ip, port))
            if result == 0:
                connect_status = True
            else:
                connect_status = False
        except Exception as e:
            connect_status = False
        finally:
            sock.close()
            end_time = time.time()
            elapsed_time = "%.2f" % ((end_time - start_time) * 1000)
        return connect_status, elapsed_time

    def test_port_connection(self, address, port, method='telnet'):
        '''
            @name 测试端口连通性
            @author Zhj<2022-07-04>
            @param address<string>  IP|域名
            @param port<integer>    端口号
            @param method<string>   测试方式 telnet|nc
            @return (端口是否连通<bool>, 测试方式<string>)
        '''
        start_time = time.time()
        if method is None:
            ok, _ = self.test_port_connection_via_telnet2(address, port)
            if ok:
                return True

            ok = self.test_port_connection_via_nc(address, port)
            if ok:
                return True

            return False

        if method not in ['telnet', 'nc']:
            return False

        if method == 'telnet':
            connect_status = self.test_port_connection_via_telnet2(address, port)
            end_time = time.time()
            elapsed_time = "%.2f" % ((end_time - start_time) * 1000)
            return connect_status, elapsed_time
            # return self.test_port_connection_via_telnet2(address, port), 'telnet'
        elif method == 'nc':
            return self.test_port_connection_via_nc(address, port)

        return False

    def test_port_connection_via_telnet2(self, address, port, timeout=0.2):
        '''
            @name 使用telnet的方式测试端口
            @author lx<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        import telnetlib
        try:
            info = telnetlib.Telnet(host=address, port=port, timeout=timeout)
            # public.print_log('--telnet的方式测试端口--')

            return True, "telnet"
        except:
            return False
            # return False, "telnet"

    def test_port_connection_via_nc(self, address, port):
        '''
            @name 使用nc的方式测试端口
            @author Zhj<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        res = public.ExecShell('nc -w 1 {} {} && echo ok || echo no'.format(address, port))
        # public.print_log('--nc的方式测试端口--')

        if len(res) < 1:
            return False

        if res[0].find('ok') < 0:
            return False

        return True

    def get_ping_task(self, args):
        '''
            @name 获取ping监控任务列表
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        keyword = args.get('keyword', None)
        # sid = args.get('sid', None)

        # if not sid:
        #     return public.error('缺少参数：sid')
        # server_list = g.get("server_list", [])
        # if sid not in server_list:
        #     public.response(False, '您没有权限访问该服务器 !')

        # 数据库查询
        uid = public.bt_auth('uid')

        query = basic_monitor_obj.db_easy('availability_ping') \
            .order('update_time', 'desc')

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid=?', uid)

        if keyword is not None:
            query.where('ip_dsc like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        ret = query.select()
        servers = self.__get_servers_by_tasks(ret)
        nodes = self.__get_nodes_by_tasks(ret, servers)
        results = self.__get_latest_results('availability_ping_info', 'ping_id',
                                                    extra_fields=('is_ping', 'delay', 'loss_ratio'))
        on_line, off_line = self.__summary_latest_results('availability_ping_info', 'ping_id', 'is_ping', len(ret))
        for i in ret:
            # 补充节点信息
            i['nodes_info'] = nodes.get(i['id'], [])
            i['nodes_num'] = len(i['nodes_info'])

            ping_result = results.get(i['id'], [])
            ping_info = ping_result[0] if len(ping_result) > 0 else None
            i['available_rate'] = self.__calculate_avg(ping_result, 'is_ping') * 100

            if ping_info is not None:
                i['is_ping'] = ping_info['is_ping']
                i['ping_result'] = ping_result
            else:
                i['is_ping'] = 2
                i['ping_result'] = []

        # 列表排序
        for sort_key, sort_reverse in public.get_sort_params(args).items():
            # {'id': True, 'name': False}
            ret.sort(key=lambda x: x.get(sort_key, 0), reverse=sort_reverse)

        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(ret),
            'list': ret[(p - 1) * p_size:p * p_size],
            'on_line': on_line,
            'off_line': off_line
        })

        # # # 分页查询
        # # ret = public.simple_page(query, args)
        # servers = self.__get_servers_by_tasks(ret['list'])
        # nodes = self.__get_nodes_by_tasks(ret['list'], servers)
        # results = self.__get_half_hour_last_results('availability_ping_info', 'ping_id',
        #                                             extra_fields=('is_ping', 'delay', 'loss_ratio'))
        # ret['on_line'], ret['off_line'] = self.__summary_half_hour_last_results(results, 'is_ping', ret['total'])
        # for i in ret['list']:
        #     # 补充节点信息
        #     i['nodes_info'] = nodes.get(i['id'], [])
        #     i['nodes_num'] = len(i['nodes_info'])
        #
        #     ping_result = results.get(i['id'], [])
        #     ping_info = ping_result[0] if len(ping_result) > 0 else None
        #
        #     if ping_info is not None:
        #         i['is_ping'] = ping_info['is_ping']
        #         i['ping_result'] = ping_result
        #     else:
        #         i['is_ping'] = 2
        #         i['ping_result'] = []
        # return public.success(ret)

    def get_ping_result(self, args):
        """
            @name 获取ping监控任务结果
            @author Law Lt <2023-03-01>
            @arg    keyword<string> 关键字
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        query = basic_monitor_obj.db_easy('availability_ping') \
            .where('id=?', id_)

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid=? AND id=?', [uid, id_])

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        servers = self.__get_servers_by_tasks([task])
        nodes = self.__get_nodes_by_tasks([task], servers)
        task['nodes_info'] = nodes[task['id']]
        task['nodes_num'] = len(task['nodes_info'])
        results = self.__get_latest_results('availability_ping_info', 'ping_id',
                                                    extra_fields=('is_ping', 'delay', 'loss_ratio'), task_ids=(task['id'],)).get(task['id'], [])

        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        ping_info = basic_monitor_obj.db_easy('availability_ping_info') \
            .where('`ping_id` = ?', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # 查询数据
        # ping_info = basic_monitor_obj.db_easy('availability_ping_info') \
        #     .where('`create_time` BETWEEN ? AND ?', [id_, cur_time - query_date]) \
        #     .field('is_ping', 'create_time')

        # 检查区间内是否有执行结果
        if not ping_info.fork().field('id').exists():
            return public.success({
                'total': 0,
                'list': [],
                'task': task,
                'available_rate': 0,
                'avg_delay': 0,
                'last_offline_time': None,
                'last_offline_duration': None,
            })

        # 获取区间内任务执行结果
        info = ping_info.fork().order('create_time', 'desc')

        # # 上次离线时间
        # cur_time = int(time.time())
        # if ping_info.fork().where('is_ping=1').exists():
        #     # 最新的失败状态
        #     last_off = ping_info.fork().where('is_ping=0').find()
        #
        #     # 存在失败状态 计算时间
        #     if last_off:
        #         last_offline_time = last_off['create_time']
        #         # 失败是最新一条    当前时间-最新的成功时间
        #         if last_off['id'] == ping_info.fork().value('id'):
        #             last_offline_duration = cur_time - ping_info.fork().where('is_ping=1').value('create_time')
        #         # 不是最新的
        #         else:
        #             end_time = ping_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
        #             last_on_line = ping_info.fork().where('id<? ', last_off['id']).where('is_ping=1').find()
        #             # 失败前没有在线状态
        #             if last_on_line is None:
        #                 start_time = ping_info.fork().value('min(create_time)')
        #             else:
        #                 start_time = ping_info.fork().where('id > ?', last_on_line['id']).where('is_ping', 0).value(
        #                     'min(create_time)')
        #
        #             last_offline_duration = end_time - start_time
        #
        #     else:
        #         last_offline_duration = 0
        #         last_offline_time = None
        # else:
        #     last_offline_duration = None
        #     last_offline_time = ping_info.fork().where('is_ping=1').value('max(create_time)')

        ret = public.simple_page(info, args)

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                # server = warning_obj.db_easy('servers').field('ip', 'remark', 'status').where('sid=?', i['node']).find()
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        ret['task'] = task
        ret['available_rate'] = self.__calculate_avg(results, 'is_ping') * 100
        # 上次离线时间
        ret['last_offline_time'] = 0
        # 上次离线时长
        ret['last_offline_duration'] = self.__calculate_last_offline_time(results, 'is_ping')
        # 平均延迟
        # ret['avg_delay'] = "%.2f" % (ping_info.fork().avg('delay'))
        ret['avg_delay'] = self.__calculate_avg(results, 'delay')

        return public.success(ret)

    # Ping连通测试 -> float|None, float|None
    def __test_ping_connection_retry(self, host, max_retry=5):
        for _ in range(max_retry):
            avg_num = None
            loss_percent = None

            ping_text, _ = public.ExecShell('ping -c30 -W1 -i 0.2 {}'.format(host))
            # public.print_log(f'%%%%%%%%%%%%%%%%ping_text%%%%%%%%%%%%%%%%%%%%%%{ping_text}')
            # 获取不到数据  如：输入错误的ip 0~255   192.168.1.266
            if ping_text is not None:
                # public.print_log(f'%%%%%%%%%%%%%%%%ping_text%%%%%%%%%%%%%%%%%%%%%%{ping_text}')
                ping_text = ping_text.split("\n")
                # public.print_log(f'%%%%%++++++ping_text++++++%%%%%{ping_text}')
                # ping_text = list(set(ping_text))
                # ping_text.remove("")

                ping_text_len = len(ping_text)

                for i in range(ping_text_len - 1, -1, -1):
                    text = ping_text[i]
                    # public.print_log(f'{text}')

                    # 优先匹配平均延迟
                    # if not avg_num:
                    avg_obj = self.__PING_PACKET_DELAY_AVG_REG_OBJ.search(text)
                    if avg_obj:
                        # public.print_log(f'------------temp_text-------------{avg_obj.group(0)}')
                        avg_num = avg_obj.group(1)
                        # public.print_log(f'***************avg_num******************{avg_num}')
                        continue

                    # 匹配丢包率
                    packet_obj = self.__PING_PACKET_REG_OBJ.search(text)
                    if packet_obj:
                        # public.print_log(f'++++++++++++temp_text++++++++++++++{packet_obj.group(0)}')
                        loss_percent = packet_obj.group(1)
                        # public.print_log(f'++++++++++++loss_percent++++++++++++++{loss_percent}')
                        break

            # 连接失败 重试
            if avg_num is None or float(loss_percent) > 99:
                continue

            return float(loss_percent), float(avg_num)

        return None, None

    # 图表数据
    def get_ping_result_simple(self, args):
        """
            @name 获取监控任务结果 简单数据 展示图表用
            @author  <2023-05-29>
            @arg    query_data<string> 时间
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        query = basic_monitor_obj.db_easy('availability_ping') \
            .where('id=?', id_)

        # 非超级管理员仅可查看自己添加的监控任务
        if uid > 1:
            query.where('uid=? AND id=?', [uid, id_])

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        servers = self.__get_servers_by_tasks([task])
        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        # 查询时间
        query_date = args.get('query_date', 'l1')
        # 判断是否是最近一小时
        if query_date == '1hour':
            query_date = self.__get_query_onehour()

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        ping_info = basic_monitor_obj.db_easy('availability_ping_info') \
            .where('`ping_id` = ?', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            # .order('create_time', 'desc')

        if not ping_info.fork().field('id').exists():
            return public.success({
                'total': 0,
                'list': [],
            })

        # 获取区间内任务执行结果
        info = ping_info.fork().order('create_time', 'desc').select()

        ret = {
            'total': len(info),
            'list': info,
        }
        # ret = public.simple_page(info, args)

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        return public.success(ret)

    # 执行ping 改累计
    def __ping_task_help(self, temp):
        cur_time = int(time.time())
        # 跳过没到时间的
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id']):
            return None

        lst = []
        nodes = temp['nodes'].split(',')

        # 没有设置主控节点，跳过
        if '0' not in nodes:
            self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id'], cur_time)
            return None

        # Ping连通测试
        loss_percent, avg_num = self.__test_ping_connection_retry(temp['ip_dsc'])
        flag = loss_percent is not None and avg_num is not None

        lst.append({
            'uid': temp['uid'],
            'ping_id': temp['id'],
            'ip_dsc': temp['ip_dsc'],
            'delay': 0 if avg_num is None else "%.2f" % (float(avg_num)),
            'loss_ratio': 100 if loss_percent is None else float(loss_percent),
            'is_ping': int(flag),
            'node': 0,
            'create_time': cur_time,
        })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id'], cur_time)

        # 告警  如果开启了告警
        if temp['warning']:
            # loss_percent = 0 if loss_percent is None else float(loss_percent)
            # avg_num = 0 if avg_num is None else float(avg_num)
            warning_type = 'ping监控告警'
            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, loss_percent, avg_num, 'ping')
            # public.print_log('@@@@@@@@@@@@@@@@@@@@@@@@@@ ping累计次数 {}'.format(retries), _level='error')
            if can_do_warning:
                # public.print_log(f'$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$', _level='error')
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 主机: {temp["ip_dsc"]}',
                    f'> 告警消息：{notify_content}',
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]

                option = {'mail_title': f'业务监控-ping告警: {temp["ip_dsc"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','),options=option)

                res['warning_logs'] = {
                    'task_id': temp['id'],  # 新加任务id
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'主机: {temp["ip_dsc"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('ping', temp['id'], retries=retries, can_do_warning=can_do_warning,
                                    cur_time=cur_time)

        return res

    def execute_ping_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        #  留有主控的
        pings = basic_monitor_obj.db_easy('availability_ping') \
            .order('create_time', 'desc') \
            .field('id', 'nodes') \
            .where('suspend=?', 0) \
            .select()

        # 包含主控的任务
        ping_id_list = []
        # 找到节点含0的
        for i in pings:
            node_list = i['nodes'].split(',')
            if '0' in node_list:
                ping_id_list.append(i['id'])

        # 获取有主控的http监控任务
        ping_list = basic_monitor_obj.db_easy('availability_ping') \
            .where_in("id", ping_id_list) \
            .order('create_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []
        # start_time = time.time()
        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in ping_list:
                f = t.submit(self.__ping_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录ping监控结果  写入信息表
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_ping_info') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_ping_info") \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        # end_time = time.time() - start_time
        # public.print_log(f'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{end_time}')
        return public.success()

    # 执行被控服务器任务 ping 改累计
    def __ping_task_controlled_help(self, temp):
        cur_time = int(time.time())
        # 跳过没到时间的
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id'], execute_type='controlled'):
            return None

        flag = True
        # loss_percent = None
        # avg_num = None
        delay = None
        loss_ratio = None

        lst = []
        nodes = temp['nodes'].split(',')
        node_list = [int(num) for num in nodes]

        # 仅主控节点时，跳过
        if len(node_list) == 1 and node_list[0] == 0:
            # 缓存执行完的时间
            self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id'], cur_time, execute_type='controlled')
            return None

        servers = warning_obj.db_easy('servers').field('sid').where('status=1').select()
        server_list = [int(i['sid']) for i in servers]
        for q in node_list:
            # 判断当前sid是否存在 不存在跳过
            if q not in server_list:
                continue
            # loss_ratio = 0
            # delay = 0
            flag = False
            resp = None
            m = 0
            while m < temp['count']:
                m += 1
                key_ = public.GetRandomString(6)
                resp = public.send_agent_msg(
                    public.get_serverid_bysid(q),
                    'vocationalwork',
                    'GetPingInfoByServer',
                    callback='recv/vocationalwork/GetPingInfoByServer/{}/{}/{}'.format(q, temp['id'],
                                                                                       key_),
                    pdata=public.g_pdata({
                        'ip_dsc': temp['ip_dsc'],
                        'key': key_,
                    }))

                if not resp:
                    flag = False
                    continue
                else:
                    # public.print_log('|------{} ping::{} {}'.format(key_, temp['ip_dsc'], resp))
                    # resp = resp if resp else {
                    #     'body': {'body': {'delay': 0, 'is_ping': False, 'loss_ratio': 0, 'keystr': 0}}, }
                    if not isinstance(resp.get('body', {}).get('body'), dict):
                        flag = False
                        continue
                    # 判断当前是否是对应任务的值
                    if key_ != resp.get('body', {}).get('body', {}).get('keystr', 0):
                        flag = False
                        continue
                    is_ping = resp.get('body', {}).get('body', {}).get('is_ping', False)
                    # loss_ratio = resp.get('body', {}).get('body', {}).get('loss_ratio', 0)
                    # delay = resp.get('body', {}).get('body', {}).get('delay', 0)
                    #
                    # ip_desc = temp['ip_dsc']

                    if is_ping:
                        flag = True
                        break
                    else:
                        flag = False
                        continue
            resp = resp if resp and isinstance(resp.get('body', {}).get('body'), dict) else {
                'body': {'body': {'delay': 0, 'is_ping': False, 'loss_ratio': 0, 'keystr': 0}}, }
            # public.print_log(
            #     '****************************{}被控resp结果:::{}'.format(temp['ip_dsc'], resp))

            delay = resp.get('body', {}).get('body', {}).get('delay', 0)
            loss_ratio = resp.get('body', {}).get('body', {}).get('loss_ratio', 100)
            lst.append({
                'uid': temp['uid'],
                'ping_id': temp['id'],
                'ip_dsc': temp['ip_dsc'],
                'delay': "%.2f" % (float(delay)),
                'loss_ratio': loss_ratio,
                'is_ping': int(flag),
                'node': q,
                'create_time': cur_time,
            })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_ping_info', 'ping_id', temp['id'], cur_time,
                                         execute_type='controlled')
        if temp['warning']:
            warning_type = 'ping监控告警'
            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, loss_ratio, delay, 'ping')
            if can_do_warning:
                # public.print_log(f'$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$', _level='error')
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 主机: {temp["ip_dsc"]}',
                    f'> 告警消息：{notify_content}',
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]
                option = {'mail_title': f'业务监控-ping告警: {temp["ip_dsc"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','), options=option)

                res['warning_logs'] = {
                    'task_id': temp['id'],  # 新加任务id
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'主机: {temp["ip_dsc"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('ping', temp['id'], retries=retries, can_do_warning=can_do_warning,
                                    cur_time=cur_time)

        return res

    # 执行被控服务器任务
    def execute_ping_task_controlled(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取ping检测监控列表
        ping_list = basic_monitor_obj.db_easy('availability_ping') \
            .order('create_time', 'desc') \
            .where('suspend=?', 0) \
            .select()

        insert_data = []
        warning_logs = []
        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in ping_list:
                f = t.submit(self.__ping_task_controlled_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录ping监控结果  写入信息表
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_ping_info') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_ping_info") \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        return public.success()

    def add_ping_task(self, args):
        '''
        @name 添加ping监控
        @author Law Lt <2023-02-24>
        @arg    ip<string> 服务器IP
        @return dict
        '''
        uid = public.bt_auth('uid')
        add_type = int(args.get('add_type', 1))  # 0 快速 1传统
        task_name = args.get('task_name', '')
        ip_src = args.get('ip_src', 0)
        network = args.get('network', '')
        ip_dsc = args.get('ip_dsc', '')
        warning = args.get('warning', 1)
        w_loss_ratio = args.get('w_loss_ratio', 20)
        w_delay = args.get('w_delay', 0)
        nodes = args.get('nodes', '0')
        frequency = args.get('frequency', 20)
        count = args.get('count', 2)
        push_methods = args.get("push_methods", '')

        if not ip_dsc:
            return public.error('缺少参数：ip_dsc')

        # 域名或ip检测
        boou, _ = self.data_check(ip_dsc, 'u/i')
        if not boou:
            return public.error('ip或域名格式错误')

        if basic_monitor_obj.db_easy('availability_ping').where("uid=? AND task_name=?", [uid, task_name]).exists():
            return public.error('任务名已存在')
        if warning == '1' and len(push_methods) < 1:
            return public.error('请选择告警推送方式')
        # 添加不成功的任务
        fail_task = []
        cur_time = int(time.time())
        # ping_data = []

        # 快速添加方式
        # if add_type == 0:
        #     if sid is not None:
        #         sid_list = sid.split(',')
        #         ip_list = basic_monitor_obj.db_easy('servers') \
        #             .field('ip','sid') \
        #             .order('create_time', 'desc') \
        #             .where_in("sid", sid_list) \
        #             .select()
        #
        #         for ip in ip_list:
        #             ping_data.append({
        #                 'uid': uid,
        #                 'task_name': task_name,
        #                 'add_type': 0,
        #                 'ip_src': ip_src,
        #                 'network': network,
        #                 'ip_dsc': ip['ip'],
        #                 'warning': warning,
        #                 'w_loss_ratio': w_loss_ratio,
        #                 'w_delay': w_delay,
        #                 'node': node,
        #                 'frequency': frequency,
        #                 'count': count,
        #                 'push_methods': push_methods,
        #                 'create_time': cur_time,
        #             })
        #
        #     with monitor_db_manager.db_mgr('availability_ping') as db:
        #         try:
        #             # 关闭事务自动提交
        #             db.autocommit(False)
        #
        #             db.query() \
        #                 .name('availability_ping') \
        #                 .insert_all(ping_data)
        #
        #             # 提交事务
        #             db.commit()
        #         except BaseException as e:
        #             # 回滚事务
        #             db.rollback()
        #
        #             # 打印异常堆栈
        #             public.print_exc_stack(e)
        #             raise e

        # 传统添加方式
        ping_data = []
        if add_type == 1:
            # # 数据库操作
            # basic_monitor_obj.db_easy('availability_ping') \
            #     .insert({
            #         'uid': uid,
            #         'task_name': task_name,
            #         'add_type': 1,
            #         'ip_src': ip_src,
            #         'network': network,
            #         'ip_dsc': ip_dsc,
            #         'warning': warning,
            #         'w_loss_ratio': w_loss_ratio,
            #         'w_delay': w_delay,
            #         'node': node,
            #         'frequency': frequency,
            #         'count': count,
            #         'push_methods': push_methods,
            #         'create_time': cur_time,
            # })
            if ip_dsc is not None:
                ip_dsc = ip_dsc.split(';')
                ip_des_len = len(ip_dsc)
                # n = 1
                for temp in ip_dsc:
                    # task_name = task_name if n == 1 else task_name + str(n)
                    if basic_monitor_obj.db_easy('availability_ping').where("uid=? AND task_name=?",
                                                                            [uid, temp]).exists():
                        fail_task.append(temp)
                        continue
                    # 域名或ip检测
                    boou, data1 = self.data_check(temp, 'u/i')
                    if boou is False:
                        public.print_log('^^^^^^^^域名或ip校验不通过的跳过^^^^^^^^^^^^^^')
                        fail_task.append(temp)
                        continue

                    ping_data.append({
                        'uid': uid,
                        # 'task_name': task_name + str(n) if ip_des_len > 1 else task_name,
                        'task_name': temp,
                        'add_type': 1,
                        'ip_src': ip_src,
                        'network': network,
                        'ip_dsc': temp,
                        'warning': int(warning),
                        'w_loss_ratio': w_loss_ratio,
                        'w_delay': w_delay,
                        'nodes': nodes,
                        'frequency': frequency,
                        'count': count,
                        'push_methods': push_methods,
                        'create_time': cur_time,
                    })
                    # n+=1

                # 添加 端口配置表
                with monitor_db_manager.db_mgr('availability_ping') as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        db.query() \
                            .name('availability_ping') \
                            .insert_all(ping_data)
                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 打印异常堆栈
                        public.print_exc_stack(e)
                        raise e

        public.WriteLog('业务监控', '添加Ping监控任务[%s] 成功' % task_name)
        if len(fail_task) > 0:
            return public.success("添加Ping监控任务成功  部分任务添加失败: {} 可能原因:重名或不规范".format(fail_task))
        return public.success('添加Ping监控任务成功')

    def remove_ping_task(self, args):
        '''
        @name 删除ping监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''
        # 接收
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')

        for i in id_list:
            data = basic_monitor_obj.db_easy('availability_ping') \
                .where('id=?', int(i)) \
                .find()

            # 删除任务
            basic_monitor_obj.db_easy('availability_ping') \
                .where('id=?', int(i)) \
                .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_ping_info') \
                .where('ping_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('type', 'ping监控告警')\
                .where('task_id=?', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除Ping监控任务[%s] 成功' % (data['task_name']))
        return public.success('删除Ping监控任务成功')

    def update_ping_task(self, args):
        '''
        @name 编辑/修改ping监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''
        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')
        dicts = {}
        old = basic_monitor_obj.db_easy('availability_ping').where("id=?", id_).find()
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_ping') \
                            .where("uid=? AND task_name=?", [uid, ta_name]) \
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "ip_dsc" in args:
            new_data["ip_dsc"] = args.get('ip_dsc')
            if old['ip_dsc'] != new_data["ip_dsc"]:
                dicts['目标IP修改为'] = new_data["ip_dsc"]

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "w_loss_ratio" in args:
            new_data["w_loss_ratio"] = int(args.get('w_loss_ratio'))
            if old['w_loss_ratio'] != new_data["w_loss_ratio"]:
                dicts['丢包率修改为'] = new_data["w_loss_ratio"]

        if "w_delay" in args:
            new_data["w_delay"] = int(args.get('w_delay'))
            if old['w_delay'] != new_data["w_delay"]:
                dicts['延迟修改为'] = str(new_data["w_delay"]) + 'ms'

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')

        if len(new_data['nodes']) < 1:
            return public.error('请选择节点')
        # if "warning_mode" in args:
        #     new_data["warning_mode"] = args.get('warning_mode')

        if len(new_data) > 0:
            new_data["update_time"] = int(time.time())
        with monitor_db_manager.db_mgr('availability_ping') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('availability_ping') \
                    .where("id=?", id_) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        # 记录日志
        info = basic_monitor_obj.db_easy('availability_ping') \
            .where("id=?", id_) \
            .find()
        if dicts:
            public.WriteLog('业务监控', '修改Ping监控任务成功!  原名[%s] 现为[%s]  %s' % (
            old['task_name'], info['task_name'], dicts))
        else:
            public.WriteLog('业务监控', '修改Ping监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改Ping监控任务成功')

    def suspend_ping_task(self, args):
        '''
        @name 批量暂停ping监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_ping').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_ping') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_ping') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停ping监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停ping监控任务成功')

    def get_http_task(self, args):
        '''
            @name 获取http/https监控任务列表
            @author  <2023-03-2>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    协议 http/https
            @return list
        '''
        keyword = args.get('keyword', None)
        uid = public.bt_auth('uid')

        # 构造查询对象
        query = basic_monitor_obj.db_easy('availability_http') \
            .order('update_time', 'desc')

        if uid > 1:
            query.where('uid', uid)

        if keyword is not None:
            query.where('url = ? or task_name like ?', (keyword, f"%{keyword}%"))

        ret = query.select()
        servers = self.__get_servers_by_tasks(ret)

        results = self.__get_latest_results('availability_http_info', 'http_id', extra_fields=('is_ok', 'response_time', 'response'))

        on_line, off_line = self.__summary_latest_results('availability_http_info', 'http_id', 'is_ok', len(ret))

        nodes = self.__get_nodes_by_tasks(ret, servers)
        for i in ret:
            # 补充节点信息
            i['nodes_info'] = nodes.get(i['id'], [])
            i['nodes_num'] = len(i['nodes_info'])

            http_result = results.get(i['id'], [])

            # 最近一次
            http_info = http_result[0] if len(http_result) > 0 else None
            i['available_rate'] = self.__calculate_avg(http_result, 'is_ok') * 100

            if http_info is None:
                i['is_ok'] = 2
                i['response_time'] = 0
                i['http_result'] = []
                continue

            i['is_ok'] = http_info['is_ok']
            i['response_time'] = http_info['response_time']
            i['http_result'] = http_result
        # 列表排序
        for sort_key, sort_reverse in public.get_sort_params(args).items():
            ret.sort(key=lambda x: x.get(sort_key, 0), reverse=sort_reverse)
        # 分页查询
        # ret = public.simple_page(query, args)
        # servers = self.__get_servers_by_tasks(ret['list'])
        #
        # results = self.__get_half_hour_last_results('availability_http_info', 'http_id', extra_fields=('is_ok', 'response_time', 'response'))
        #
        # ret['on_line'], ret['off_line'] = self.__summary_half_hour_last_results(results, 'is_ok', ret['total'])
        #
        # nodes = self.__get_nodes_by_tasks(ret['list'], servers)
        # for i in ret['list']:
        #     # 补充节点信息
        #     i['nodes_info'] = nodes.get(i['id'], [])
        #     i['nodes_num'] = len(i['nodes_info'])
        #
        #     http_result = results.get(i['id'], [])
        #
        #     # 最近一次
        #     http_info = http_result[0] if len(http_result) > 0 else None
        #
        #     if http_info is None:
        #         i['is_ok'] = 2
        #         i['response_time'] = 0
        #         i['http_result'] = []
        #         continue
        #
        #     i['is_ok'] = http_info['is_ok']
        #     i['response_time'] = http_info['response_time']
        #     i['http_result'] = http_result


        # 列表排序

        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(ret),
            'list': ret[(p - 1) * p_size:p * p_size],
            'on_line': on_line,
            'off_line': off_line
        })

        # return public.success(ret)

    def get_http_result(self, args):
        """
            @name 获取http/https监控任务结果
            @author  <2023-03-02>
            @arg    keyword<string> 关键字
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')

        uid = public.bt_auth('uid')

        query = basic_monitor_obj.db_easy('availability_http').where('id', id_)

        if uid > 1:
            query.where('uid', uid)

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        # 监控任务的节点信息
        servers = self.__get_servers_by_tasks([task])
        nodes = self.__get_nodes_by_tasks([task], servers)
        task['nodes_info'] = nodes[task['id']]
        task['nodes_num'] = len(task['nodes_info'])

        results = self.__get_latest_results('availability_http_info', 'http_id', 100, extra_fields=('is_ok', 'response_time',), task_ids=(task['id'],)).get(task['id'], [])

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        http_info = basic_monitor_obj.db_easy('availability_http_info') \
            .where('http_id', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # 检查区间内是否有执行结果
        if not http_info.fork().field('id').exists():
            ret = {}
            ret['total'] = 0
            ret['list'] = []
            ret['task'] = task
            ret['available_rate'] = 0
            ret['avg_response_time'] = 0
            ret['last_offline_time'] = None
            ret['last_offline_duration'] = None
            return public.success(ret)
        # http_info = http_info.select()

        # 获取连接成功率
        # rate = http_info.fork().value('ROUND(1.0 * SUM(CASE `is_ok` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')

        # 上次离线时长
        # # 有成功的状态
        # if http_info.fork().where('is_ok=1').exists():
        #     # 最新的失败状态
        #     last_off = http_info.fork().where('is_ok=0').find()
        #
        #     # 存在失败状态 计算时间
        #     if last_off:
        #         last_offline_time = last_off['create_time']
        #
        #         # 失败是最新一条    当前时间-最新的成功时间
        #         if last_off['id'] == http_info.fork().value('id'):
        #             last_offline_duration = cur_time - http_info.fork().where('is_ok=1').value('create_time')
        #
        #         # 不是最新的  最新一次是正常的
        #         else:
        #             end_time = http_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
        #             if end_time is None:
        #                 end_time = cur_time
        #             # raw_sql = http_info.fork().where('id > ?', (last_off['id'])).build_sql()
        #             # public.print_log('|||||===')
        #             # public.print_log('|||||======||||| SQL: %s' % raw_sql)
        #
        #             last_on_line = http_info.fork().where('id<? ', last_off['id']).where('is_ok=1').find()
        #             # public.print_log('+++1111 end_time::{}'.format(end_time))
        #
        #             # 失败前没有在线状态
        #             if last_on_line is None:
        #                 start_time = http_info.fork().value('min(create_time)')
        #             else:  # 失败前有在线状态
        #                 start_time = http_info.fork().where('id > ?', last_on_line['id']).where('is_ok', 0).value(
        #                     'min(create_time)')
        #
        #             last_offline_duration = end_time - start_time
        #
        #     else:
        #         last_offline_duration = 0
        #         last_offline_time = None
        # else:
        #     last_offline_duration = None
        #     last_offline_time = http_info.fork().where('is_ok=0').value('max(create_time)')

        # 分页查询
        # ret = {
        #     "total": len(http_info),
        #     "list": http_info,
        # }
        # 取消分页
        ret = public.simple_page(http_info, args)


        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                # server = warning_obj.db_easy('servers').field('ip', 'remark', 'status').where('sid=?', i['node']).find()
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        ret['available_rate'] = self.__calculate_avg(results, 'is_ok') * 100
        ret['task'] = task

        # 上次离线时间
        ret['last_offline_time'] = 0

        # 上次离线时长
        ret['last_offline_duration'] = self.__calculate_last_offline_time(results, 'is_ok')
        # 平均响应时间
        # ret['avg_response_time'] = "%.2f" % (http_info.fork().avg('response_time'))
        ret['avg_response_time'] = self.__calculate_avg(results, 'response_time')
        return public.success(ret)

    # 图表数据(执行结果)
    def get_http_result_simple(self, args):
        """
            @name 获取http/https监控任务结果 简单数据 展示图表用
            @author  <2023-03-02>
            @arg    keyword<string> 关键字
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')

        uid = public.bt_auth('uid')

        query = basic_monitor_obj.db_easy('availability_http').where('id', id_)

        if uid > 1:
            query.where('uid', uid)

        task = query.find()

        if task is None:
            return public.error('任务不存在或者权限不足')

        internal_ips, published_ip = basic_monitor_obj.get_server_ip()
        servers = self.__get_servers_by_tasks([task])

        # 查询时间
        query_date = args.get('query_date', 'l1')
        # 判断是否是最近一小时
        if query_date == '1hour':
            query_date = self.__get_query_onehour()

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        http_info = basic_monitor_obj.db_easy('availability_http_info') \
            .where('http_id', id_) \
            .where('uid > 0') \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            # .order('create_time', 'desc')

        # 检查区间内是否有执行结果
        if not http_info.fork().field('id').exists():
            ret = {}
            ret['total'] = 0
            ret['list'] = []
            return public.success(ret)
        http_info = http_info.select()

        ret = {
            "total": len(http_info),
            "list": http_info,
        }

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '主控'
                i['node_ip'] = internal_ips[0]
                i['node_state'] = None
            else:
                server = servers.get(i['node'], None)
                if server:
                    i['node_remark'] = server['remark'] if server['remark'] else ''
                    i['node_ip'] = server['ip']
                    i['node_state'] = server['status']
                else:
                    i['node_remark'] = '被控节点可能卸载,请重新添加节点'
                    i['node_ip'] = ''
                    i['node_state'] = None

        return public.success(ret)

    # 执行http  改累计
    def __http_task_help(self, temp):
        """
            @name 执行http
            @author  <2023-03-22>
            @arg    temp 两个判断告警的条件
            @return dict
        """
        cur_time = int(time.time())
        # 跳过没到时间的 先从缓存取上次执行时间 缓存没有 取数据库取
        # 优先从缓存中获取 其次从数据库获取
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id']):
            return None

        nodes = temp['nodes'].split(',')
        # 没有设置主控节点，跳过
        if '0' not in nodes:
            self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id'], cur_time)
            return None

        flag = True
        status = None
        response_time = None
        # 获取证书详情
        start_time = 0
        end_time = 0
        issuer = ''
        subject = ''
        certificate = warning_obj.get_domain_cert_info(temp['url'])
        request_methods = (requests.get, requests.post)
        if certificate is not None:
            start_time = int(certificate.get('start_time', 0))
            end_time = int(certificate.get('end_time', 0))
            issuer = json.dumps(certificate.get('issuer', ''), ensure_ascii=False)
            subject = json.dumps(certificate.get('subject', ''), ensure_ascii=False)
        # name = temp['task_name']

        lst = []
        for _ in range(1):
            status = None
            response_time = None
            # public.print_log(f'-------------------- {name}执行第{n}次>_< ------------------------------')
            # 自定义user-agent头
            headers = {
                "User-Agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
            }
            # 开启basic认证
            if temp['is_basic']:
                import base64
                user = public.decrypt_password(temp['bs_user'])
                pwd = public.decrypt_password(temp['bs_pwd'])
                bs = str(base64.b64encode((user + ":" + pwd).encode("utf-8")), "utf-8")
                headers.update({"Authorization": "Basic {}".format(bs)})

            # public.print_log(f'开启basic认证 --- {headers}')
            mtd = request_methods[int(temp['method'])]
            # s_type = ('get', 'post')[int(temp['method'])]
            # public.print_log(f'--- {s_type}请求 ---')
            post_data = {}
            # 捕获异常 跳过本次
            try:
                # 传入了参数
                if temp['body'] is not None:
                    if len(temp['body']) > 1:
                        list_k_v = temp['body'].split(
                            ';')  # temp['body'] = 'key1,value1;key2,value2;key3,value3'
                        # list1 = ['key1,value1', 'key2,value2', 'key3,value3']

                        for i in list_k_v:
                            k_v = i.split(',')  # [key, value]
                            post_data[k_v[0]] = k_v[1]
                        # public.print_log(f'=========={s_type}传入参数{post_data}')
                    # basic 参数: auth=(temp['bs_user'], temp['bs_pwd'])
                    result = mtd(temp['url'], verify=False, params=post_data, headers=headers, timeout=(3, 120))
                else:
                    result = mtd(temp['url'], params=None, verify=False, headers=headers, timeout=(3, 120))
                status = result.status_code
                res_time = "%.2f" % (float(result.elapsed.total_seconds() * 1000))  # 时间为秒*1000 毫秒
                response_time = res_time if res_time else 0
                # data = None
                # try:
                #     data = json.loads(result.json())
                # except:
                #     pass

                # 两个同时存在
                # if temp['status'] is not None and len(temp['keyword']) > 0:
                #     # public.print_log(f'|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||')
                #     n = 0
                #     text = result.content.decode('utf-8')
                #     # 没返回状态码 用关键字查
                #     if status is None:
                #         if str(text).find(temp['keyword']) > -1:
                #             n = 1
                #             break
                #     # 有状态码 和 关键字
                #     # text = result.content.decode('utf-8')
                #     if str(text).find(temp['keyword']) > -1:
                #         n = 1
                #         break
                #
                #     stu_list = temp['status'].split(',')  # ['200-299', '300-300']
                #     for i in stu_list:
                #         start_end = i.split('-')  # ['200', '299']
                #         n = 1 if int(start_end[0]) <= int(status) <= int(start_end[1]) else 0
                #         # 成功停止重试
                #         if n == 1:
                #             break
                #         else:
                #             continue
                #     flag = True if n == 1 else False

                # 只有状态码
                if temp['status'] is not None:
                    # public.print_log('____只有状态码 配置:{}_______响应:{}'.format(temp['status'], status))
                    # 状态码为空 不能比较
                    if status is None:
                        flag = False
                        continue
                    s = temp['status']
                    stu_list = s.split(',')
                    for i in stu_list:
                        start_end = i.split('-')  # ['200', '299']
                        if int(start_end[0]) <= int(status) <= int(start_end[1]):
                            flag = True
                            break
                        else:
                            flag = False

                # 只有关键字
                # if len(temp['keyword']) > 0:
                #     public.print_log(f'_______________________只有关键字判断________________________________')
                #     text = result.content.decode('utf-8')
                #     if str(text).find(temp['keyword']) > -1:
                #         flag = True
                #         break
            except BaseException as e:
                # print('Unfortunitely -- An Unknow Error Happened')
                # # 打印异常堆栈信息
                # public.print_log(temp['url'])
                # public.print_exc_stack(e)
                flag = False
                continue

        lst.append({
            'uid': temp['uid'],
            'http_id': temp['id'],
            'response': status,
            'response_time': response_time,
            'start_time': start_time,  # 证书开始时间
            'end_time': end_time,  # 证书结束时间
            'issuer': issuer,  # 证书签发信息
            'subject': subject,  # 证书信息
            'is_ok': int(flag),
            'node': 0,
            'create_time': cur_time,
        })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id'], cur_time)

        if temp['warning']:
            warning_type = 'http监控告警'

            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, task_type='http')
            # public.print_log('@@@@@@@@@@@@@@@@@@@@@@@@@@ http累计次数 {}'.format(retries), _level='error')
            if can_do_warning:
                # public.print_log(f'$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$', _level='error')
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 告警域名: {temp["url"]}',
                    '> 告警消息：[{}]:{}'.format(temp["url"], notify_content),
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]

                option = {'mail_title': f'业务监控-http(s)告警: {temp["url"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','), options=option)


                res['warning_logs'] = {
                    'task_id': temp['id'],
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'告警域名: {temp["url"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('http', temp['id'], retries=retries, can_do_warning=can_do_warning,
                                    cur_time=cur_time)


        return res

    def execute_http_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        s_time = time.time()
        e_time = s_time
        tmp_time = None
        task_cost_time = None
        database_cost_time = None

        # 获取检测监控列表          未暂停
        https = basic_monitor_obj.db_easy('availability_http') \
            .where('suspend', 0) \
            .select()

        # 包含主控的任务
        http_list = filter(lambda x: '0' in x['nodes'].split(','), https)

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in http_list:
                f = t.submit(self.__http_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        tmp_time = time.time()
        task_cost_time = int((tmp_time - e_time) * 1000)
        e_time = tmp_time

        # 记录http监控结果  写入信息表
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_http_info') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_http_info") \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        tmp_time = time.time()
        database_cost_time = int((tmp_time - e_time) * 1000)
        e_time = tmp_time

        # public.print_log('>>> HTTP_MONITORING <<<\nTASK_COST: {}ms\nDATABASE_COST: {}ms\nTOTAL_COST: {}ms'.format(task_cost_time, database_cost_time, int((e_time - s_time) * 1000)))

        return True

    # 执行被控服务器任务 改累计
    def __http_task_controlled_help(self, temp):
        cur_time = int(time.time())
        if cur_time <= temp['frequency'] + self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id'], execute_type='controlled'):
            return None

        flag = True
        # 获取证书详情
        start_time = 0
        end_time = 0
        issuer = ''
        subject = ''
        certificate = warning_obj.get_domain_cert_info(temp['url'])
        if certificate is not None:
            start_time = int(certificate.get('start_time', 0))
            end_time = int(certificate.get('end_time', 0))
            issuer = json.dumps(certificate.get('issuer', ''), ensure_ascii=False)
            subject = json.dumps(certificate.get('subject', ''), ensure_ascii=False)

        lst = []
        nodes = temp['nodes'].split(',')
        node_list = [int(num) for num in nodes]

        # 仅主控节点时，跳过
        if len(node_list) == 1 and node_list[0] == 0:
            # 缓存执行完的时间
            self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id'], cur_time, execute_type='controlled')
            return None

        servers = warning_obj.db_easy('servers').field('sid').where('status=1').select()
        server_list = [int(i['sid']) for i in servers]
        for q in node_list:
            # 判断当前sid是否存在 不存在跳过
            if q not in server_list:
                continue

            # public.print_log(f'^^^^^^%%%%%%%%%%%%%%%%http 被控执行{q}')
            resp = None
            response_time = 0
            response = ''
            m = 0
            flag = False
            while m < temp['count']:
                url = temp['url']
                m += 1
                # 传入数据
                key_ = public.GetRandomString(6)
                bs_user = public.decrypt_password(temp['bs_user'])
                bs_pwd = public.decrypt_password(temp['bs_pwd'])

                resp = public.send_agent_msg(
                    public.get_serverid_bysid(q),
                    'vocationalwork',
                    'GetHttpsInfoByServer',
                    callback='recv/vocationalwork/GetHttpsInfoByServer/{}/{}/{}'.format(q, temp['id'], key_),
                    pdata=public.g_pdata({
                        'url': temp['url'],
                        'status': temp['status'],
                        'body': temp['body'],
                        'method': ('get', 'post')[int(temp['method'])],
                        'keyword': '' if temp['keyword'] is None else temp['keyword'],
                        'is_basic': str(temp['is_basic']),
                        'bs_user': str(bs_user),
                        'bs_pwd': str(bs_pwd),
                        'key': key_,
                    }))

                # public.print_log(f'))))))))))))))))))))))))))))))|-key:::{key_}    -send agent message:::{resp}')

                if not resp:
                    flag = False
                    continue
                else:
                    public.print_log('|------{} {} {}'.format(key_, url, resp))
                    # resp = resp if resp is not None else {
                    #     'body': {'body': {'delay': 0, 'is_ok': False, 'response_time': 0, 'response': '',
                    #                       'keystr': 0, }}, }

                    # 返回值不是字典 跳过
                    if not isinstance(resp.get('body', {}).get('body'), dict):
                        flag = False
                        continue
                    # 判断当前是否是对应任务的值
                    if key_ != resp.get('body', {}).get('body', {}).get('keystr', '0'):
                        flag = False
                        continue
                    is_ok = resp.get('body', {}).get('body', {}).get('is_ok', False)
                    response = resp.get('body', {}).get('body', {}).get('response', '')
                    response_time = resp.get('body', {}).get('body', {}).get('response_time', 0)

                    # public.print_log(f'))))))))))))))))))))))))))))))))))is_ok:::{is_ok}')
                    # public.print_log(f'))))))))))))))))))))))))response_time:::{response_time}')
                    # public.print_log(f'))))))))))))))))))))))))))))))))))response:::{response}')
                    if is_ok:
                        flag = True
                        break
                    else:
                        flag = False
                        continue

            resp = resp if resp and isinstance(resp.get('body', {}).get('body'), dict) else {
                'body': {'body': {'delay': 0, 'is_ok': False, 'response_time': 0, 'response': '',
                                  'keystr': 0, }}, }
            # public.print_log(
            #     '****************************{}被控resp结果:::{}'.format(temp['url'], resp))

            response = resp.get('body', {}).get('body', {}).get('response', '')
            response_time = resp.get('body', {}).get('body', {}).get('response_time', 0)

            lst.append({
                'uid': temp['uid'],
                'http_id': temp['id'],
                'response': response,
                'response_time': "%.2f" % (float(response_time)),
                'start_time': start_time,
                'end_time': end_time,
                'issuer': issuer,
                'subject': subject,
                'is_ok': int(flag),
                'node': q,
                'create_time': cur_time,
            })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        self.__cache_latest_execute_time('availability_http_info', 'http_id', temp['id'], cur_time, execute_type='controlled')

        if temp['warning']:
            warning_type = 'http监控告警'

            can_do_warning, notify_content, times, retries = self.__is_warning(temp, flag, cur_time, task_type='http')
            if can_do_warning:
                # public.print_log(f'$$$$$$$PORT -------满足告警条件 进行告警-----$$$$$$$$$$$$$$$', _level='error')
                send_msg = [
                    f'> 告警类型：{warning_type}',
                    f'> 推送时间: {times}',
                    f'> 告警任务名: {temp["task_name"]}',
                    f'> 告警域名: {temp["url"]}',
                    '> 告警消息：[{}]:{}'.format(temp["url"], notify_content),
                    '',
                    '堡塔云安全监控告警提醒，请尽快处理',
                ]
                option = {'mail_title': f'业务监控-http(s)告警: {temp["url"]}'}

                warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','), options=option)

                res['warning_logs'] = {
                    'task_id': temp['id'],
                    'type': warning_type,
                    'content': '\n'.join(send_msg),
                    'task_name': temp['task_name'],
                    'push_methods': temp['push_methods'],
                    'subject': f'告警域名: {temp["url"]}',
                    'message': notify_content,
                }

            # 更新监控任务信息
            self.__update_task_info('http', temp['id'], retries=retries, can_do_warning=can_do_warning,
                                    cur_time=cur_time)

        return res

    # 执行被控服务器任务
    def execute_http_task_controlled(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取检测监控列表          未暂停
        http_list = basic_monitor_obj.db_easy('availability_http') \
            .where('suspend=?', 0) \
            .order('create_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in http_list:
                f = t.submit(self.__http_task_controlled_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录http监控结果  写入信息表
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('availability_http_info') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_http_info") \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        return True

    def add_http_task(self, args):
        '''
        @name 添加监控http/https任务
        @author <2023-03-2>
        @arg    协议 http/https
        @return dict
        '''
        uid = public.bt_auth('uid')
        add_type = args.get("add_type", 0)
        task_name = args.get("task_name", '')
        url = args.get("url", None)
        method = args.get("method", 0)
        frequency = args.get("frequency", 20)
        status = args.get("status", '')
        count = args.get("count", 2)
        body = args.get("body", None)
        head = args.get("head", None)
        warning = args.get("warning", 0)
        nodes = args.get("nodes", '0')
        keyword = args.get("keyword", None)
        warning_mode = args.get("warning_mode", 0)
        push_methods = args.get("push_methods", '')
        # basic认证
        is_basic = args.get("is_basic", 0)
        bs_user = args.get("bs_user", '')
        bs_pwd = args.get("is_basic", '')
        ase_bs_user = public.encrypt_password(bs_user) if len(bs_user) > 0 else ''
        ase_bs_pwd = public.encrypt_password(bs_pwd) if len(bs_pwd) > 0 else ''

        if int(add_type) not in [0, 1]:
            return public.error("add_type 参数错误！")

        if url is None:
            return public.error("缺少参数：url")
        if int(method) not in [0, 1, 2, 3]:
            return public.error("缺少参数：method")
        if warning == '1' and len(push_methods) < 1:
            return public.error('请选择告警推送方式')
        # 添加不成功的任务
        fail_task = []

        temp = {
            "uid": uid,
            "method": int(method),
            "status": status,
            "frequency": int(frequency),
            "count": int(count),
            "body": body,
            "head": head,
            "warning": int(warning),
            "nodes": nodes,
            "keyword": keyword,
            "warning_mode": int(warning_mode),
            'push_methods': push_methods,
            'is_basic': int(is_basic),
            'bs_user': ase_bs_user,
            'bs_pwd': ase_bs_pwd,
        }

        # 扫描添加 可能批量
        if int(add_type) == 1:
            url_list = url.split(',')  # https://111,https://222
            for i in url_list:
                temp['add_type'] = 1
                temp['url'] = i
                temp['task_name'] = i
                # 校验任务名是否存在
                if basic_monitor_obj.db_easy('availability_http').where("uid=? AND url=?",
                                                                        [uid, temp['url']]).exists():
                    fail_task.append(i)
                    continue
                with monitor_db_manager.db_mgr('availability_http') as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        db.query().name('availability_http').insert(temp)

                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 打印异常堆栈
                        public.print_exc_stack(e)
                        return public.error(f'添加失败:{e}')
                public.WriteLog('业务监控', '添加HTTP监控任务[%s] 成功' % i)
        else:
            # 校验任务名是否存在
            if basic_monitor_obj.db_easy('availability_http').where("uid=? AND task_name=?", [uid, task_name]).exists():
                return public.error('任务名已存在')

            # 单独添加的 校验域名
            boo, data = self.data_check(url, 'url')
            if boo is False:
                return public.error(data)

            temp['add_type'] = 0
            temp['url'] = url
            temp['task_name'] = task_name
            # 添加 http配置表
            with monitor_db_manager.db_mgr('availability_http') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query().name('availability_http').insert(temp)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    return public.error(f'添加失败:{e}')
            public.WriteLog('业务监控', '添加HTTP监控任务[%s] 成功' % task_name)
        if len(fail_task) > 0:
            return public.success("添加http监控任务  部分任务添加失败: {} 原因:重名".format(fail_task))
        return public.success("添加http监控任务成功!")

    def remove_http_task(self, args):
        '''
        @name 删除http/https监控任务
        @author <2023-02-25>
        @return dict
        '''
        # 接收要删除的任务列表 逗号隔开
        ids = args.get('ids', None)

        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')

        # 批量删除
        for i in id_list:
            data = basic_monitor_obj.db_easy('availability_http') \
                .where('id=?', int(i)) \
                .find()

            basic_monitor_obj.db_easy('availability_http') \
                .where('id=?', int(i)) \
                .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_http_info') \
                .where('http_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('type', 'http监控告警')\
                .where('task_id=?', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除HTTP监控任务[%s] 成功' % data['task_name'])
        return public.success('删除HTTP监控任务成功')

    def update_http_task(self, args):
        '''
        @name 编辑/修改http/https监控任务
        @author <2023-02-25>
        @return dict
        '''
        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')
        dicts = {}
        old = basic_monitor_obj.db_easy('availability_http').where("id=?", id_).find()
        # old = basic_monitor_obj.db_easy('availability_http').where("uid=? AND id=?", [uid, id_]).find()
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_http') \
                            .where("uid=? AND task_name=?", [uid, ta_name]) \
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "url" in args:
            new_data["url"] = args.get('url')
            if old['url'] != new_data["url"]:
                dicts['url修改为'] = new_data["url"]

        if "method" in args:
            new_data["method"] = int(args.get('method'))
            if old['method'] != new_data["method"]:
                dicts['请求方法修改为'] = 'get' if new_data["method"] == 0 else 'post'

        if "status" in args:
            new_data["status"] = args.get('status')
            if old['status'] != new_data["status"]:
                dicts['匹配的状态码修改为'] = new_data["status"]

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "keyword" in args:
            new_data["keyword"] = args.get('keyword')
            if old['keyword'] != new_data["keyword"]:
                dicts['关键字修改为'] = new_data["keyword"]

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "is_basic" in args:
            new_data["is_basic"] = int(args.get('is_basic'))
            if old['is_basic'] != new_data["is_basic"]:
                dicts['basic认证'] = '关闭' if new_data["is_basic"] == 0 else '开启'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "bs_user" in args:
            bs_user = args.get('bs_user')
            if old['bs_user'] != bs_user:
                new_data["bs_user"] = public.encrypt_password(bs_user)
                dicts['basic认证'] = '修改用户名'

        if "bs_pwd" in args:
            bs_pwd = args.get('bs_pwd')
            if old['bs_pwd'] != bs_pwd:
                new_data["bs_pwd"] = public.encrypt_password(bs_pwd)
                dicts['basic认证'] = '修改密码'

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "body" in args:
            new_data["body"] = args.get('body')
        if "head" in args:
            new_data["head"] = args.get('head')
        if "warning_mode" in args:
            new_data["warning_mode"] = args.get('warning_mode')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')
        if len(new_data['nodes']) < 1:
            return public.error('请选择节点')
        if len(new_data) > 0:
            new_data["update_time"] = int(time.time())
        with monitor_db_manager.db_mgr('availability_http') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('availability_http') \
                    .where("id=?", id_) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e
            # 记录日志
            info = basic_monitor_obj.db_easy('availability_http') \
                .where("id=?", id_) \
                .find()
            # IP 端口 被修改
            if dicts:
                public.WriteLog('业务监控', '修改HTTP监控任务成功!  原名[%s] 现为[%s]  %s' % (
                old['task_name'], info['task_name'], dicts))
            else:
                public.WriteLog('业务监控', '修改HTTP监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改HTTP监控任务成功')

    def suspend_http_task(self, args):
        '''
        @name 批量暂停ping监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_http').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_http') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_http') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停http监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停http监控任务成功')

    def get_server_urls(self, args):
        '''
        @name 获取服务器下的域名
        @args
        '''

        # 先从缓存取上次执行时间 缓存没有 取数据库取
        server_url_ = public.cache_get(f"get_server_urls")
        if server_url_:
            # public.print_log(f'有缓存 从缓存取')
            server_url = json.loads(server_url_)

        else:
            # public.print_log(f' 无缓存 查数据库')
            # 获取当前时间
            cur_time = int(time.time())

            # nginx进程id
            pne_id =warning_obj.db_easy('process_name_exe')\
                .where('name=?', 'nginx')\
                .value('id')

            # nginx进程id对应的sid
            sids = warning_obj.db_memory('processes')\
                .where('pne_id=?', pne_id) \
                .where('update_time > ?', cur_time - 120) \
                .field('sid') \
                .column('sid')
            # 去重
            sids = list(set(sids))

            # 配置了nginx的服务器
            sid_list = warning_obj.db_easy('servers')\
                .where_in('sid', sids)\
                .field('sid', 'ip', 'remark')\
                .select()

            # 配置了nginx的服务器
            server_url = []
            for i in sid_list:
                with monitor_db_manager.MonitorDbManager(i['sid']).db_mgr('nginx_stats_info') as db:
                    # nginx_stats_info = db.query().name('nginx_stats_info').find()
                    website_list = db.query().name('nginx_stats_info').value('website_list')

                    if website_list is None:
                        continue

                    website_list1 = json.loads(website_list) if isinstance(website_list, str) else website_list

                    website_list1 = [item for item in website_list1 if len(item["domain_list"]) != 0]

                    for item in website_list1:
                        domain_list = []
                        for j in item['domain_list']:
                            # 域名或ip检测
                            boou, data1 = self.data_check(j, 'u/i')
                            if boou is False:
                                public.print_log('^^^^^^^^获取服务器下的域--域名或ip校验不通过的跳过^^^^^^^^^^^^^^')
                                continue
                            else:
                                domain_list.append(j)
                        item['domain_list'] = domain_list
                    website_list1 = [item for item in website_list1 if len(item["domain_list"]) != 0]
                    nginx_stats_info = {'sid': i['sid'],
                                        's_ip': i['ip'],
                                        's_remark': i['remark'],
                                        "website_list": website_list1}

                    server_url.append(nginx_stats_info)
            server_url_ = json.dumps(server_url, ensure_ascii=False)

            # 缓存执行完的时间
            public.cache_set("get_server_urls", server_url_, 600)

        return public.success(server_url)

    # 获取最近n秒内的业务监控执行结果
    def __get_last_n_seconds_results(self, table_name, relation_field, per_task=10, extra_fields=(), last_seconds=1800):
        """
            @name 获取最近n秒内的业务监控执行结果
            @author Zhj<2023-05-16>
            @param  table_name<string>       业务监控对应的结果表名称
            @param  relation_field<string>   关联字段
            @param  per_task<integer>        每个任务最多取多少个结果
            @param  extra_fields<tuple|list> 额外获取的字段
            @param  last_seconds<int>        最近n秒
            @return dict[integer]dict
        """
        max_id = basic_monitor_obj.db_easy(table_name) \
            .where('uid > 0') \
            .where('create_time > ?', int(time.time()) - last_seconds) \
            .value('id')

        raw_results = basic_monitor_obj.db_easy(table_name) \
            .where('id >= ?', max_id) \
            .field('id', relation_field, 'create_time', *extra_fields) \
            .select()

        raw_results.sort(key=lambda x: x['create_time'], reverse=True)

        results = {}
        for result in raw_results:
            if result[relation_field] not in results:
                results[result[relation_field]] = [result]
                continue

            if len(results[result[relation_field]]) - 1 > per_task:
                continue

            results[result[relation_field]].append(result)

        return results

    # 获取最近n条业务监控执行结果
    def __get_latest_results(self, table_name, relation_field, per_task=20, extra_fields=(), task_ids=()):
        """
            @name 获取最近n条业务监控执行结果
            @author Zhj<2023-05-16>
            @param  table_name<string>        业务监控对应的结果表名称
            @param  relation_field<string>    关联字段
            @param  per_task<integer>         每个任务最多取多少个结果
            @param  extra_fields<tuple|list>  额外获取的字段
            @param  task_ids<tuple|list>      监控任务ID列表[可选 默认全部]
            @return dict[integer]dict
        """
        # 获取最近两小时内的监控结果
        return self.__get_last_n_seconds_results(table_name, relation_field, per_task, extra_fields, 7200)

        # 没有指定监控任务ID时，获取最近半小时内的监控结果
        if len(task_ids) == 0:
            return self.__get_last_n_seconds_results(table_name, relation_field, per_task, extra_fields, 1800)

        s_time = time.time()
        e_time = s_time
        total_query_time = None
        avg_time = None
        query_time = None
        sort_time = None
        n = 0

        result_ids = []
        for task_id in task_ids:
            result_ids += basic_monitor_obj.db_easy(table_name) \
                .where(relation_field, task_id) \
                .order('id', 'desc') \
                .limit(per_task) \
                .column('id')
            n += 1

        tmp_time = time.time()
        total_query_time = int((tmp_time - e_time) * 1000)
        avg_time = int(total_query_time / n)
        e_time = tmp_time

        raw_results = basic_monitor_obj.db_easy(table_name) \
            .where_in('id', result_ids) \
            .field('id', relation_field, 'create_time', *extra_fields) \
            .select()

        tmp_time = time.time()
        query_time = int(int((tmp_time - e_time) * 1000) / n)
        e_time = tmp_time

        raw_results.sort(key=lambda x: x['create_time'], reverse=True)

        tmp_time = time.time()
        sort_time = int(int((tmp_time - e_time) * 1000) / n)
        e_time = tmp_time

        results = {}
        for result in raw_results:
            if result[relation_field] not in results:
                results[result[relation_field]] = [result]
                continue

            if len(results[result[relation_field]]) - 1 > per_task:
                continue

            results[result[relation_field]].append(result)

        # public.print_log('>>> __GET_LATEST_RESULTS__ <<<\nCOST_TIME: {}ms\nTOTAL_QUERY_TIME: {}ms\nAVG_TIME: {}ms\nQUERY_TIME: {}ms\nSORT_TIME: {}ms'.format(int((e_time - s_time) * 1000), total_query_time, avg_time, query_time, sort_time))

        return results

    # 统计业务监控任务状态
    def __summary_latest_results(self, table_name, relation_field, judge_field, total=None):
        """
            @name 统计业务监控任务状态
            @author Zhj<2023-05-16>
            @param  table_name<string>      业务监控对应的结果表名称
            @param  relation_field<string>  关联字段
            @param  judge_field<string>     判断结果状态的字段名
            @param  total<?int>             监控任务总数
            @return (online_count, offline_count)
        """
        offline_count = 0

        # 获取最近半小时内监控结果为正常的任务数
        online_count = basic_monitor_obj.db_easy(table_name)\
            .where('uid > 0') \
            .where('create_time > ?', int(time.time()) - 1800) \
            .where(judge_field, 1) \
            .value('count(distinct `{}`)'.format(relation_field)) or 0

        if total is not None:
            offline_count += max(0, total - (online_count + offline_count))

        return (online_count, offline_count)

    # 获取全部主机信息
    def __get_servers(self):
        servers = warning_obj.db_easy('servers')\
            .field('sid', 'ip', 'remark')\
            .where('type', 0) \
            .select()

        # 组装主机在线状态
        for server_info in servers:
            _, _, server_info['status'] = basic_monitor_obj.cache_server_status(server_info['sid'])

        return servers

    # 根据业务监控任务列表获取主机信息
    def __get_servers_by_tasks(self, tasks):
        """
            @name 根据业务监控任务列表获取主机信息
            @author Zhj<2023-05-16>
            @param  tasks<list> 业务监控任务列表
            @return dict[integer]dict
        """
        servers = warning_obj.db_easy('servers') \
            .where_in('sid', list(set(reduce(lambda x, y: x + y['nodes'].split(','), tasks, [])))) \
            .field('sid', 'ip', 'remark')\
            .column(None, 'sid')

        # 组装主机在线状态
        for sid in servers.keys():
            _, _, servers[sid]['status'] = basic_monitor_obj.cache_server_status(sid)

        return servers

    # 组装节点列表
    def __get_nodes_by_tasks(self, tasks, servers=None):
        """
            @name 组装节点列表
            @author Zhj<2023-05-16>
            @param  tasks<list>     业务监控任务列表
            @param  servers<dict>   主机信息
            @return dict[integer]dict
        """
        if servers is None:
            servers = self.__get_servers_by_tasks(tasks)

        internal_ips, _ = basic_monitor_obj.get_server_ip()

        nodes = {}
        for task in tasks:
            node_list = task['nodes'].split(',')
            nodes[task['id']] = []
            if len(node_list) == 0:
                continue
            for node in node_list:
                server_info = servers.get(int(node), None)
                if server_info is None:
                    continue

                nodes[task['id']].append({
                    'node_remark': server_info['remark'] if server_info['remark'] else '',
                    'node_ip': server_info['ip'],
                    'node_state': server_info['status'],
                })

            if '0' in node_list:
                nodes[task['id']].append({
                    'node_remark': '主控',
                    'node_ip': internal_ips[0],
                    'node_state': None,
                })

        return nodes

    # 读写和写入业务监控任务最新执行时间
    def __cache_latest_execute_time(self, table_name, relation_field, task_id, cur_execute_time=None, execute_type='NORMAL'):
        """
            @name 读写和写入业务监控任务最新执行时间
            @author Zhj<2023-05-16>
            @param  table_name<string>      业务监控对应的结果表名称
            @param  relation_field<string>  关联字段
            @param  task_id<int>            任务ID
            @param  cur_execute_time<?int>  任务最新执行时间 不为None时表示更新缓存
            @param  execute_type<string>    执行类型
            @return int
        """
        cache_key = 'AVAILABILITY_TASK_LATEST_EXECUTE_TIME_{}_{}__{}'.format(table_name, execute_type.upper(), task_id)
        if cur_execute_time is not None:
            public.cache_set(cache_key, cur_execute_time, 600)
            return cur_execute_time

        ret = public.cache_get(cache_key)

        if ret is None:
            sub_query = basic_monitor_obj.db_easy(table_name)\
                .where(relation_field, task_id) \
                .field('max(id)')\
                .build_sql(True)

            ret = basic_monitor_obj \
                .db_easy(table_name) \
                .where('`id` = {}'.format(sub_query)) \
                .value('create_time') or 0

            public.cache_set(cache_key, ret, 600)

        return ret

    # 计算上一次离线时间
    def __calculate_last_offline_time(self, results, judge_field):
        """
            @name 计算上一次离线时间
            @author Zhj<2023-05-17>
            @param  results<list>       某个任务的结果列表，按创建时间降序排序
            @param  judge_field<string> 判断结果状态的字段名
            @return int
        """
        cur_time = int(time.time())
        last_offline_time = None
        latest_online_time = None
        last_is_ok = None
        for result in results:
            if int(result[judge_field]) == 0:
                last_is_ok = False
                last_offline_time = result['create_time']

                if latest_online_time is None:
                    break

                continue

            if last_is_ok is not None and not last_is_ok:
                break

            last_is_ok = True
            latest_online_time = result['create_time']

        return max((latest_online_time or cur_time) - (last_offline_time or cur_time), 0)

    # 计算平均值
    def __calculate_avg(self, results, field):
        """
            @name 计算平均值
            @author Zhj<2023-02-17>
            @param  results<list>   某个任务的结果列表，按创建时间降序排序
            @param  field<string>   字段名
            @return float
        """
        if len(results) == 0:
            return 0

        return round(reduce(lambda x, y: x + int(y[field] or 0), results, 0) / len(results), 2)

    # 获取最近一小时的时间戳
    def __get_query_onehour(self):
        """获取最近一小时的时间戳 """
        end_time = int(time.time())
        start_time = end_time - 3600
        # 时间转格式yyyymmddhhiiss
        start_time = time.strftime('%Y%m%d%H%M%S', time.localtime(start_time))
        end_time = time.strftime('%Y%m%d%H%M%S', time.localtime(end_time))
        query_date = start_time + '-' + end_time
        # public.print_log('监控时间段~~~    {}'.format(query_date))
        return query_date

    # 判断是否要进行告警
    def __is_warning(self, temp, flag, cur_time, loss_ratio=None, delay=None, task_type='http'):
        """
            @name 判断是否要进行告警
            @param  temp<string>        当前任务信息
            @param  flag<bool>          当前任务是否成功
            @param  time<string>        当前时间 格式: 2020-01-01 00:00:00
            @param  task_type<string>   任务类型 默认http/port, ping判断与http/port不同
            @return bool, string, string, int   是否告警, 告警内容, 告警时间, 告警累计次数
        """
        notify_content = ''
        times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
        # a = temp['retries']
        # http监控 port监控
        if task_type in ['http', 'port']:
            # 失败时告警  设置了失败且失败
            # public.print_log('!!!!!!!!!!!!!!!!!!!!!http/端口判断条件 warning_mode {}-->{} '.format(temp['warning_mode'],int(flag)), _level='error')
            for _ in range(1):
                if temp['warning_mode'] == 0 and int(flag) == 0:
                    notify_content = '匹配失败'
                    temp['retries'] += 1
                    break

                # 成功时告警 设置了成功且成功
                if temp['warning_mode'] == 1 and int(flag) == 1:
                    notify_content = '匹配成功'
                    temp['retries'] += 1
                    break

                # 未匹配到阈值，重置重试次数
                temp['retries'] = 0
                break

        # ping
        if task_type == 'ping':
            for _ in range(1):
                if loss_ratio is None or float(loss_ratio) >= float(temp['w_loss_ratio']):
                    notify_content = '丢包率大于或等于{}%'.format(temp['w_loss_ratio'])
                    temp['retries'] += 1
                    break

                if delay is None or float(delay) > float(temp['w_delay']):
                    notify_content = '延迟大于{}毫秒'.format(temp['w_delay'])
                    temp['retries'] += 1
                    break

                # 未匹配到阈值，重置重试次数
                temp['retries'] = 0
                break

        # b = temp['retries']
        # public.print_log('!!!!!!!!!!!!!!!!!!!!!!!!!! 重试累加 变化 {}-->{} '.format(a, b), _level='error')

        # 满足告警条件 进行告警
        if temp['retries'] >= temp['count'] and self.__warning_threshold(task_type, temp['id']):
            return True, notify_content, times, 0

        return False, notify_content, times, temp['retries']

    # 更新监控任务信息
    def __update_task_info(self, task_type, task_id, retries=None, can_do_warning=False, cur_time=None):
        """
            @name 更新监控任务信息
            @author Zhj<2023-06-05>
            @param task_type<str>       监控任务类型
            @param task_id<int>         监控任务ID
            @param retries<int>         重试次数
            @param can_do_warning<bool> 是否告警
            @param cur_time<int>        当前时间戳
            @return None
        """
        update_info = {}

        if retries is not None:
            update_info['retries'] = int(retries)

        if can_do_warning:
            update_info['last_warning_time'] = int(cur_time or time.time())

        if len(update_info.keys()) == 0:
            return

        table_name_map = {
            'http': 'availability_http',
            'port': 'availability_port',
            'ping': 'availability_ping',
        }

        if task_type not in table_name_map:
            raise RuntimeError('invalid task_type {}'.format(task_type))

        basic_monitor_obj.db_easy(table_name_map[task_type]) \
            .where('id', task_id)\
            .update(update_info)

    # 告警推送限流 -> bool
    def __warning_threshold(self, task_type, task_id):
        """
            @name 告警推送限流
            @author Zhj<2023-06-06>
            @param task_type<str>   任务类型
            @param task_id<int>     任务ID
            @return bool
        """
        cur_time = int(time.time())
        warnings_last_day = basic_monitor_obj.db_easy('availability_wanrning_log') \
            .where('task_id', task_id) \
            .where('type', '{}监控告警'.format(task_type)) \
            .where('create_time > ?', cur_time - 86400) \
            .field('create_time')\
            .order('create_time', 'desc')\
            .column('create_time')

        warning_count = len(warnings_last_day)

        if warning_count == 0:
            return True

        latest_warning_time = warnings_last_day[0]

        for cnt, interval in self.__WARNING_THRESHOLD_RULES:
            if warning_count >= cnt:
                return cur_time > latest_warning_time + (interval * 60)

        return True
