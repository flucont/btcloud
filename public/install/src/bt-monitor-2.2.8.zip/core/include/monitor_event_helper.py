# encoding: utf-8
#
# 注册通用事件模块
# Author Zhj<2023-03-23>

import core.include.public as public
from core.include.monitor_helpers import monitor_task_queue

monitor_events = public.import_via_loader('{}/core/include/monitor_events.py'.format(public.get_panel_path()))
monitor_handlers = public.import_via_loader('{}/core/include/monitor_handlers.py'.format(public.get_panel_path()))


def __get_class_name(obj_or_class):
    '''
        @name 获取类或对象的类名
        @author Zhj<2023-03-23>
        @param  obj_or_class<mixed> 对象或类
        @return string
    '''
    return str(obj_or_class)[8:-2].split('.')[-1]


# 事件注册表
events = {
    # 用户登录成功事件
    __get_class_name(monitor_events.UserLoginSuccess): [
        __get_class_name(monitor_handlers.SubmitStatistics),  # 提交统计数据
    ],

    # 堡塔账号绑定成功事件
    __get_class_name(monitor_events.AccountBoundSuccess): [
        __get_class_name(monitor_handlers.SubmitStatistics),  # 提交统计数据
    ],

    # 主机授权事件
    __get_class_name(monitor_events.ServerAuthorization): [
        __get_class_name(monitor_handlers.SubmitStatistics),  # 提交统计数据
        __get_class_name(monitor_handlers.ApplyServerDefaultTemplateRules),  # 应用默认告警模板到主机
        __get_class_name(monitor_handlers.CreateServerWarningRules),  # 尝试新建关联所有主机的告警规则
    ],

    # 主机删除成功事件
    __get_class_name(monitor_events.ServerRemoved): [
        __get_class_name(monitor_handlers.UpdateServerPosition),  # 更新首页监控大屏主机位置信息
        # TODO 清除/dev/shm/数据库中主机相关的信息
        __get_class_name(monitor_handlers.DeleteProcessMonitoring),  # 删除进程监控数据
        __get_class_name(monitor_handlers.DeleteServerBugs),  # 删除主机漏洞统计
        __get_class_name(monitor_handlers.DeleteServerMinings),  # 删除主机挖矿木马统计
        __get_class_name(monitor_handlers.DeleteServerMaliciousRecords),  # 删除主机病毒扫描记录
        __get_class_name(monitor_handlers.DeleteServerWarningRules),  # 删除关联的主机告警规则
    ],

    # 主机分组设置成功事件
    __get_class_name(monitor_events.ServerGroupSetting): [
        __get_class_name(monitor_handlers.UpdateServerWarningRulesWhenGroupSetting),  # 更新主机分组关联的主机告警规则
    ],

    # 主机分组删除事件
    __get_class_name(monitor_events.ServerGroupRemoved): [
        __get_class_name(monitor_handlers.DeleteWarningRulesWhenGroupRemoved),  # 删除主机分组关联的告警规则
    ],
}


# 注册事件
def register(event, handlers):
    if __get_class_name(event) not in events:
        events[__get_class_name(event)] = []

    if not isinstance(handlers, list):
        handlers = [handlers]

    events[__get_class_name(event)].extend(list(map(lambda x: __get_class_name(x), handlers)))

    return True


# 移除事件
def unregister(event, handlers=None):
    if __get_class_name(event) not in events:
        return True

    if handlers is None:
        del (events[__get_class_name(event)],)
        return True

    if not isinstance(handlers, list):
        handlers = [handlers]

    handlers = list(map(lambda x: __get_class_name(x), handlers))

    events[__get_class_name(event)] = list(filter(lambda x: x not in handlers, events[__get_class_name(event)]))

    return True


# 触发事件
def fire(event_obj):
    # 推送至队列中执行
    monitor_task_queue.add_task_easy(__fire, event_obj)

    return True


# 触发事件帮助函数
def __fire(event_obj):
    if __get_class_name(event_obj) not in events:
        return

    for handler in events[__get_class_name(event_obj)]:
        obj = getattr(monitor_handlers, handler)()

        if not isinstance(obj, monitor_handlers.BaseHandler):
            raise RuntimeError('{}'.format(obj))

        if getattr(obj, 'handle')(event_obj) is False:
            break
