# encoding: utf-8
#
# 云监控告警 检测函数与处理函数
# Author Zhj<2022-06-25>

import core.include.public as public
import json, time, re
from core.include.monitor_helpers import warning_obj as warning_obj_common, basic_monitor_obj, monitor_task_queue

# from core.include.monitor_db_manager import MonitorDbManager

MonitorDbManager = public.import_via_loader(
    '{}/core/include/monitor_db_manager.py'.format(public.get_panel_path())).MonitorDbManager


# |-----------------------------------
# | 资源
# |-----------------------------------


#   检查主机CPU使用率是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resouce_cpu_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''

        @param  warning_config<dict>                        告警规则
        @param  cur_percent<number>                         当前CPU使用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        # 获取用户设置时间内cpu平均占用率
        cur_percent = warning_obj.db_memory('server_cpu_info_list') \
            .where(
            '`sid` = ? AND `create_time` > ?',
            [int(warning_config['sid']), int(time.time()) - int(warning_config['duration'])]
        ).avg('percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前CPU使用率为[{}]'.format(warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


#   检查主机内存占用率是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resource_mem_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>                        告警规则
        @param  cur_percent<number>                         当前内存占用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        # 获取用户设置时间内内存平均占用率
        cur_percent = warning_obj.db_memory('server_mem_info_list') \
            .where(
            '`sid` = ? AND `create_time` > ?',
            [int(warning_config['sid']), int(time.time()) - int(warning_config['duration'])]
        ).avg('percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前内存占用率为[{}]'.format(warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


#   检查主机内存已占用空间是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resouce_mem_used(warning_config, cur_used=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict> 告警规则
        @param  cur_used<number>     当前内存已占用空间[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_used is None:
        # 获取用户设置时间内平均内存占用
        cur_used = warning_obj.db_memory('server_mem_info_list') \
            .where(
            '`sid` = ? AND `create_time` > ?',
            [int(warning_config['sid']), int(time.time()) - int(warning_config['duration'])]
        ).avg('used')

    if not warning_obj.compare(warning_config, cur_used):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前内存占用为[{}]'.format(warning_obj.transform_value(cur_used, 'bytes'))
    )

    return True


#   检查主机swap占用率是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resource_swap_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @param warning_config<dict> 告警规则
        @param cur_percent<number>  当前swap占用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        # 获取用户设置时间内swap平均占用率
        cur_percent = warning_obj.db_memory('server_swap_info_list') \
            .where(
            '`sid` = ? AND `create_time` > ?',
            [int(warning_config['sid']), int(time.time()) - int(warning_config['duration'])]
        ).avg('percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前swap占用率为[{}]'.format(warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


#   检查主机swap占用空间是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resource_swap_used(warning_config, cur_used=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict> 告警规则
        @param  cur_used<number>     当前swap占用空间[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_used is None:
        # 获取用户设置时间内swap平均占用
        cur_used = warning_obj.db_memory('server_swap_info_list') \
            .where(
            '`sid` = ? AND `create_time` > ?',
            [int(warning_config['sid']), int(time.time()) - int(warning_config['duration'])]
        ).avg('used')

    if not warning_obj.compare(warning_config, cur_used):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前swap占用为[{}]'.format(warning_obj.transform_value(cur_used, 'bytes'))
    )

    return True


#   检查主机磁盘占用率是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resource_disk_used_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前磁盘占用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'used_percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    mountpoint = warning_obj.get_var(warning_config['sub_type'])

    disk_list = warning_obj.db_easy('server_details') \
        .where('sid=?', warning_config.get('sid', 0)) \
        .value('disk_info')

    disk_list = json.loads(disk_list)

    total = ''
    free = ''
    for disk_txt in disk_list:
        mount = disk_txt.get('mountpoint', None)
        if mountpoint == mount:
            total = disk_txt.get('total', None)
            free = disk_txt.get('free', None)

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] 占用率为[{}] 剩余容量[{}Gb可用]'.format(warning_obj.get_var(warning_config['sub_type']),
                                       warning_obj.transform_value(cur_percent, 'percent'),
                                      round(free / 1024 ** 3), 2)
    )
    return True


#   检查主机磁盘inode占用率是否匹配告警规则 如果匹配则告警 否则跳过
def handle_resource_disk_inodes_used_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前磁盘inode占用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'inodes_used_percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] inode占用率为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                            warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


def handle_resource_disk_iops(warning_config, cur_iops=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘iops是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_iops<number>     当前磁盘iops[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_iops is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'iops')

    if not warning_obj.compare(warning_config, cur_iops):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] iops为[{}]'.format(warning_obj.get_var(warning_config['sub_type']), cur_iops)
    )

    return True


def handle_resource_disk_io_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘io耗时占比是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前磁盘io耗时占比[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'io_percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] IO耗时占比为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                           warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


def handle_resource_disk_used(warning_config, cur_used=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘已占用空间是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_used<number>     当前磁盘已占用空间[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_used is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'used')

    if not warning_obj.compare(warning_config, cur_used):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] 占用空间为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                         warning_obj.transform_value(cur_used, 'bytes'))
    )

    return True


def handle_resource_disk_inodes_used(warning_config, cur_used=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘inode已占用空间是否匹配告警规则 如果匹配则告警 否则跳过
        @param warning_config<dict> 告警规则
        @param cur_used<number>     当前磁盘inode已占用空间[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_used is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'inodes_used')

    if not warning_obj.compare(warning_config, cur_used):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前inode占用率为[{}]'.format(warning_obj.transform_value(cur_used, 'bytes'))
    )

    return True


def handle_resource_disk_read_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘每秒读取字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前磁盘每秒读取字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'read_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] 每秒读取速率为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                             warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_disk_write_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机磁盘每秒写入字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前磁盘每秒写入字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_resource_disk_helper(warning_config, 'write_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '磁盘[{}] 每秒写入速率为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                             warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_net_sent(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机网卡发送总字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前网卡发送总字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控的网卡名称
    net_name = warning_obj.get_var(warning_config['sub_type'])

    if net_name is None:
        return False

    # 匹配告警规则
    if cur_bytes is None:
        # 获取网卡列表
        net_info_list = warning_obj.cache_realtime_server_info(warning_config['sid']).get('net_info', [])

        ok = False

        # 遍历网卡列表 对比规则
        for net_info in net_info_list:
            if net_name == net_info['name']:
                # ok = warning_obj.compare(warning_config, net_info['sent'])
                cur_bytes = net_info['sent']
                break

            if net_name == 'all' and warning_obj.compare(warning_config, net_info['sent']):
                ok = True

                # 添加告警任务
                warning_obj.add_task(
                    warning_config,
                    '网卡[{}] 当前上传总流量为[{}]'.format(net_info['name'],
                                                           warning_obj.transform_value(net_info['sent'], 'bytes'))
                )

        if cur_bytes is None:
            return ok

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '网卡[{}] 上传总流量为[{}]'.format(net_name, warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_net_recv(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机网卡接收总字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前网卡接收总字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控的网卡名称
    net_name = warning_obj.get_var(warning_config['sub_type'])

    if net_name is None:
        return False

    # 匹配告警规则
    if cur_bytes is None:
        # 获取网卡列表
        net_info_list = warning_obj.cache_realtime_server_info(warning_config['sid']).get('net_info', [])

        ok = False

        # 遍历网卡列表 对比规则
        for net_info in net_info_list:
            if net_name == net_info['name']:
                # cur = warning_obj.compare(warning_config, net_info['recv'])
                cur_bytes = net_info['recv']
                break

            if net_name == 'all' and warning_obj.compare(warning_config, net_info['recv']):
                ok = True

                # 添加告警任务
                warning_obj.add_task(
                    warning_config,
                    '网卡[{}] 当前下载总流量为[{}]'.format(net_info['name'],
                                                           warning_obj.transform_value(net_info['recv'], 'bytes'))
                )

        if cur_bytes is None:
            return ok

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '网卡[{}] 下载总流量为[{}]'.format(net_name, warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_net_sent_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机网卡每秒发送字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前网卡每秒发送字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_resource_net_helper(warning_config, 'sent_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '网卡[{}] 每秒上传速率为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                             warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_net_recv_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机网卡每秒接收字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_bytes<number>    当前网卡每秒接收字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_resource_net_helper(warning_config, 'recv_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '网卡[{}] 每秒下载速率为[{}]'.format(warning_obj.get_var(warning_config['sub_type']),
                                             warning_obj.transform_value(cur_bytes, 'bytes'))
    )

    return True


def handle_resource_load_avg_last_1_min(warning_config, cur_val=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机最近1分钟内负载是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_val<number>         当前负载[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


def handle_resource_load_avg_last_5_min(warning_config, cur_val=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机最近5分钟内负载是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_val<number>         当前负载[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


def handle_resource_load_avg_last_15_min(warning_config, cur_val=None, warning_obj=warning_obj_common):
    '''
        @name   检查主机最近15分钟内负载是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_val<number>         当前负载[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


# |--------------------------
# | 服务
# |--------------------------
def handle_service_proc_cpu_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程CPU使用率是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前进程CPU使用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_cpu_info_list', 'percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False
    # public.print_log('匹配进程状态告警规则cpu----将添加告警{}'.format(cur_percent), _level='error')
    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前CPU使用率为[{}]'.format(warning_obj.transform_value(cur_percent, 'percent'))
    )
    # public.print_log('匹配进程状态告警规则cpu----将执行脚本{}'.format(cur_percent), _level='error')
    # # 执行脚本
    # public.custom_exec_script(warning_config)

    return True


def handle_service_proc_mem_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程内存占用率是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前进程内存占用率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_percent is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_mem_info_list', 'percent')

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前内存占用率为[{}]'.format(warning_obj.transform_value(cur_percent, 'percent'))
    )
    # # 执行脚本
    # public.custom_exec_script(warning_config)
    return True


def handle_service_proc_disk_io_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程磁盘IO耗时占比是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict> 告警规则
        @param  cur_percent<number>  当前进程磁盘IO耗时占比[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


def handle_service_proc_disk_read_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程磁盘每秒读取字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_bytes<number>       当前进程磁盘每秒读取字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_disk_io_info_list',
                                                          'read_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前磁盘每秒读取速率为[{}]'.format(warning_obj.transform_value(cur_bytes, 'bytes'))
    )
    # # 执行脚本
    # public.custom_exec_script(warning_config)
    return True


def handle_service_proc_disk_write_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程磁盘每秒写入字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_bytes<number>       当前进程磁盘每秒写入字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_disk_io_info_list',
                                                          'write_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前磁盘每秒写入速率为[{}]'.format(warning_obj.transform_value(cur_bytes, 'bytes'))
    )
    # # 执行脚本
    # public.custom_exec_script(warning_config)
    return True


def handle_service_proc_net_sent_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程网络每秒发送字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_bytes<number>       当前进程网络每秒发送字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_network_io_info_list',
                                                          'sent_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前网络每秒上传速率为[{}]'.format(warning_obj.transform_value(cur_bytes, 'bytes'))
    )
    # # 执行脚本
    # public.custom_exec_script(warning_config)
    return True


def handle_service_proc_net_recv_per_second(warning_config, cur_bytes=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程网络每秒接收字节数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_bytes<number>       当前进程网络每秒接收字节数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if cur_bytes is None:
        return warning_obj.compare_service_process_helper(warning_config, 'process_network_io_info_list',
                                                          'recv_bytes_per_second')

    if not warning_obj.compare(warning_config, cur_bytes):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前网络每秒下载速率为[{}]'.format(warning_obj.transform_value(cur_bytes, 'bytes'))
    )
    # # 执行脚本
    # public.custom_exec_script(warning_config)
    return True


# def handle_service_proc_status(warning_config, cur_status = None, warning_obj = warning_obj_common):
#     '''
#         @name   检查进程状态是否匹配告警规则 如果匹配则告警 否则跳过
#         @param  warning_config<dict>    告警规则
#         @param  cur_status<?string>     当前进程活动状态[可选]
#         @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
#         @return bool
#     '''
#     # 匹配告警规则
#     if cur_status is None:
#         parts = str(warning_obj.get_var(warning_config['sub_type'])).split('|', 1)
#
#         if len(parts) < 2:
#             print('failed to call handle_service_proc_status: {}'.format(str(warning_obj.get_var(warning_config['sub_type']))))
#             return False
#
#         # 获取进程名称与启动命令
#         proc_name, boot_command = parts
#
#         pne_id = warning_obj_common.get_pne_id(proc_name, boot_command)
#
#         # 获取当前时间
#         cur_time = int(time.time())
#
#         # 获取进程信息
#         proc_info = warning_obj.db_memory('processes')\
#             .where('sid=?', int(warning_config['sid']))\
#             .where('pne_id=?', pne_id)\
#             .where('update_time > ?', cur_time - 1800)\
#             .order('update_time', 'desc')\
#             .field('id', 'update_time')\
#             .find()
#
#         if proc_info is None:
#             return False
#
#         # 获取进程当前活动状态
#         cur_status = 'active' if proc_info['update_time'] > cur_time - 120 else 'deactive'
#
#         # 计算查询时间范围
#         begin_time = cur_time - 240
#         end_time = cur_time - 120
#
#         # proc_mem_record_exists = False
#         # proc_net_io_record_exists = False
#
#         # 获取进程上次活动状态
#         # 查询进程内存占用记录
#         proc_mem_record_exists = warning_obj.db_memory('process_mem_info_list')\
#             .where('process_id=?', proc_info['id'])\
#             .where('create_time between ? and ?', [begin_time, end_time])\
#             .field('id')\
#             .exists()
#
#         # 查询网络IO记录
#         proc_net_io_record_exists = warning_obj.db_memory('process_network_io_info_list')\
#             .where('process_id=?', proc_info['id'])\
#             .where('create_time between ? and ?', [begin_time, end_time])\
#             .field('id')\
#             .exists()
#
#         # 如果上面两个结果其中一个为True
#         # 则说明进程上一次状态为 活动状态
#         # 否则为 终止状态
#         last_status = 'active' if proc_mem_record_exists or proc_net_io_record_exists else 'deactive'
#
#         # 当本次进程活动状态与上次活动状态相同
#         # 跳过本次告警
#         if cur_status == last_status:
#             return False
#
#     if not warning_obj.compare(warning_config, cur_status):
#         return False
#
#     # 添加告警任务
#     warning_obj.add_task(
#         warning_config,
#         '进程[{}|{}] {}'.format(proc_name, boot_command, '开始活动' if cur_status == 'active' else '停止活动')
#     )
#
#     return True


def handle_service_proc_status(warning_config, cur_status=None, warning_obj=warning_obj_common):
    '''
        @name   检查进程状态是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_status<?string>     当前进程活动状态[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    proc_name = None
    boot_command = None

    # public.print_log('---------------- 开始检测进程状态 -------------------------- {}'.format(cur_status), _level='error')

    # 匹配告警规则
    if cur_status is None:
        parts = str(warning_obj.get_var(warning_config['sub_type'])).split('|', 1)

        # public.print_log('---------------- 开始检测进程状态(1) -------------------------- {}'.format(parts), _level='error')

        if len(parts) < 2:
            print('failed to call handle_service_proc_status: {}'.format(
                str(warning_obj.get_var(warning_config['sub_type']))))
            return False

        # 获取进程名称与启动命令
        proc_name, boot_command = parts
        # 根据进程名称和启动命令获取进程ID
        pne_id = warning_obj_common.get_pne_id(proc_name, boot_command)

        # 获取当前时间
        cur_time = int(time.time())

        # 获取进程信息
        proc_info = warning_obj.db_memory('processes') \
            .where('sid=?', int(warning_config['sid'])) \
            .where('pne_id=?', pne_id) \
            .where('update_time > ?', cur_time - 1800) \
            .order('update_time', 'desc') \
            .field('id', 'update_time') \
            .find()

        # 无进程信息  跳过警告
        if proc_info is None:
            return False

        # 获取进程当前活动状态  两分钟内有修改活跃  无修改不活跃
        cur_status = 'active' if proc_info['update_time'] > cur_time - 120 else 'deactive'

        # public.print_log('---------------- 开始检测进程状态(2) -------------------------- 本次状态： {}'.format(cur_status), _level='error')

        # 进程状态表 是否有历史数据
        proc_active = warning_obj.db_memory('process_active_status') \
            .where('process_id=?', int(proc_info['id'])) \
            .field('id', 'process_id', 'status') \
            .order('id', 'desc') \
            .find()

        # 无数据 插入
        if proc_active is None:
            # 将数据库更新操作推迟至队列中执行
            def __inner_func():
                # 状态已记录，不插入
                if warning_obj.db_memory('process_active_status').where('process_id', int(proc_info['id'])).exists():
                    return

                # 存储进程状态
                warning_obj.db_memory('process_active_status') \
                    .insert({
                        'process_id': int(proc_info['id']),
                        'status': cur_status
                    })

            monitor_task_queue.add_task_easy(__inner_func)

            # 无历史数据 跳过告警
            return False

        # 上次活跃状态
        last_status = proc_active['status']

        # public.print_log(
        #     '---------------- 开始检测进程状态(2) -------------------------- 上一次状态： {}'.format(last_status),
        #     _level='error')

        # 将数据库更新操作推迟至队列中执行
        def __inner_func():
            # 有数据 修改状态
            warning_obj.db_memory('process_active_status') \
                .where('process_id=?', int(proc_info['id'])) \
                .update({'status': cur_status})

        monitor_task_queue.add_task_easy(__inner_func)

        if cur_status == last_status:
            return False

    if not warning_obj.compare(warning_config, cur_status):
        return False

    # 自定义监控添加的告警 如果不推送 则不告警
    if warning_config['add_source'] == 1 and warning_config['is_push'] == 0:
        return False

    # public.print_log('KKKKKKKKKKKKKKKKK warning_functions.py {}即将告警----进程状态{} '.format(proc_name, cur_status), _level='error')

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '进程[{}|{}] {}'.format(proc_name, boot_command, '开始活动' if cur_status == 'active' else '停止活动')
    )
    # 有脚本则执行脚本
    # public.print_log('KKKKKKKKKKKKKKKKK warning_functions.py 状态告警后---{}进程状态{} 将执行脚本'.format(proc_name, cur_status), _level='error')
    # 执行脚本
    public.custom_exec_script(warning_config)
    # public.print_log('KKKKKKKKKKKKKKKKK 执行完脚本 进程', _level='error')
    return True


# |---------------------
# | 端口
# |---------------------

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))


# def handle_port_connection(warning_config, success_to_connect=None, warning_obj=warning_obj_common):
#     '''
#         @name   检查端口连通性是否匹配告警规则 如果匹配则告警 否则跳过
#         @param  warning_config<dict>        告警规则
#         @param  success_to_connect<string>  当前端口连通性(success|fail)[可选]
#         @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
#         @return bool
#     '''
#     # 匹配告警规则
#     if success_to_connect is None:
#         # 获取数据库管理对象
#         db_mgr = MonitorDbManager(warning_config['sid'])
#         # basic_monitor_obj.db_easy('availability_port') \
#         with monitor_db_manager.db_mgr('availability_port_info') as db:
#         # with db_mgr.db_cur_date('availability_port_info') as db:
#             # 获取端口号
#             port_num = warning_obj.get_var(warning_config['sub_type'])
#
#             if port_num is None:
#                 return False
#
#             # 获取当前时间
#             cur_time = int(time.time())
#
#             # 获取监控指标
#             watch_value = 1 if warning_config['watch_value'] == 'success' else 0
#
#             # 监控所有端口
#             if port_num == 'all':
#                 port_list = warning_obj.db_easy('availability_port').where(
#                     '`sid` = ?',
#                     [int(warning_config['sid'])]
#                 ) \
#                     .field('id', 'ip', 'port') \
#                     .select()
#
#                 if warning_obj.is_empty_result(port_list):
#                     return False
#
#                 ok = False
#
#                 # 遍历所有端口
#                 for port_info in port_list:
#                     if re.match(r'^127', port_info['ip']):
#                         continue
#
#                     # 检查最近5分钟内端口是否能正常访问
#                     if not db.query().name('availability_port_info').where(
#                             '`sid` = ? AND `port_id` = ? AND `is_connect` = ? AND `create_time` > ?',
#                             [int(warning_config['sid']), int(port_info['id']), watch_value, cur_time - 300]
#                     ).field('id').exists():
#                         continue
#
#                     ok = True
#
#                     # 添加告警任务
#                     warning_obj.add_task(
#                         warning_config,
#                         '端口[{}] 当前连接状态为[{}]'.format(port_info['port'],
#                                                              '可访问' if watch_value == 1 else '无法访问')
#                     )
#
#                 return ok
#
#             # 监控单个端口
#             else:
#                 # 检查端口号是否合法
#                 if int(port_num) < 1 or int(port_num) > 65535:
#                     return False
#
#                 port_task = warning_obj.db_easy('availability_port') \
#                     .where(
#                     '`sid` = ? AND `port` = ?', [int(warning_config['sid']), int(port_num)])
#
#                 # 检查当前端口是否正在监听中
#                 if not port_task.field('id').exists():
#                     return False
#
#                 # 当前任务id
#                 port_id = port_task.field('id').find()
#
#                 # 获取该端口最近5分钟内是否能正常访问
#                 if not db.query().name('availability_port_info').where(
#                         '`sid` = ? AND `port_id` = ? AND `is_connect` = ? AND `create_time` > ?',
#                         [int(warning_config['sid']), int(port_id['id']), watch_value, cur_time - 300]
#                 ).field('id').exists():
#                     return False
#
#                 success_to_connect = warning_config['watch_value']
#
#     if not warning_obj.compare(warning_config, success_to_connect):
#         return False
#
#     # 添加告警任务
#     warning_obj.add_task(
#         warning_config,
#         '当前连接状态为[{}]'.format('可访问' if watch_value == 1 else '无法访问')
#     )
#
#     return True


def handle_port_faileds_in_last_hour(warning_config, faileds_in_last_hour=None, warning_obj=warning_obj_common):
    '''
        @name   检查最近一个小时内端口连接失败数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>            告警规则
        @param  faileds_in_last_hour<number>    最近一个小时内端口连接失败数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if faileds_in_last_hour is None:
        # 获取数据库管理对象
        # db_mgr = MonitorDbManager(warning_config['sid'])

        with monitor_db_manager.db_mgr('availability_port_info') as db:
            # 获取端口号
            port_num = warning_obj.get_var(warning_config['sub_type'])

            if port_num is None:
                return False

            # 获取当前时间
            cur_time = int(time.time())

            # 监控所有端口
            if port_num == 'all':
                port_list = warning_obj.db_easy('availability_port').where(
                    '`sid` = ? ',
                    [int(warning_config['sid'])]
                ) \
                    .field('id', 'ip', 'port') \
                    .select()

                if warning_obj.is_empty_result(port_list):
                    return False

                ok = False

                # 遍历所有端口
                for port_info in port_list:
                    if re.match(r'^127', port_info['ip']):
                        continue

                    # 查询最近一小时内端口连接失败数
                    faileds_in_last_hour = db.query().name('availability_port_info').where(
                        '`sid` = ? AND `port_id` = ? AND `is_connect` = 0 AND `create_time` > ?',
                        [int(warning_config['sid']), int(port_info['id']), cur_time - 3600]
                    ).count()

                    if warning_obj.compare(warning_config, faileds_in_last_hour):
                        ok = True

                        # 添加告警任务
                        warning_obj.add_task(
                            warning_config,
                            '端口[{}] 最近1小时内端口连接失败数为[{}]'.format(port_info['port'], faileds_in_last_hour)
                        )

                return ok

            # 监控单个端口
            else:
                # 检查端口号是否合法
                if int(port_num) < 1 or int(port_num) > 65535:
                    return False

                port_task = warning_obj.db_easy('availability_port') \
                    .where(
                    '`sid` = ? AND `port` = ?', [int(warning_config['sid']), int(port_num)])

                # 检查当前端口是否正在监听中
                if not port_task.field('id').exists():
                    return False
                # 当前任务id
                port_id = port_task.field('id').find()

                # 查询最近一小时内端口连接失败数
                faileds_in_last_hour = db.query().name('availability_port_info').where(
                    '`sid` = ? AND `port_id` = ? AND `is_connect` = 0 AND `create_time` > ?',
                    [warning_config['sid'], int(port_id['id']), cur_time - 3600]
                ).count()

    if not warning_obj.compare(warning_config, faileds_in_last_hour):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '最近1小时内端口连接失败数为[{}]'.format(faileds_in_last_hour)
    )

    return True


def handle_port_success_percent(warning_config, cur_percent=None, warning_obj=warning_obj_common):
    '''
        @name   检查端口连接成功率是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  cur_percent<number>     当前端口连接成功率[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取端口号
    port_num = warning_obj.get_var(warning_config['sub_type'])

    if port_num is None:
        return False

    # 匹配告警规则
    if cur_percent is None:

        # # 获取数据库管理对象
        # db_mgr = MonitorDbManager(warning_config['sid'])

        with monitor_db_manager.db_mgr('availability_port_info') as db:
            # 获取当前时间
            cur_time = int(time.time())

            # 监控所有端口
            if port_num == 'all':
                port_list = warning_obj.db_easy('availability_port').where(
                    '`sid` = ?', [int(warning_config['sid'])]
                ) \
                    .field('id', 'ip', 'port') \
                    .select()

                if warning_obj.is_empty_result(port_list):
                    return False

                ok = False

                # 遍历所有端口
                for port_info in port_list:
                    if re.match(r'^127', port_info['ip']):
                        continue

                    # 获取端口最近1小时内连接成功率
                    p = db.query().name('availability_port_info').where(
                        '`sid` = ? AND `port_id` = ? AND `create_time` > ?',
                        [warning_config['sid'], int(port_info['id']), cur_time - 3600]
                    ).value(
                        'ROUND(1.0 * SUM(CASE `is_connect` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS `ok_percent`')

                    if p is None:
                        continue
                    # 匹配阈值 warning.py
                    if warning_obj.compare(warning_config, p):
                        ok = True

                        # 添加告警任务
                        warning_obj.add_task(
                            warning_config,
                            '端口[{}] 当前端口连接成功率为[{}]'.format(port_info['port'],
                                                                       warning_obj.transform_value(p, 'percent')))

                return ok

            # 监控单个端口
            else:
                # 检查端口号是否合法
                if int(port_num) < 1 or int(port_num) > 65535:
                    return False

                # 检查当前端口是否正在监听中
                if not warning_obj.db_easy('availability_port').where(
                        '`sid` = ? AND `port` = ? ',
                        [int(warning_config['sid']), int(port_num)]
                ).field('id').exists():
                    return False
                # 根据 端口 sid 找到 任务id
                port_task = warning_obj.db_easy('availability_port').where(
                    '`sid` = ?  AND `port` = ? ', [int(warning_config['sid']), int(port_num)]
                ).find()

                # 获取端口最近1小时内连接成功率
                cur_percent = db.query().name('availability_port_info').where(
                    '`sid` = ? AND `port_id` = ? AND `create_time` > ?',
                    [warning_config['sid'], int(port_task['id']), cur_time - 3600]
                ).value(
                    'ROUND(1.0 * SUM(CASE `is_connect` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')

                if cur_percent is None:
                    return False

    if not warning_obj.compare(warning_config, cur_percent):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '端口[{}]连接成功率为[{}]'.format(port_num, warning_obj.transform_value(cur_percent, 'percent'))
    )

    return True


# def handle_port_connection(warning_config, success_to_connect = None, warning_obj = warning_obj_common):
#     '''
#         @name   检查端口连通性是否匹配告警规则 如果匹配则告警 否则跳过
#         @param  warning_config<dict>        告警规则
#         @param  success_to_connect<string>  当前端口连通性(success|fail)[可选]
#         @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
#         @return bool
#     '''
#     # 匹配告警规则
#     if success_to_connect is None:
#         # 获取数据库管理对象
#         db_mgr = MonitorDbManager(warning_config['sid'])
#
#         with db_mgr.db_cur_date('port_connection_logs') as db:
#             # 获取端口号
#             port_num = warning_obj.get_var(warning_config['sub_type'])
#
#             if port_num is None:
#                 return False
#
#             # 获取当前时间
#             cur_time = int(time.time())
#
#             # 获取监控指标
#             watch_value = 1 if warning_config['watch_value'] == 'success' else 0
#
#             # 监控所有端口
#             if port_num == 'all':
#                 port_list = warning_obj.db_easy('server_ports').where(
#                     '`sid` = ? AND `status` = 1  AND `test_connection` = 1',
#                     [int(warning_config['sid'])]
#                 )\
#                 .field('id', 'ip', 'port')\
#                 .select()
#
#                 if warning_obj.is_empty_result(port_list):
#                     return False
#
#                 ok = False
#
#                 # 遍历所有端口
#                 for port_info in port_list:
#                     if re.match(r'^127', port_info['ip']):
#                         continue
#
#                     # 检查最近5分钟内端口是否能正常访问
#                     if not db.query().name('port_connection_logs').where(
#                         '`sid` = ? AND `port` = ? AND `ok` = ? AND `create_time` > ?',
#                         [int(warning_config['sid']), int(port_info['port']), watch_value, cur_time - 300]
#                     ).field('id').exists():
#                         continue
#
#                     ok = True
#
#                     # 添加告警任务
#                     warning_obj.add_task(
#                         warning_config,
#                         '端口[{}] 当前连接状态为[{}]'.format(port_info['port'], '可访问' if watch_value == 1 else '无法访问')
#                     )
#
#                 return ok
#
#             # 监控单个端口
#             else:
#                 # 检查端口号是否合法
#                 if int(port_num) < 1 or int(port_num) > 65535:
#                     return False
#
#                 # 检查当前端口是否正在监听中
#                 if not warning_obj.db_easy('server_ports').where(
#                     '`sid` = ? AND `port` = ? AND `status` = 1 AND `test_connection` = 1',
#                     [int(warning_config['sid']), int(port_num)]
#                 ).field('id').exists():
#                     return False
#
#                 # 获取该端口最近5分钟内是否能正常访问
#                 if not db.query().name('port_connection_logs').where(
#                     '`sid` = ? AND `port` = ? AND `ok` = ? AND `create_time` > ?',
#                     [int(warning_config['sid']), int(port_num), watch_value, cur_time - 300]
#                 ).field('id').exists():
#                     return False
#
#                 success_to_connect = warning_config['watch_value']
#
#     if not warning_obj.compare(warning_config, success_to_connect):
#         return False
#
#     # 添加告警任务
#     warning_obj.add_task(
#         warning_config,
#         '当前连接状态为[{}]'.format('可访问' if watch_value == 1 else '无法访问')
#     )
#
#     return True

# def handle_port_faileds_in_last_hour(warning_config, faileds_in_last_hour = None, warning_obj = warning_obj_common):
#     '''
#         @name   检查最近一个小时内端口连接失败数是否匹配告警规则 如果匹配则告警 否则跳过
#         @param  warning_config<dict>            告警规则
#         @param  faileds_in_last_hour<number>    最近一个小时内端口连接失败数[可选]
#         @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
#         @return bool
#     '''
#     # 匹配告警规则
#     if faileds_in_last_hour is None:
#         # 获取数据库管理对象
#         db_mgr = MonitorDbManager(warning_config['sid'])
#
#         with db_mgr.db_cur_date('port_connection_logs') as db:
#             # 获取端口号
#             port_num = warning_obj.get_var(warning_config['sub_type'])
#
#             if port_num is None:
#                 return False
#
#             # 获取当前时间
#             cur_time = int(time.time())
#
#             # 监控所有端口
#             if port_num == 'all':
#                 port_list = warning_obj.db_easy('server_ports').where(
#                     '`sid` = ? AND `status` = 1 AND `test_connection` = 1',
#                     [int(warning_config['sid'])]
#                 )\
#                 .field('id', 'ip', 'port')\
#                 .select()
#
#                 if warning_obj.is_empty_result(port_list):
#                     return False
#
#                 ok = False
#
#                 # 遍历所有端口
#                 for port_info in port_list:
#                     if re.match(r'^127', port_info['ip']):
#                         continue
#
#                     # 查询最近一小时内端口连接失败数
#                     faileds_in_last_hour = db.query().name('port_connection_logs').where(
#                         '`sid` = ? AND `port` = ? AND `ok` = 0 AND `create_time` > ?',
#                         [warning_config['sid'], int(port_info['port']), cur_time - 3600]
#                     ).count()
#
#                     if warning_obj.compare(warning_config, faileds_in_last_hour):
#                         ok = True
#
#                         # 添加告警任务
#                         warning_obj.add_task(
#                             warning_config,
#                             '端口[{}] 最近1小时内端口连接失败数为[{}]'.format(port_info['port'], faileds_in_last_hour)
#                         )
#
#                 return ok
#
#             # 监控单个端口
#             else:
#                 # 检查端口号是否合法
#                 if int(port_num) < 1 or int(port_num) > 65535:
#                     return False
#
#                 # 检查当前端口是否正在监听中
#                 if not warning_obj.db_easy('server_ports').where(
#                     '`sid` = ? AND `port` = ? AND `status` = 1 AND `test_connection` = 1',
#                     [int(warning_config['sid']), int(port_num)]
#                 ).field('id').exists():
#                     return False
#
#                 # 查询最近一小时内端口连接失败数
#                 faileds_in_last_hour = db.query().name('port_connection_logs').where(
#                     '`sid` = ? AND `port` = ? AND `ok` = 0 AND `create_time` > ?',
#                     [warning_config['sid'], int(port_num), cur_time - 3600]
#                 ).count()
#
#     if not warning_obj.compare(warning_config, faileds_in_last_hour):
#         return False
#
#     # 添加告警任务
#     warning_obj.add_task(
#         warning_config,
#         '最近1小时内端口连接失败数为[{}]'.format(faileds_in_last_hour)
#     )
#
#     return True

# def handle_port_success_percent(warning_config, cur_percent = None, warning_obj = warning_obj_common):
#     '''
#         @name   检查端口连接成功率是否匹配告警规则 如果匹配则告警 否则跳过
#         @param  warning_config<dict>    告警规则
#         @param  cur_percent<number>     当前端口连接成功率[可选]
#         @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
#         @return bool
#     '''
#     # 获取端口号
#     port_num = warning_obj.get_var(warning_config['sub_type'])
#
#     if port_num is None:
#         return False
#
#     # 匹配告警规则
#     if cur_percent is None:
#         # 获取数据库管理对象
#         db_mgr = MonitorDbManager(warning_config['sid'])
#
#         with db_mgr.db_cur_date('port_connection_logs') as db:
#             # 获取当前时间
#             cur_time = int(time.time())
#
#             # 监控所有端口
#             if port_num == 'all':
#                 port_list = warning_obj.db_easy('server_ports').where(
#                     '`sid` = ? AND `status` = 1 AND `test_connection` = 1',
#                     [int(warning_config['sid'])]
#                 )\
#                 .field('id', 'ip', 'port')\
#                 .select()
#
#                 if warning_obj.is_empty_result(port_list):
#                     return False
#
#                 ok = False
#
#                 # 遍历所有端口
#                 for port_info in port_list:
#                     if re.match(r'^127', port_info['ip']):
#                         continue
#
#                     # 获取端口最近1小时内连接成功率
#                     p = db.query().name('port_connection_logs').where(
#                         '`sid` = ? AND `port` = ? AND `create_time` > ?',
#                         [warning_config['sid'], int(port_info['port']), cur_time - 3600]
#                     ).value('ROUND(1.0 * SUM(CASE `ok` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS `ok_percent`')
#
#                     if p is None:
#                         continue
#
#                     if warning_obj.compare(warning_config, p):
#                         ok = True
#
#                         # 添加告警任务
#                         warning_obj.add_task(
#                             warning_config,
#                             '端口[{}] 当前端口连接成功率为[{}]'.format(port_info['port'], warning_obj.transform_value(p, 'percent'))
#                         )
#
#                 return ok
#
#             # 监控单个端口
#             else:
#                 # 检查端口号是否合法
#                 if int(port_num) < 1 or int(port_num) > 65535:
#                     return False
#
#                 # 检查当前端口是否正在监听中
#                 if not warning_obj.db_easy('server_ports').where(
#                         '`sid` = ? AND `port` = ? AND `status` = 1 AND `test_connection` = 1',
#                         [int(warning_config['sid']), int(port_num)]
#                 ).field('id').exists():
#                     return False
#
#                 # 获取端口最近1小时内连接成功率
#                 cur_percent = db.query().name('port_connection_logs').where(
#                     '`sid` = ? AND `port` = ? AND `create_time` > ?',
#                     [warning_config['sid'], int(port_num), cur_time - 3600]
#                 ).value('ROUND(1.0 * SUM(CASE `ok` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')
#
#                 if cur_percent is None:
#                     return False
#
#     if not warning_obj.compare(warning_config, cur_percent):
#         return False
#
#     # 添加告警任务
#     warning_obj.add_task(
#         warning_config,
#         '端口[{}]连接成功率为[{}]'.format(port_num, warning_obj.transform_value(cur_percent, 'percent'))
#     )
#
#     return True


# |--------------------
# | 日志
# |--------------------

def handle_log_ssh_login_logs_user(warning_config, status=None, warning_obj=warning_obj_common):
    '''
        @name   检查某个用户SSH登录状态是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>   告警规则
        @param  status<string>         SSH登录状态(success|fail)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控用户
    user = warning_obj.get_var(warning_config['watch_target'])

    if user is None:
        return False

    # 匹配告警规则
    if status is None:
        # 获取数据库管理对象
        db_mgr = MonitorDbManager(warning_config['sid'])

        with db_mgr.db_mgr('ssh_login_logs') as db:
            # 获取当前时间
            cur_time = int(time.time())

            # 获取监控指标
            watch_value = 1 if warning_config['watch_value'] == 'success' else 0

            # 监控所有用户
            if user == 'all':
                # 获取最近2分钟内ssh登录日志
                ret = db.query().name('ssh_login_logs').where(
                    '`login_time` > ? AND `success` = ?',
                    [cur_time - 120, watch_value]
                ) \
                    .field('id', 'user') \
                    .select()

                if warning_obj.is_empty_result(ret):
                    return False

                for user_info in ret:
                    # 添加告警任务
                    warning_obj.add_task(
                        warning_config,
                        '用户[{}] 当前登录状态为[{}]'.format(user_info['user'],
                                                             '登录成功' if watch_value == 1 else '登录失败')
                    )

                return True

            # 监控单个用户
            else:
                # 获取最近2分钟内ssh登录日志
                if not db.query().name('ssh_login_logs').where(
                        '`user` = ? AND `login_time` > ? AND `success` = ?',
                        [user, cur_time - 120, watch_value]
                ).field('id').exists():
                    return False

                status = warning_config['watch_value']

    if not warning_obj.compare(warning_config, status):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '用户[{}] 当前登录状态为[{}]'.format(user, '登录成功' if watch_value == 1 else '登录失败')
    )

    return True


def handle_log_ssh_login_logs_ip(warning_config, status=None, warning_obj=warning_obj_common):
    '''
        @name   检查某个IP SSH登录状态是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>   告警规则
        @param  status<string>         SSH登录状态(success|fail)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控IP
    ip = warning_obj.get_var(warning_config['watch_target'])

    if ip is None:
        return False

    # 匹配告警规则
    if status is None:
        # 获取数据库管理对象
        db_mgr = MonitorDbManager(warning_config['sid'])

        with db_mgr.db_mgr('ssh_login_logs') as db:
            # 获取当前时间
            cur_time = int(time.time())

            # 获取监控指标
            watch_value = 1 if warning_config['watch_value'] == 'success' else 0

            # 监控所有IP
            if ip == 'all':
                # 获取最近2分钟内ssh登录日志
                ret = db.query().name('ssh_login_logs').where(
                    '`login_time` > ? AND `success` = ?',
                    [cur_time - 120, watch_value]
                ) \
                    .field('id', 'ip') \
                    .select()

                if warning_obj.is_empty_result(ret):
                    return False

                for user_info in ret:
                    # 添加告警任务
                    warning_obj.add_task(
                        warning_config,
                        'SSH登录IP[{}]  当前登录状态为[{}]'.format(user_info['ip'],
                                                                   '登录成功' if watch_value == 1 else '登录失败')
                    )

                return True

            # 监控单个IP
            else:
                # 获取最近2分钟内ssh登录日志
                if not db.query().name('ssh_login_logs').where(
                        '`ip` = ? AND `login_time` > ? AND `success` = ?',
                        [ip, cur_time - 120, watch_value]
                ).field('id').exists():
                    return False

                status = warning_config['watch_value']

    if not warning_obj.compare(warning_config, status):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        'SSH登录IP[{}]  当前登录状态为[{}]'.format(ip, '登录成功' if watch_value == 1 else '登录失败')
    )

    return True


def handle_log_ssh_login_logs_user_faileds(warning_config, faileds=None, warning_obj=warning_obj_common):
    '''
        @name   检查某个用户 SSH登录失败总次数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>   告警规则
        @param  faileds<number>        SSH登录失败总次数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控用户
    user = warning_obj.get_var(warning_config['watch_target'])

    if user is None:
        return False

    # 匹配告警规则
    if faileds is None:
        # 获取数据库管理对象
        db_mgr = MonitorDbManager(warning_config['sid'])

        with db_mgr.db_mgr('ssh_login_logs') as db:
            # 监控所有用户
            if user == 'all':
                # 获取所有用户ssh登录失败总次数
                ret = db.query() \
                    .name('ssh_login_logs') \
                    .where('success=0') \
                    .field('user', 'COUNT(*) as faileds') \
                    .group('user') \
                    .select()

                if warning_obj.is_empty_result(ret):
                    return False

                ok = False

                for user_info in ret:
                    if warning_obj.compare(warning_config, user_info['faileds']):
                        ok = True

                        # 添加告警任务
                        warning_obj.add_task(
                            warning_config,
                            '用户[{}] 当前登录失败总次数为[{}]'.format(user_info['user'], user_info['faileds'])
                        )

                return ok

            # 监控单个用户
            else:
                # 获取用户登录失败总次数
                faileds = db.query() \
                    .name('ssh_login_logs') \
                    .where(
                    '`user` = ? AND `success` = 0',
                    [user]
                ).count()

                if faileds is None:
                    return False

    if not warning_obj.compare(warning_config, faileds):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '用户[{}] 当前登录失败总次数为[{}]'.format(user, faileds)
    )

    return True


def handle_log_ssh_login_logs_user_faileds_in_last_hour(warning_config, faileds_in_last_hour=None,
                                                        warning_obj=warning_obj_common):
    '''
        @name   检查某个用户 最近一小时内SSH登录失败总次数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>            告警规则
        @param  faileds_in_last_hour<number>    最近一小时内SSH登录失败总次数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 获取监控用户
    user = warning_obj.get_var(warning_config['watch_target'])

    if user is None:
        return False

    # 获取当前时间
    cur_time = int(time.time())

    # 获取最近一次告警时间
    last_warning_time = warning_obj.db_easy('warning_tasks') \
        .where('sid=?', warning_config['sid']) \
        .where('conf_id=?', warning_config['id']) \
        .order('create_time', 'desc') \
        .value('create_time')

    # 如果上一次告警时间在最近一小时内
    # 忽略本次告警
    if last_warning_time is not None and int(last_warning_time) > cur_time - 3600:
        return False

    # 匹配告警规则
    if faileds_in_last_hour is None:
        # 获取数据库管理对象
        db_mgr = MonitorDbManager(warning_config['sid'])

        with db_mgr.db_mgr('ssh_login_logs') as db:
            # 监控所有用户
            if user == 'all':
                # 获取所有用户ssh登录失败总次数
                ret = db.query() \
                    .name('ssh_login_logs') \
                    .where('success=0') \
                    .where('login_time > ?', cur_time - 3600) \
                    .field('user', 'COUNT(*) as faileds') \
                    .group('user') \
                    .select()

                if warning_obj.is_empty_result(ret):
                    return False

                ok = False

                for user_info in ret:
                    if warning_obj.compare(warning_config, user_info['faileds']):
                        ok = True

                        # 添加告警任务
                        warning_obj.add_task(
                            warning_config,
                            '用户[{}] 最近1小时内登录失败次数为[{}]'.format(user_info['user'], user_info['faileds'])
                        )

                return ok

            # 监控单个用户
            else:
                # 获取用户登录失败总次数
                faileds_in_last_hour = db.query() \
                    .name('ssh_login_logs') \
                    .where(
                    '`user` = ? AND `success` = 0 AND `login_time` > ?',
                    [user, cur_time - 3600]
                ).count()

    if not warning_obj.compare(warning_config, faileds_in_last_hour):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '用户[{}] 最近1小时内登录失败次数为[{}]'.format(user, faileds_in_last_hour)
    )

    return True


def handle_log_ssh_login_logs_faileds(warning_config, faileds=None, warning_obj=warning_obj_common):
    '''
        @name   检查SSH登录失败总次数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  faileds<number>         SSH登录失败总次数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if faileds is None:
        # 获取数据库管理对象
        db_mgr = MonitorDbManager(warning_config['sid'])

        with db_mgr.db_mgr('ssh_login_logs') as db:
            # 获取上一次告警任务处理时间
            last_handle_time = warning_obj.get_last_handled_task_handle_time(warning_config)

            faileds = db.query() \
                .name('ssh_login_logs') \
                .where('success', 0) \
                .count()

    if not warning_obj.compare(warning_config, faileds):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '当前SSH登录失败总次数为[{}]'.format(faileds)
    )

    return True


#   检查SSH是否异地登录 如果匹配则告警 否则跳过
def handle_log_ssh_login_logs_place_other(warning_config, status=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>    告警规则
        @param  status<string>          SSH登录状态(success|fail)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    if status is None or status != 'success':
        return False

    if warning_config['watch_value'] == 'off':
        return False

    # 获取被控ip
    server_ip = basic_monitor_obj.db_easy('servers').where('`sid` = ?', int(warning_config['sid'])).value('ip')

    # 获取数据库管理对象
    db_mgr = MonitorDbManager(warning_config['sid'])

    with db_mgr.db_mgr('ssh_login_logs') as db:
        # 异地登录检查
        # 获取最近两次登录成功记录
        latest_ssh_login_success = db.query() \
            .name('ssh_login_logs') \
            .where('success', 1) \
            .order('login_time', 'desc') \
            .limit(2) \
            .field('ip', 'port', 'user', 'login_time') \
            .select()

    # public.print_log('latest_ssh_login_success: {}'.format(latest_ssh_login_success))

    # 最近登录成功次数少于2次，不检测异地登录
    if len(latest_ssh_login_success) < 2:
        return False

    # 登录IP列表(去重)、去除内网IP
    login_ips = list(set(filter(lambda x: not public.is_local_ip(x), map(lambda x: x['ip'], latest_ssh_login_success))))

    # 登录IP相同时，不检测异地登录
    if len(login_ips) < 2:
        return False

    # 查询IP信息
    ip_info = warning_obj_common.search_ip_info(login_ips)
    ip_place_list = []
    i = 0

    for ssh_login_info in latest_ssh_login_success:
        # 获取登录IP
        login_ip = ssh_login_info['ip']

        # 查询不到其中一个IP归属地信息时
        # 不继续检测异地登录
        if login_ip not in ip_info:
            return False

        latest_ssh_login_success[i]['ip_info'] = ip_info[login_ip]
        ip_place_list.append(ip_info[login_ip]['country'] + ip_info[login_ip]['province'])

        i += 1

    # 异地登录检测
    # 两次登录地点相同
    if ip_place_list[0] == ip_place_list[1]:
        return False

    # 发生异地登录
    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '用户[{}]在[{}（{}）]登录成功'.format(
            latest_ssh_login_success[0]['user'],
            ip_place_list[0],
            '{}:{}'.format(login_ips[0], latest_ssh_login_success[0]['port'])
        ),
        mail_title = '[{}]发生异地登陆,登陆地[{}]'.format(server_ip, ip_place_list[0]),
        content = '用户[{}]在[{}（{}）]登录成功'.format(
            latest_ssh_login_success[0]['user'],
            ip_place_list[0],
            '{}:{}'.format(login_ips[0], latest_ssh_login_success[0]['port'])
        ),
        notify_content='''
    登录用户：{}
    登录地点：<font color="#FF0000">{}</font>
    登录IP：{}'''.format(
            latest_ssh_login_success[0]['user'],
            ip_place_list[0],
            '{}:{}'.format(latest_ssh_login_success[0]['ip'], latest_ssh_login_success[0]['port'])
        )
    )

    return True


def handle_log_executed_logs_dangers(warning_config, executed_count=None, warning_obj=warning_obj_common):
    '''
        @name   检查危险命令执行次数是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>      告警规则
        @param  executed_count<number>    危险命令执行次数[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


#   检查系统防火墙规则变化是否匹配告警规则 如果匹配则告警 否则跳过
def handle_firewall_rule_change(warning_config, firewall_info=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  firewall_info<string>    系统防火墙规则操作类型(add|delete)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''

    # public.print_log("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^{}".format(firewall_info), _level='error')
    # public.print_log("++++++{}".format(firewall_info['add']), _level='error')
    # public.print_log("------{}".format(firewall_info['del']), _level='error')
    # 匹配告警规则
    if firewall_info is None:
        return False

    # firewall_info = warning_obj.db_easy('server_details') \
    #     .where('`sid` = ?', warning_config['sid']) \
    #     .value('firewall_info')
    #
    # if firewall_info is None:
    #     return False
    #
    # try:
    #     firewall_info = json.loads(firewall_info)
    # except:
    #     return False
    #
    # if not warning_obj.is_empty_result(firewall_info['rules_change']['add']) and not warning_obj.is_empty_result(
    #         firewall_info['rules_change']['del']):
    #     change_type = 'all'
    # elif not warning_obj.is_empty_result(firewall_info['rules_change']['add']):
    #     change_type = 'add'
    # elif not warning_obj.is_empty_result(firewall_info['rules_change']['del']):
    #     change_type = 'del'
    # else:
    #     return False
    #
    # if not warning_obj.compare(warning_config, change_type):
    #     return False
    #
    # # 添加告警任务
    # warning_obj.add_task(warning_config)

    if len(firewall_info['add']) > 0 or len(firewall_info['del']) > 0:
        rule_data = {
            # 'add': '[]' if firewall_info['add'] is None else firewall_info['add'],
            # 'del': '[]' if firewall_info['del'] is None else firewall_info['del']
            'add':  firewall_info['add'],
            'del':  firewall_info['del']
        }
    else:
        return False

    add_rules = [] if rule_data['add'] is None else json.loads(rule_data['add'])
    del_rules = [] if rule_data['del'] is None else json.loads(rule_data['del'])

    data = []
    if len(del_rules) > 0 :
        for del_rule in del_rules:
            source = del_rule['source']
            port = del_rule['release_port']
            protocol = del_rule['protocol']
            access = del_rule['access']

            data.append("源地址：" + source \
                   + " | 端口：" + port \
                   + " | 协议：" + protocol \
                   + " | 规则: " + access)

        content = json.dumps(data,ensure_ascii=False, indent=4)

        msg = "检测到防火墙规则减少：{}".format(content)

        warning_obj.add_task(
            warning_config,
            msg
        )
        return True
    else:
        for add_rule in add_rules:
            source = add_rule['source']
            port = add_rule['release_port']
            protocol = add_rule['protocol']
            access = add_rule['access']

            data.append("源地址：" + source \
                    + " | 端口：" + port \
                    + " | 协议：" + protocol \
                    + " | 规则: " + access)

        content = json.dumps(data, ensure_ascii=False, indent=4)

        msg = "检测到防火墙规则新增：{}".format(content)

        warning_obj.add_task(
            warning_config,
            msg
        )

        return True


def handle_firewall_rule_status_start_stop(warning_config, status=None, warning_obj=warning_obj_common):
    '''
        @name   检查系统防火墙规则变化是否匹配告警规则 如果匹配则告警 否则跳过
        @param  warning_config<dict>    告警规则
        @param  status<string>          系统防火墙启停状态(start|stop)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    return False


#   检查主机在线状态是否匹配告警规则 如果匹配则告警 否则跳过
def handle_client_status_on_off(warning_config, change_type=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  change_type<string>    主机状态变更(online|offline)[可选]
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    if change_type is None:
        return False

    # 匹配规则
    if not warning_obj.compare(warning_config, change_type):
        return False

    # 添加告警任务
    warning_obj.add_task(
        warning_config,
        '已上线' if change_type == 'online' else '已下线'
    )

    return True


#   发送非在线磁盘数量告警消息
def handle_raid_check(warning_config, check_detail=None, warning_obj=warning_obj_common):

    if not check_detail:
        return False

    arr = check_detail['checkDetail'].split("|")
    pd_count = 0
    for info_str in arr:
        no, pd_count, online_count = info_str.split(",")
        pd_count = int(pd_count)

    serverModule = public.import_via_loader('{}/modules/serverModule/main.py'.format(public.get_panel_path())).main
    sm = serverModule()
    output = check_detail['checkOutput']

    if check_detail['checkdell'] == "1":
        res = sm.parse_raid_info(output)
    else:
        res = sm.parse_raid_infov2(output)

    # check_res = check_detail["checkResult"]
    online_count = 0
    flags = True
    for temp in res:
        for pds in temp['pds']:
            if pds['state'] == 'Onln':
                online_count += 1
            else:
                flags = False
                check_res = "异常"
                continue
        if not flags:
            break

    detail_desc = ''
    # if check_res != "OK" or output is None:
    #     detail_desc = "共 {} 块磁盘，检测到 {} 块硬盘状态异常。".format(pd_count, pd_count - online_count)

    # if pd_count - online_count > 0:
    #     check_res = '异常'
    # detail_desc = "共 {} 块磁盘，检测到 {} 块硬盘状态异常。".format(pd_count, pd_count - online_count)

    if int(pd_count - online_count) > 0:
        msg = "检测到{}块物理磁盘状态异常。".format(pd_count - online_count)

        # 添加告警任务
        warning_obj.add_task(
            warning_config,
            msg
        )
    return True


#   检查安全监控漏洞扫描是否存在 如果匹配则告警 否则跳过
def handle_safety_bug(warning_config, change_type=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  change_type<string>    新增数据状态异常 status_error
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if change_type is None:
        return False
    # 漏洞扫描  # 查询主机漏洞数
    bug_info = warning_obj.db_easy('server_bug_total') \
        .where('`sid` = ?', warning_config['sid']) \
        .value('`bugs` - `ignored` - `fixed` as `bugs`')

    if bug_info is None or bug_info == 0:
        return False

    server_info = basic_monitor_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid',
                                                                                          warning_config['sid']).find()
    msg = "检测到:存在漏洞，请尽快处理。"

    warning_obj.add_task(
        warning_config,
        msg
    )

    return True


#   检查安全监控挖矿木马是否存在 如果匹配则告警 否则跳过
def handle_safety_mining(warning_config, change_type=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  change_type<string>    新增数据状态异常 status_error
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if change_type is None:
        return False
    # 挖矿木马  查询主机挖矿木马数
    mining_info = basic_monitor_obj.db_easy('server_mining_total') \
        .where('`sid` = ?', warning_config['sid']) \
        .value('`minings` - `ignored` - `fixed` as `minings`')

    if mining_info is None or mining_info == 0:
        return False

    server_info = basic_monitor_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid',
                                                                                          warning_config['sid']).find()
    msg = "检测到:存在挖矿木马进程，请尽快处理。"

    warning_obj.add_task(
        warning_config,
        msg
    )

    return True


#   检查安全监控病毒扫描是否存在 如果匹配则告警 否则跳过
def handle_safety_scan(warning_config, change_type=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  change_type<string>    新增数据状态异常 status_error
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    # if change_type is  None:
    #     return  False

    # 病毒扫描  查询主机病毒数
    with monitor_db_manager.db_mgr('malicious_scan') as db:
        # 自动扫描任务id
        automatic_ids = db.query().name('malicious_scan_tasks') \
            .where('is_automatic', 1) \
            .column('id')

        max_id = db.query().name('malicious_scan_tasks') \
            .where('is_automatic', 0) \
            .field('id', 'name') \
            .order('id', 'desc') \
            .find()
        # 最新的手动扫描任务id
        ids = db.query() \
            .name('malicious_scan_tasks') \
            .where('name', max_id['name']) \
            .field('id', 'name') \
            .value('id')
        # 所有任务id
        all_ids = automatic_ids + [ids]

        query = db.query() \
            .name('malicious_scan_results') \
            .where('`sid` = ?', warning_config['sid']) \
            .where('status = 0') \
            .where('white_list_id = 0')\
            .where('isolate_id = 0')\
            .where_in('task_id', all_ids) \
            .count()


    if query is None or query == 0:
        return False

    # server_info = basic_monitor_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid',
    #                                                                                       warning_config['sid']).find()
    msg = "检测到:存在病毒文件，请尽快处理。"

    warning_obj.add_task(
        warning_config,
        msg
    )

    return True


#   检查端口状态是否变更 如果匹配则告警 否则跳过
def handle_port_change(warning_config, new_ports=None, warning_obj=warning_obj_common):
    '''
        @param  warning_config<dict>   告警规则
        @param  change_type<string>    新增数据状态异常 status_error
        @param  warning_obj<core.include.warning.Warning>   云监控告警对象[可选 默认使用公共单例对象]
        @return bool
    '''
    # 匹配告警规则
    if new_ports is None:
        return False

    # 获取数据库主机端口列表
    sql_info = warning_obj.db_easy('server_details') \
        .field('id', 'port_info') \
        .where('`sid` = ?', warning_config['sid']) \
        .value('port_info')

    # from deepdiff import DeepDiff
    # 被控推送过来的Port信息
    old_ports_raw = json.loads(sql_info)
    old_ports = {}

    new_ports_raw = new_ports
    new_ports = {}

    for k, v in old_ports_raw.items():
        old_ports[int(k)] = v

    for k, v in new_ports_raw.items():
        new_ports[int(k)] = v

    del (old_ports_raw, new_ports_raw)

    set_1 = set(old_ports.keys())
    set_2 = set(new_ports.keys())
    set_intersect = set_1.intersection(set_2)

    d = {
        'add': [],
        'del': [],
    }

    pne_ids = []

    # 减少
    for k in set_1.difference(set_intersect):
        item = old_ports[k]
        pne_ids.append(item['pne_id'])
        d['del'].append(item)

    # 增加
    for k in set_2.difference(set_intersect):
        item = new_ports[k]
        pne_ids.append(item['pne_id'])
        d['add'].append(item)

    # for k in set_diff:
    #     if k in set_1:
    #         item = old_ports[k]
    #         pne_ids.append(item['pne_id'])
    #         d['del'].append(item)
    #         continue
    #
    #     item = new_ports[k]
    #     d['add'].append(item)
    #     pne_ids.append(item['pne_id'])

    pne_map = warning_obj.db_easy('process_name_exe') \
        .where_in('id', pne_ids) \
        .field('*') \
        .column(None, 'id')

    for item in d['add']:
        p_info = pne_map.get(item['pne_id'], {})
        item['process_name'] = p_info.get('name', '')
        item['exe'] = p_info.get('exe', '')
        item.pop('pne_id', None)

    for item in d['del']:
        p_info = pne_map.get(item['pne_id'], {})
        item['process_name'] = p_info.get('name', '')
        item['exe'] = p_info.get('exe', '')
        item.pop('pne_id', None)


    msg = ['检测到主机:']

    res = []
    for data in d['add']:
        res.append("端口:" + str(data['port']) + " 进程名:" + data['process_name'])

    if len(res) > 0:
        msg.append('{}'.format(json.dumps(res, ensure_ascii=False, indent=4)))

    reduce = []
    for data in d['del']:
        reduce.append("端口:" + str(data['port']) + " 进程名:" + data['process_name'])

    if len(reduce) > 0:
        msg.append('{}'.format(json.dumps(reduce, ensure_ascii=False, indent=4)))

    if len(msg) < 2:
        return False

    warning_obj.add_task(
        warning_config,
        '\n'.join(msg)
    )

    return True
