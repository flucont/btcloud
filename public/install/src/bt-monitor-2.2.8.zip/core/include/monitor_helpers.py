# -*- encoding: utf-8 -*-
#
# 云监控工具模块
# @author Zhj<2022-07-05>


# from core.include.basic_monitor import BasicMonitor
# from core.include.warning import Warning

import core.include.public as public


monitor_events = public.import_via_loader('{}/core/include/monitor_events.py'.format(public.get_panel_path()))
monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
monitor_task_obj = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path()))
MonitorTaskQueue = monitor_task_obj.MonitorTaskQueue
MonitorTask = monitor_task_obj.MonitorTask

# 云监控任务队列
monitor_task_queue = MonitorTaskQueue().run()

# 云监控消息推送队列
message_push_queue = MonitorTaskQueue().run()

# 云监控异步调用被控队列
async_call_queue = MonitorTaskQueue().run()

BasicMonitor = public.import_via_loader('{}/core/include/basic_monitor.py'.format(public.get_panel_path())).BasicMonitor
WarningClass = public.import_via_loader('{}/core/include/warning.py'.format(public.get_panel_path())).Warning

# 监控数据收集类
basic_monitor_obj = BasicMonitor()

# 云监控告警对象
warning_obj = WarningClass()
