System.register(["./typescript-legacy.js","./monaco-editor-legacy.js"],(function(e,t){"use strict";var s,i;return{setters:[function(e){s=e.conf,i=e.language},null],execute:function(){
/*!-----------------------------------------------------------------------------
       * Copyright (c) Microsoft Corporation. All rights reserved.
       * Version: 0.35.0(71ac097e6155a405f6be52b0b368a04508c31e31)
       * Released under the MIT license
       * https://github.com/microsoft/monaco-editor/blob/main/LICENSE.txt
       *-----------------------------------------------------------------------------*/
e("conf",s),e("language",{defaultToken:"invalid",tokenPostfix:".js",keywords:["break","case","catch","class","continue","const","constructor","debugger","default","delete","do","else","export","extends","false","finally","for","from","function","get","if","import","in","instanceof","let","new","null","return","set","super","switch","symbol","this","throw","true","try","typeof","undefined","var","void","while","with","yield","async","await","of"],typeKeywords:[],operators:i.operators,symbols:i.symbols,escapes:i.escapes,digits:i.digits,octaldigits:i.octaldigits,binarydigits:i.binarydigits,hexdigits:i.hexdigits,regexpctl:i.regexpctl,regexpesc:i.regexpesc,tokenizer:i.tokenizer})}}}));
