import{a1 as r}from"./windi.js";const o=o=>(s,a)=>!r(a)||new Error(o);export{o as v};
