# encoding: utf-8
#
# 监听器模块
# Author Zhj<2023-03-23>

import json
import core.include.public as public


class BaseHandler:
    '''
        @name 监听器基类
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        raise RuntimeError('method handle() must be implements.')


class SubmitStatistics(BaseHandler):
    '''
        @name 提交统计数据
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        from core.include.monitor_helpers import basic_monitor_obj, monitor_task_queue, MonitorTask
        # 提交至任务队列执行
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj.submit_statistics, args=(True,)))


class UpdateServerPosition(BaseHandler):
    '''
        @name 更新首页监控大屏主机位置信息
        @author Zhj<2023-04-11>
    '''
    def handle(self, event):
        server_position = None
        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'r') as fp:
            try:
                server_position = json.loads(fp.read())
            except:
                server_position = {}

        server_position.pop(str(event.server_info['sid']), None)

        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'w') as fp:
            fp.write(json.dumps(server_position))
