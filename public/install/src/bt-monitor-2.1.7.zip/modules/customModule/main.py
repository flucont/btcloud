# encoding: utf-8
import json, os, sys, re, time, random, copy
from core import g
import core.include.public as public
import core.include.Locker as Locker
from core.include.monitor_helpers import basic_monitor_obj, warning_obj
from core.include.monitor_exceptions import BtMonitorException
import core.include.monitor_enums as monitor_enums
import core.include.pymmh3 as mmh3

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))


class main():
    '''
        @name 云监控自定义监控模块
        @author lt<2023-05-06>
    '''

    # 服务器列表 去掉未授权 离线
    def get_server_list(self, args):
        '''
            @name 获取主机列表(简易数据)
            @author Zhj<2023-01-10>
            @param args<dict> 请求参数列表
            @return dict
        '''
        server_authorized = g.get("server_list", [])

        if not server_authorized:
            return public.success({
                'total': 0,
                'list': [],
            })

        group_id = args.get('group_id', None)

        query = basic_monitor_obj.db_easy('servers s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .left_join('server_warning_template_package_merge m', 's.sid=m.sid') \
            .left_join('warning_template_packages p', 'm.package_id=p.id') \
            .left_join('server_details sys', 's.sid = sys.sid') \
            .where_in('s.sid', server_authorized) \
            .where('s.is_authorized', 1) \
            .where('s.status', 1) \
            .order('s.sid', 'desc') \
            .field('s.sid', 'sg.name as group_name', 's.ip', 's.remark', 's.is_authorized', 's.status',
                   'ifnull(p.name, \'\') as cur_template', 's.type', 'sys.host_info')

        # query['host_info'] = json.loads(query['host_info'])

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        def query_hander(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('s.remark like ? OR s.ip like ?', (k, k,))

        public.add_retrieve_keyword_query(query, args, query_hander)

        ret = public.simple_page(query, args)

        for item in ret['list']:
            # 更新主机状态
            _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
            item['host_info'] = json.loads(item['host_info'])

        return public.success(ret)

    def add_process(self, args):
        '''
            @name 添加进程监控
            @author lt<2023-05-10>
            @arg    json_data<list>         json_data
            @arg    sid<str>                sid
            @arg    sub_type<str>           proc_[进程名称|启动命令]
            @arg    push_methods<str>       推送配置: 钉钉 飞书
            @arg    scores<str>             规则参数 告警级别
            @arg    watch_target<str>      规则参数
            @arg    watch_type<str>        规则参数

            @return dict
        '''

        public.print_log('添加', _level='error')
        try:
            json_data = args.get('json_data/json', None)
            sid = args.get('sid', None)
            sub_type = args.get('sub_type', None)
            push_methods = args.get('push_methods', None)
            scores = args.get('scores', None)
            watch_target = args.get('watch_target', None)
            watch_type = args.get('watch_type', None)

        except Exception as e:
            return public.return_error(str(e))
        if sid is None or sub_type is None:
            return public.return_error('缺少参数：sid or sub_type')

        proc_name, boot_command = sub_type.split('[')[1].split(']')[0].split('|')
        # public.print_log('proc_name::{}   boot_command::{}'.format(proc_name, boot_command), _level='error')

        pne_id = warning_obj.get_pne_id(proc_name, boot_command)

        # 任务重复性检测
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 存在 不添加
            if db.query().name('custom_process').where('pne_id', pne_id).where('sid', sid).exists():
                return public.return_error('进程任务已存在')

        # 主机信息
        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark') \
            .where('sid', sid) \
            .find()

        servers = server_info['remark'] if server_info['remark'] else server_info['ip']
        title = '自定义进程监控-{}-{}'.format(servers, proc_name)
        # scripts = []
        rule_lst = []
        center_add = []

        # 固定数据
        rule_data_ = {
            "type": "service",
            "content": "",
            "duration": 0,
            'add_source': 1,
        }

        # 进程信息
        rule_data_.update(
            {
                "sid": int(sid),
                "sub_type": sub_type,
                "push_methods": push_methods,
                "scores": int(scores),
                "watch_type": int(watch_type),
                "title": title,
                "watch_target": watch_target,
            }
        )

        watch_value_ = {0: 'deactive', 1: 'active'}
        is_push = 0
        for i in json_data:
            # 是否推送
            push_ = i['is_push']
            if push_ == 1:
                is_push = 1

            script = i['script']
            # 脚本合法性
            if script != '':
                if basic_monitor_obj.is_sensitive_command(script):
                    return public.return_error('脚本包含危险命令')
                    # public.print_log('脚本非法', _level='error')

            # 规则
            rule = {
                'is_push': i['is_push'],
                'watch_value': watch_value_[i['push_condition']],
            }
            # 中间表
            center = {
                'is_push': i['is_push'],
                'push_condition': i['push_condition'],
                'script': script,
                # pro_id  rule_id
            }

            center_add.append(copy.deepcopy(center))

            # 拷贝固定数据
            d = copy.deepcopy(rule_data_)
            rule.update(d)
            rule_lst.append(rule)
        # public.print_log('~~~~~~~~~~~~~center_add:{}'.format(center_add),_level='error')

        # 验证告警规则是否合法
        rule_add = []
        rule_err = []
        for rule in rule_lst:
            ok, err_msg = warning_obj.check_rule(rule)
            if ok:
                rule_add.append(rule)
            else:
                rule_err.append(err_msg)
                public.print_log('!!!!!!!!!!!!!!!rule_err: {}'.format(err_msg), _level='error')
        # public.print_log('!!!!!!!!!!!!!!!rule_add: {}'.format(rule_add), _level='error')
        if len(rule_add) > 0:
            # 添加告警规则
            with monitor_db_manager.db_mgr() as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)
                    for i, j in enumerate(rule_add):
                        rule_id = db.query() \
                            .name('warning_configurations') \
                            .insert(j)

                        center_add[i]['rule_id'] = rule_id

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()
                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    return public.error('规则添加失败')

        with monitor_db_manager.db_mgr('custom_process') as db:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 添加进程监控
                pro_id = db.query() \
                    .name('custom_process') \
                    .insert({
                    'pne_id': pne_id,
                    'sid': sid,
                    'is_push': is_push,
                    'push_methods': push_methods,
                    'create_time': int(time.time()),
                })
                # 中间表数据
                if len(center_add) > 0:
                    for i in center_add:
                        i['pro_id'] = pro_id

                    # 添加中间表
                    db.query() \
                        .name('custom_process_rule_script') \
                        .insert_all(center_add)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        # 记录日志
        public.WriteLog('自定义监控进程',
                        '监控【%s（%s）】下的进程【%s' % (server_info['ip'], server_info['remark'], proc_name))
        return public.success('操作成功')

    # 获取进程信息
    def get_processes_list(self, args):
        """进程监控列表
        @author lt<2023-05-10>
        Args:
            args (dict_obj): 查询参数对象
                p<?integer>             分页页码[可选 默认1]
                p_size<?integer>        分页大小[可选 默认20]
        """
        # public.print_log('======进程监控列表======'.format(), _level='error')

        with monitor_db_manager.db_mgr('custom_process') as db:
            process = db.query().name('custom_process').select()
            pro_isd = [i['id'] for i in process]
            # 中间表信息   .field('sum(`script`!="") AS `num_script`', 'sum(`rule_id`>0) AS `num_rule_id`', 'is_push', 'pro_id') \
            center_info = db.query().name('custom_process_rule_script') \
                .where_in('pro_id', pro_isd) \
                .field('sum(`script`!="") AS `num_script`', 'pro_id') \
                .group('pro_id') \
                .column(None, 'pro_id')
        for i in process:
            i['info'] = center_info[i['id']]
        # public.print_log('======进程监控列表======{}'.format(process), _level='error')

        if len(process) == 0:
            return public.return_data(True, {'total': 0, 'data': []})
        pne_ids_ = [i['pne_id'] for i in process]
        sids = list(set([i['sid'] for i in process]))

        server_info = warning_obj.db_easy('servers') \
            .field('ip', 'remark', 'sid') \
            .where_in('sid', sids) \
            .column(None, 'sid')

        query = basic_monitor_obj.db_memory('processes') \
            .field(
            'id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user',
            'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes',
            'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes', 'create_time',
            'update_time', 'boot_time',
        ) \
            .where_in('pne_id', pne_ids_) \
            .where('`update_time` > ?', int(time.time()) - 120)

        result = public.simple_page(query, args)
        # 进程基本信息ID
        pne_ids = []
        # 数据采样设置ID
        sampling_ids = []
        # 主机ID列表
        sid_list = set()

        for item in result['list']:
            pne_ids.append(item['pne_id'])

            # 构造数据采样设置ID
            item['sampling_id'] = public.mmh3_hash64('process|{}|{}'.format(
                item['id'], monitor_enums.SAMPLING_TYPE__GLOBAL))
            sampling_ids.append(item['sampling_id'])

            sid_list.add(item['sid'])

        # 查询进程基本信息
        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', pne_ids_) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        # 重组进程监控数据
        custom_proc = {}
        for item in process:
            custom_proc[item['pne_id']] = item

        proc_info = {}
        for p_item in result['list']:
            # p_item['pid'] = p_item['id']
            # pne = pnes.get(p_item['pne_id'], {})
            # p_item['name'] = pne.get('name', '')
            # p_item['boot_command'] = pne.get('exe', '')
            p_item.update(
                basic_monitor_obj.cache_realtime_proc_info(p_item['id']))

            # 进程监控信息
            # p_item['is_script'] = custom_proc.get(str(p_item['pne_id']), {}).get('info', {}).get('num_script', None)
            # p_item['is_warning'] = custom_proc.get(str(p_item['pne_id']), {}).get('is_push', 0)
            # p_item['is_warning'] = custom_proc.get(str(p_item['pne_id']), {}).get('info', {}).get('num_rule_id', None)
            # p_item['is_push'] = custom_proc.get(str(p_item['pne_id']), {}).get('info', {}).get('is_push', None)
            p_item['pro_id'] = custom_proc.get(str(p_item['pne_id']), {}).get('info', {}).get('pro_id', None)
            p_item['run_time'] = int(time.time()) - p_item['boot_time']

            del (p_item['sampling_id'])

            proc_info[p_item['pro_id']] = p_item

        for p in process:
            server_ = server_info.get(p['sid'], {})
            p['server_info'] = {'ip': server_.get('ip', ''), 'remark': server_.get('remark', '')}
            p['is_script'] = custom_proc.get(str(p['pne_id']), {}).get('info', {}).get('num_script', None)
            p['is_warning'] = custom_proc.get(str(p['pne_id']), {}).get('is_push', 0)
            pne = pnes.get(int(p['pne_id']), {})
            p['name'] = pne.get('name', '')
            p['boot_command'] = pne.get('exe', '')
            p['info'] = proc_info.get(p['id'], {})  # 进程监控信息
            p['proc_status'] = 0 if p['info'] == {} else 1

        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(process),
            'list': process[(p - 1) * p_size:p * p_size],
        })

    # 获取关联表 列表
    def get_custom_process(self, args):
        '''
            @name   获取进程监控 关联表
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
        '''

        pro_id = args.get('pro_id', None)
        if not pro_id:
            return public.return_error('缺少参数 pro_id')

        center_data = []
        script = None
        rule_ids = []
        scores = None
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 进程监控
            cusproc_info = db.query() \
                .name('custom_process') \
                .where('id=?', int(pro_id)) \
                .find()

            # 中间表
            center = db.query() \
                .name('custom_process_rule_script') \
                .where('pro_id=?', int(pro_id)) \
                .select()
        if not cusproc_info:
            data = {
            }

            return public.success(data)
        if center:
            # 拿中间表 数据 规则id 执行条件
            d = {0: '终止时通知', 1: '恢复时通知'}
            for item in center:
                center_data.append({
                    'push_condition': d[item['push_condition']],
                    'center_id': item['id'],
                    'is_push': item['is_push'],
                })

                if item['rule_id']:
                    rule_ids.append(item['rule_id'])
                if item['script'] != '':
                    # if item['push_condition'] == 0:
                    script = item['script']
                    # public.print_log('YYYYYYYYYYYYYYYYYscript::{}'.format(script), _level='error')
        if rule_ids:
            with monitor_db_manager.db_mgr() as db:
                rule_infos = db.query() \
                    .name('warning_configurations') \
                    .field('scores') \
                    .where_in('id', rule_ids) \
                    .select()

            scores = rule_infos[0]['scores'] if rule_infos else None
        # public.print_log('进程监控获取::{}'.format(cusproc_info), _level='error')
        proc_info = basic_monitor_obj.db_easy('process_name_exe') \
            .where('id', cusproc_info['pne_id']) \
            .field('id', 'name', 'exe') \
            .find()

        proc_name = proc_info['name'] + '|' + proc_info['exe']
        data = {
            'sid': cusproc_info['sid'],
            'pro_id': cusproc_info['id'],
            'proc_name': proc_name,
            'script_deactive': script,
            'center_data': center_data,
            'is_push': cusproc_info['is_push'],
            'push_methods': cusproc_info['push_methods'],
            'scores': scores,
        }

        return public.success(data)

    # 修改监控配置 脚本 规则
    def update_custom_process(self, args):
        '''
            @name 修改进程监控
            @author lt<2023-05-10>
            @arg    json_data<list>         json_data
            @arg    pro_id<list>           监控任务id
            @arg    push_methods<list>     推送通道
            @arg    scores<list>           告警级别
            @arg    is_push<list>          是否推送

            @return dict
        '''
        public.print_log('修改', _level='error')
        try:
            json_data = args.get('json_data/json', None)
            pro_id = args.get('pro_id', None)
            push_methods = args.get('push_methods', None)
            scores = args.get('scores', None)
            is_push = args.get('is_push', None)
        except Exception as e:
            return public.return_error(str(e))
        if pro_id is None or push_methods is None or scores is None or is_push is None or json_data is None:
            return public.return_error('缺少参数')
        # 进程监控
        custom_proc = {
            'is_push': is_push,
            'push_methods': push_methods
        }
        public.print_log('进程监控修改::{}'.format(custom_proc), _level='error')

        with monitor_db_manager.db_mgr('custom_process') as db, monitor_db_manager.db_mgr() as dbr:

            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 添加进程监控
                pro_id = db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .update(custom_proc)

                # 中间表
                for item in json_data:
                    # 脚本合法性
                    if item['script'] != '' and item['script'] is not None:
                        if basic_monitor_obj.is_sensitive_command(item['script']):
                            return public.return_error('脚本存在危险命令')

                    db.query() \
                        .name('custom_process_rule_script') \
                        .where('id=?', int(item['center_id'])) \
                        .update({
                        'is_push': item['is_push'],
                        'push_condition': item['push_condition'],
                        'script': item['script'],
                    })

                    # 规则id
                    rule_id = db.query() \
                        .name('custom_process_rule_script') \
                        .where('id=?', item['center_id']) \
                        .value('rule_id')

                try:
                    # 关闭事务自动提交
                    dbr.autocommit(False)
                    # 添加告警规则
                    dbr.query() \
                        .name('warning_configurations') \
                        .where('id=?', rule_id) \
                        .update({
                        'is_push': is_push,
                        'push_methods': push_methods,
                        'scores': scores,
                    })

                    # 提交事务
                    dbr.commit()
                except BaseException as e:
                    # 回滚事务
                    dbr.rollback()
                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    return public.error('修改规则失败')
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        return public.success('修改成功')

    # 删除
    def delete_custom_process(self, args):
        '''
            @name   删除进程监控
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
            删除监控表 pro_id  中间表center_id  规则表rule_id  结果表pro_id
        '''
        pro_id = args.get('pro_id', None)
        if not pro_id:
            return public.return_error('缺少参数 pro_id')

        with monitor_db_manager.db_mgr('custom_process') as db:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 删除进程监控
                db.query() \
                    .name('custom_process') \
                    .where('id=?', int(pro_id)) \
                    .delete()

                # 删除中间表
                query = db.query().name('custom_process_rule_script').where('pro_id=?', int(pro_id))
                rule_ids = query.fork().field('rule_id').column('rule_id')
                query.fork().delete()

                # 删除结果表
                db.query() \
                    .name('custom_process_script_result') \
                    .where('pro_id=?', int(pro_id)) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        # 删除规则表

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 获取告警规则
                warning_rules = db.query() \
                    .name('warning_configurations') \
                    .where_in('id', rule_ids) \
                    .field('id', 'sid', 'title', 'content', 'type', 'sub_type', 'watch_target',
                           'watch_type', 'watch_value', 'is_push', 'scores', 'push_methods', 'duration'
                           ) \
                    .select()

                # 删除告警规则
                db.query() \
                    .name('warning_configurations') \
                    .where_in('id', rule_ids) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)
        # 设置端口测试连接状态
        warning_obj.set_server_port_test_state_with_warning_rules(warning_rules, False, False)

        return public.success('删除成功')

    # 脚本执行结果
    def get_process_script_result(self, args):
        '''
            @name   脚本执行结果
            @author lt<2023-05-10>
            @arg    pro_id<int>     进程监控表id 必填
            @return dict
        '''
        pro_id = args.get('pro_id', None)
        with monitor_db_manager.db_mgr('custom_process') as db:
            # 进程监控
            # cusproc_info = db.query() \
            #     .name('custom_process') \
            #     .where('id=?', int(pro_id)) \
            #     .order('create_time', 'desc') \
            #     .find()

            # query = db.query() \
            #     .name('custom_process_rule_script') \
            #     .alias('center') \
            #     .join('custom_process_script_result as res', 'center.id=res.center_id', 'left') \
            #     .field('center.script as script','res.create_time as create_time',
            #            'result', 'err_msg', 'status') \
            #     .where('center.pro_id=?', int(pro_id)) \
            #     .where('center.script!=?', '') \
            #     .order('res.create_time', 'desc') \
            #     .select()

            # # 中间表
            # center = db.query() \
            #     .name('custom_process_rule_script') \
            #     .where('pro_id=?', int(pro_id)) \
            #     .where('script=?', int(pro_id)) \
            #     .select()
            #
            # 中间表
            result = db.query() \
                .name('custom_process_script_result') \
                .where('pro_id=?', int(pro_id)) \
                .select()

        return public.success(result)

    # # 获取配置详情
    # def get_custom_process_detail(self, args):
    #     '''
    #         @name   删除进程监控
    #         @author lt<2023-05-10>
    #         @arg    center_id<int>     中间表id
    #         @arg    pro_id<int>     进程监控表id 必填
    #         @arg    rule_id  <int>    规则表id
    #         @return dict
    #     '''
    #
    #     pro_id = args.get('pro_id', None)
    #     center_id = args.get('center_id', None)
    #     rule_id = args.get('rule_id', None)
    #     if not pro_id:
    #         return public.return_error('缺少参数 pro_id')
    #
    #     cusproc_info = None
    #     center_info = None
    #     rule_info = None
    #     with monitor_db_manager.db_mgr('custom_process') as db:
    #         # 进程监控
    #         cusproc_info = db.query() \
    #             .name('custom_process') \
    #             .where('id=?', int(pro_id)) \
    #             .find()
    #
    #         # 中间表                     .where('pro_id=?', int(pro_id)) \
    #         #                     .where('rule_id=?', int(pro_id)) \
    #         if center_id:
    #             center_info = db.query() \
    #                 .name('custom_process_rule_script') \
    #                 .where('id=?', int(center_id)) \
    #                 .find()
    #
    #     if rule_id:
    #         with monitor_db_manager.db_mgr() as db:
    #             rule_info = db.query() \
    #                 .name('warning_configurations') \
    #                 .where('id=?', int(rule_id)) \
    #                 .find()
    #
    #
    #     data = {
    #         'cusproc_info': cusproc_info,
    #         'center_info': center_info,
    #         'rule_info': rule_info
    #     }
    #
    #     return public.success(data)
    # def add_process(self, args):
    #     '''
    #         @name 添加进程监控
    #         @author lt<2023-05-10>
    #         @arg    rule_data<string>           告警规则数据
    #         @arg    script<string>              脚本 单条
    #         @return dict
    #     '''
    #     # rule_data = {"sid": 14, "title": "测试111", "content": "", "is_push": 1, "type": "service",
    #     #      "sub_type": "proc_[BT-MonitorAgent|/usr/local/btmonitoragent/BT-MonitorAgent]",
    #     #      "watch_target": "cpu.percent",
    #     #      "watch_type": 1, "watch_value": "100", "push_methods": "weixin", "scores": 80, "duration": 1}
    #
    #     try:
    #         rule_data = args.get('rule_data/json', None)
    #         script = args.get('script', None)
    #     except Exception as e:
    #         return public.return_error(str(e))
    #
    #     if rule_data is None or script is None:
    #         return public.return_error('缺少参数：rule_data/script')
    #
    #     public.print_log('!!!!!!!!!!!!!!script: {}'.format(script), _level='error')
    #
    #     # 验证告警规则是否合法
    #     ok, err_msg = warning_obj.check_rule(rule_data)
    #     if not ok:
    #         return public.return_error(err_msg)
    #     # 合法脚本
    #     valid_commands = []
    #     # 非法脚本
    #     invalid_commands = []
    #
    #     # 验证脚本是否合法
    #     scripts = script.split('\n')
    #     for command in scripts:
    #         is_ok = basic_monitor_obj.is_sensitive_command(command)
    #         if is_ok:  # 不合法
    #             public.print_log('!!!!!!!!!!!!!!脚本不合法: {}'.format(command), _level='error')
    #             invalid_commands.append(command)
    #         else:   # 合法
    #             valid_commands.append(command)
    #
    #     with monitor_db_manager.db_mgr() as db:
    #         try:
    #             # 关闭事务自动提交
    #             db.autocommit(False)
    #             # 添加告警规则
    #             rule_id = db.query() \
    #                 .name('warning_configurations') \
    #                 .insert(rule_data)
    #             # # 检验脚本是否已经存在
    #             # add_script = []
    #             # old_script_lst = basic_monitor_obj.db_easy('custom_script').where('rule_id', rule_id).field('script').select()
    #             # public.print_log('已有的脚本{}'.format(old_script_lst), _level='error')
    #             # if old_script_lst:
    #             #     old_script_lst = [i['script'] for i in old_script_lst]
    #             #
    #             # for i in valid_commands:
    #             #     if i not in old_script_lst:
    #             #         add_script.append({'rule_id': rule_id, 'script': i, 'create_time': int(time.time())})
    #             #
    #             # # 添加扫描任务
    #             # with monitor_db_manager.db_mgr('custom_script') as db:
    #             #     # 关闭事务自动提交
    #             #     db.autocommit(False)
    #             #     try:
    #             #         if len(add_script) > 0:
    #             #             public.print_log('添加的脚本{}'.format(add_script), _level='error')
    #             #             # 添加脚本
    #             #             db.query() \
    #             #                 .name('custom_script') \
    #             #                 .insert_all(add_script)
    #             #         # 提交事务
    #             #         db.commit()
    #             #     except BaseException as e:
    #             #         # 回滚事务
    #             #         db.rollback()
    #             #
    #             #         # 打印异常堆栈
    #             #         public.print_exc_stack(e)
    #
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #
    #             return public.error('操作失败')
    #     # 检验脚本是否已经存在
    #     add_script = []
    #     old_script_lst = basic_monitor_obj.db_easy('custom_script').where('rule_id', rule_id).field('script').select()
    #     public.print_log('已有的脚本{}'.format(old_script_lst), _level='error')
    #     if old_script_lst:
    #         old_script_lst = [i['script'] for i in old_script_lst]
    #
    #     for i in valid_commands:
    #         if i not in old_script_lst:
    #             add_script.append({'rule_id': rule_id, 'script': i, 'create_time': int(time.time())})
    #
    #     # 添加脚本
    #     with monitor_db_manager.db_mgr('custom_script') as db:
    #         # 关闭事务自动提交
    #         db.autocommit(False)
    #         try:
    #             if len(add_script) > 0:
    #                 public.print_log('添加的脚本{}'.format(add_script), _level='error')
    #                 # 添加脚本
    #                 db.query() \
    #                     .name('custom_script') \
    #                     .insert_all(add_script)
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #
    #             # 打印异常堆栈
    #             public.print_exc_stack(e)
    #
    #
    #     # 设置端口测试连接状态
    #     warning_obj.set_server_port_test_state_with_warning_rules(rule_data, check_rule=False)
    #
    #     # 记录日志
    #     pro_name = rule_data['sub_type']
    #     sid = rule_data['sid']
    #     add_script_ = json.dumps(add_script, ensure_ascii=False, indent=4)
    #     invalid_commands_ = json.dumps(invalid_commands, ensure_ascii=False, indent=4)
    #     server_info = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').where('sid', sid).find()
    #
    #     if len(add_script) > 0:
    #         public.WriteLog('自定义监控进程', '监控【%s（%s）】下的进程【%s】 添加脚本:【%s】' % (
    #             server_info['ip'], server_info['remark'], pro_name, add_script_))
    #
    #     if len(invalid_commands) > 0:
    #         public.WriteLog('自定义监控进程', '监控【%s（%s）】下的进程【%s】 未成功添加的脚本:【%s】' % (
    #             server_info['ip'], server_info['remark'], pro_name, invalid_commands_))
    #         return public.success('操作成功, 未成功添加的脚本有：{}'.format(invalid_commands_))
    #
    #     return public.success('操作成功')
    #
    # # 追加脚本
    # def append_script(self, args):
    #     '''
    #         @name 追加脚本 可以追加多个脚本
    #         @author lt<2023-05-10>
    #         @arg    rule_id<string>             规则id
    #         @arg    script<string>              脚本 多条换行
    #         @return dict
    #     '''
    #     rule_id = args.get('rule_id', None)
    #     script = args.get('script', None)
    #     if rule_id is None or script is None:
    #         return public.return_error('缺少参数：rule_id/script')
    #
    #     # 验证脚本是否合法
    #     valid_commands = []
    #     invalid_commands = []
    #     scripts = script.split('\n')
    #     for command in scripts:
    #         is_ok = basic_monitor_obj.is_sensitive_command(command)
    #         if is_ok:  # 不合法
    #             invalid_commands.append(command)
    #         else:   # 合法
    #             valid_commands.append(command)
    #
    #     # 检验脚本是否已经存在
    #     add_script = []
    #     old_script_lst = basic_monitor_obj.db_easy('custom_script').where('rule_id', rule_id).field('script').select()
    #     public.print_log('已有的脚本{}'.format(old_script_lst), _level='error')
    #     if old_script_lst:
    #         old_script_lst = [i['script'] for i in old_script_lst]
    #     for i in valid_commands:
    #         if i not in old_script_lst:
    #             add_script.append({'rule_id': rule_id, 'script': i, 'create_time': int(time.time())})
    #     # 添加脚本
    #     with monitor_db_manager.db_mgr('custom_script') as db:
    #         # 关闭事务自动提交
    #         db.autocommit(False)
    #         try:
    #             if len(add_script) > 0:
    #                 public.print_log('添加的脚本{}'.format(add_script), _level='error')
    #                 # 添加脚本
    #                 db.query() \
    #                     .name('custom_script') \
    #                     .insert_all(add_script)
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #
    #             # 打印异常堆栈
    #             public.print_exc_stack(e)
    #
    #     rule_info = basic_monitor_obj.db_easy('warning_configurations').where('rule_id', rule_id).field('title').find()
    #     # 记录日志
    #     title = rule_info['title']
    #     add_script_ = json.dumps(add_script, ensure_ascii=False, indent=4)
    #     invalid_commands_ = json.dumps(invalid_commands, ensure_ascii=False, indent=4)
    #
    #     if len(add_script) > 0:
    #         public.WriteLog('自定义监控进程', '规则【%s】 追加脚本:【%s】' % (title, add_script_))
    #
    #     if len(invalid_commands) > 0:
    #         public.WriteLog('自定义监控进程', '规则【%s】 未成功追加的脚本:【%s】' % (title, invalid_commands_))
    #         return public.success('操作成功, 未成功添加的脚本有：{}'.format(invalid_commands_))
    #
    #     return public.success('操作成功')
    #
    # # 获取规则下的脚本列表
    # def get_script(self, args):
    #     '''
    #         @name 获取规则下的脚本列表
    #         @author lt<2023-05-10>
    #         @arg    rule_id<int>                 规则id   告警配置表 bt_warning_configurations --> id
    #         @arg    keyword<string>              关键字
    #         @arg    p<integer>                  分页页码
    #         @arg    p_size<integer>             分页大小
    #         @return dict
    #     '''
    #     rule_id = args.get('rule_id', None)
    #     keyword = args.get('keyword', None)
    #     if rule_id is None:
    #         return public.return_error('缺少参数：rule_id')
    #
    #     query = warning_obj.db_easy('custom_script') \
    #         .where('rule_id=?', int(rule_id)) \
    #         .order('create_time', 'desc')
    #     if keyword is not None:
    #         query.where('script like ?', '%{}%'.format(keyword))
    #
    #     # 分页查询
    #     ret = public.simple_page(query, args)
    #     return public.success(ret)
    #
    # # 修改监控脚本
    # def update_script(self, args):
    #     '''
    #         @name 修改监控脚本
    #         @author lt<2022-07-01>
    #         @arg    id<string>                  脚本id
    #         @arg    script<string>              新脚本 单条
    #         @return dict
    #     '''
    #     script = args.get('script', None)
    #     id = args.get('id', None)
    #     if id is None:
    #         return public.return_error('缺少参数：id')
    #     if script is None:
    #         return public.return_error('缺少参数：script')
    #     is_ok = basic_monitor_obj.is_sensitive_command(script)
    #     if not is_ok:
    #         return public.return_error('脚本不合法')
    #
    #     # 获取脚本信息与告警规则信息
    #     s = warning_obj.db_easy('custom_script').field('id', 'rule_id', 'script').where('id=?', int(id)).find()
    #     if s is None:
    #         return public.return_error('脚本不存在')
    #     warning_confs = basic_monitor_obj.db_easy('warning_configurations').where('id=?', s['rule_id']).field('id', 'title').find()
    #     if warning_confs is None:
    #         return public.return_error('告警规则不存在')
    #
    #     with monitor_db_manager.db_mgr() as db:
    #         try:
    #             # 关闭事务自动提交
    #             db.autocommit(False)
    #             db.query() \
    #                 .name('custom_script') \
    #                 .where('id=?', int(script)) \
    #                 .update({
    #                     'script': script,
    #                     'update_time': int(time.time())
    #                 })
    #
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #             return public.error('操作失败')
    #
    #     # 记录日志
    #     public.WriteLog('自定义监控', '修改脚本--将进程【%s】的原脚本【%s】修改为【%s】' % (warning_confs['title'], s['script'], script))
    #     return public.success('操作成功')
    #
    # # 删除监控脚本
    # def delete_script(self, args):
    #     '''
    #         @name 删除脚本 (删除脚本时, 同时删除脚本对应的执行结果)
    #         @author lt<2023-05-10>
    #         @arg    script<string>             脚本id 多个逗号隔开, 不传删除全部
    #         @return dict
    #     '''
    #     script_id = args.get('script', None)
    #     with monitor_db_manager.db_mgr() as db:
    #         try:
    #             # 关闭事务自动提交
    #             db.autocommit(False)
    #             # 删除原有脚本
    #             query = db.query().name('custom_script')
    #
    #             if script_id is not None and re.match(r'^\d+(?:,\d+)*$', script_id):
    #                 query.where_in('id', list(map(lambda x: x.strip(), script_id.split(','))))
    #
    #             script_data = query.fork().select()
    #             # 执行删除操作
    #             query.fork().delete()
    #
    #             # 删除脚本对应的执行结果
    #             db.query().name('custom_script_result') \
    #                 .where_in('script_id', list(map(lambda x: x.strip(), script_id.split(',')))) \
    #                 .delete()
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #             if isinstance(e, BtMonitorException):
    #                 return public.error(str(e))
    #             return public.error('操作失败')
    #     # 记录日志
    #     s_info = []
    #     for i in script_data:
    #         s_info.append('脚本: 【%s】'.format(i['script']))
    #     public.WriteLog('自定义监控', '删除脚本--%s' % s_info)
    #     return public.success('操作成功')
    #
    # # 获取进程信息
    # def get_processes_list(self, args):
    #     """进程监控列表 配置了脚本的进程才会显示
    #     @author lt<2023-05-10>
    #     Args:
    #         args (dict_obj): 查询参数对象
    #             query_date<?string>     时间查询[可选]
    #             process_name<?string>   搜索关键字[可选]
    #             sort<?string>           排序[可选]
    #             p<?integer>             分页页码[可选 默认1]
    #             p_size<?integer>        分页大小[可选 默认20]
    #     """
    #     public.print_log('======进程监控列表======'.format(), _level='error')
    #     query_date = args.get('query_date', None)
    #     process_name = args.get('process_name', None)
    #     # 查询所有脚本的规则id
    #     rule_ids = warning_obj.db_easy('custom_script') \
    #         .group('rule_id') \
    #         .column('rule_id')
    #     public.print_log('111(rule_ids) {}'.format(rule_ids), _level='error')
    #     if len(rule_ids) == 0:
    #         return public.return_data(True, {'total': 0, 'data': []})
    #
    #     # 查询所有规则id对应的进程信息
    #     configurations = basic_monitor_obj.db_easy('warning_configurations') \
    #         .where_in('id', rule_ids) \
    #         .field('sid', 'sub_type') \
    #         .where('`type` = ?', 'service') \
    #         .select()
    #
    #     if len(configurations) == 0:
    #         return public.return_data(True, {'total': 0, 'data': []})
    #
    #     # 进程名称
    #     pne_list = []
    #     # for i in configurations:
    #     #     pen_id = public.mmh3_hash64(i['sub_type'])
    #     #     pen_list.append(pen_id)
    #
    #     # 服务器sid
    #     sids = list(set([i['sid'] for i in configurations]))
    #     sub_types = list(set([i['sub_type'] for i in configurations]))
    #     for i in sub_types:
    #         pro_name = i.split('[')[1].split(']')[0].split('|')[0]
    #         pne_list.append(pro_name)
    #
    #     # # 如果pen_list 里有 'all' 删掉pen_list里的 'all'
    #     # pen_list = [i for i in pen_list if i != 'all']
    #     # public.print_log('333(sids {}'.format(sids), _level='error')
    #     # public.print_log('333(pen_list {}'.format(pen_list), _level='error')
    #
    #     query = basic_monitor_obj.db_memory('processes') \
    #         .field(
    #         'id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user',
    #         'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes',
    #         'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes', 'create_time',
    #         'update_time'
    #     ) \
    #         .where_in('sid', sids) \
    #         .where('`update_time` > ?', int(time.time()) - 120)
    #
    #     # 筛选出有规则,脚本的进程
    #     if 'all' not in pne_list:
    #         pne_ids = basic_monitor_obj.db_easy('process_name_exe').where_in('name', pne_list).field('id').column('id')
    #         query.where_in('pne_id', pne_ids)
    #
    #     if query_date is not None:
    #         query.where('`create_time` BETWEEN ? AND ?',
    #                     public.get_query_timestamp(query_date))
    #
    #     if process_name is not None:  # 进程名称与进程启动程序绝对路径表
    #         search_by_pne_id = basic_monitor_obj.db_easy('process_name_exe') \
    #             .where('`name` like ?', '%{}%'.format(process_name)) \
    #             .field('id') \
    #             .limit(500) \
    #             .column('id')
    #         # query.where('`name` like ?', '%{}%'.format(process_name))
    #         query.where_in('pne_id', search_by_pne_id)
    #
    #     # -disk_read_bytes_per_second|-disk_write_bytes_per_second
    #     if 'sort' not in args:
    #         query.order('`cpu_used_percent` + `mem_used_percent`', 'desc')
    #
    #     public.add_retrieve_sort_query(query, args)
    #     result = public.simple_page(query, args)
    #     # 进程基本信息ID
    #     pne_ids = []
    #
    #     # 数据采样设置ID
    #     sampling_ids = []
    #
    #     # 主机ID列表
    #     sid_list = set()
    #
    #     for item in result['list']:
    #         pne_ids.append(item['pne_id'])
    #
    #         # 构造数据采样设置ID
    #         item['sampling_id'] = public.mmh3_hash64('process|{}|{}'.format(
    #             item['id'], monitor_enums.SAMPLING_TYPE__GLOBAL))
    #         sampling_ids.append(item['sampling_id'])
    #
    #         sid_list.add(item['sid'])
    #
    #     # 查询进程基本信息
    #     pnes = basic_monitor_obj.db_easy('process_name_exe') \
    #         .where_in('id', pne_ids) \
    #         .field('id', 'name', 'exe') \
    #         .column(None, 'id')
    #
    #     # 查询数据采样设置
    #     sampling_settings = basic_monitor_obj.db_easy('sampling_settings') \
    #         .where_in('id', sampling_ids) \
    #         .field('id', 'status') \
    #         .column('status', 'id')
    #
    #     # 查询全局数据采样设置
    #     sampling_global = basic_monitor_obj.db_easy('servers') \
    #         .where_in('sid', list(sid_list)) \
    #         .field('sid', 'sampling') \
    #         .column('sampling', 'sid')
    #
    #     for p_item in result['list']:
    #         pne = pnes.get(p_item['pne_id'], {})
    #         p_item['name'] = pne.get('name', '')
    #         p_item['boot_command'] = pne.get('exe', '')
    #         p_item.update(
    #             basic_monitor_obj.cache_realtime_proc_info(p_item['id']))
    #         p_item['sampling_status'] = int(
    #             ((int(sampling_global[p_item['sid']])
    #               & monitor_enums.SAMPLING_GLOBAL__PROCESS)
    #              == monitor_enums.SAMPLING_GLOBAL__PROCESS)
    #             and sampling_settings.get(p_item['sampling_id'], 1))
    #         del (p_item['sampling_id'])
    #     result['custom'] = {
    #         'rule_ids': rule_ids,
    #         'pne_name': pne_list,
    #         'sid_ids': sids,
    #     }
    #     return public.success(result)

    # def update_script(self, args):
    #     '''
    #         @name 修改进程监控脚本
    #         @author lt<2023-05-10>
    #         @arg    rule_id<string>             规则id
    #         @arg    script<string>              新脚本 多条换行
    #         @return dict
    #     '''
    #     script = args.get('script', None)
    #     rule_id = args.get('rule_id', None)
    #     if rule_id is None:
    #         return public.return_error('缺少参数：rule_id')
    #     if script is None:
    #         return public.return_error('缺少参数：script')
    #
    #     # 合法脚本
    #     valid_commands = []
    #     # 非法脚本
    #     invalid_commands = []
    #
    #     # 验证脚本是否合法
    #     scripts = script.split('\n')
    #     for command in scripts:
    #         is_ok = basic_monitor_obj.is_sensitive_command(command)
    #         if is_ok:
    #             valid_commands.append(command)
    #         else:
    #             public.print_log('!!!!!!!!!!!!!!脚本不合法: {}'.format(command))
    #             invalid_commands.append(command)
    #
    #     script_data = []
    #     with monitor_db_manager.db_mgr() as db:
    #         try:
    #             # 关闭事务自动提交
    #             db.autocommit(False)
    #             # 删除原有脚本
    #             db.query() \
    #                 .name('custom_script') \
    #                 .where('rule_id=?', int(rule_id)) \
    #                 .delete()
    #
    #             # 脚本
    #             for command in valid_commands:
    #                 script_dict = {
    #                     'rule_id': rule_id,
    #                     'script': command
    #                 }
    #                 script_data.append(script_dict)
    #
    #             if len(script_data) > 0:
    #                 # 添加脚本
    #                 db.query() \
    #                     .name('custom_script') \
    #                     .insert_all(script_data)
    #
    #             # 提交事务
    #             db.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #
    #             return public.error('操作失败')
    #
    #     # 记录日志
    #
    #     return public.success('操作成功')
