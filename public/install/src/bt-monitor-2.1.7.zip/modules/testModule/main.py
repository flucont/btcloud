# encoding: utf-8
import os,sys
os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public, re, time
from core.include.monitor_helpers import warning_obj

class main():

    def test(self, args):
        return public.success(public.sqlite_execute_batch('monitor', '''
            delete from `bt_warning_tasks`;
        '''))

    def test1(self, args):
        warning_rules = [
            {
                "sid": 1,
                "title": "CPU使用率超过1%",
                "content": "检测到该主机CPU使用率超过1%，请及时处理",
                "type": "resource",
                "sub_type": "cpu",
                "watch_target": "percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "内存占用率超过1%",
                "content": "检测到该主机内存占用率超过1%，请及时处理",
                "type": "resource",
                "sub_type": "mem",
                "watch_target": "percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "内存占用超过100M",
                "content": "检测到该主机内存占用超过100M，请及时处理",
                "type": "resource",
                "sub_type": "mem",
                "watch_target": "used",
                "watch_type": 3,
                "watch_value": "100M"
            },
            {
                "sid": 1,
                "title": "swap占用率超过1%",
                "content": "检测到该主机swap占用率超过1%，请及时处理",
                "type": "resource",
                "sub_type": "swap",
                "watch_target": "percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "swap占用超过100M",
                "content": "检测到该主机swap占用超过100M，请及时处理",
                "type": "resource",
                "sub_type": "swap",
                "watch_target": "used",
                "watch_type": 3,
                "watch_value": "100M"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]占用率超过1%",
                "content": "检测到该主机磁盘[/dev/sda1]占用率1%，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "used_percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]inodes占用率超过1%",
                "content": "检测到该主机磁盘[/dev/sda1]inodes占用率超过1%，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "inodes_used_percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]iops超过1KB",
                "content": "检测到该主机磁盘[/dev/sda1]iops超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "iops",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]io耗时占比超过1%",
                "content": "检测到该主机磁盘[/dev/sda1]io耗时占比超过1%，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "io_percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]占用空间超过100M",
                "content": "检测到该主机磁盘[/dev/sda1]已占用空间超过100M，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "used",
                "watch_type": 3,
                "watch_value": "100MB"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]inodes占用空间超过100MB",
                "content": "检测到该主机磁盘[/dev/sda1]inodes占用空间超过100MB，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "inodes_used",
                "watch_type": 3,
                "watch_value": "100MB"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]每秒读取超过1KB",
                "content": "检测到该主机磁盘[/dev/sda1]每秒读取超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "read_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "磁盘[/dev/sda1]每秒写入超过1KB",
                "content": "检测到该主机磁盘[/dev/sda1]每秒写入超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "disk_[/dev/sda1]",
                "watch_target": "write_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "网卡[ens18]发送总流量超过1KB",
                "content": "检测到该主机网卡[ens18]发送总流量超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "net_[ens18]",
                "watch_target": "sent",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "网卡[ens18]接收总流量超过1KB",
                "content": "检测到该主机网卡[ens18]接收总流量超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "net_[ens18]",
                "watch_target": "recv",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "网卡[ens18]每秒发送流量超过1KB",
                "content": "检测到该主机网卡[ens18]每秒发送流量超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "net_[ens18]",
                "watch_target": "sent_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "网卡[ens18]每秒接收流量超过1KB",
                "content": "检测到该主机网卡[ens18]每秒接收流量超过1KB，请及时处理",
                "type": "resource",
                "sub_type": "net_[ens18]",
                "watch_target": "recv_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "最近1分钟内负载超过0.01",
                "content": "检测到该主机最近1分钟内负载超过0.01，请及时处理",
                "type": "resource",
                "sub_type": "load_avg",
                "watch_target": "last_1_min",
                "watch_type": 3,
                "watch_value": "0.01"
            },
            {
                "sid": 1,
                "title": "最近5分钟内负载超过0.01",
                "content": "检测到该主机最近5分钟内负载超过0.01，请及时处理",
                "type": "resource",
                "sub_type": "load_avg",
                "watch_target": "last_5_min",
                "watch_type": 3,
                "watch_value": "0.01"
            },
            {
                "sid": 1,
                "title": "最近15分钟内负载超过0.01",
                "content": "检测到该主机最近15分钟内负载超过0.01，请及时处理",
                "type": "resource",
                "sub_type": "load_avg",
                "watch_target": "last_15_min",
                "watch_type": 3,
                "watch_value": "0.01"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]CPU使用率超过1%",
                "content": "检测到该主机进程[BT-MonitorAgent]CPU使用率超过1%，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "cpu.percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]内存使用率超过1%",
                "content": "检测到该主机进程[BT-MonitorAgent]内存使用率超过1%，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "mem.percent",
                "watch_type": 1,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]每秒磁盘读取超过1KB",
                "content": "检测到该主机进程[BT-MonitorAgent]每秒磁盘读取超过1KB，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "disk.read_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]每秒磁盘写入超过1KB",
                "content": "检测到该主机进程[BT-MonitorAgent]每秒磁盘写入超过1KB，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "disk.write_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]每秒网络发送超过1KB",
                "content": "检测到该主机进程[BT-MonitorAgent]每秒网络发送超过1KB，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "net.sent_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "进程[BT-MonitorAgent]每秒网络接收超过1KB",
                "content": "检测到该主机进程[BT-MonitorAgent]每秒网络接收超过1KB，请及时处理",
                "type": "service",
                "sub_type": "proc_[BT-MonitorAgent]",
                "watch_target": "net.recv_per_second",
                "watch_type": 3,
                "watch_value": "1KB"
            },
            {
                "sid": 1,
                "title": "用户[root]登录成功",
                "content": "检测到该主机用户[root]登录成功，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "user_[]",
                "watch_type": 5,
                "watch_value": "success"
            },
            {
                "sid": 1,
                "title": "IP[192.168.1.45]登录成功",
                "content": "检测到该主机IP[192.168.1.45]登录成功，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "ip_[]",
                "watch_type": 5,
                "watch_value": "success"
            },
            {
                "sid": 1,
                "title": "用户[root]登录失败次数超过1次",
                "content": "检测到该主机用户[root]登录失败次数超过1次，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "user_[].faileds",
                "watch_type": 3,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "最近1小时内用户[root]登录失败次数超过1次",
                "content": "检测到该主机最近1小时内用户[root]登录失败次数超过1次，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "user_[].faileds_in_last_hour",
                "watch_type": 3,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "SSH登录总次数超过1次",
                "content": "检测到该主机SSH登录失败总次数超过1次，请及时处理",
                "type": "log",
                "sub_type": "ssh_login_logs",
                "watch_target": "faileds",
                "watch_type": 3,
                "watch_value": "1"
            },
            {
                "sid": 1,
                "title": "系统防火墙规则修改",
                "content": "检测到该主机系统防火墙规则发生修改，请及时处理",
                "type": "firewall",
                "sub_type": "rule",
                "watch_target": "change",
                "watch_type": 5,
                "watch_value": "all"
            },
        ]

        query = public.db_monitor('warning_configurations')

        for warning_rule in warning_rules:
            query.addAll('sid,title,content,type,sub_type,watch_target,watch_type,watch_value', (
                warning_rule['sid'],
                warning_rule['title'],
                warning_rule['content'],
                warning_rule['type'],
                warning_rule['sub_type'],
                warning_rule['watch_target'],
                warning_rule['watch_type'],
                warning_rule['watch_value']
            ))

        query.commit()

        return public.success('ok')

    def test2(self, args):
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        # 测试告警
        warning_rules = public.db_monitor('warning_configurations').field(
            'id,sid,title,content,type,sub_type,watch_target,watch_type,watch_value,is_push,push_methods'
        ).where('`sid` = ?', [int(sid)]).select()

        if warning_obj.is_empty_result(warning_rules):
            return public.error('fail')

        public.print_log(warning_rules)

        res = {}

        for warning_rule in warning_rules:
            res[str(warning_rule['id'])] = warning_obj.warn(warning_rule)

        return public.success(res)

    def test3(self, args):
        public.sqlite_easy('monitor').query().execute_script('''
            alter table `bt_warning_template_packages` add `push_methods` text not null default '';
        ''')
        return public.success('ok')

    def test4(self, args):
        db_safety = public.db('safety')

        res = db_safety.execute('''
            UPDATE `bt_server_list`
            SET `address` = '192.168.1.46'
            WHERE `sid` = 1
        ''')

        return public.success(res)

    def test5(self, args):
        query = public.db_monitor()

        query.execute('''
            ALTER TABLE `bt_warning_templates`
                ADD `package_id` INTEGER NOT NULL DEFAULT 0;
        ''')

        return public.success('ok')

    def test6(self, args):
        query = public.db_monitor()

        query.execute('''
            ALTER TABLE `bt_processes`
                ADD `disk_read_bytes_per_second` INTEGER NOT NULL DEFAULT 0;
        ''')

        query.execute('''
            ALTER TABLE `bt_processes`
                ADD `disk_write_bytes_per_second` INTEGER NOT NULL DEFAULT 0;
        ''')

        query.execute('''
            ALTER TABLE `bt_processes`
                ADD `net_sent_bytes_per_second` INTEGER NOT NULL DEFAULT 0;
        ''')

        query.execute('''
            ALTER TABLE `bt_processes`
                ADD `net_recv_bytes_per_second` INTEGER NOT NULL DEFAULT 0;
        ''')

        return public.success('ok')

    def test7(self, args):
        mount_point = '/www'
        m = re.search(r'((?:100(?:\.0{1,2})?|(?:[1-9]\d|\d)(?:\.\d{1,2})?))\%\s+'+mount_point, public.ExecShell('df -i {}'.format(mount_point))[0])
        return public.success(m.group(1))

    def test8(self, args):
        # 清空进程相关的表
        return public.success(warning_obj.db_easy().execute_script('''
            delete from `bt_processes`;
            delete from `bt_process_cpu_info_list`;
            delete from `bt_process_mem_info_list`;
            delete from `bt_process_disk_io_info_list`;
            delete from `bt_process_network_io_info_list`;
            delete from `bt_process_opened_connections_info_list`;
            delete from `bt_process_opened_files_info_list`;
            delete from `bt_process_opened_threads_info_list`;
        '''))

    def test9(self, args):
        res = public.db('safety').table('server_list').field('sid,address,status').select()

        cur_time = int(time.time())

        for item in res:
            update_data = {
                'sid': item['sid'],
                'ip': item['address'],
                'is_authorized': item['status'],
                'update_time': cur_time,
            }

            if public.db_monitor('servers').where('sid=?', int(item['sid'])).update(update_data) == 0 or not warning_obj.is_empty_result(public.db_monitor('servers').where('sid=?', int(item['sid'])).field('sid').find()):
                public.db_monitor('servers').insert(update_data)

        return public.success('ok')

    def test10(self, args):
        return public.success([
            int(public.db_monitor().query('select strftime("%s", "now")')[0][0]),
            int(time.time())
        ])
    
    def test11(self, args):
        return public.success(public.sqlite_execute_batch('monitor', '''
            alter table `bt_server_ports` add `last_test_time` integer not null default 0;
            drop index `idx_sid_ip_port_status_createTime`;
            create index `idx_sid_ip_port_status_createTime_lastTestTime`
                on `bt_server_ports` (`sid`, `port`, `status`, `create_time`, `last_test_time`);
        '''))
    
    def test12(self, args):
        sid = args.get('sid', None)
        
        if sid is None:
            return public.error('缺少参数：sid')
        
        if not warning_obj.server_is_online(sid):
            return public.error('主机已离线')
        
        server_id = public.get_serverid_bysid(sid)
        
        agent_data = public.send_agent_msg(
            server_id,
            'systeminfo',
            'GetSystemInfoByServer',
            'recv/systeminfo/GetSystemInfoByServer/'+server_id,
            public.g_pdata({})
        )
        
        server_detail = public.get_agent_msg(agent_data).get('body', {})
        
        public.print_log(server_detail)
        
        res = {
            'host_info': server_detail.get('host', {}),
            'cpu_info': server_detail.get('cpu', {}),
            'mem_info': server_detail.get('mem', {}),
            'disk_info': server_detail.get('disk_list', []),
            'net_info': server_detail.get('net_io_list', []),
            'load_avg': server_detail.get('loadavg', {}),
        }
        
        return public.success(res)
    
    def test13(self, args):
        return public.success(public.db_monitor('server_cpu_info_list').where(
            '`sid` = ? AND `create_time` > ?',
            [5, int(time.time()) - 60]
        ).field('ROUND(AVG(`percent`), 2)').select())

    def test14(self, args):
        return public.success(public.db_monitor().query('''
            SELECT ROUND(AVG(`percent`), 2) AS `percent_avg`
            FROM `bt_{table_name}`
            WHERE `sid` = ? AND `create_time` > ?
        '''.format_map({
            'table_name': 'server_cpu_info_list'
        }), [5, int(time.time()) - 60]))

    def test15(self, args):
        import core.include.cron_task as cron_task

        m = cron_task.main()
        params = {
            "type": "minute-n",
            "where1": 5,
        }
        task_name = "update_servers"
        res = m.create_task(task_name, params=params)

        return public.success(res)

    def test16(self, args):
        import core.include.cron_task as cron_task

        m = cron_task.main()

        res = m.delete_task('port_test_task')

        return public.success(res)

    def test17(self, args):
        return public.success('i am a encrypted test17')

    def test_report_data(self, queue=None, target=None):
        types = [
            'test_networktraffic',
            'test_systeminfo',
            'test_firewall_info',
            'test_sshandsoft',
            'test_loganalysis',
            'test_serverport',
            "test_process"
        ]
        import random, json, os

        if target is None:
            mock_type = random.choice(types)
        else:
            for t in types:
                if "test_"+target == t:
                    mock_type = t
                    break
        local_dir = os.path.dirname(os.path.abspath(__file__))
        # print(local_dir)
        data_file = os.path.join(local_dir, mock_type)
        if os.path.exists(data_file):
            # print("reading: {}".format(data_file))
            mock_data = json.loads(public.readFile(data_file))
            if "stype" in mock_data:
                # print("data type: {}".format(mock_data["stype"]))
                mock_data["stype"] = "test_"+mock_data["stype"]
                import time
                mock_data["addtime"] = time.time()
            queue.put(mock_data)
            # public.print_log("put test data: {}".format(mock_data["stype"]))

if __name__ == "__main__":
    m = main()
    m.test_report_data()