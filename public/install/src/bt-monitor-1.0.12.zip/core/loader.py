#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------

#--------------------------------
# 加载器
#--------------------------------
import os, queue, time
import json
import threading
from flask import g,Response
import core.include.public as public
import core.include.rbac as rbac
from core import get_input,not_login_modules,not_login_uri,mod_action_match,check_login,check_csrf,session,cache
# import core.include.c_loader.PluginLoader as plugin_loader


monitor_task = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path()))

rbac_obj = rbac.Rbac()
class loader:
    '''
        @name 加载模块
        @author hwliang
    '''
    __module = None
    __action = None
    __module_path = "{}/modules".format(public.get_panel_path())
    __action_object = None
    __module_object = None
    __plugin_path = "{}/plugin".format(public.get_panel_path())

    def __init__(self,module,action):
        '''
            @name 初始化模块加载
            @author hwliang
            @param module 模块名称
            @param action 方法名称
        '''
        self.__module = module
        self.__action = action

    def run(self, args):
        '''
            @name 加载并执行
            @author hwliang
            @param args 外部参数
            @return mixed
        '''
        return getattr(public.import_via_loader('{}/modules/{}Module/main.py'.format(public.get_panel_path(), self.__module)).main(), self.__action)(args)
        # return plugin_loader.module_run(self.__module,self.__action, args)


def http_run(module, action, args = None):
    '''
        @name http请求处理
        @author hwliang
        @param module: 模块名
        @param action: 方法名
        @param args<?dict_obj> 参数
        @return mixed
    '''

    if not rbac_obj.AccessDecision():
        return public.response(False,'您没有权限访问该模块!')
    args = args or get_input()
    loader_obj = loader(module,action)
    result = loader_obj.run(args)
    if isinstance(result,Response):
        return result
    if isinstance(result,str):
        return Response(result)
    return Response(json.dumps(result,ensure_ascii=False),mimetype='application/json')

# ws消息体队列
ws_body_queue = monitor_task.MonitorTaskQueue().blocking().run(16)

# 心跳包消息队列
heartbeat_queue = monitor_task.MonitorTaskQueue().blocking().run()

def ws_run(ws):
    '''
        @name websocket请求处理
        @author hwliang
        @param ws: websocket对象
        @return void
    '''
    # ws监听
    while ws.connected:
        ws_body = ws.receive()
        if not ws_body: continue

        try:
            ws_dict = json.loads(ws_body)
        except Exception as e: 
            public.print_log("receive exception: {}".format(e))
            continue

        # 心跳包单独队列处理
        if 'stype' in ws_dict and ws_dict['stype'] == 'Heartbeat':
            heartbeat_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))
            # heartbeat_queue.put(ws_body)
            continue

        # public.print_log('recv ws: {}'.format(ws_dict['stype']))

        # 将ws消息体放入队列中
        # ws_body_queue.put(ws_body)
        ws_body_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))

        # public.print_log('|--当前队列剩余消息数：{}'.format(ws_body_queue.qsize()))

    ws.close()


def ws_send(ws,status,msg):
    '''
        @name 发送消息
        @author hwliang
        @param ws: websocket对象
        @param status: 状态码
        @param msg: 消息体
        @return void
    '''
    if not ws.connected: return
    ws.send(json.dumps(public.return_data(status,msg),ensure_ascii=False))


def ws_thread(ws_body,ws):
    '''
        @name websocket消息处理线程
        @author hwliang
        @param ws_body: websocket消息
        @return void
    '''
    # 将接收到的消息体写入日志
    # public.print_log('recv ws_body: '+ws_body)
    if not ws_body: return
    try:
        # 解析数据
        ws_dict = json.loads(ws_body)

        args = public.to_dict_obj(ws_dict)

        # 获取模块、方法、回调
        module = args.get('module',None)
        action = args.get('action',None)
        callback = args.get('callback',None)
        server_id = args.get('server_id',None)

        # 如果是响应数据，则从callback中获取调用的模块、方法
        if callback and server_id and callback.find('recv/') == 0:
            result = public.agent_decrypt(server_id,args.pdata)
            if 'args' in result:
                result = result['args']
            if 'data' in result:
                result = result['data']

            try:
                if isinstance(result,str):
                    cache.set(callback,json.loads(result))
                else:
                    cache.set(callback,result)
            except:
                cache.set(callback,result)
            return


        # 模块名和方法名是否为空？
        if not module or not action: return

        # 检查URI格式
        if not mod_action_match.match(module) or not mod_action_match.match(action):
            return

        # 检查登录
        uri = "{}/{}".format(module,action)
        if not module in not_login_modules and not uri in not_login_uri:
            if not check_login(): return ws_send(ws,False,'请先登录')
            if not check_csrf(): return ws_send(ws,False,'CSRF验证失败')

        # print('--recv message from ws action[{}] server_id[{}] server_ip[{}]'.format(action, server_id, ws.environ['REMOTE_ADDR']))

        # 缓存ws会话
        if server_id and action == 'connected':
            public.set_server_ws(ws,server_id)
            # from core import servers_ws
            # public.print_log("{}".format(servers_ws))

        # 加载模块
        loader_obj = loader(module,action)

        # 执行模块方法
        args._ws = ws
        args.remote_addr = ws.environ['REMOTE_ADDR']
        result = loader_obj.run(args)

        # 如果返回侧为空？
        if not result: return

        if ws.connected:
            # 如果响应值不是dict
            if isinstance(result,dict):
                result['callback'] = callback
                ws.send(json.dumps(result,ensure_ascii=False))
            elif isinstance(result,str):
                    ws.send(result)
            else:
                ws.send(json.dumps(result,ensure_ascii=False))
    except BaseException as e:
        try:
            public.print_exc_stack(e)

            del (e,)

            if ws.connected:
                ws.send(public.get_error_info())
        except BaseException as e:
            del (e,)
