# -*- encoding: utf-8 -*-
#
# 云监控响应状态码
# @author Zhj<2022-11-09>

ok = 1 # 成功
fail = -1 # 失败
auth_num_exceed = 2001 # 超过最大可授权数量