import fcntl
from contextlib import contextmanager
from sqlite_server import acquire

@contextmanager
def acquire_with_file(filename = '/tmp/bt_monitor.lock'):
        try:
            # 加锁
            with open(filename, 'w') as fp:
                fcntl.flock(fp, fcntl.LOCK_EX)
            yield
        finally:
            # 释放锁
            with open(filename, 'w') as fp:
                fcntl.flock(fp, fcntl.LOCK_UN)