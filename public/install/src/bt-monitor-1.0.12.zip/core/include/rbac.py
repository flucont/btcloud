#coding: utf-8
'''
 +------------------------------------------------------------------------------
 * 基于角色的数据库方式验证类
 +------------------------------------------------------------------------------
 */
// 配置文件增加设置
// USER_AUTH_ON 是否需要认证
// USER_AUTH_TYPE 认证类型
// USER_AUTH_KEY 认证识别号
// REQUIRE_AUTH_MODULE  需要认证模块
// NOT_AUTH_MODULE 无需认证模块
// USER_AUTH_GATEWAY 认证网关
// RBAC_DB_DSN  数据库连接DSN
// RBAC_ROLE_TABLE 角色表名称
// RBAC_USER_TABLE 用户表名称
// RBAC_ACCESS_TABLE 权限表名称
// RBAC_NODE_TABLE 节点表名称
/*
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bt_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `sid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
# sid 服务器id

CREATE TABLE IF NOT EXISTS `bt_node` (
  `node_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;
# level： 1 菜单，2 模块，3 权限，4 服务器权限

CREATE TABLE IF NOT EXISTS `bt_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE IF NOT EXISTS `bt_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
*/
'''
from core import session,g,public


class Rbac:
    USER_AUTH_ON = True         # 开关
    USER_AUTH_TYPE = 2          # 认证类型
    ADMIN_AUTH_KEY = 1          # 超级管理员标识
    USER_AUTH_KEY = 'uid'           # 认证识别号
    REQUIRE_AUTH_MODULE = []    # 需要认证模块列表
    NOT_AUTH_MODULE = []        # 无需认证模块
    REQUIRE_AUTH_ACTION = []    # 需要认证的操作
    NOT_AUTH_ACTION = []        # 无需认证的操作
    RBAC_ROLE_TABLE = 'bt_role'     # 角色表
    RBAC_USER_TABLE = 'bt_role_user'    # 用户表
    RBAC_ACCESS_TABLE = 'bt_access' # 权限表
    RBAC_NODE_TABLE = 'bt_node'     # 节点表


    def __init__(self):
        '''
            @name 构造函数
        '''

        self.read_config()


    def read_config(self):
        '''
            @name 读取配置文件
        '''
        # 初始化配置信息
        rbac_config = public.read_config('rbac')
        self.USER_AUTH_ON = rbac_config['USER_AUTH_ON']
        self.USER_AUTH_TYPE = rbac_config['USER_AUTH_TYPE']
        self.ADMIN_AUTH_KEY = rbac_config['ADMIN_AUTH_KEY']
        self.USER_AUTH_KEY = rbac_config['USER_AUTH_KEY']
        self.REQUIRE_AUTH_MODULE = rbac_config['REQUIRE_AUTH_MODULE']
        self.NOT_AUTH_MODULE = rbac_config['NOT_AUTH_MODULE']
        self.REQUIRE_AUTH_ACTION = rbac_config['REQUIRE_AUTH_ACTION']
        self.NOT_AUTH_ACTION = rbac_config['NOT_AUTH_ACTION']
        self.RBAC_ROLE_TABLE = rbac_config['RBAC_ROLE_TABLE']
        self.RBAC_USER_TABLE = rbac_config['RBAC_USER_TABLE']
        self.RBAC_ACCESS_TABLE = rbac_config['RBAC_ACCESS_TABLE']
        self.RBAC_NODE_TABLE = rbac_config['RBAC_NODE_TABLE']


    def saveAccessList(self,authId=None):
        '''
            @name 保存权限列表
            @param authId 认证识别号
            @return boolean
        '''
        if not authId: authId = session.get('uid',0)
        if not authId: return False

        # 如果不是超级管理员，则需要获取当前用户的角色
        if self.USER_AUTH_TYPE != 2 and authId != self.ADMIN_AUTH_KEY:
            session['_ACCESS_LIST'] = self.getAccessList(authId)
        return True


    def getRecordAccessList(self,authId = None,module = None):
        '''
            @name 取得模块的所属记录访问权限列表 返回有权限的记录ID数组
            @author hwliang
            @param authId 认证识别号
            @param module 模块名称
            @return array
        '''
        if not authId: authId = session.get('uid',0)
        if not authId: return False

        if not module: module = g.get('module','')
        if not module: return False

        accessList = self.getModuleAccessList(authId,module)
        return accessList


    def checkAccess(self):
        '''
            @name 检查当前操作是否需要认证
            @author hwliang
            @return bool
        '''

        if self.USER_AUTH_ON:
            _module = g.get('module','')
            _action = g.get('action','')
            _uid = session.get('uid',0)
            if _uid == self.ADMIN_AUTH_KEY: # 超级管理员？
                return False
            if _module in self.NOT_AUTH_MODULE: # 无需认证的模块名?
                return False
            if _action in self.NOT_AUTH_ACTION: # 无需认证的操作名?
                return False
            return True
        return False

    def AccessDecision(self):
        '''
            @name 决定是否可以访问
            @author hwliang
            @param module 模块名称
            @param action 权限
            @return bool
        '''
        if self.USER_AUTH_TYPE == 2:
            self.read_config()

        # 检查认证过滤器
        if not self.checkAccess():
            return True

        _module = g.get('module', '')
        _action = g.get('action', '')
        _uid = session.get('uid',0)
        accessGuid = public.md5("{}/{}".format(_module ,_action))

        # 管理员无需认证
        if self.ADMIN_AUTH_KEY == _uid: return True

        if self.USER_AUTH_TYPE == 2:
            #加强验证和即时验证模式 更加安全 后台权限修改可以即时生效
            #通过数据库进行访问检查
            accessList = self.getAccessList(session.get(self.USER_AUTH_KEY,0))
        else:
            #如果是管理员或者当前操作已经认证过，无需再次认证
            if session.get(accessGuid,None):
                return True
            #登录验证模式，比较登录后保存的权限访问列表
            accessList = session.get('_ACCESS_LIST',[])
        # return accessList
        #判断是否为组件化模式，如果是，验证其全模块名
        accessStatus = session.get(accessGuid,False)
        if _module in accessList and _action in accessList[_module]:
            if not accessStatus: session[accessGuid] = True
            return True
        else:
            if accessStatus: session[accessGuid] = False
            return False



    def getAccessList(self, authId):
        '''
            @name 取得模块的所属记录访问权限列表 返回有权限的记录ID数组
            @author hwliang
            @param authId 认证识别号
            @return dict
        '''

        if not authId: return {}


        # 获取模块
        sql = '''select node.node_id,node.name from
            {user_table} as user,
            {role_table} as role,
            {access_table} as access,
            {node_table} as node
            where
            user.uid='{authId}'
            and user.role_id=role.role_id
            and role.role_id=access.role_id
            and role.status=1
            and access.node_id=node.node_id
            and access.sid = 0
            and node.level=2
            and node.status=1
            and node.display=1
        '''.format(
        user_table=self.RBAC_USER_TABLE,
        role_table=self.RBAC_ROLE_TABLE,
        access_table=self.RBAC_ACCESS_TABLE,
        node_table=self.RBAC_NODE_TABLE,
        authId=authId)

        db_obj = public.M('')
        modules = db_obj.query(sql)

        access = {}
        for value in modules:
            node_id = value[0]
            node_name = value[1]

            sql = '''select node.name from
                {user_table} as user,
                {role_table} as role,
                {access_table} as access,
                {node_table} as node
                where
                user.uid='{authId}'
                and user.role_id=role.role_id
                and role.role_id=access.role_id
                and role.status=1
                and access.node_id=node.node_id
                and access.sid = 0
                and node.pid={pid}
                and node.level=3
                and node.status=1
                and node.display=1
            '''.format(
            user_table=self.RBAC_USER_TABLE,
            role_table=self.RBAC_ROLE_TABLE,
            access_table=self.RBAC_ACCESS_TABLE,
            node_table=self.RBAC_NODE_TABLE,
            authId=authId,
            pid=node_id)
            node_list = db_obj.query(sql)
            if len(node_list) == 0:
                node_list = []
            else:
                node_list = [i[0] for i in node_list]
            access[node_name] = node_list
        return access


    def getModuleAccessList(self,authId = None,module = None):
        '''
            @name 读取模块所属的记录访问权限
            @author hwliang
            @param authId 认证识别号
            @param module 模块名称
            @return list
        '''

        db_obj = public.M('')
        sql = '''select node.node_id from
            {user_table} as user,
            {role_table} as role,
            {access_table} as access,
            {node_table} as node
            where
            user.uid='{authId}'
            and user.role_id=role.role_id
            and role.role_id=access.role_id
            and role.status=1
            and access.node_id=node.node_id
            and access.sid = 0
            and node.name='{module}'
            and node.level=2
            and node.status=1
            and node.display=1
            '''.format(
        role_table=self.RBAC_ROLE_TABLE,
        user_table=self.RBAC_USER_TABLE,
        access_table=self.RBAC_ACCESS_TABLE,
        node_table=self.RBAC_NODE_TABLE,
        authId=authId,
        module=module)
        modules_id = db_obj.query(sql)
        if len(modules_id) != 0:
            modules_id = modules_id[0][0]
        else:
            return []

        sql = '''select node.node_id from
            {user_table} as user,
            {role_table} as role,
            {access_table} as access,
            {node_table} as node
            where
            user.uid='{authId}'
            and user.role_id=role.role_id
            and role.role_id=access.role_id
            and role.status=1
            and access.node_id=node.node_id
            and access.sid = 0
            and node.pid='{modules_id}'
            and node.level=3
            and node.status=1
            and node.display=1
            '''.format(
        role_table=self.RBAC_ROLE_TABLE,
        user_table=self.RBAC_USER_TABLE,
        access_table=self.RBAC_ACCESS_TABLE,
        node_table=self.RBAC_NODE_TABLE,
        authId=authId,
        modules_id=modules_id)
        rs = db_obj.query(sql)

        access = []
        for node in rs:
            access.append(node[0])
        return access






