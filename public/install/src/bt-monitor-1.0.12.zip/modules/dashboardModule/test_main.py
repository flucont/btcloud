
import os,sys

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from modules.dashboardModule.main import main as DashboardModule


def test_get_processes():

	get = public.dict_obj()
	get.sid = 1

	dm = DashboardModule()
	print(dm.get_processes_list(get))

def test_get_log_path():
	dm = DashboardModule()
	get = public.dict_obj()
	get.sid = 1
	dm.get_logs_path_list(get)

def test_get_port_info():
	dm = DashboardModule()
	get = public.dict_obj()
	get.sid = 1
	get.p = 1
	print(dm.get_host_port_info(get))

def test_get_firewall_info():
	dm = DashboardModule()
	get = public.dict_obj()
	get.sid = 1
	get.p = 1
	print(dm.get_host_firewall_info(get))

def test_get_soft_info():
	dm = DashboardModule()
	get = public.dict_obj()
	get.sid = 1
	print(dm.get_installed_soft_info(get))

if __name__ == "__main__":
	# test_get_processes()
	# test_get_log_path()
	# test_get_port_info()
	test_get_soft_info()
	# test_get_firewall_info()