# encoding: utf-8
import core.include.public as public
from core.include.monitor_helpers import warning_obj
from core.include.monitor_exceptions import BtMonitorException
from core import session
import re, json, time
# import core.include.monitor_db_manager as monitor_db_manager
import core.include.c_loader.PluginLoader as plugin_loader


monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))

class main():
    '''
        @name 云监控告警模块
        @author Zhj<2022-06-30>
    '''
    def get_template_packages(self, args):
        '''
            @name 获取告警模板包
            @author Zhj<2022-07-08>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        keyword = args.get('keyword', None)

        query = warning_obj.db_easy('warning_template_packages')\
            .field('id', 'name', 'push_methods', 'create_time')\
            .order('create_time', 'desc')

        if keyword is not None:
            query.where('name like ?', '%{}%'.format(keyword))

        res = public.simple_page(query, args)

        for item in res['list']:
            # 模板规则数量
            item['rule_num'] = warning_obj.db_easy('warning_templates')\
                .where('package_id=?', int(item['id']))\
                .count()

            # 应用了此模板的主机数量
            item['applied_num'] = warning_obj.db_easy('server_warning_template_package_merge')\
                .where('package_id=?', int(item['id']))\
                .count()

        return public.success(res)

    def modify_template_package(self, args):
        '''
            @name 修改模板包名称
            @author Zhj<2022-07-08>
            @arg    package_id<integer> 模板包ID
            @arg    name<string>        模板包名称
            @return dict
        '''
        package_id = args.get('package_id', None)
        name = args.get('name', None)

        if package_id is None:
            return public.return_error('缺少参数：package_id')

        if name is None:
            return public.return_error('缺少参数：name')

        # 模板包名称不能为空
        if name == '':
            return public.error('模板名称不能为空')

        # 模板名称不能重复
        if db.query() \
                .name('warning_template_packages') \
                .where('name=?', name) \
                .where_not_in('id', [package_id]) \
                .field('id') \
                .exists():
            return public.error('模板名称【{}】已被使用'.format(name))

        warning_obj.db_easy('warning_template_packages')\
            .where('id=?', int(package_id))\
            .update({
                'name': name,
                'update_time': int(tim.time()),
            })

        return public.success('操作成功')

    def remove_template_packages(self, args):
        '''
            @name 删除模板包
            @author Zhj<2022-07-08>
            @arg    ids<string> 模板包ID列表
            @return dict
        '''
        package_ids = args.get('ids', None)

        if package_ids is None:
            return public.return_error('缺少参数：ids')

        if not re.match(r'^\d+(?:,\d+)*$', package_ids):
            return public.return_error('参数 ids 格式不正确')

        # 将模板包ID列表转为列表
        package_ids = package_ids.split(',')

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 删除模板包
                db.query().name('warning_template_packages').where_in('id', package_ids).delete()

                # 删除模板包对应的模板
                db.query().name('warning_templates').where_in('package_id', package_ids).delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error('删除失败')

        return public.success('操作成功')

    def apply_template_package(self, args):
        '''
            @name 应用模板包
            @author Zhj<2022-07-08>
            @args   sid<integer|string> 主机ID列表 使用[,]分隔
            @arg    package_id<integer> 模板包ID
            @return dict
        '''
        sid = args.get('sid', None)
        package_id = args.get('package_id', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^\d+(?:,\d+)*$', str(sid)):
            return public.error('参数sid格式错误')

        if package_id is None:
            return public.error('缺少参数：package_id')

        sid_list = str(sid).split(',')

        # sid为0时，应用所有主机
        if len(sid_list) == 1 and int(sid_list[0]) == 0:
            sid_list = warning_obj.db_easy('servers')\
                .field('sid')\
                .column('sid')

        # 检查主机是否存在
        if not warning_obj.db_easy('servers').where_in('sid', sid_list).field('sid').exists():
            return public.return_error('应用模板失败：主机不存在')

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 获取模板包下所有模板
                templates = db.query()\
                    .name('warning_templates')\
                    .where('package_id=?', int(package_id))\
                    .field(
                        'title', 'content', 'type', 'sub_type', 'watch_target', 'watch_type',
                        'watch_value', 'is_push', 'push_methods'
                    ).select()

                if warning_obj.is_empty_result(templates):
                    raise BtMonitorException('应用模板失败：模板为空')

                # 清空主机所有告警规则
                db.query().name('warning_configurations').where_in('sid', sid_list).delete()

                # 删除主机模板关联记录
                db.query().name('server_warning_template_package_merge').where_in('sid', sid_list).delete()

                # 批量插入数据
                insert_data = []

                for item in templates:
                    ok, _ = warning_obj.check_rule(item)

                    if not ok:
                        continue

                    for sid in sid_list:
                        tmp = item
                        tmp.update({
                            'sid': int(sid),
                        })
                        insert_data.append(tmp)

                # 批量插入告警规则
                if len(insert_data) > 0:
                    db.query()\
                        .name('warning_configurations')\
                        .insert_all(insert_data)

                # 添加主机告警模板包关联记录
                db.query()\
                    .name('server_warning_template_package_merge')\
                    .insert_all([{
                        'sid': int(sid),
                        'package_id': int(package_id),
                    } for sid in sid_list])

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error(str(e) if isinstance(e, BtMonitorException) else '应用模板失败')

        return public.success('操作成功')

    def get_server_list(self, args):
        '''
            @name 获取主机列表
            @author Zhj<2022-07-08>
            @arg    p<?integer>         分页页码
            @arg    p_size<?integer>    分页大小
            @arg    keyword<?string>    关键字
            @return dict
        '''
        keyword = args.get('keyword', None)

        query = warning_obj.db_easy('servers s')\
            .left_join('server_warning_template_package_merge m', 's.sid=m.sid')\
            .left_join('warning_template_packages p', 'm.package_id=p.id')\
            .field('s.sid', 's.ip', 's.remark', 's.status', 'ifnull(p.id,0) as package_id',
                   'ifnull(p.name, \'\') as cur_template', 'ifnull(p.push_methods,\'\') as push_methods')\
            .order('s.create_time', 'desc')

        if keyword is not None:
            query.where('s.ip LIKE ? OR s.remark LIKE ?', [
                '%{}%'.format(keyword),
                '%{}%'.format(keyword),
            ])

        res = public.simple_page(query, args)

        for item in res['list']:
            item['rule_num'] = warning_obj.db_easy('warning_configurations').where('sid=?', int(item['sid'])).count()

        return public.success(res)

    def get_templates(self, args):
        '''
            @name 获取告警模板列表
            @author Zhj<2022-06-30>
            @arg    p<integer>              分页页码
            @arg    p_size<integer>         分页大小
            @arg    keyword<string>         关键字
            @arg    package_id<?integer>    模板包ID
            @return dict
        '''
        keyword = args.get('keyword', None)
        package_id = args.get('package_id', None)

        query = warning_obj.db_easy('warning_templates')\
            .field('id', 'title', 'type', 'sub_type', 'watch_target', 'watch_type', 'watch_value',
                   'is_push', 'push_methods', 'content', 'create_time')\
            .order('create_time', 'desc')

        if package_id is not None:
            query.where('package_id=?', int(package_id))

        if keyword is not None:
            query.where('title like ?', '%{}%'.format(keyword))

        return public.success(public.simple_page(query, args))

    def remove_templates(self, args):
        '''
            @name   删除告警模板
            @author Zhj<2022-06-30>
            @arg    ids<string> 模板ID列表
            @return dict
        '''
        temp_ids = args.get('ids', None)

        if temp_ids is None:
            return public.return_error('缺少参数：ids')

        if not re.match(r'^\d+(?:,\d+)*$', temp_ids):
            return public.return_error('参数 ids 格式不正确')

        warning_obj.db_easy('warning_templates')\
            .where_in('id', temp_ids.split(','))\
            .delete()

        return public.success('操作成功')

    def modify_template(self, args):
        '''
            @nmae   修改告警模板
            @author Zhj<2022-06-30>
            @arg    id<integer>         模板ID
            @arg    modified<string>    更改后的数据
            @return dict
        '''
        try:
            temp_id = args.get('id/d', None)
            modified = args.get('modified/json', None)
        except Exception as e:
            return public.return_error(str(e))

        if temp_id is None:
            return public.return_error('缺少参数：temp_id')

        if modified is None:
            return public.return_error('缺少参数：modified')

        if not warning_obj.db_easy('warning_templates').where('id=?', temp_id).field('id').exists():
            return public.return_error('无效的模板ID')

        if 'id' in modified:
            del modified['id']

        if 'create_time' in modified:
            del modified['create_time']

        modified['update_time'] = int(time.time())

        # 验证告警规则是否合法
        ok, err_msg = warning_obj.check_rule(modified)

        if not ok:
            return public.return_error(err_msg)

        warning_obj.db_easy('warning_templates').where('id=?').update(modified)

        return public.success('操作成功')

    def add_template(self, args):
        '''
            @name   添加告警模板
            @author Zhj<2022-06-30>
            @arg    package_id<?integer>    模板包ID
            @arg    package_name<?string>   模板包名称
            @arg    template_data<string>   模板数据列表
            @return dict
        '''
        try:
            package_id = args.get('package_id/d', None)
            package_name = args.get('package_name', None)
            template_data = args.get('template_data/json', None)
            push_methods = args.get('push_methods', '')
            sync_rules = args.get('sync_rules/d', None)
        except Exception as e:
            return public.return_error(str(e))

        if package_id is None and package_name is None:
            return public.return_error('缺少参数：package_id或者package_name')

        if template_data is None:
            return public.return_error('缺少参数：template_data')

        if not isinstance(template_data, list):
            return public.error('无效的参数：template_data')

        # 获取数据库对象
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 模板包名称验证
                if package_name is not None:
                    # 模板包名称不能为空
                    if package_name == '':
                        raise BtMonitorException('模板名称不能为空')

                    query = db.query()\
                        .name('warning_template_packages')\
                        .where('name=?', package_name)\
                        .field('id')\

                    if package_id is not None:
                        query.where_not_in('id', [package_id])

                    # 模板名称不能重复
                    if query.exists():
                        raise BtMonitorException('模板名称【{}】已被使用'.format(package_name))

                # 指定模板包ID
                # 则新增模板包
                if package_id is None:
                    package_id = db.query().name('warning_template_packages').insert({
                        'name': package_name,
                        'push_methods': push_methods,
                    })
                # 否则更新模板包名称
                else:
                    # 更新模板包信息
                    db.query()\
                        .name('warning_template_packages')\
                        .where('id=?', int(package_id))\
                        .update({
                            'name': package_name,
                            'push_methods': push_methods,
                            'update_time': int(time.time()),
                        })

                # 删除模板包下所有模板
                db.query().name('warning_templates').where('package_id=?', int(package_id)).delete()

                insert_data = []

                for item in template_data:
                    # 验证告警规则是否合法
                    ok, err_msg = warning_obj.check_rule(item)

                    if not ok:
                        raise BtMonitorException('添加模板失败： {}'.format(err_msg))

                    insert_data.append({
                        'package_id': package_id,
                        'title': item.get('title', ''),
                        'content': item.get('content', ''),
                        'type': item['type'],
                        'sub_type': item['sub_type'],
                        'watch_target': item['watch_target'],
                        'watch_type': item['watch_type'],
                        'watch_value': item['watch_value'],
                        'is_push': item.get('is_push', 0),
                        'push_methods': push_methods
                    })

                # 批量插入
                if len(insert_data) > 0:
                    db.query().name('warning_templates').insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error(str(e) if isinstance(e, BtMonitorException) else '添加模板失败')

        # 更新所有应用此模板的主机告警规则
        if sync_rules == 1:
            return self.update_rules_by_templates(public.to_dict_obj({
                'package_ids': str(package_id),
            }))

        return public.success('操作成功')

    def get_rules(self, args):
        '''
            @name 获取告警规则列表
            @author Zhj<2022-06-30>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @arg    sid<?integer>   主机ID
            @return dict
        '''
        keyword = args.get('keyword', None)
        sid = args.get('sid', None)

        query = warning_obj.db_easy('warning_configurations wc')\
            .join('servers s', 'wc.sid=s.sid')\
            .field('wc.id', 'wc.sid', 'wc.title', 'wc.type', 'wc.sub_type', 'wc.watch_target', 'wc.watch_type', 'wc.watch_value',
                   'wc.is_push', 'wc.content', 'wc.push_methods', 'wc.create_time', 's.ip', 's.remark as server_name')\
            .order('wc.create_time', 'desc')

        if keyword is not None:
            query.where('title like ?', '%{}%'.format(keyword))

        if sid is not None:
            query.where('wc.sid=?', int(sid))

        # 分页查询
        ret = public.simple_page(query, args)

        # 监控动作转换文本
        # trans = {
        #     'success': '成功',
        #     'fail': '失败',
        #     'online': '上线',
        #     'offline': '下线',
        #     'active': '活动',
        #     'deactive': '终止',
        # }

        # for item in ret['list']:
        #     if item['watch_type'] == 5:
        #         item['watch_value'] = trans.get(item['watch_value'], item['watch_value'])

        return public.success(ret)

    def remove_rules(self, args):
        '''
            @name 删除告警规则
            @author Zhj<2022-06-30>
            @arg    ids<string> 告警规则ID列表
            @return dict
        '''
        rule_ids = args.get('ids', None)

        if rule_ids is None:
            return public.return_error('缺少参数：ids')

        if not re.match(r'^\d+(?:,\d+)*$', rule_ids):
            return public.return_error('参数 ids 格式不正确')

        # 主机告警规则列表
        warning_rules = []

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 获取告警规则
                warning_rules = db.query()\
                    .name('warning_configurations')\
                    .where_in('id', rule_ids.split(','))\
                    .field('id', 'sid', 'title', 'content', 'type', 'sub_type', 'watch_target',
                           'watch_type', 'watch_value', 'is_push', 'push_methods'
                    )\
                    .select()

                # 删除告警规则
                db.query()\
                    .name('warning_configurations')\
                    .where_in('id', rule_ids.split(','))\
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)

                return public.error('删除失败')

        # 设置端口测试连接状态
        warning_obj.set_server_port_test_state_with_warning_rules(warning_rules, False, False)

        return public.success('操作成功')

    def modify_rule(self, args):
        '''
            @name 修改告警规则
            @author Zhj<2022-06-30>
            @arg    id<integer>         告警规则ID
            @arg    modified<string>    修改后的告警规则
            @return dict
        '''
        try:
            rule_id = args.get('id/d', None)
            modified = args.get('modified/json', None)
        except Exception as e:
            return public.return_error(str(e))

        if rule_id is None:
            return public.return_error('缺少参数：rule_id')

        if modified is None:
            return public.return_error('缺少参数：modified')

        if not warning_obj.db_easy('warning_configurations').where('id=?', rule_id).field('id').exists():
            return public.return_error('无效的告警规则ID')

        if 'id' in modified:
            del modified['id']

        if 'create_time' in modified:
            del modified['create_time']

        modified['update_time'] = int(time.time())

        # 验证告警规则是否合法
        ok, err_msg = warning_obj.check_rule(modified)

        if not ok:
            return public.return_error(err_msg)

        warning_obj.db_easy('warning_configurations').where('id=?', rule_id).update(modified)

        return public.success('操作成功')

    def add_rule(self, args):
        '''
            @name 添加告警规则
            @author Zhj<2022-07-01>
            @arg    rule_data<string>           告警规则数据
            @arg    save_to_template<?integer>  是否保存为模板
            @return dict
        '''
        try:
            rule_data = args.get('rule_data/json', None)
            save_to_template = args.get('save_to_template/d', 0)
        except Exception as e:
            return public.return_error(str(e))

        if rule_data is None:
            return public.return_error('缺少参数：rule_data')

        # 验证告警规则是否合法
        ok, err_msg = warning_obj.check_rule(rule_data)

        if not ok:
            return public.return_error(err_msg)

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query()\
                    .name('warning_configurations')\
                    .insert(rule_data)

                # 是否需要保存为模板
                if save_to_template == 1:
                    insert_data = {}
                    insert_data.update(rule_data)

                    if 'sid' in insert_data:
                        del insert_data['sid']

                    if 'push_methods' in insert_data:
                        del insert_data['push_methods']

                    db.query()\
                        .name('warning_templates')\
                        .insert(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error('操作失败')

        # 设置端口测试连接状态
        warning_obj.set_server_port_test_state_with_warning_rules(rule_data, check_rule=False)

        return public.success('操作成功')

    def save_rules_to_template(self, args):
        '''
            @name 保存主机规则为告警模板
            @author Zhj<2022-08-31>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 获取主机信息
                server_info = db.query()\
                    .name('servers')\
                    .where('sid=?', sid)\
                    .field('sid', 'ip', 'remark')\
                    .find()

                if server_info is None:
                    raise BtMonitorException('无效的参数：sid')

                # 获取主机告警规则
                warning_rules = db.query()\
                    .name('warning_configurations')\
                    .where('sid=?', sid)\
                    .field(
                        'title',
                        'content',
                        'type',
                        'sub_type',
                        'watch_target',
                        'watch_type',
                        'watch_value',
                        'is_push',
                        'push_methods'
                    )\
                    .select()

                if len(warning_rules) < 1:
                    raise BtMonitorException('主机告警规则为空')

                # 插入模板包
                package_id = db.query() \
                    .name('warning_template_packages') \
                    .insert({
                        'name': '主机[{}]的告警模板_{}'.format('{}（{}）'.format(server_info['ip'], server_info['remark']) if server_info['remark'] != '' else server_info['ip'], public.gen_password(8)),
                        'push_methods': warning_rules[0]['push_methods'],
                    })

                # 生成告警模板
                for item in warning_rules:
                    item['package_id'] = package_id

                db.query()\
                    .name('warning_templates')\
                    .insert_all(warning_rules)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error(str(e) if isinstance(e, BtMonitorException) else '操作失败')

        return public.success('操作成功')

    def update_rules_by_templates(self, args):
        '''
            @name 更新所有应用此模板的主机告警规则
            @author Zhj<2022-07-27>
            @arg    package_ids<string>     告警模板包ID列表
            @arg    sid_list<?string>       主机ID列表[可选]
            @return dict
        '''
        package_ids = args.get('package_ids', None)
        sid_list = args.get('sid_list', None)

        if package_ids is None:
            return public.return_error('缺少参数：package_ids')

        if not re.match(r'^\d+(?:,\d+)*$', package_ids):
            return public.return_error('参数 package_ids 格式不正确')

        # 将模板包ID列表转为列表
        package_ids = package_ids.split(',')

        # 主机告警规则列表
        warning_rules = []

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 查询模板包对应的所有主机ID
                query = db.query()\
                    .name('server_warning_template_package_merge')\
                    .where_in('package_id', package_ids)\
                    .field('package_id', 'sid')

                # 指定了主机ID
                if sid_list is not None:
                    if not re.match(r'^\d+(?:,\d+)*$', sid_list):
                        raise BtMonitorException('参数 sid_list 格式不正确')

                    query.where_in('sid', sid_list.split(','))

                merge_list = query.select()

                # 查询模板包对应的模板规则
                templates = db.query() \
                    .name('warning_templates') \
                    .where_in('package_id', package_ids) \
                    .field(
                        'title', 'content', 'type', 'sub_type', 'watch_target', 'watch_type',
                        'watch_value', 'is_push', 'push_methods', 'package_id'
                    ).select()

                # package_id => [templates]
                t_dict = {}
                for template_info in templates:
                    if template_info['package_id'] not in t_dict:
                        t_dict[template_info['package_id']] = []

                    tmp = {}
                    tmp.update(template_info)
                    del(tmp['package_id'])
                    t_dict[template_info['package_id']].append(tmp)

                # 批量插入数据
                insert_data = []
                for merge_info in merge_list:
                    # 获取主机告警规则
                    warning_rules += db.query() \
                        .name('warning_configurations') \
                        .where('sid=?', merge_info['sid']) \
                        .field('id', 'sid', 'title', 'content', 'type', 'sub_type', 'watch_target',
                               'watch_type', 'watch_value', 'is_push', 'push_methods'
                        ) \
                        .select()

                    # 删除主机所有告警规则
                    db.query().name('warning_configurations').where('sid=?', merge_info['sid']).delete()


                    # 添加告警规则
                    if merge_info['package_id'] in t_dict:
                        for template_info in t_dict[merge_info['package_id']]:
                            tmp = {}
                            tmp.update(template_info)
                            tmp['sid'] = merge_info['sid']
                            insert_data.append(tmp)

                # 批量添加主机告警规则
                if len(insert_data) > 0:
                    db.query()\
                        .name('warning_configurations')\
                        .insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error(str(e) if isinstance(e, BtMonitorException) else '操作失败')

        # 设置端口测试连接状态
        warning_obj.set_server_port_test_state_with_warning_rules(warning_rules, False, False)

        return public.success('操作成功')

    def get_settings(self, args):
        '''
            @name 获取告警设置规则
            @author Zhj<2022-07-01>
            @arg    sid<?integer>   主机ID
            @return dict
        '''
        return public.success(warning_obj.get_settings(args.get('sid/d', None)))

    def handled_task(self, args):
        '''
            @name 将告警任务的状态更改为 已处理
            @author Zhj<2022-07-05>
            @arg    sid<?integer>    主机ID
            @arg    task_id<?string> 告警任务ID
            @return dict
        '''
        cur_time = int(time.time())

        sid = args.get('sid', None)
        task_id = args.get('task_id', None)

        # if task_id is None and sid is None:
        #     return public.error('缺少参数：task_id 或 sid')

        if task_id is not None and not re.match(r'^\d+(?:,\d+)*$', task_id):
            return public.error('参数 task_id 格式不正确')

        # 告警规则id列表
        warning_conf_id_list = []

        with monitor_db_manager.db_mgr('warning_tasks') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                query = db.query()\
                    .name('warning_tasks')

                if sid is not None:
                    query.where('sid=?', int(sid))

                if task_id is not None:
                    query.where_in('id', task_id.split(','))

                warning_tasks = query.field('id', 'conf_id').select()
                warning_task_id_list = []

                for warning_task in warning_tasks:
                    warning_task_id_list.append(warning_task['id'])
                    warning_conf_id_list.append(warning_task['conf_id'])

                # 更新告警任务处理状态
                db.query()\
                    .name('warning_tasks')\
                    .where_in('id', warning_task_id_list)\
                    .update({
                        'status': 1,
                        'update_time': cur_time,
                        'handle_time': cur_time,
                    })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)

                return public.error('操作失败')

        if len(warning_conf_id_list) > 99:
            # 查询告警规则信息
            warning_conf_list = warning_obj.db_easy('warning_configurations')\
                .alias('wc')\
                .join('servers s', 'wc.sid=s.sid')\
                .field('s.ip', 's.remark', 'wc.title')\
                .where_in('wc.id', list(set(warning_conf_id_list)))\
                .select()

            if warning_obj.is_empty_result(warning_conf_list):
                warning_conf = []

            for warning_conf in warning_conf_list:
                server_describe = '{}{}'.format(warning_conf['ip'], '（{}）'.format(warning_conf['remark']) if warning_conf['remark'] != '' else '')
                # 写入操作日志
                public.WriteLog('告警任务', '用户[{}]将主机[{}]的告警任务[{}]状态设置为[已处理]'.format(session.get('username', ''), server_describe, warning_conf.get('title', '')))

        return public.success('操作成功')

    def clear_tasks(self, args):
        '''
            @name 清除告警任务
            @author Zhj<2022-07-19>
            @arg    sid<?integer>       主机ID[可选 默认清空所有主机告警任务]
            @arg    task_ids<?string>   要删除的告警任务ID列表[可选 默认清空所有告警任务]
            @return dict
        '''
        sid = args.get('sid', None)
        task_ids = args.get('task_ids', None)

        # 打开数据库
        with monitor_db_manager.db_mgr('warning_tasks') as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                query = db.query().name('warning_tasks')

                if sid is not None:
                    query.where('`sid` = ?', int(sid))

                if task_ids is not None and re.match(r'^\d+(?:,\d+)*$', task_ids):
                    query.where_in('id', list(map(lambda x: x.strip(), task_ids.split(','))))

                # 执行删除操作
                query.delete()

                # 提交事务
                query.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                if isinstance(e, BtMonitorException):
                    return public.error(str(e))

        return public.success('操作成功')

    def export_templates(self, args):
        '''
            @name 导出告警模板
            @author Zhj<2022-07-06>
            @arg    ids<string> 模板包ID列表
            @return dict
        '''
        package_ids = args.get('ids', None)

        if package_ids is None:
            return public.error('缺少参数：ids')

        if not re.match(r'^\d+(?:,\d+)*$', package_ids):
            return public.error('参数 ids 格式不正确')

        templates = warning_obj.db_easy('warning_template_packages wtp')\
            .join('warning_templates wt', 'wtp.id=wt.package_id')\
            .where_in('wtp.id', package_ids.split(','))\
            .field(
                'wtp.id as package_id', 'wtp.name as package_name', 'wtp.push_methods as package_push_methods',
                'wt.title', 'wt.content', 'wt.type', 'wt.sub_type', 'wt.watch_target', 'wt.watch_type',
                'wt.watch_value', 'wt.is_push', 'wt.push_methods'
            )\
            .select()

        if warning_obj.is_empty_result(templates):
            return public.error('导出告警模板失败')

        d = {}
        content = []
        for i in templates:
            k = '{}|{}|{}'.format(i['package_name'], i['package_push_methods'], i['package_id'])
            if k not in d:
                d[k] = []

            d[k].append('{}|{}|{}|{}|{}|{}|{}|{}|{}'.format(
                i['title'],
                i['content'],
                i['type'],
                i['sub_type'],
                i['watch_target'],
                i['watch_type'],
                i['watch_value'],
                i['is_push'],
                i['push_methods']
            ))

        # 告警模板名称列表
        package_names = []

        # 组装导出文本
        for k, v in d.items():
            if len(v) == 0:
                continue
            package_info = k.split('|', 2)
            package_names.append(package_info[0])
            content.append("{}\n{}".format('|'.join(package_info[:2]), "\n".join(v)))

        content = "\n==============================\n".join(content)

        if len(content) == 0:
            return public.return_error('导出告警模板失败')

        # 记录操作日志
        public.WriteLog('告警设置', '用户[{}]导出告警模板[{}]'.format(public.bt_auth('username'), ','.join(package_names)))

        from datetime import date

        return public.send_file(bytes(content, encoding='utf-8'), 'warning_template_{}.pl'.format(date.today()))

    def import_templates(self, args):
        '''
            @name 导入告警模板
            @author Zhj<2022-07-06>
            @args   content<string> 模板文件内容
            @return dict
        '''
        content = args.get('content', None)

        if content is None:
            return public.error('缺少参数：content')

        if not re.match(r'^[^\n]+\n[^|\n]*(?:[|][^|\n]*){8}(?:\n[^|\n]*(?:[|][^|\n]*){8})*(?:\n\={30}\n[^\n]+\n[^|\n]*(?:[|][^|\n]*){8}(?:\n[^|\n]*(?:[|][^|\n]*){8})*)*$', content):
            return public.error('参数 content 格式错误')

        # 告警模板名称列表
        package_names = []

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 批量插入数据
                insert_data = []
                fields = ['title', 'content', 'type', 'sub_type', 'watch_target', 'watch_type', 'watch_value', 'is_push', 'push_methods']
                for sec in content.split('=============================='):
                    package_info, templates = sec.strip().split("\n", 1)

                    package_name, package_push_methods = package_info.strip().split('|', 1)

                    package_name = package_name.strip()
                    package_push_methods = package_push_methods.strip()

                    # 模板包名称为空
                    # 跳过
                    if package_name == '':
                        continue

                    # 存在重名
                    # 则后面拼接8位随机字符串
                    if db.query()\
                        .name('warning_template_packages')\
                        .where('name=?', package_name)\
                        .field('id')\
                        .exists():
                        package_name = '{}_{}'.format(package_name, public.md5(str(time.time()))[:9])

                    package_names.append(package_name)

                    # 插入模板包
                    package_id = db.query()\
                        .name('warning_template_packages')\
                        .insert({
                            'name': package_name,
                            'push_methods': package_push_methods,
                        })

                    # 收集告警模板批量插入数据
                    for row in templates.split("\n"):
                        el = {
                            'package_id': package_id,
                        }
                        for idx, field in enumerate(row.strip().split('|')):
                            el[fields[idx]] = field

                        insert_data.append(el)

                # 批量插入告警模板
                if len(insert_data) > 0:
                    db.query()\
                        .name('warning_templates')\
                        .insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error('导入失败')

        # 记录操作日志
        if len(package_names) > 0:
            public.WriteLog('告警设置', '用户[{}]导入告警模板[{}]'.format(public.bt_auth('username'), ','.join(package_names)))

        return public.success('导入成功')