import paramiko
import threading
import json
import time
from io import StringIO
import sys
import socket
import os

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core import my_terms
# from serverModule.main import main as serverModule
from core.include.flask_session import Session

serverModule = public.import_via_loader('{}/modules/serverModule/main.py'.format(public.get_panel_path())).main


class main:
    __log_type = '被控面板终端'
    _coll_user = None
    _host = None
    _web_socket = None
    _ssh_info = None
    _ssh_socket = None
    _uid = 1

    def __init__(self):
        pass

    def connect(self, ssh_info=None):
        if ssh_info: self._ssh_info = ssh_info
        if not self._host: self._host = self._ssh_info['host']
        if self._ssh_info['host'] in my_terms:
            if time.time() - my_terms[self._host].last_time < 86400:
                return True
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
            sock.connect((self._ssh_info['host'], int(self._ssh_info['port'])))
        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("服务器连接失败!")
            return False

        # 使用Transport连接
        p1 = paramiko.Transport(sock)
        p1.start_client()
        if 'pkey' not in self._ssh_info:
            self._ssh_info['pkey'] = None
        else:
            self._ssh_info['c_type'] = True
        try:
            # 如果有pkey时则使用RSA私钥登录
            if self._ssh_info['pkey'] and self._ssh_info['c_type']:
                # 将RSA私钥转换为io对象，然后生成rsa_key对象
                p_file = StringIO(self._ssh_info['pkey'])
                pkey = paramiko.RSAKey.from_private_key(p_file)
                p1.auth_publickey(username=self._ssh_info['username'], key=pkey)
            else:
                p1.auth_password(username=self._ssh_info['username'], password=self._ssh_info['password'])
        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("用户验证失败!")
            p1.close()
            return False

        my_terms[self._host] = public.dict_obj()
        my_terms[self._host].last_time = time.time()
        my_terms[self._host].connect_time = time.time()
        # 打开会话
        my_terms[self._host].tty = p1.open_session()
        # 获取终端对象
        my_terms[self._host].tty.get_pty(term='xterm', width=100, height=29)
        my_terms[self._host].tty.invoke_shell()
        # 记录登陆记录
        public.M('ssh_records').add('coll_user,ssh_user,host,cmd,addtime', (
            self._coll_user, self._ssh_info['username'], self._ssh_info['host'], 'login', int(time.time())))
        return True

    def resize(self, data):
        try:
            data = json.loads(data)
            if "width" in data:
                my_terms[self._host].tty.resize_pty(width=data['width'], height=data['height'],
                                                    width_pixels=data['width_px'], height_pixels=data['height_px'])
            else:
                my_terms[self._host].tty.resize_pty(width=data['cols'], height=data['rows'])
            return True
        except BaseException as e:
            public.print_exc_stack(e)
            print(public.get_error_info())
            return False

    def send(self):
        try:
            while self._web_socket.connected:
                c_data = self._web_socket.receive()
                if not c_data: continue
                if len(c_data) > 10:
                    if c_data.find('{"host":"') != -1:
                        continue
                    if c_data.find('"resize":1') != -1:
                        self.resize(c_data)
                        continue
                    if c_data.find('resize_pty') != -1:
                        if self.resize(c_data): continue
                    elif c_data.find('"password"') != -1 and c_data.find('"host"') != -1:
                        continue
                if self._host in my_terms:
                    my_terms[self._host].last_time = time.time()
                    my_terms[self._host].tty.send(c_data)
                else:
                    return
        except BaseException as e:
            public.print_exc_stack(e)
            # print(public.get_error_info())

    def recv(self):
        try:
            n = 0
            while self._web_socket.connected:
                self.not_send()
                if n == 0: self.last_send()
                data = my_terms[self._host].tty.recv(1024)
                self.not_send()
                if not data:
                    self.close()
                    self._web_socket.send('连接已断开,连续按两次回车将尝试重新连接!')
                    return
                try:
                    result = data.decode()
                except:
                    result = str(data)
                if not result: continue
                if not self._web_socket.connected:
                    my_terms[self._host].not_send = result
                    return
                self.set_last_send(result)
                if not n: n = 1
                self._web_socket.send(result)
        except BaseException as e:
            public.print_exc_stack(e)
            # print(public.get_error_info())

    def set_last_send(self, result):
        last_size = 1024
        if 'last_send' not in my_terms[self._host]:
            my_terms[self._host].last_send = []

        my_terms[self._host].last_send.append(result)
        last_len = len(my_terms[self._host].last_send)
        if last_len > last_size:
            my_terms[self._host].last_send = my_terms[self._host].last_send[last_len - last_size:]

    def not_send(self):
        if 'not_send' in my_terms[self._host]:
            if my_terms[self._host].not_send:
                self._web_socket.send(my_terms[self._host].not_send)
                my_terms[self._host].not_send = ""

    def last_send(self):
        if 'last_send' in my_terms[self._host]:
            for d in my_terms[self._host].last_send:
                self._web_socket.send(d)

    def close(self):
        try:
            my_terms[self._host].tty.close()
        except:
            pass
        if self._host in my_terms:
            del my_terms[self._host]

    def run(self, args):
        public.print_log('xterm running ...')

        sid = args.sid
        self._web_socket = args.ws
        sm = serverModule()
        args = public.dict_obj()
        args.sid = sid
        res = sm.get_ssh_info(args)

        public.print_log(res)

        if not res or not res["status"]:
            return

        self._ssh_info = res["data"]

        if not self._ssh_info:
            return

        public.print_log(self._ssh_info)

        result = self.connect()
        time.sleep(0.1)
        if result:
            sendt = threading.Thread(target=self.send)
            recvt = threading.Thread(target=self.recv)
            sendt.start()
            recvt.start()
            sendt.join()
            recvt.join()
            if time.time() - my_terms[self._host].last_time > 86400: self.close()
            self._web_socket = None

    def check_login(self, args):
        '''
            @name 检查登录状态
            @author hwliang
            @return bool
        '''
        if not session.get('login', None):
            return False

        # 检查会话是否过期
        stime = int(time.time())
        if stime - session.get('last_login_time', 0) > app.config['SESSION_TIMEOUT']:
            # public.WriteLog("用户登录", "会话过期,请重新登录")
            public.print_log(
                "{} 的会话过期,请重新登录, {}, {}".format(session.get('username'), session.get('last_login_time'), stime))
            session.clear()
            return False

        # 设置最后活动时间
        session['last_login_time'] = stime

        return True

    def panel_webssh(ws, sid=0):
        if not check_login():
            return abort(403)
        import core.loader as loader
        module = "terminal"
        action = "run"
        args = public.dict_obj()
        args.sid = sid
        args.ws = ws
        g.module = module
        g.action = module
        return loader.http_run(module, action, args)

    # # 取所有服务器的ssh登陆信息
    # def get_ssh_info_list(self, args):
    #     table = public.M('ssh_infos')
    #     if 'p' not in args:
    #         args.p = 1
    #     print("uid: {}".format(self._uid))
    #     if self._uid != 1:
    #         ssh_info_list = table.field('id,username,password,c_type,host,port,pkey,ps,addtime,addby').where("auth like '%#{}#%'".format(self._uid), (),).select()
    #     else:
    #         ssh_info_list = table.field('id,username,password,c_type,host,port,pkey,ps,addtime,addby').select()
    #     print(ssh_info_list)
    #     if hasattr(args, 'query'):
    #         if args.query:
    #             tmpList = []
    #             for ssh_info in ssh_info_list:
    #                 if ssh_info['host'].find(args.query) != -1 or ssh_info['ps'].find(args.query) != -1: tmpList.append(ssh_info)
    #             ssh_info_list = tmpList
    #
    #     for item in ssh_info_list:
    #         if item['password']:
    #             item['password'] = public.decrypt_password(item['password'])
    #         if item['pkey']:
    #             item['pkey'] = public.decrypt_password(item['pkey'])
    #     return self.get_page(ssh_info_list, args)
    #
    # # 取分页
    # def get_page(self, data, get):
    #     # 包含分页类
    #     import page
    #     # 实例化分页类
    #     page = page.Page()
    #
    #     info = {}
    #     info['count'] = len(data)
    #     info['row'] = 15
    #     info['p'] = 1
    #     if hasattr(get, 'p'):
    #         info['p'] = int(get['p'])
    #     info['uri'] = {}
    #     info['return_js'] = ''
    #     if hasattr(get, 'tojs'):
    #         info['return_js'] = get.tojs
    #
    #     # 获取分页数据
    #     result = {}
    #     result['page'] = page.GetPage(info, limit='1,2,3,4,5,8')
    #     n = 0
    #     result['data'] = []
    #     for i in range(info['count']):
    #         if n >= page.ROW: break
    #         if i < page.SHIFT: continue
    #         n += 1
    #         result['data'].append(data[i])
    #     return result
    #
    # # 取指定服务器的ssh登陆信息
    # def get_server_ssh_info(self, args):
    #     id = int(args['id'])
    #     data = public.M('ssh_infos').where('id=?', (id,)).field('username,password,c_type,host,port,pkey,ps').find()
    #     if not data:
    #         return None
    #     if data['password']:
    #         data['password'] = public.decrypt_password(data['password'])
    #     if data['pkey']:
    #         data['pkey'] = public.decrypt_password(data['pkey'])
    #     return data
