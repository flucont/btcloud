
import os,sys

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

from main import main
import core.include.public as public

def test_delete_panel():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	res = m.delete_panel_info(args)
	if res["status"]:
		print("面板信息删除成功。")
	else:
		print("* 面板信息删除失败。")

def test_modify_panel():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	args.panel_address = "htpp://192.168.1.65:8888"
	args.token = "1111111111111111"
	print(m.modify_panel_info(args))

def test_add_panel():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	args.panel_address = "htpp://192.168.1.67:8888"
	args.token = "abcd"
	print(m.add_panel_info(args))

def test_add_ssh():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	args.username = "root"
	args.host = "192.168.1.65"
	args.password = "www.bt.cn"
	print(m.add_ssh_info(args))

def test_modify_ssh():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	args.username = "root1"
	args.host = "192.168.1.66"
	args.password = "www.bt.cn2"
	print(m.modify_ssh_info(args))

def test_delete_ssh():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	print(m.delete_ssh_info(args))

def test_find_panel_info():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	print(m.get_panel_info(args))

def test_find_ssh_info():
	m = main()
	args = public.dict_obj()
	args.sid = 9
	print(m.get_ssh_info(args))

def test_sync_panel_info():
	import json
	m = main()
	args = public.dict_obj()
	args.sid = 12
	args.p_uri = "system"
	pdata = json.dumps({"action": "GetNetWork"})
	args.pdata = pdata
	print(m.sync_panel_info(args))

if __name__ == "__main__":
	pass
	# test_add_panel()
	# test_modify_panel()
	# test_find_panel_info()
	# test_delete_panel()
	# test_add_ssh()
	# test_modify_ssh()
	# test_delete_ssh()
	# test_find_ssh_info()
	test_sync_panel_info()
