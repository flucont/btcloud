import core.include.public as public
from gettext import find
import json,time,re,os
import sqlite3
from flask import Response,request
from core import session


class main:

    def __to_sort(self,data,pid,key):
        '''
            @name 无限级分类排序
            @author hwliang
            @param data<list> 待排序数据
            @param pid<int> 父级id
            @param key<string> 排序字段
            @return list
        '''
        result = []
        for i in data:
            if i['pid'] == pid:
                result.append(i)
                result += self.__to_sort(data,i[key],key)
        return public.return_data(True,result)


    def get_menu(self,args):
        '''
            @name 获取菜单
            @author hwliang
            @return list
        '''

        role_id = session.get('role_id')
        if not role_id: return []

        sql = '''select node.name,node.title from
            {access_table} as access,
            {node_table} as node
            where
            access.role_id='{role_id}'
            and access.node_id=node.node_id
            and access.sid = 0
            and node.level=1
            and node.pid=0
            and node.status=1
            and node.display=1
        '''.format(role_id=role_id)

        db_obj = public.M('')
        node_list = db_obj.query(sql)

        result = []
        for value in node_list:
            result.append({"name":value[0],"title":value[1]})
        return public.return_data(True,result)


    def get_user_list(self,args):
        '''
            @name 获取用户列表
            @author hwliang
            @return list
        '''
        try:
            conn = None
            cur = None

            conn = sqlite3.connect("/www/server/bt-monitor/data/safety.db")
            cur = conn.cursor()
            fields = "u.uid,u.username,u.username_hash,u.password,u.nickname,"\
            "u.status,u.ps,u.last_login_time,u.last_login_ip,u.create_time," \
            "u.pwd_update_time,u.expire_day,u.gid,g.name"
            sql = "select {} from bt_users u left join bt_role g on u.gid==g.role_id;"
            sor = cur.execute(sql.format(fields))
            res = sor.fetchall()
            data = []
            for line in res:
               item = {
                    "uid": line[0],
                    "username": line[1],
                    "username_hash": line[2],
                    "password": line[3],
                    "nickname": line[4],
                    "status": line[5],
                    "ps": line[6],
                    "last_login_time": line[7],
                    "last_login_ip": line[8],
                    "create_time": line[9],
                    "pwd_update_time": line[10],
                    "expire_day": line[11],
                    "gid": line[12],
                    "gname": line[13]
               } 
               data.append(item)
            return public.return_data(True, data)
        except Exception as e:
            return public.return_data(False, "用户信息异常: {}".format(e))
        finally:
            cur and cur.close()
            conn and conn.close()
        # sql = public.M('users')
        # user_list = sql.field('uid,gid,username,nickname,status,ps,last_login_time,last_login_ip,create_time').order('uid DESC').select()
        # return user_list

    def set_user_status(self,args):
        '''
            @name 设置用户状态
            @author hwliang
            @param uid <int> 用户id
            @param status <int> 状态
            @return dict
        '''
        uid = args.get('uid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        status = args.get('status/d',-1)
        if not status in [0,1]: return public.return_data(False,'status值必需为0或1')

        # 获取当前登录用户信息
        if int(public.bt_auth('uid')) == int(uid):
            return public.error('操作失败：您不能操作自己')

        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        sql.where('uid=?',uid).setField('status',status)
        status_msg = '禁用' if status == 0 else '启用'
        public.WriteLog('用户管理','设置用户[%s]状态为[%s]' % (userInfo['username'],status_msg))
        return public.return_data(True,'设置成功')

    def set_user_ps(self,args):
        '''
            @name 设置用户备注
            @author hwliang
            @param uid <int> 用户id
            @param ps <string> 备注
            @return dict
        '''
        uid = args.get('uid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        ps = args.get('ps/xss','')
        sql.where('uid=?',uid).setField('ps',ps)
        public.WriteLog('用户管理','设置用户[%s]备注为[%s]' % (userInfo['username'],ps))
        return public.return_data(True,'设置成功')

    def set_user_group(self,args):
        '''
            @name 设置用户组
            @author hwliang
            @param uid <int> 用户id
            @param gid <int> 组id
            @return dict
        '''
        uid = args.get('uid/d',0)
        gid = args.get('gid/d',0)
        if not uid or not gid: return public.return_data(False,'UID或GID格式不正确')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        sql.where('uid=?',uid).setField('gid',gid)
        role_name = public.M('role').where('role_id=?',gid).getField('name')
        public.WriteLog('用户管理','设置用户[%s]的用户组为[%s]' % (userInfo['username'],role_name))
        return public.return_data(True,'设置成功')

    def __get_user_pwd(self,pwd,salt):
        '''
            @name 获取用户密码
            @author hwliang
            @param pwd <string> 密码
            @param salt <string> 盐
            @return string
        '''
        return public.md5(public.md5(pwd + '_bt') + salt)

    def check_password_safe(self,password):
        '''
            @name 密码复杂度验证
            @auther hwliang<2021-10-18>
            @param password(string) 密码
            @return bool
        '''
        num = 0
        # 密码是否包含数字
        if re.search(r'[0-9]+',password): num += 1
        # 密码是否包含小写字母
        if re.search(r'[a-z]+',password): num += 1
        # 密码是否包含大写字母
        if re.search(r'[A-Z]+',password): num += 1
        # 密码是否包含特殊字符
        if re.search(r'[^\w\s]+',password): num += 1
        # 密码是否包含以上任意3种组合
        if num < 3: return False
        return True


    def set_user_pwd(self,args):
        '''
            @name 设置用户密码
            @author hwliang
            @param uid <int> 用户id
            @param pwd <string> 密码
            @return dict
        '''
        uid = args.get('uid/d',0)
        pwd = args.get('pwd/s','')
        if not uid: return public.return_data(False,'UID格式不正确')

        # 密码长度验证
        if len(pwd) < 8: return public.error('密码长度必须8位或以上')

        if public.get_config_value('config', 'password_complexity', False) and not self.check_password_safe(pwd):
            return public.return_data(False,'密码复杂度要求：密码长度8位以上，包含数字、小写字母、大写字母、特殊符号任意3种组合!')

        userInfo = public.M('users').where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        salt = public.GetRandomString(12)
        password = self.__get_user_pwd(pwd,salt)
        sql = public.M('users')
        sql.where('uid=?',uid).update({'password':password,'salt':salt,'pwd_update_time':int(time.time())})
        public.WriteLog('用户管理','修改用户[%s]的密码成功' % (userInfo['username'],))
        return public.return_data(True,'修改成功')

    def set_user_nickname(self,args):
        '''
            @name 修改用户昵称
            @author hwliang
            @param uid <int> 用户id
            @param nickname <string> 昵称
            @return dict
        '''
        uid = args.get('uid/d',0)
        nickname = args.get('nickname/xss','')
        if not uid: return public.return_data(False,'UID格式不正确')
        if not nickname: return public.return_data(False,'昵称不能为空')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        sql.where('uid=?',uid).setField('nickname',nickname)
        public.WriteLog('用户管理','修改用户[%s]的昵称为[%s]' % (userInfo['username'],nickname))
        return public.return_data(True,'修改成功')

    def create_user(self,args):
        '''
            @name 创建用户
            @author hwliang
            @param username <string> 用户名
            @param pwd <string> 密码
            @param nickname <string> 昵称
            @param ps <string> 备注
            @param gid <int> 组id
            @return dict
        '''
        username = args.get('username/s','')
        pwd = args.get('pwd/s','')
        nickname = args.get('nickname/xss','')
        ps = args.get('ps/xss','')
        gid = args.get('gid/d',0)
        if not username: return public.return_data(False,'用户名不能为空')
        if not pwd: return public.return_data(False,'密码不能为空')
        if not gid: return public.return_data(False,'用户组不能为空')
        if len(pwd) < 8: return public.return_data(False,'密码长度不能小于8位')
        if not re.match("^[\w\.-]+$",username): return public.return_data(False,'用户名格式不正确')
        sql = public.M('users')
        if sql.where('username=?',username).count(): return public.return_data(False,'用户名已存在')
        if sql.where('nickname=?',nickname).count(): return public.return_data(False,'昵称已存在')
        salt = public.GetRandomString(12)
        password = self.__get_user_pwd(pwd,salt)
        day_time = int(time.time())
        uid = sql.add('username,username_hash,password,salt,nickname,ps,gid,create_time,pwd_update_time',(username,public.md5(username),password,salt,nickname,ps,gid,day_time,day_time))
        if not uid: return public.return_data(False,'创建失败')
        if isinstance(uid,str): return public.return_data(False,uid)
        # 创建用户角色关系
        public.M('role_user').insert({'uid':uid,'role_id':gid})
        public.WriteLog('用户管理','创建用户[%s]成功' % (username))
        return public.return_data(True,'创建成功')


    def modify_user(self,args):
        '''
            @name 修改用户
            @author hwliang
            @param uid <int> 用户id
            @param username <string> 用户名
            @param pwd <string> 密码
            @param nickname <string> 昵称
            @param ps <string> 备注
            @param gid <int> 组id
            @return dict
        '''
        uid = args.get('uid/d',0)
        username = args.get('username/xss','')
        pwd = args.get('pwd/s','')
        nickname = args.get('nickname/xss','')
        ps = args.get('ps/xss','')
        gid = args.get('gid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        if not username: return public.return_data(False,'用户名不能为空')
        if not gid: return public.return_data(False,'用户组不能为空')
        if pwd and len(pwd) < 8: return public.return_data(False,'密码长度不能小于8位')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')
        if username != userInfo['username']:
            if sql.where('username=?',username).count(): return public.return_data(False,'用户名已存在')
        if nickname != userInfo['nickname']:
            if sql.where('nickname=?',nickname).count(): return public.return_data(False,'昵称已存在')
        if pwd:
            salt = public.GetRandomString(12)
            password = self.__get_user_pwd(pwd,salt)
            sql.where('uid=?',uid).update({'password':password,'salt':salt,'pwd_update_time':int(time.time())})

        sql.where('uid=?',uid).update({'username':username,'username_hash':public.md5(username),'nickname':nickname,'ps':ps,'gid':gid})
        public.WriteLog('用户管理','修改用户[%s]的信息' % (userInfo['username']))
        return public.return_data(True,'修改成功')


    def remove_user(self,args):
        '''
            @name 删除用户
            @author hwliang
            @param uid <int> 用户id
            @return dict
        '''
        uid = args.get('uid/d',0)
        if not uid: return public.return_data(False,'UID格式不正确')
        sql = public.M('users')
        userInfo = sql.where('uid=?',uid).find()
        if not userInfo: return public.return_data(False,'用户不存在')

        # 获取当前登录用户信息
        if int(public.bt_auth('uid')) == int(uid):
            return public.error('操作失败：您不能操作自己')

        sql.where('uid=?',uid).delete()
        # 删除用户角色关系
        public.M('role_user').where('uid=?',uid).delete()
        public.WriteLog('用户管理','删除用户[%s]成功' % (userInfo['username']))
        return public.return_data(True,'删除成功')



    def get_role_list(self,args):
        '''
            @name 获取角色列表
            @author hwliang
            @return list
        '''
        sql = public.M('role')
        data = sql.field('role_id,name,pid,status,ps').select()
        return public.return_data(True,data)


    def create_role(self,args):
        '''
            @name 创建角色
            @author hwliang
            @param name <string> 角色名
            @param status<int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @param pid <int> 父角色id
            @return dict
        '''
        name = args.get('name/xss','')
        ps = args.get('ps/xss','')
        pid = args.get('pid/d',0)
        status = args.get('status/d',1)
        if not name: return public.return_data(False,'角色名不能为空')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        if sql.where('name=?',name).count(): return public.return_data(False,'角色名已存在')
        if pid and not sql.where('role_id=?',pid).count(): return public.return_data(False,'父角色不存在')
        role_id = sql.add('name,pid,status,ps',(name,pid,status,ps))
        if not role_id: return public.return_data(False,'创建失败')
        public.WriteLog('用户管理','创建角色[%s]成功' % (name))
        return public.return_data(True,'创建成功')


    def modify_role(self,args):
        '''
            @name 修改角色
            @author hwliang
            @param role_id <int> 角色id
            @param name <string> 角色名
            @param status<int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @param pid <int> 父角色id
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        name = args.get('name/xss','')
        ps = args.get('ps/xss','')
        pid = args.get('pid/d',0)
        status = args.get('status/d',1)
        if not role_id: return public.return_data(False,'角色ID不能为空')
        if not name: return public.return_data(False,'角色名不能为空')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        if sql.where('name=? AND role_id!=?',(name,role_id)).count(): return public.return_data(False,'角色名已存在')
        if pid and not sql.where('role_id=?',pid).count(): return public.return_data(False,'父角色不存在')
        sql.where('role_id=?',role_id).save('name,pid,status,ps',(name,pid,status,ps))
        public.WriteLog('用户管理','修改角色[%s]成功' % (name))
        return public.return_data(True,'修改成功')


    def remove_role(self,args):
        '''
            @name 删除角色
            @author hwliang
            @param role_id <int> 角色id
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        if public.M('role_user').where('role_id=?',role_id).count():
            return public.return_data(False,'该角色下有用户，不能删除')
        sql.where('role_id=?',role_id).delete()

        # 删除角色权限关系
        public.M('access').where('role_id=?',role_id).delete()

        public.WriteLog('用户管理','删除角色[%s]成功' % (roleInfo['name']))
        return public.return_data(True,'删除成功')


    def set_role_status(self,args):
        '''
            @name 设置角色状态
            @author hwliang
            @param role_id <int> 角色id
            @param status <int> 状态 0.禁用 1.启用
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        status = args.get('status/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')
        if not status in [0,1]: return public.return_data(False,'状态值不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        sql.where('role_id=?',role_id).save('status',status)
        status_msg = '禁用' if status == 0 else '启用'
        public.WriteLog('用户管理','设置角色[%s]状态为[%s]' % (roleInfo['name'],status_msg))
        return public.return_data(True,'设置成功')

    def set_role_ps(self,args):
        '''
            @name 设置角色备注
            @author hwliang
            @param role_id <int> 角色id
            @param ps <string> 备注
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        ps = args.get('ps/xss','')
        if not role_id: return public.return_data(False,'角色ID不正确')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        sql.where('role_id=?',role_id).save('ps',ps)
        public.WriteLog('用户管理','设置角色[%s]备注为[%s]' % (roleInfo['name'],ps))
        return public.return_data(True,'设置成功')



    def set_role_access(self,args):
        '''
            @name 设置角色权限
            @author hwliang
            @param role_id <int> 角色id
            @param access <string> 权限信息(node_id|level),多个用逗号隔开,如：1|1,2|2,3|3
            @return dict
        '''
        role_id = args.get('role_id/d',0)
        access = args.get('access','')
        sid = args.get('sid',0)
        if not role_id: return public.return_data(False,'角色ID不正确')
        if not access: return public.return_data(False,'权限不能为空')
        sql = public.M('role')
        roleInfo = sql.where('role_id=?',role_id).find()
        if not roleInfo: return public.return_data(False,'角色不存在')
        acc_sql = public.M('access')

        # 清空当前角色权限
        acc_sql.where('role_id=?',role_id).delete()

        # 添加新的权限
        for acc in access.split(','):
            node_id,level = acc.split('|')
            # 添加事务
            acc_sql.addAll('role_id,node_id,sid,level',(role_id,node_id,sid,level))

        # 提交事务
        acc_sql.commit()

        public.WriteLog('用户管理','更新角色[%s]权限成功' % (roleInfo['name']))
        return public.return_data(True,'权限更新成功')


    def create_node(self,args):
        '''
            @name 添加节点
            @author hwliang
            @param name <string> 节点名称
            @param title <string> 节点标题
            @param pid <int> 父节点id
            @param level <int> 节点级别
            @param sort <int> 排序
            @param display <int> 是否显示 0.不显示 1.显示
            @param status <int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @return dict
        '''
        name = args.get('name/xss','')
        title = args.get('title/xss','')
        pid = args.get('pid/d',0)
        level = args.get('level/d',0)
        sort = args.get('sort/d',0)
        display = args.get('display/d',0)
        status = args.get('status/d',0)
        ps = args.get('ps/xss','')
        if not name: return public.return_data(False,'节点名称不能为空')
        if not title: return public.return_data(False,'节点标题不能为空')
        sql = public.M('node')
        if sql.where('name=? OR title=?',(name,title)).count(): return public.return_data(False,'节点名称或标题已存在')
        sql.add('name,title,pid,level,sort,display,status,ps',(name,title,pid,level,sort,display,status,ps))
        public.WriteLog('用户管理','添加节点[%s(%s)]' % (name,title))
        return public.return_data(True,'添加成功')


    def modify_node(self,args):
        '''
            @name 修改节点
            @author hwliang
            @param node_id <int> 节点id
            @param name <string> 节点名称
            @param title <string> 节点标题
            @param pid <int> 父节点id
            @param level <int> 节点级别
            @param sort <int> 排序
            @param display <int> 是否显示 0.不显示 1.显示
            @param status <int> 状态 0.禁用 1.启用
            @param ps <string> 备注
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        name = args.get('name/xss','')
        title = args.get('title/xss','')
        pid = args.get('pid/d',0)
        level = args.get('level/d',0)
        sort = args.get('sort/d',0)
        display = args.get('display/d',0)
        status = args.get('status/d',0)
        ps = args.get('ps/xss','')
        if not node_id: return public.return_data(False,'节点ID不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        if not name: return public.return_data(False,'节点名称不能为空')
        if not title: return public.return_data(False,'节点标题不能为空')
        if sql.where('name=? AND node_id!=?',(name,node_id)).count(): return public.return_data(False,'节点名称已存在')
        if sql.where('title=? AND node_id!=?',(title,node_id)).count(): return public.return_data(False,'节点标题已存在')
        sql.where('node_id=?',node_id).save('name,title,pid,level,sort,display,status,ps',(name,title,pid,level,sort,display,status,ps))
        public.WriteLog('用户管理','修改节点[%s(%s)]' % (name,title))
        return public.return_data(True,'修改成功')


    def remove_node(self,args):
        '''
            @name 删除节点
            @author hwliang
            @param node_id <int> 节点id
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        if not node_id: return public.return_data(False,'节点ID不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        sql.where('node_id=?',node_id).delete()
        public.M('access').where('node_id=?',node_id).delete()
        public.WriteLog('用户管理','删除节点[%s(%s)]' % (nodeInfo['name'],nodeInfo['title']))
        return public.return_data(True,'删除成功')


    def get_node_list(self,args):
        '''
            @name 获取节点列表
            @author hwliang
            @return list
        '''
        sql = public.M('node')
        data = sql.field('node_id,name,title,pid,level,sort,display,status,ps').where('level!=3',()).order('sort ASC').select()
        if isinstance(data,str): return public.return_data(False,'',0,data)
        return public.return_data(True,data)

    def get_node_list_by_all(self,args):
        '''
            @name 获取节点列表全部
            @author hwliang
            @return list
        '''
        sql = public.M('node')
        data = sql.field('node_id,name,title,status,ps,pid,sort,level,display').order('sort ASC').select()
        return public.return_data(True,data)


    def get_role_access(self,args):
        '''
            @name 获取角色权限
            @author hwliang
            @param role_id <int> 角色id
            @return list
        '''
        role_id = args.get('role_id/d',0)
        if not role_id: return public.return_data(False,'角色ID不正确')

        access_sql = public.M('access')
        sql = public.M('node')
        node_list = sql.where("level!=4", ()).order('sort ASC').select()
        for node in node_list:
            node['access'] = access_sql.where('role_id=? AND node_id=? AND sid=0',(role_id,node['node_id'])).count() > 0
        return public.return_data(True,node_list)

    def get_role_server(self,args):
        '''
            @name 获取角色服务器权限
            @author hwliang
            @param role_id <int> 角色id
            @return list
        '''
        role_id = args.get('role_id/d', 0)
        if not role_id: return public.return_data(False, '角色ID不正确')

        access_sql = public.M('access')
        server_sql = public.M('server_list')
        sql = public.M('node')

        access_list = access_sql.field("sid,node_id").where("role_id=? AND sid!=0 AND level=4", (role_id)).select()

        temp = {}
        for access in access_list:
            if temp.get(access["sid"]):temp[access["sid"]].append(access["node_id"])
            else:temp[access["sid"]] = [access["node_id"],]


        server_list = []
        for sid,value in temp.items():
            server = server_sql.field('sid,address').where("sid=?", (sid)).find()
            if not server:
                access_sql.where('sid=?', sid).delete()
                continue

            node_list = []
            for node_id in value:
                temp = sql.where("node_id=? AND level=4", (node_id)).order('sort ASC').find()
                node_list.append(temp)

            server["node_list"] = node_list
            server_list.append(server)
        return public.return_data(True, server_list)

    def set_node_display(self,args):
        '''
            @name 设置节点显示
            @author hwliang
            @param node_id <int> 节点id
            @param display <int> 是否显示 0.不显示 1.显示
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        display = args.get('display/d',0)

        if not node_id: return public.return_data(False,'节点ID不正确')
        if not display in [0,1]: return public.return_data(False,'显示参数不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        sql.where('node_id=?',node_id).save('display',display)
        display_msg = '不显示' if display else '显示'
        public.WriteLog('用户管理','设置节点[%s]显示状态为[%s]' % (nodeInfo['name'],display_msg))
        return public.return_data(True,'设置成功')


    def set_node_status(self,args):
        '''
            @name 设置节点状态
            @author hwliang
            @param node_id <int> 节点id
            @param status <int> 状态 0.禁用 1.启用
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        status = args.get('status/d',0)

        if not node_id: return public.return_data(False,'节点ID不正确')
        if not status in [0,1]: return public.return_data(False,'状态参数不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        sql.where('node_id=?',node_id).save('status',status)
        status_msg = '禁用' if status else '启用'
        public.WriteLog('用户管理','设置节点[%s]状态为[%s]' % (nodeInfo['name'],status_msg))
        return public.return_data(True,'设置成功')

    def set_node_sort(self,args):
        '''
            @name 设置节点排序编号
            @author hwliang
            @param node_id <int> 节点id
            @param sort <int> 排序
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        sort = args.get('sort/d',0)

        if not node_id: return public.return_data(False,'节点ID不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        sql.where('node_id=?',node_id).save('sort',sort)
        public.WriteLog('用户管理','设置节点[%s]排序编号为[%s]' % (nodeInfo['name'],sort))
        return public.return_data(True,'设置成功')





    def set_node_ps(self,args):
        '''
            @name 设置节点描述
            @author hwliang
            @param node_id <int> 节点id
            @param ps <str> 描述
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        ps = args.get('ps/xss','')

        if not node_id: return public.return_data(False,'节点ID不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        sql.where('node_id=?',node_id).save('ps',ps)
        public.WriteLog('用户管理','设置节点[%s]描述为[%s]' % (nodeInfo['name'],ps))
        return public.return_data(True,'设置成功')


    def set_node_title(self,args):
        '''
            @name 设置节点标题
            @author hwliang
            @param node_id <int> 节点id
            @param title <str> 标题
            @return dict
        '''
        node_id = args.get('node_id/d',0)
        title = args.get('title/xss','')

        if not node_id: return public.return_data(False,'节点ID不正确')
        sql = public.M('node')
        nodeInfo = sql.where('node_id=?',node_id).find()
        if not nodeInfo: return public.return_data(False,'节点不存在')
        if sql.where('node_id!=? AND title=?',(node_id,title)).count():
            return public.return_data(False,'标题已存在')
        sql.where('node_id=?',node_id).save('title',title)
        public.WriteLog('用户管理','设置节点[%s]标题为[%s]' % (nodeInfo['name'],title))
        return public.return_data(True,'设置成功')

