
import os,sys
from time import time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")


import core.include.public as public

def test_task():
    from main import main
    m = main()
    params = {
        "type": "day",
        "minute": 30,
        "hour": 8
    }
    task_name = "day_task"
    res = m.create_task(task_name, params=params)
    assert res == 1 or res == 2

    res = m.create_task(task_name, params=params)
    assert res == 2

    res = m.delete_task(task_name)
    assert res == 1

def test_task2():
    from main import main as task_main
    m = task_main()
    params = {
        "type": "minute-n",
        "where1": 5,
    }
    task_name = "minute_task"
    res = m.create_task(task_name, params=params)
    assert res == 1 or res == 2

    res = m.create_task(task_name, params=params)
    assert res == 2

    res = m.delete_task(task_name)
    assert res == 1

def test_port_test():
    
    from core.include.monitor_helpers import warning_obj
    warning_obj.test_port_connection_via_telnet2("192.168.1.66", 800)

def test_auth_send():

    base_dir = os.path.join(public.get_panel_path(), "data")
    # print("base dir:")
    # print(base_dir)
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
    __path = '{}/msg_push.json'.format(base_dir)
    msg_list = {
        "sms": {"setup": True},
        "weixin": {"setup": False},
        "email": {"setup": True},
        "dingding": {"setup": True} 
    }
    import json
    public.writeFile(__path, json.dumps(msg_list))
    from modules.msgModule.main import main as msg_main
    m = msg_main()
    get = public.dict_obj()
    get.msg_info = "SEND TEST!"
    get.title = "HELLO"
    # print("Auto send:")
    m.auto_send(get)


if __name__ == "__main__":
    test_task()
    test_task2()
    # test_auth_send()
    # test_port_test()