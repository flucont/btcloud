function i(){import("data:text/javascript,")}import"./windi.js";import"./login.js";import"./utils.js";import"./vue.js";import"./naive-ui.js";export{i as __vite_legacy_guard};
