
import os,sys
from time import time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")


import core.include.public as public


from main import main

m = main()
args = public.dict_obj()
print(m.get_user_list(args))