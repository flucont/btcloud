# encoding: utf-8
import json, os, sys, re, time, random

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

from core.include.monitor_helpers import basic_monitor_obj, monitor_events, warning_obj
from core import session,g
import core.include.public as public
from core.include.monitor_exceptions import BtMonitorException
from threading import Lock
import core.include.Locker as Locker
import core.include.monitor_status_codes as monitor_status_codes
import core.include.monitor_enums as monitor_enums
import copy

from core.include.rbac import AccessIntersection

# import core.include.monitor_db_manager as monitor_db_manager
# import core.include.c_loader.PluginLoader as plugin_loader

monitor_db_manager = public.import_via_loader(
    '{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))


class main():
    '''
        @name 监控概览
        @author Zhj<2022-06-28>
    '''
    timeout = 60

    __EDIT_SERVER_AUTH_STATUS_LOCK = Lock()

    def get_login_logs(self, args):
        '''
            @name 获取服务端登录日志
            @author Zhj<2022-06-28>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @return list
        '''
        with public.sqlite_easy('safety') as db:
            query = db.query() \
                .name('logs') \
                .where('`type`=?', '用户登录') \
                .field('log', 'addtime') \
                .order('addtime', 'desc')

            ret = public.simple_page(query, args)

        # DEMO
        if basic_monitor_obj.in_demo():
            for item in ret['list']:
                item['log'] = public.mask_ipv4_address(item['log'])

        return public.success(ret)

    def get_servers_overview(self, args):
        '''
            @name 获取主机概览信息
            @author Zhj<2022-06-28>
            @return dict
        '''
        # 更新所有主机状态
        # basic_monitor_obj.update_servers()

        m = {
            '0': 'offline',
            '1': 'online',
            '2': 'maintenance',
        }

        ret = {
            'total': 0,  # 主机总数
            'offline': 0,  # 离线
            'online': 0,  # 正常/在线
            'maintenance': 0,  # 关闭告警
        }

        # 查询全部主机IP、备注
        servers = basic_monitor_obj.db_easy('servers') \
            .field('sid', 'status', 'ip', 'remark') \
            .select()

        # 统计主机数
        for server in servers:
            k = m.get(str(server['status']), 'total')

            if k != 'total':
                ret['total'] += 1

            ret[k] += 1

        ret['servers'] = servers

        return public.success(ret)

    def get_server_list(self, args):
        '''
            @name 获取主机列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    主机状态 0-离线 1-在线 2-维护(弃用) 3-未授权 4-已授权
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    group_id<?integer>  分组ID[可选]
            @arg    sort<str>           排序方式[可选]  asc desc
            @arg    sort_key<str>       排序关键词[可选]  cpu load mem
            @return list
        '''
        # 筛选关键词 在线 离线
        is_line = args.get('is_line', None)
        # 更新所有主机状态
        cache_key = 'BT_MONITOR_CACHE__UPDATE_UNAUTHORIZED_SERVERS'

        # 从safety库中更新未授权的主机(每次间隔15分钟)
        if not public.cache_get(cache_key):
            with public.sqlite_easy('safety') as db_safety, monitor_db_manager.db_mgr() as db:
                try:
                    unauth_sid_list = db.query() \
                        .name('servers') \
                        .where('is_authorized=0') \
                        .column('sid')

                    unauth_servers = db_safety.query() \
                        .name('server_list') \
                        .where_not_in('sid', unauth_sid_list) \
                        .field(
                        'sid',
                        '`address` as `ip`',
                        'ifnull(`ps`,\'\') as `remark`',
                        '`addtime` as `create_time`'
                    ) \
                        .select()

                    if unauth_servers is not None and len(unauth_servers) > 0:
                        # 批量插入
                        db.query().name('servers').insert_all(unauth_servers, option='ignore')

                except BaseException as e:
                    # 记录异常堆栈
                    public.print_exc_stack(e)

            public.cache_set(cache_key, 1, 900)
        server_list = g.get("server_list", [])

        status = args.get('status', None)
        group_id = args.get('group_id', None)
        sort = args.get('sort', None)

        query = basic_monitor_obj.db_easy('servers') \
            .alias('s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .where_in("s.sid", server_list)

        if status is not None and int(status) in [0, 1, 2, 3, 4]:
            d = {
                3: ('is_authorized', 0),
                4: ('is_authorized', 1),
            }

            field = 'status'
            val = int(status)

            if val in d:
                field, val = d[val]

            query.where('`{}` = ?'.format(field), val)

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        query.field(
            'sid',
            'group_id',
            'sg.name as group_name',
            'status',
            'is_authorized',
            'allow_notify',
            'ip',
            'remark',
            's.create_time',
            'last_active_time',
            "ssh_info",
            "panel_info",
            's.sampling',
            's.type'
        ).order('s.create_time', 'DESC')

        # 添加关键字查询
        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('remark like ? OR ip like ?', (k, k,))

        public.add_retrieve_keyword_query(query, args, query_handler)

        # 添加筛选条件
        if is_line is not None:
            if int(is_line) == 1:
                query.where('status=1')
            else:
                query.where('status=0')

        # 查询全部
        ret_list = query.fork().select()
        # public.print_log(f'>>>直接获取的数据:{ret_list}')

        ret = {'total': 0, 'list': []}

        # 查询主机漏洞数
        server_bugs = basic_monitor_obj.db_easy('server_bug_total') \
            .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
            .field('sid', '`bugs` - `ignored` - `fixed` as `bugs`') \
            .column('bugs', 'sid')

        # 查询主机挖矿木马数
        server_minings = basic_monitor_obj.db_easy('server_mining_total') \
            .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
            .field('sid', '`minings` - `ignored` - `fixed` as `minings`') \
            .column('minings', 'sid')

        ssh_id = basic_monitor_obj.db_easy('ssh_info') \
            .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
            .field('sid', 'id') \
            .column('id', 'sid')


            # 查询主机详细信息关联数据
        for item in ret_list:
            # 实时数据
            item.update(basic_monitor_obj.cache_realtime_server_info(item['sid']))

            # 更新主机状态
            _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])

            # 显示主机漏洞数
            item['bugs'] = server_bugs.get(item['sid'], 0)

            # 显示主机挖矿木马数
            item['minings'] = server_minings.get(item['sid'], 0)

            # 终端登陆信息表id
            item['ssh_id'] = ssh_id.get(item['sid'], 0)

            if item['status'] == 0:
                item['cpu_info'] = {}
                item['disk_info'] = [{'read_bytes_per_second': -1, 'write_bytes_per_second': -1},]
                # item['host_info'] = {}
                item['load_avg'] = {}
                item['mem_info'] = {}
                item['net_info'] = [{'recv_per_second': -1, 'sent_per_second': -1, 'recv': -1, 'sent': -1}]
                item['bugs'] = -1
                item['minings'] = -1

        ret['total'] = len(ret_list)
        # 获取全部数据 拿到排序  1负载 load  2CPU cpu  3内存 mem 4漏洞 bugs
        page = int(args.get('p', 1))
        page_size = int(args.get('p_size', 20))
        page_start = (page - 1) * page_size
        page_end = page * page_size

        if 'sort' in args:
            sort = args.get('sort', '')   # '-+cpu_info_percent'  '-+load_avg_last1min' '-+mem_info_used_percent '-+bugs'  '-+minings' '-+status'  '-+disk_info' 磁盘读写
            sort_key = sort[1:]
            # sorted(s, key=lambda x:(x[0],x[1]))  多个关键字使用元祖
            cpu = lambda x: x.get('cpu_info', {}).get('percent', -1)
            load = lambda x: x.get('load_avg', {}).get('last1min', -1)
            mem = lambda x: x.get('mem_info', {}).get('used_percent', -1)
            bugs = lambda x: x.get('bugs', -1)
            minings = lambda x: x.get('minings', -1)
            # x.get('is_authorized', -1),
            status = lambda x: (x.get('status', -1))
            # 累计所有磁盘的读写   +-disk_info
            disk_info = lambda x: (sum([i.get('read_bytes_per_second', -1) for i in x.get('disk_info', [])]),
                                   sum([i.get('write_bytes_per_second', -1) for i in x.get('disk_info', [])]))
            # 累计总流量   +-net_info_total
            net_info_total = lambda x: (sum([i.get('recv', -1) for i in x.get('net_info', [])]),
                                        sum([i.get('sent', -1) for i in x.get('net_info', [])]))
            # 累计流量  +-net_info
            net_info = lambda x: (sum([i.get('recv_per_second', -1) for i in x.get('net_info', [])]),
                                  sum([i.get('sent_per_second', -1) for i in x.get('net_info', [])]))

            sort_keys = {
                'cpu_info_percent': cpu,
                'load_avg_last1min': load,
                'mem_info_used_percent': mem,
                'bugs': bugs,
                'minings': minings,
                'status': status,
                'disk_info': disk_info,
                'net_info_total': net_info_total,
                'net_info': net_info,
            }

            sort_bool = True if sort[0] == '-' else False
            ret_list = sorted(ret_list, key=sort_keys[sort_key], reverse=sort_bool)
            # 未授权的主机排在最前
            ret_lists = sorted(ret_list, key=lambda x: (x.get('is_authorized', -1)), reverse=False)

            # 排序完 重组数据
            ret['list'] = ret_lists[page_start:page_end]
        else:
            # 未授权的主机排在最前
            ret_lists = sorted(ret_list, key=lambda x: (x.get('is_authorized', -1)), reverse=False)
            ret['list'] = ret_lists[page_start:page_end]

        # 查询授权客户端数量/可授权的客户端数量
        # 获取允许授权的客户端数量
        auth_info = basic_monitor_obj.get_auth_info()

        if not auth_info:
            ret['available_auth_num'] = basic_monitor_obj.get_available_clients()

            # 获取当前已授权的客户端数量
            ret['cur_auth_num'] = basic_monitor_obj.db_easy('servers') \
                .where('is_authorized=1') \
                .where_in('status', [0, 1]) \
                .count()
        else:
            ret['available_auth_num'] = auth_info.get('clients', 0)
            ret['cur_auth_num'] = auth_info.get('cur_auth_num', 0)

        return public.return_data(True, ret)

    # def get_server_list(self, args):
    #     '''
    #         @name 获取主机列表
    #         @author Zhj<2022-06-28>
    #         @arg    status<?integer>    主机状态 0-离线 1-在线 2-维护(弃用) 3-未授权 4-已授权
    #         @arg    p<integer>          分页页码
    #         @arg    p_size<integer>     分页大小
    #         @arg    group_id<?integer>  分组ID[可选]
    #         @return list
    #     '''
    #     # 更新所有主机状态
    #     cache_key = 'BT_MONITOR_CACHE__UPDATE_UNAUTHORIZED_SERVERS'
    #
    #     # 从safety库中更新未授权的主机(每次间隔15分钟)
    #     if not public.cache_get(cache_key):
    #         with public.sqlite_easy('safety') as db_safety, monitor_db_manager.db_mgr() as db:
    #             try:
    #                 unauth_sid_list = db.query() \
    #                     .name('servers') \
    #                     .where('is_authorized=0') \
    #                     .column('sid')
    #
    #                 unauth_servers = db_safety.query() \
    #                     .name('server_list') \
    #                     .where_not_in('sid', unauth_sid_list) \
    #                     .field(
    #                     'sid',
    #                     '`address` as `ip`',
    #                     'ifnull(`ps`,\'\') as `remark`',
    #                     '`addtime` as `create_time`'
    #                 ) \
    #                     .select()
    #
    #                 if unauth_servers is not None and len(unauth_servers) > 0:
    #                     # 批量插入
    #                     db.query().name('servers').insert_all(unauth_servers, option='ignore')
    #
    #             except BaseException as e:
    #                 # 记录异常堆栈
    #                 public.print_exc_stack(e)
    #
    #         public.cache_set(cache_key, 1, 900)
    #     server_list = g.get("server_list", [])
    #
    #     status = args.get('status', None)
    #     group_id = args.get('group_id', None)
    #
    #     query = basic_monitor_obj.db_easy('servers') \
    #         .alias('s') \
    #         .left_join('server_group sg', 's.group_id=sg.id') \
    #         .where_in("s.sid", server_list)
    #
    #     if status is not None and int(status) in [0, 1, 2, 3, 4]:
    #         d = {
    #             3: ('is_authorized', 0),
    #             4: ('is_authorized', 1),
    #         }
    #
    #         field = 'status'
    #         val = int(status)
    #
    #         if val in d:
    #             field, val = d[val]
    #
    #         query.where('`{}` = ?'.format(field), val)
    #
    #     if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
    #         query.where_in('group_id', str(group_id).split(','))
    #
    #     query.field(
    #         'sid',
    #         'group_id',
    #         'sg.name as group_name',
    #         'status',
    #         'is_authorized',
    #         'allow_notify',
    #         'ip',
    #         'remark',
    #         's.create_time',
    #         'last_active_time',
    #         "ssh_info",
    #         "panel_info",
    #         's.sampling',
    #         's.type'
    #     ).order('s.create_time', 'DESC')
    #
    #     # 添加关键字查询
    #     def query_handler(query, keyword):
    #         k = '%{}%'.format(keyword)
    #
    #         # 主机IP与主机备注模糊搜索
    #         query.where('remark like ? OR ip like ?', (k, k,))
    #
    #     public.add_retrieve_keyword_query(query, args, query_handler)
    #
    #     ret = public.simple_page(query, args)
    #
    #     # 查询主机漏洞数
    #     server_bugs = basic_monitor_obj.db_easy('server_bug_total')\
    #         .where_in('sid', list(map(lambda x: x['sid'], ret['list'])))\
    #         .field('sid', '`bugs` - `ignored` - `fixed` as `bugs`')\
    #         .column('bugs', 'sid')
    #
    #     # 查询主机详细信息关联数据
    #     for item in ret['list']:
    #         # 实时数据
    #         item.update(basic_monitor_obj.cache_realtime_server_info(item['sid']))
    #
    #         # 更新主机状态
    #         _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
    #
    #         # 显示主机漏洞数
    #         item['bugs'] = server_bugs.get(item['sid'], 0)
    #
    #
    #
    #     # 查询授权客户端数量/可授权的客户端数量
    #     # 获取允许授权的客户端数量
    #     auth_info = basic_monitor_obj.get_auth_info()
    #
    #     if not auth_info:
    #         ret['available_auth_num'] = basic_monitor_obj.get_available_clients()
    #
    #         # 获取当前已授权的客户端数量
    #         ret['cur_auth_num'] = basic_monitor_obj.db_easy('servers') \
    #             .where('is_authorized=1') \
    #             .where_in('status', [0, 1]) \
    #             .count()
    #     else:
    #         ret['available_auth_num'] = auth_info.get('clients', 0)
    #         ret['cur_auth_num'] = auth_info.get('cur_auth_num', 0)
    #
    #     return public.return_data(True, ret)

    def get_server_detail(self, args):
        '''
            @name 获取主机监控信息
            @author Zhj<2022-07-08>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^\d+$', sid):
            return public.error('无效的参数：sid')
        server_info = basic_monitor_obj.db_easy('servers') \
            .where('sid=?', int(sid)) \
            .field('sid', 'ip', 'remark', 'status', "type") \
            .find()
        # return server_info
        # public.writeFile('/tmp/aa.aa', server_info)
        if basic_monitor_obj.is_empty_result(server_info):
            return public.return_error('未查询到主机信息')

        server_detail, err_msg = basic_monitor_obj.retrieve_server_detail(sid)

        if not server_detail:
            return public.error(err_msg)

        agent_version = public.cache_get("AGENT_VERSION_" + str(sid))
        if not agent_version:
            agent_version_file = '{}/data/monitor_servers/{}/{}'.format(
                public.get_panel_path(), public.md5(str(sid)),
                "agentversion.pl")
            _str = public.readFile(agent_version_file)
            if _str:
                agent_version = _str
        if agent_version:
            server_info["agent_version"] = agent_version
        else:
            server_info["agent_version"] = ""

        server_info.update(server_detail)

        # 更新主机状态
        _, _, server_info['status'] = basic_monitor_obj.cache_server_status(server_info['sid'])

        # 主机漏洞数
        server_info['bugs'] = basic_monitor_obj.db_easy('server_bug_total') \
            .where('sid', int(sid)) \
            .value('`bugs` - `ignored` - `fixed` as `bugs`')

        # 查询主机挖矿木马数
        server_info['minings'] = basic_monitor_obj.db_easy('server_mining_total') \
            .where('sid', int(sid)) \
            .value('`minings` - `ignored` - `fixed` as `minings`')

        return public.success(server_info)

    def edit_server_auth_status(self, args):
        '''
            @name 修改主机授权状态
            @author Zhj<2022-07-05>
            @arg    sid<integer|string>     主机ID列表
            @arg    status<integer>         授权状态 0-未授权 1-已授权
            @arg    initialize<?integer>    是否重新分配，会将剩余主机授权状态重置<可选>
            @return dict
        '''
        sid = args.get('sid', None)
        status = args.get('status', None)
        is_init = args.get('initialize', 0)

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^\d+(?:,\d+)*$', str(sid)):
            return public.error('参数sid格式错误')

        if status is None:
            return public.error('缺少参数：status')

        if int(status) not in [0, 1]:
            return public.error('无效的参数：status')

        sid_list = str(sid).split(',')

        # 上锁
        with Locker.acquire(self.__EDIT_SERVER_AUTH_STATUS_LOCK, timeout=60):
            # 查询主机信息
            server_list = basic_monitor_obj.db_easy('servers') \
                .where_in('sid', sid_list) \
                .field('ip', 'is_authorized', 'remark') \
                .select()

            if basic_monitor_obj.is_empty_result(server_list):
                return public.error('无效的参数：sid')

            # 筛选授权状态发生变化的主机
            server_list = list(
                filter(lambda x: int(x['is_authorized']) != int(status),
                       server_list))

            server_num = len(server_list)

            if server_num == 0:
                return public.success('操作成功')

            # 获取允许授权的客户端数量
            available_auth_num = basic_monitor_obj.get_available_clients()

            if is_init:
                cur_auth_num = 0
            else:
                # 获取当前已授权的客户端数量
                cur_auth_num = basic_monitor_obj.db_easy('servers') \
                    .where('is_authorized=1') \
                    .where_in('status', [0, 1]) \
                    .count()

            # 已达最大授权数量时，不允许继续授权客户端
            if int(status) == 1 and available_auth_num < cur_auth_num + len(
                    server_list):
                return public.error('当前已达最大授权数量，请升级授权数量或者取消其它客户端授权',
                                    monitor_status_codes.auth_num_exceed)

            m = {'0': '未授权', '1': '已授权'}

            with public.sqlite_easy('safety') as db_safety, public.sqlite_easy(
                    'monitor_mgr') as db_monitor:
                # 关闭事务自动提交
                db_safety.autocommit(False)
                db_monitor.autocommit(False)

                # 更新主机授权状态缓存
                safety_servers = db_safety.query() \
                    .name('server_list') \
                    .where_in('sid', sid_list) \
                    .select()

                # 更新主机授权状态
                db_safety.query() \
                    .name('server_list') \
                    .where_in('sid', sid_list) \
                    .update({
                        'status': int(status),
                    })

                update_data = {
                    'is_authorized': int(status),
                    'update_time': int(time.time()),
                }

                # 主机授权状态更新为 未授权
                # 更新主机状态为 离线
                if int(status) == 0:
                    update_data['status'] = 0

                db_monitor.query() \
                    .name('servers') \
                    .where_in('sid', sid_list) \
                    .update(update_data)

                if is_init:
                    db_safety.query() \
                        .name('server_list') \
                        .where_not_in('sid', sid_list) \
                        .update({
                            'status': 0,
                        })

                    db_monitor.query() \
                        .name('servers') \
                        .where_not_in('sid', sid_list) \
                        .update({
                            'is_authorized': 0,
                            'status': 0,
                            'update_time': update_data['update_time'],
                        })

                # 提交事务
                db_safety.commit()
                db_monitor.commit()

            for server_info in server_list:
                public.WriteLog(
                    '主机授权', '用户【%s】更改主机[%s（%s）]授权状态为【%s】' %
                                (session.get('username', ''), server_info['ip'],
                                 server_info['remark'], m.get(str(status), '--')))

            for server_info in safety_servers:
                server_info['status'] = 0 if is_init else int(status)
                public.cache_set('BT_MONITOR_API__CHECK_ACCESS_SERVER_INFO__{}'.format(server_info['server_id']), server_info, 600)

        # 更新缓存
        public.cache_set(
            'BT_MONITOR_CACHE__CUR_AUTH_NUM',
            server_num if is_init else cur_auth_num +
                                       (server_num if int(status) == 1 else -1 * server_num), 120)

        # 触发主机授权事件
        public.event(monitor_events.ServerAuthorization())

        return public.success('操作成功')

    def get_warning_tasks(self, args):
        '''
            @name 获取告警任务列表
            @author Zhj<2022-06-28>
            @arg    sid<?integer>       主机ID
            @arg    status<?integer>    告警任务状态 0-未处理 1-已处理
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @return list
        '''
        sid = args.get('sid', None)
        status = args.get('status', None)
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)
        server_list = g.get("server_list", [])

        query = basic_monitor_obj.db_easy('warning_tasks') \
            .field('id', 'sid', 'title', 'content', 'status', 'is_pushed', 'create_time', 'conf_id') \
            .where_in("sid", server_list) \
            .order('create_time', 'desc')

        if keyword is not None:
            tmp = '%{}%'.format(keyword)
            sid_list = basic_monitor_obj.db_easy('servers') \
                .where('ip like ? OR remark like ?', [tmp, tmp]) \
                .field('sid') \
                .column('sid')

            query.where_in('sid', sid_list)

        if query_date is not None and len(query_date) > 0:
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        if status is not None:
            query.where('status=?', int(status))

        if sid is not None:  # g对象里有服务器ip列表
            query.where('sid=?', int(sid))

        data = query.fork()
        ret = public.simple_page(query, args)

        # 查询告警规则信息
        warning_confs = basic_monitor_obj.db_easy('warning_configurations') \
            .where_in('id', list(map(lambda x: x['conf_id'], ret['list']))) \
            .field('id', 'title', 'scores') \
            .column(None, 'id')

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret['list']:
            warning_conf = warning_confs.get(item['conf_id'], {})
            server_info = servers.get(item['sid'], {})
            item['scores'] = warning_conf.get('scores', 0)
            item['rule_name'] = warning_conf.get('title', '')
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['conf_id'])
            del (item['sid'])

        # 日志导出 export_log
        if args.get('export_log', None) == '1':
            data = data.select()

            if data is None or len(data) == 0:
                return public.error('没有可导出的数据')
            # 查询告警规则信息
            warning_confs = basic_monitor_obj.db_easy('warning_configurations') \
                .where_in('id', list(map(lambda x: x['conf_id'], data))) \
                .field('id', 'title', 'scores') \
                .column(None, 'id')

            # 查询服务器信息
            servers = basic_monitor_obj.db_easy('servers') \
                .where_in('sid', list(map(lambda x: x['sid'], data))) \
                .field('sid', 'ip', 'remark') \
                .column(None, 'sid')

            for item in data:
                warning_conf = warning_confs.get(item['conf_id'], {})
                server_info = servers.get(item['sid'], {})
                item['scores'] = warning_conf.get('scores', 0)
                item['rule_name'] = warning_conf.get('title', '')
                item['ip'] = server_info.get('ip', '')
                item['remark'] = server_info.get('remark', '')
                del (item['conf_id'])
                del (item['sid'])

            import pandas as pd
            # 处理数据
            for i in data:
                i['create_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['create_time']))
                i['status'] = '已处理' if i['status'] == 1 else '未处理'
                i['is_pushed'] = '已推送' if i['is_pushed'] == 1 else '未推送'
                score = i['scores']
                if 0 <= score < 30:
                    i['score'] = '低'
                elif 30 <= score < 60:
                    i['score'] = '中'
                elif 60 <= score <= 100:
                    i['score'] = '高'
                else:
                    i['score'] = '无效分数'
            # 将数据转换为DataFrame对象
            df = pd.DataFrame(data)
            #  选择需要导出的字段
            selected_columns = {"id": "编号", "ip": "服务器IP", "create_time": "告警时间",
                                "score": "等级", "rule_name": "任务名", "title": "标题", "content": "内容",
                                "status": "状态", "is_pushed": "是否推送", "remark": "备注", }

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_data_warning.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_data_warning.csv', 'warning_tasks_{}.csv'.format(date.today()))

        return public.success(ret)

    # # 清空告警任务
    # def clear_warning_tasks(self, args):
    #     '''
    #          @name 清除告警任务
    #          @return dict
    #      '''
    #
    #     # 打开数据库
    #     with monitor_db_manager.db_mgr('warning_tasks') as db:
    #         try:
    #             # 关闭自动提交事务
    #             db.autocommit(False)
    #             # 开启自动释放空间
    #             db.auto_vacuum()
    #             query = db.query().name('warning_tasks')
    #             # 执行删除操作
    #             query.delete()
    #             # 提交事务
    #             query.commit()
    #         except BaseException as e:
    #             # 回滚事务
    #             db.rollback()
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #             if isinstance(e, BtMonitorException):
    #                 return public.error(str(e))
    #     return public.success('操作成功')

    def get_ssh_login_logs(self, args):
        '''
            @name 获取SSH登录日志列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    SSH登录状态 0-登录失败 1-登录成功
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    sid<?integer>       主机ID[可选]
            @arg    keyword<?string>    关键字[可选]
            @return list
        '''

        status = args.get('status', None)
        sid = args.get('sid', None)
        keyword = args.get('keyword', None)

        if sid is None:
            l = self._latest_ssh_login_logs_help()
            return public.success({
                'list': l,
                'total': len(l),
            })

        db_mgr = monitor_db_manager.MonitorDbManager(sid)

        with db_mgr.db_sgl('ssh_login_logs') as db:
            query = db.query().name('ssh_login_logs') \
                .field('id', 'user', '{} as login_ip'.format("'****'" if basic_monitor_obj.in_demo() else 'ip'), 'port', 'ip_place', 'success', 'login_time',
                       '{} as `sid`'.format(int(sid))) \
                .order('login_time', 'desc')

            if status is not None:
                query.where('success=?', int(status))

            # if sid is not None:
            #     query.where('sid=?', int(sid))

            if keyword is not None:
                tmp = '%{}%'.format(keyword)
                query.where('user like ? OR ip like ?', [tmp, tmp])

            ret = public.simple_page(query, args)

            servers = basic_monitor_obj.db_easy('servers') \
                .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
                .field('sid', 'ip', 'remark') \
                .column(None, 'sid')

            login_ip_idx_map = {}
            i = 0

            for item in ret['list']:
                if item['ip_place'] == '' and item['login_ip'] != '':
                    if item['login_ip'] not in login_ip_idx_map:
                        login_ip_idx_map[item['login_ip']] = []

                    login_ip_idx_map[item['login_ip']].append(i)

                server_info = servers.get(item['sid'], {})
                item['ip'] = server_info.get('ip', '')
                item['login_ip'] = '{}{}'.format(
                    item['login_ip'], ':{}'.format(item['port'])
                    if int(item['port']) > 0 else '')
                item['remark'] = server_info.get('remark', '')
                del (item['sid'])
                del (item['port'])

                i += 1

            # 查询IP信息
            if len(login_ip_idx_map.keys()) > 0:
                ip_info_dict = basic_monitor_obj.search_ip_info(
                    list(login_ip_idx_map.keys()))

                with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                    try:
                        # 关闭自动提交事务
                        db.autocommit(False)

                        for (login_ip, idx_list) in login_ip_idx_map.items():
                            if login_ip not in ip_info_dict:
                                continue

                            ip_place = ip_info_dict[login_ip][
                                           'country'] + ip_info_dict[login_ip]['province']

                            ids = []

                            for idx in idx_list:
                                ret['list'][idx]['ip_place'] = ip_place
                                ids.append(ret['list'][idx]['id'])

                            # 更新IP信息
                            db.query() \
                                .name('ssh_login_logs') \
                                .where_in('id', ids) \
                                .update({
                                'ip_place': ip_place,
                            })

                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 记录异常堆栈信息
                        public.print_exc_stack(e)

            # 统计登录成功与失败次数
            query = basic_monitor_obj.db_easy('ssh_login_total_daily') \
                .field('SUM(`success`) AS `success_cnt`', 'SUM(`fail`) AS `fail_cnt`') \
                .where('sid', sid)

            statistics_info = query.find()

            if statistics_info is None:
                statistics_info = {
                    'success_cnt': 0,
                    'fail_cnt': 0,
                }

            ret.update(statistics_info)
            # 日志导出 export_log
            if args.get('export_log', None) == '1':
                if ret['list'] is None or len(ret['list']) == 0:
                    return public.error('没有可导出的数据')
                import pandas as pd
                # 处理数据
                for i in ret['list']:
                    i['create_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['create_time']))
                    i['success'] = '成功' if i['success'] == 1 else '失败'

                # 将数据转换为DataFrame对象
                df = pd.DataFrame(ret['list'])

                #  选择需要导出的字段
                selected_columns = {"id": "编号", "ip": "服务器", "login_ip": "登录IP", "create_time": "登录时间",
                                    "user": "用户", "success": "状态"}

                selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

                # # 导出数据到CSV文件中
                export_file_path = "/tmp/exported_ssh_login_logs.csv"
                selected_df.to_csv(export_file_path, index=False)
                from datetime import date
                return public.send_file('/tmp/exported_ssh_login_logs.csv', 'ssh_login_logs_{}.csv'.format(date.today()))

            return public.success(ret)

            # # 打开数据库
            # with public.sqlite_easy('monitor') as db:
            #     try:
            #         query = db.query()\
            #             .name('ssh_login_logs sll')\
            #             .join('servers s', 'sll.sid=s.sid')\
            #             .field(
            #                 'sll.user',
            #                 'sll.ip as login_ip',
            #                 'sll.success',
            #                 'sll.login_time',
            #                 's.ip',
            #                 's.remark'
            #             )\
            #             .order('login_time', 'desc')
            #
            #         if status is not None:
            #             query.where('sll.success=?', int(status))
            #
            #         if sid is not None:
            #             query.where('sll.sid=?', int(sid))
            #
            #         if keyword is not None:
            #             tmp = '%{}%'.format(keyword)
            #             query.where('sll.user like ? OR sll.ip like ?', [tmp, tmp])
            #
            #         ret = public.simple_page(query, args)
            #
            #         return public.return_data(True, ret)
            #
            #     except BtMonitorException as e:
            #         return public.error(str(e))

    def get_dashboard_overview(self, args):
        '''
            @name 获取仪表盘信息
            @author Zhj<2022-06-29>
            @return dict
        '''
        # 更新主机状态
        # basic_monitor_obj.update_servers()

        # 获取所有在线主机ID
        sid_list = basic_monitor_obj.db_easy('servers') \
            .where('status=1') \
            .field('sid') \
            .column('sid')

        server_num = 0
        cpu_percent_total = 0
        mem_percent_total = 0
        ret = {
            'cpu_core_total': 0,
            'mem_total': 0,
            'cpu_avg_percent': 0,
            'mem_avg_percent': 0,
        }

        for sid in sid_list:
            server_info = basic_monitor_obj.cache_realtime_server_info(sid)
            server_num += 1
            cpu_info = server_info.get('cpu_info', {})
            mem_info = server_info.get('mem_info', {})
            ret['cpu_core_total'] += int(cpu_info.get('logical_cores', 1))
            ret['mem_total'] += int(mem_info.get('total', 0))
            cpu_percent_total += float(cpu_info.get('percent', 0))
            mem_percent_total += float(mem_info.get('used_percent', 0))

        ret['cpu_avg_percent'] = round(cpu_percent_total / server_num, 2) if server_num > 0 else 0
        ret['mem_avg_percent'] = round(mem_percent_total / server_num, 2) if server_num > 0 else 0

        return public.success(ret)

    def get_proc_traffic_top(self, args):
        '''
            @name 进程流量top10
            @author Zhj<2022-06-29>
            @return list
        '''
        try:
            ret = basic_monitor_obj.db_memory('processes') \
                .where('update_time > ?', int(time.time()) - 60) \
                .field(
                'sid',
                'pne_id',
                '(net_sent_bytes_per_second + net_recv_bytes_per_second) as bytes',
                'net_sent_bytes_per_second as sent_bytes',
                'net_recv_bytes_per_second as recv_bytes'
            ) \
                .order('bytes', 'desc') \
                .limit(10) \
                .select()

            servers = basic_monitor_obj.db_easy('servers') \
                .where_in('sid', list(map(lambda x: x['sid'], ret))) \
                .field('sid', 'ip', 'remark') \
                .column(None, 'sid')

            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .where_in('id', list(map(lambda x: x['pne_id'], ret))) \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            for item in ret:
                server_info = servers.get(item['sid'], {})
                pne = pnes.get(item['pne_id'], {})
                item['ip'] = server_info.get('ip', '')
                item['remark'] = server_info.get('remark', '')
                item['name'] = pne.get('name', '')
                item['boot_command'] = pne.get('exe', '')
                del (item['sid'], item['pne_id'])

            return public.success(ret)
        except BaseException as e:
            if isinstance(e, TypeError):
                public.print_log(ret)

            raise e

    def get_proc_connection_top(self, args):
        '''
            @name 进程连接数top10
            @author Zhj<2022-06-29>
            @return list
        '''
        ret = basic_monitor_obj.db_memory('processes') \
            .where('update_time > ?', int(time.time()) - 60) \
            .field(
            'sid',
            'pne_id',
            'opened_connections as connections'
        ) \
            .order('connections', 'desc') \
            .limit(10) \
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', list(map(lambda x: x['pne_id'], ret))) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            pne = pnes.get(item['pne_id'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            item['name'] = pne.get('name', '')
            item['boot_command'] = pne.get('exe', '')
            del (item['sid'])

        return public.success(ret)

    def get_proc_cpu_top(self, args):
        '''
            @name 获取进程CPU占用TOP10
            @authot Zhj<2022-07-19>
            @return dict
        '''
        ret = basic_monitor_obj.db_memory('processes') \
            .where('update_time > ?', int(time.time()) - 120) \
            .field(
            'sid',
            'pne_id',
            'cpu_used_percent as used_percent'
        ) \
            .order('cpu_used_percent', 'desc') \
            .limit(10) \
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', list(map(lambda x: x['pne_id'], ret))) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            pne = pnes.get(item['pne_id'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            item['name'] = pne.get('name', '')
            item['boot_command'] = pne.get('exe', '')
            del (item['sid'])

        return public.success(ret)

    def get_proc_mem_top(self, args):
        '''
            @name 获取进程内存占用TOP10
            @authot Zhj<2022-07-19>
            @return dict
        '''
        ret = basic_monitor_obj.db_memory('processes') \
            .where('update_time > ?', int(time.time()) - 120) \
            .field(
            'id',
            'sid',
            'pne_id',
            'mem_used_percent as used_percent'
        ) \
            .order('mem_used_percent', 'desc') \
            .limit(10) \
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', list(map(lambda x: x['pne_id'], ret))) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            pne = pnes.get(item['pne_id'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            item['name'] = pne.get('name', '')
            item['boot_command'] = pne.get('exe', '')
            del (item['sid'])

            real_info = basic_monitor_obj.cache_realtime_proc_info(item['id'])
            item['used'] = real_info['mem_used']
            del item['id']

        return public.success(ret)

    def get_proc_top(self, args):
        '''
            @name 获取主机进程TOP10
            @author Zhj<2022-07-07>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        query = basic_monitor_obj.db_memory('processes') \
            .field(
            'id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user', \
            'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes', \
            'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes' \
            ).where('`sid` = ?', int(sid)) \
            .where('`update_time` > ?', int(time.time()) - 120) \
 \
            # 默认排序
        if 'sort' not in args:
            query.order('`cpu_used_percent` + `mem_used_percent`', 'DESC')

        # 添加排序条件
        public.add_retrieve_sort_query(query, args)

        ret = query.limit(10).select()

        if basic_monitor_obj.is_empty_result(ret):
            ret = []

        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', list(map(lambda x: x['pne_id'], ret))) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        for p_item in ret:
            pne = pnes.get(p_item['pne_id'], {})
            p_item['name'] = pne.get('name', '')
            p_item['boot_command'] = pne.get('exe', '')
            p_item.update(
                basic_monitor_obj.cache_realtime_proc_info(p_item['id']))

        return public.success(ret)

    def get_processes_list(self, args):
        """主机详情-进程监控列表

        Args:
            args (dict_obj): 查询参数对象
                sid<integer>            主机ID
                query_date<?string>     时间查询[可选]
                process_name<?string>   搜索关键字[可选]
                sort<?string>           排序[可选]
                p<?integer>             分页页码[可选 默认1]
                p_size<?integer>        分页大小[可选 默认20]
        """
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        process_name = args.get('process_name', None)

        if sid is None:
            return public.error('缺少参数：sid')
        # s = time.time()
        query = basic_monitor_obj.db_memory('processes') \
            .field(
            'id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user',
            'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes',
            'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes', 'create_time',
            'update_time'
        ) \
            .where('`sid` = ?', int(sid)) \
            .where('`update_time` > ?', int(time.time()) - 120)

        if query_date is not None:
            query.where('`create_time` BETWEEN ? AND ?',
                        public.get_query_timestamp(query_date))

        if process_name is not None:  # 进程名称与进程启动程序绝对路径表
            search_by_pne_id = basic_monitor_obj.db_easy('process_name_exe') \
                .where('`name` like ?', '%{}%'.format(process_name)) \
                .field('id') \
                .limit(500) \
                .column('id')
            # query.where('`name` like ?', '%{}%'.format(process_name))
            query.where_in('pne_id', search_by_pne_id)
        # -disk_read_bytes_per_second|-disk_write_bytes_per_second
        if 'sort' not in args:
            query.order('`cpu_used_percent` + `mem_used_percent`', 'desc')

        public.add_retrieve_sort_query(query, args)

        # print(query.fork().build_sql())

        # print('查询前cost: {}'.format(str(time.time() - s)))

        # raw_sql = query.build_sql()
        # print('SQL: %s' % raw_sql)
        # print('SQL EXPLAIN: %s' % query.explain_raw_sql(raw_sql))

        result = public.simple_page(query, args)

        # print('--获取主机进程列表-查询耗时: %s' % str(time.time() - s))

        # result = {
        #     'total': len(ret),
        #     'list': ret
        # }

        # print('查询后cost: {}'.format(str(time.time() - s)))

        # 进程基本信息ID
        pne_ids = []

        # 数据采样设置ID
        sampling_ids = []

        # 主机ID列表
        sid_list = set()

        for item in result['list']:
            pne_ids.append(item['pne_id'])

            # 构造数据采样设置ID
            item['sampling_id'] = public.mmh3_hash64('process|{}|{}'.format(
                item['id'], monitor_enums.SAMPLING_TYPE__GLOBAL))
            sampling_ids.append(item['sampling_id'])

            sid_list.add(item['sid'])

        # 查询进程基本信息
        pnes = basic_monitor_obj.db_easy('process_name_exe') \
            .where_in('id', pne_ids) \
            .field('id', 'name', 'exe') \
            .column(None, 'id')

        # 查询数据采样设置
        sampling_settings = basic_monitor_obj.db_easy('sampling_settings') \
            .where_in('id', sampling_ids) \
            .field('id', 'status') \
            .column('status', 'id')

        # 查询全局数据采样设置
        sampling_global = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(sid_list)) \
            .field('sid', 'sampling') \
            .column('sampling', 'sid')

        for p_item in result['list']:
            pne = pnes.get(p_item['pne_id'], {})
            p_item['name'] = pne.get('name', '')
            p_item['boot_command'] = pne.get('exe', '')
            p_item.update(basic_monitor_obj.cache_realtime_proc_info(p_item['id']))
            p_item['sampling_status'] = int(
                ((int(sampling_global[p_item['sid']])
                  & monitor_enums.SAMPLING_GLOBAL__PROCESS)
                 == monitor_enums.SAMPLING_GLOBAL__PROCESS)
                and sampling_settings.get(p_item['sampling_id'], 1))
            p_item['pne_id'] = str(p_item['pne_id'])
            del (p_item['sampling_id'],)

        # print('总cost: {}'.format(str(time.time() - s)))

        return public.success(result)

    def get_process_cpu_info_list(self, args):
        """进程CPU占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_cpu_info_list',
                ['id', 'process_id', 'percent', 'create_time'], 'process_id=?',
                [int(pid)]))

    def get_process_mem_info_list(self, args):
        """进程MEM占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_mem_info_list',
                ['id', 'process_id', 'percent', 'used', 'create_time'],
                'process_id=?', [int(pid)]))

    def get_process_disk_info_list(self, args):
        """进程磁盘占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_disk_io_info_list', [
                    'id', 'process_id', 'read_bytes_per_second',
                    'write_bytes_per_second', 'create_time'
                ], 'process_id=?', [int(pid)]))

    def get_process_network_io_info_list(self, args):
        """进程网络IO占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_network_io_info_list', [
                    'id', 'process_id', 'recv_bytes_per_second',
                    'sent_bytes_per_second', 'create_time'
                ], 'process_id=?', [int(pid)]))

    def get_process_opened_files_info_list(self, args):
        """进程打开文件数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_opened_files_info_list',
                ['id', 'process_id', 'opened_files', 'create_time'],
                'process_id=?', [int(pid)]))

    def get_process_opened_connections_info_list(self, args):
        """进程网络连接数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args, 'process_opened_connections_info_list',
                ['id', 'process_id', 'opened_connections', 'create_time'],
                'process_id=?', [int(pid)]))

    def get_process_opened_threads_info_list(self, args):
        """进程打开线程数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(
            basic_monitor_obj.process_statistics_helper(
                args,
                'process_opened_threads_info_list',
                ['id', 'process_id', 'opened_threads', 'create_time'],
                'process_id=?', [int(pid)],
                pad_el={
                    'id': 0,
                    'process_id': 0,
                    'opened_threads': 1,
                    'create_time': 0
                }))

    def get_host_firewall_info(self, args):
        """获取主机系统防火墙信息

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        if sid is None:
            return public.error('缺少参数：sid')

        fields = ['firewall_info']
        where_str = "sid=?"
        where_val = (sid,)
        res = basic_monitor_obj.db_easy("server_details").field(*fields).where(
            where_str, where_val).select()
        if not res and not res[0]["firewall_info"]:
            d = {"total": 0, "list": []}
            return public.return_data(True, d)

        res_data = json.loads(res[0]["firewall_info"])

        if len(res_data.keys()) == 0:
            return public.success({
                'total': 0,
                'list': [],
            })

        page = int(args.get('p', 1))
        page_size = int(args.get('p_size', 20))

        page_start = (page - 1) * page_size
        page_end = page * page_size
        rules = res_data["rules"] or []
        total = len(rules)

        # 更新主机状态
        _, _, status = basic_monitor_obj.cache_server_status(sid)
        if status == 0:
            return public.error("主机离线")

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 端口号
                if keyword.isdigit():
                    if int(keyword) > 0 and int(keyword) < 65536:
                        # 端口范围
                        if item['release_port'].find('-') > -1 or item[
                            'release_port'].find(':') > -1:
                            port_begin, port_end = re.split(
                                r'\-|\:', item['release_port'], 1)

                            if not port_begin.isdigit(
                            ) or not port_end.isdigit():
                                return False

                            return int(port_begin) <= int(keyword) and int(
                                keyword) <= int(port_end)

                        return str(item['release_port']).isdigit() and int(
                            item['release_port']) == int(keyword)
                    return False

                # 协议
                if re.match(r'^tcp|udp$', keyword, flags=re.IGNORECASE):
                    return item['protocol'].lower() == keyword.lower()

                # 规则
                if re.match(r'^allow|drop$', keyword, flags=re.IGNORECASE):
                    return item['access'].upper() == keyword.upper()

                return item['source'].find(keyword) > -1

            return True

        # 列表筛选
        rules = list(filter(filter_handler, rules))

        d = {
            "is_running": res_data["is_running"],
            "rule_change": res_data["rule_change"],
            "total": total,
            "list": rules[page_start:page_end]
        }
        return public.return_data(True, d)

    def get_host_port_info(self, args):
        """获取主机端口信息

        Args:
            args (_type_): _description_
        """
        # 使用v2接口
        return self.get_host_port_info_v2(args)

        sid = args.sid
        fields = [
            'id', 'ip', 'port', 'protocol', 'process_name', 'process_path',
            'test_connection'
        ]
        where_str = '`sid` = ? AND `status` = 1'
        where_val = (sid,)

        query = basic_monitor_obj.db_easy('server_ports') \
            .field(*fields) \
            .where(where_str, where_val) \
            .order('create_time', 'DESC')

        # 添加关键字查询
        def query_handler(query, keyword):
            # 端口号搜索
            if keyword.isdigit():
                if int(keyword) > 0 and int(keyword) < 65536:
                    query.where('port=?', keyword)
                return

            # 进程路径搜索
            if str(keyword).find('/') > -1:
                query.where('process_path like ?', '%{}%'.format(keyword))
                return

            # 进程名称模糊搜索
            query.where('process_name like ?', '%{}%'.format(keyword))

        public.add_retrieve_keyword_query(query, args, query_handler)

        return public.success(public.simple_page(query, args))

    # 重构后的获取主机监听端口列表
    def get_host_port_info_v2(self, args):
        '''
            @name 获取主机监听端口列表
            @arg sid<integer>       主机ID
            @arg p<integer>         分页页码
            @arg p_size<integer>    分页大小
            @arg keyword<string>    查询关键字
            @return dict
        '''
        # 获取主机端口列表
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        port_info_str = basic_monitor_obj.db_easy('server_details') \
            .field('id', 'port_info') \
            .where('sid', sid) \
            .value('port_info')

        try:
            port_info = json.loads(port_info_str)
        except:
            pass

        # 通过pne_id获取进程信息
        pne_id_list = []

        # 检查端口是否在测试列表中
        in_test = basic_monitor_obj.db_easy('server_port_connection_test') \
            .field('id') \
            .where('`id` IN ({})'.format(','.join(port_info.keys()))) \
            .column('id')

        for k, v in port_info.items():
            port_info[k]['in_test'] = k in in_test

            if str(v['pne_id']) in pne_id_list:
                continue
            pne_id_list.append(str(v['pne_id']))

        proc_info = basic_monitor_obj.db_easy('process_name_exe') \
            .field('id', 'name', 'exe') \
            .where('`id` IN ({})'.format(','.join(pne_id_list))) \
            .column(None, 'id')

        # 结果集(处理前)
        raw_ret = []

        for k, v in port_info.items():
            p = proc_info.get(v['pne_id'], {})

            tmp = {
                'id': k,
                'process_name': p.get('name'),
                'process_path': p.get('exe'),
            }
            tmp.update(v)
            del (tmp['pne_id'])
            raw_ret.append(tmp)

        # 根据查询条件筛选结果
        def filter_handler(item):
            # 关键字查询
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 端口号搜索
                if keyword.isdigit():
                    if int(keyword) > 0 and int(keyword) < 65536 and int(
                            keyword) == int(item.get('port', 0)):
                        return True

                # 进程路径搜索
                if str(keyword).find('/') > -1 and str(
                        item.get('process_path', '')).find(keyword) > -1:
                    return True

                # 进程名称搜索
                if str(item.get('process_name', '')).find(keyword) > -1:
                    return True

                return False

            return True

        # 筛选数据
        ret = list(filter(filter_handler, raw_ret))

        # 分页
        # if 'p' in args:
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(ret),
            'list': ret[(p - 1) * p_size:p * p_size],
        })

        # return public.success(ret)

    def get_port_connection_logs(self, args):
        """
        @deprecated 已废弃
        获取端口连接测试记录

        Args:
            args (_type_): _description_

        Returns:
            _type_: _description_
        """
        return public.error('接口下线')
        sid = args.sid
        query_date = "today"
        if "query_date" in args:
            query_date = args.query_date
        query_start, query_end = public.get_query_timestamp(query_date)
        data_fields = "id,sid,ip,port,test_method,ok,create_time"
        query = public.db_monitor('port_connection_logs').field(
            data_fields).where("sid=? and create_time>=? and create_time<=?", (
            sid,
            query_start,
            query_end,
        )).order('`create_time` DESC')
        result = public.simple_page(query, args)
        return public.return_data(True, result)

    def get_logs_path_list(self, get):
        """获取日志路径列表"""
        sid = get.sid

        if sid is None:
            return public.error('缺少参数：sid')
        syslog_paths = basic_monitor_obj.cache_server_syslog_paths(sid)

        if not basic_monitor_obj.is_empty_result(syslog_paths):
            return public.success(syslog_paths)

        server_id = public.get_serverid_bysid(sid)
        if not server_id:
            return public.return_data(False, {}, error_msg="主机不存在。")

        res = public.send_agent_msg(server_id,
                                    'loganalysis',
                                    'FetchLogByServer',
                                    "recv/loganalysis/FetchLogByServer/" +
                                    server_id,
                                    pdata=public.g_pdata({}),
                                    timeout=self.timeout)
        data = public.get_agent_msg(res)

        if not isinstance(data, dict) or not isinstance(
                data.get('body', {}), dict):
            return public.success([])

        return public.success(
            basic_monitor_obj.cache_server_syslog_paths(
                sid,
                data.get('body', {}).get('sys_log', [])))

    def get_log_content(self, get):
        sid = get.sid

        if sid is None:
            return public.error('缺少参数：sid')
        lines = 100
        if "n" in get:
            lines = int(get.n)
        params = {'path': get.path, 'n': str(lines)}
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(
            server_id,
            'loganalysis',
            'FetchLogContentByServer',
            "recv/loganalysis/FetchLogContentByServer/" + server_id,
            timeout=self.timeout,
            pdata=public.g_pdata(params))
        # public.print_log("get res:")
        # public.print_log(res)
        data = public.get_agent_msg(res)
        if not data:
            return public.return_data(False, {}, error_msg="数据为空")
        return public.return_data(True, data)

    def get_ssh_users_info(self, args):
        """获取当前SSH在线用户

        Args:
            args (_type_): _description_
        """
        sid = args.sid

        ssh_users = basic_monitor_obj.cache_server_ssh_users(sid)

        if not basic_monitor_obj.is_empty_result(ssh_users):
            return public.success(ssh_users)

        server_id = public.get_serverid_bysid(sid)
        if not server_id:
            return public.return_data(False, {}, error_msg="主机不存在。")

        res = public.send_agent_msg(server_id,
                                    'systeminfo',
                                    'FetchSSHWhoByServer',
                                    'recv/systeminfo/FetchSSHWhoByServer/' +
                                    server_id,
                                    pdata=public.g_pdata({}),
                                    timeout=self.timeout)
        data = public.get_agent_msg(res)

        if not isinstance(data, dict):
            return public.success([])

        return public.success(
            basic_monitor_obj.cache_server_ssh_users(sid, data.get('body',
                                                                   [])))

    def get_installed_soft_info(self, args):
        """获取当前软件安装列表

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        if sid is None:
            return public.error('缺少参数：sid')

        installed_softs = basic_monitor_obj.cache_server_installed_softs(sid)

        if basic_monitor_obj.is_empty_result(installed_softs):
            server_id = public.get_serverid_bysid(sid)
            if not server_id:
                return public.return_data(False, {}, error_msg="主机不存在。")

            res = public.send_agent_msg(
                server_id,
                'systeminfo',
                'FetchSoftInstalledByServer',
                'recv/systeminfo/FetchSoftInstalledByServer/' + server_id,
                pdata=public.g_pdata({}),
                timeout=self.timeout)
            data = public.get_agent_msg(res)

            if not isinstance(data, dict):
                return public.success([])

            installed_softs = basic_monitor_obj.cache_server_installed_softs(
                sid, data.get('body', []))

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # linux
                # 软件名称\版本号\架构\描述
                return '|'.join([
                    item['softname'], item['version'], item.get('architecture',''),
                    item.get('description',''),item.get('publisher','')
                ]).find(keyword) > -1


            return True

        # 列表筛选
        installed_softs = list(filter(filter_handler, installed_softs))

        # 分页
        if 'p' in args:
            p = int(args.get('p', 1))
            p_size = int(args.get('p_size', 20))
            return public.success({
                'total':
                    len(installed_softs),
                'list':
                    installed_softs[(p - 1) * p_size:p * p_size],
            })

        return public.success(installed_softs)

    def get_command_history(self, args):
        """获取命令历史记录

        Args:
            get (_type_): _description_
        """
        sid = args.sid

        command_history = basic_monitor_obj.cache_server_command_history(sid)

        if basic_monitor_obj.is_empty_result(command_history):
            server_id = public.get_serverid_bysid(sid)
            if not server_id:
                return public.return_data(False, {}, error_msg="主机不存在。")

            res = public.send_agent_msg(
                server_id,
                'sshandsoft',
                'FetchUserHistoryByServer',
                'recv/sshandsoft/FetchUserHistoryByServer/' + server_id,
                pdata=public.g_pdata({}),
                timeout=self.timeout)

            data = public.get_agent_msg(res)

            if not isinstance(data, dict):
                return public.success([])

            command_history = basic_monitor_obj.cache_server_command_history(
                sid, data.get('body', []))

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 软件名称\版本号\架构\描述
                return '|'.join([item['user'], item['command']
                                 ]).find(keyword) > -1

            return True

        # 列表筛选
        command_history = list(filter(filter_handler, command_history))

        return public.success(command_history)

    def get_raid_info(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        result = basic_monitor_obj.db_easy('server_raid_info') \
            .field("check_result",'output') \
            .where('sid=?', (sid,)).find()
        res = {"display": True, "check_res": ""}
        if not result or result['output'] =='':
            res["display"] = False
        else:
            res["display"] = True
            res["check_res"] = result["check_result"]
        return public.success(res)

    def get_agent_info(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(server_id,
                                    "agentinfo",
                                    "GetAgentInfo",
                                    "recv/agentinfo/GetAgentInfo/" + server_id,
                                    pdata={},
                                    timeout=60)
        data = public.get_agent_msg(res)
        if not data or 'body' not in data:
            return public.error("获取信息失败。")
        return public.success(data["body"])

    def repair_agent(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(server_id,
                                    "agentinfo",
                                    "RepairAgent",
                                    "recv/agentinfo/RepairAgent/" + server_id,
                                    pdata={},
                                    timeout=60)
        # public.print_log("客户端回复信息："+str(res))
        return public.success("OK")

    ##### 云监控预览大屏接口

    # 主机统计
    def server_statistics(self, args):
        '''
            @name 主机统计
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
        '''
        cur_time = int(time.time())

        server_list = g.get("server_list", [])

        # 0-离线
        # 1-正常
        # 2-告警中
        m = {
            '0': 'offline',
            '1': 'online',
            '2': 'warning',
        }

        ret = {
            'total': 0,  # 主机总数
            'offline': 0,  # 离线
            'online': 0,  # 正常/在线
            'warning': 0,  # 告警中
        }

        # 统计主机数
        servers_all = basic_monitor_obj.db_easy('servers').count()

        # 查询全部主机IP、备注
        servers = basic_monitor_obj.db_easy('servers') \
            .field('sid', 'status', 'ip', 'remark', 'is_authorized') \
            .where_in("sid", server_list) \
            .select()

        # 计算格子数
        grid_num = 100 + (20 * int((max(0, servers_all - 81) / 20)))
        server_position = {}
        server_position_file = '{}/data/server_position.json'.format(public.get_panel_path())

        # 获取每台主机随机位置
        if os.path.exists(server_position_file):
            server_position = json.loads(public.readFile(server_position_file))

        # 检查主机数与记录的主机位置数量是否一致，不一致时更新
        ks = list(server_position.keys())
        if servers_all != len(ks):
            # 查询出所有主机ID
            sid_all = basic_monitor_obj.db_easy('servers').column('sid')
            for k in ks:
                if int(k) not in sid_all:
                    server_position.pop(k, None)

        # 主机位置集合
        server_position_set = set(server_position.values())

        # 统计当前正在告警的主机
        warning_servers_cache_key = 'BT_MONITOR_CACHE__WARNING_SERVERS'

        # 优先从缓存中获取
        warning_servers = public.cache_get(warning_servers_cache_key)

        # 其次从数据库查询
        if not warning_servers:
            warning_servers = basic_monitor_obj.db_easy('warning_tasks') \
                .where_in('sid', list(map(lambda x: x['sid'], servers))) \
                .where('status', 0) \
                .where('create_time > ?', cur_time - 86400) \
                .group('sid') \
                .field('sid', 'count(*) as cnt') \
                .having('cnt > ?', 0) \
                .column('sid')
            public.cache_set(warning_servers_cache_key, warning_servers, 120)

        # 生成随机格子
        free_grids = [i for i in range(1, grid_num + 1)]
        free_grids = list(filter(lambda x: x not in server_position_set, free_grids))
        random.shuffle(free_grids)

        # 统计主机数
        for server in servers:
            # 更新主机状态
            _, _, server['status'] = basic_monitor_obj.cache_server_status(server['sid'])

            k = m.get(str(server['status']), 'total')

            if k != 'total':
                ret['total'] += 1

            # 未授权统计为离线
            if server['is_authorized'] == 0 or int(server['status']) == 0:
                ret['offline'] += 1

            # 检查该主机是否存在告警
            elif server['sid'] in warning_servers:
                ret['warning'] += 1
                server['status'] = 2
            else:
                ret[k] += 1

            # 位置信息不存在时，更新位置信息
            if str(server['sid']) not in server_position:
                # pos = random.randint(0, grid_num - 1)
                #
                # while pos in server_position_set:
                #     pos = random.randint(0, grid_num - 1)
                #
                # server_position[str(server['sid'])] = pos
                # server_position_set.add(pos)

                pos = free_grids.pop()
                server_position[str(server['sid'])] = pos
                server_position_set.add(pos)

            server['pos'] = server_position[str(server['sid'])]

        ret['servers'] = servers

        # 同步主机位置信息
        # if len(server_position) != len(servers):
        #     sid_list = list(map(lambda x: str(x['sid']), servers))
        #
        #     remove_list = []
        #     for k in server_position.keys():
        #         if k not in sid_list:
        #             remove_list.append(k)
        #
        #     for k in remove_list:
        #         server_position.pop(k)

        with open(server_position_file, 'w') as fp:
            fp.write(json.dumps(server_position))

        warn_today_cache_key = 'BT_MONITOR_CACHE__WARN_TODAY'
        warn_today = public.cache_get(warn_today_cache_key)

        if warn_today is None:
            # 统计当天告警数
            today_begin, today_end = public.get_query_timestamp('today')
            warn_today = basic_monitor_obj.db_easy('warning_tasks') \
                .where('create_time >= ?', today_begin) \
                .where('create_time <= ?', today_end) \
                .count()
            public.cache_set(warn_today_cache_key, warn_today, 120)

        ret['warn_today'] = warn_today

        return public.success(ret)

    # 主机实时信息排行(CPU/内存/流量)
    def server_realtime_net_rank(self, args):
        '''
            @name 主机实时信息排行(CPU/内存/流量)
            @author Zhj<2022-12-10>
            @param  args<dict> 请求参数
            @return dict
        '''
        server_list = g.get("server_list", [])

        servers_tmp = basic_monitor_obj.db_easy('servers') \
            .field('sid', 'ip', 'remark') \
            .where('is_authorized', 1) \
            .where_in("sid", server_list) \
            .select()

        servers = []
        for server_info in servers_tmp:
            # 更新主机状态
            _, _, server_status = basic_monitor_obj.cache_server_status(server_info['sid'])

            if server_status == 0:
                continue

            servers.append(server_info)

        del (servers_tmp,)

        for server_info in servers:
            server_detail = basic_monitor_obj.cache_realtime_server_info(server_info['sid'])
            server_info['realtime_net_sent'] = 0
            server_info['realtime_net_recv'] = 0
            server_info['realtime_cpu_percent'] = server_detail.get('cpu_info', {}).get('percent', 0)
            server_info['realtime_mem_percent'] = server_detail.get('mem_info', {}).get('used_percent', 0)

            for net_info in server_detail.get('net_info', []):
                server_info['realtime_net_sent'] += net_info['sent_per_second']
                server_info['realtime_net_recv'] += net_info['recv_per_second']

            del (server_info['sid'],)

        return public.success({
            'realtime_net_rank': sorted(servers, key=lambda x: x['realtime_net_sent'] + x['realtime_net_recv'],
                                        reverse=True)[:10],
            'realtime_cpu_rank': sorted(servers, key=lambda x: x['realtime_cpu_percent'], reverse=True)[:10],
            'realtime_mem_rank': sorted(servers, key=lambda x: x['realtime_mem_percent'], reverse=True)[:10],
        })

    # 敏感命令执行记录
    def sensitive_execute_records(self, args):
        '''
            @name 敏感命令执行记录
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return:
        '''
        server_list = g.get("server_list", [])

        sensitive_commands = basic_monitor_obj.db_easy('command_execute_logs') \
            .where('is_sensitive', 1) \
            .order('create_time', 'desc') \
            .field('sid', 'command', 'create_time') \
            .where_in("sid", server_list) \
            .limit(20) \
            .select()

        server_info_map = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(set(map(lambda x: x['sid'], sensitive_commands)))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in sensitive_commands:
            server_info = server_info_map.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['sid'])

            # DEMO
            if basic_monitor_obj.in_demo():
                item['command'] = '****'

        return public.success(sensitive_commands)

    # 敏感命令详情页
    def sensitive_listpage(self, args):
        keyword = args.get('keyword', None)
        query_date = args.get('query_date', None)

        query = basic_monitor_obj.db_easy('command_execute_logs') \
            .where('is_sensitive', 1) \
            .order('create_time', 'desc') \
            .field('sid', 'command', 'create_time', 'user')

        query2 = basic_monitor_obj.db_easy('servers') \
            .field('sid')

        query3 = basic_monitor_obj.db_easy('command_execute_logs') \
            .field('id')

        if keyword is not None and len(keyword) > 0:
            tmp = '%{}%'.format(keyword)
            query3.where('command like ?', [tmp])
            query2.where('ip like ? OR remark like ?', [tmp, tmp])

            query.where('(`sid` IN ({}) OR `id` IN ({}))'.format(
                ','.join(map(lambda x: str(x), query2.column('sid'))),
                ','.join(map(lambda x: str(x), query3.column('id')))))

        if query_date is not None and len(query_date) > 0:
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        sensitive_commands = query.fork()
        ret = public.simple_page(query, args)

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret['list']:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['sid'])

            # DEMO
            if basic_monitor_obj.in_demo():
                item['command'] = '****'
            if item['ip'] == '' or item['ip'] is None:
                del item
        # 日志导出 export_log
        if args.get('export_log', None) == '1':
            sensitive_commands = sensitive_commands.select()
            if sensitive_commands is None or len(sensitive_commands) == 0:
                return public.error('没有可导出的数据')
            # 查询服务器信息
            servers = basic_monitor_obj.db_easy('servers') \
                .where_in('sid', list(map(lambda x: x['sid'], sensitive_commands))) \
                .field('sid', 'ip', 'remark') \
                .column(None, 'sid')

            for item in sensitive_commands:
                server_info = servers.get(item['sid'], {})
                item['ip'] = server_info.get('ip', '')
                item['remark'] = server_info.get('remark', '')
                del (item['sid'])

            import pandas as pd
            # 处理数据
            for i in sensitive_commands:
                i['create_time'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(i['create_time']))

            # 将数据转换为DataFrame对象
            df = pd.DataFrame(sensitive_commands)
            #  选择需要导出的字段
            selected_columns = {"ip": "IP", "create_time": "告警时间",
                                "command": "命令", "remark": "备注"}

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_sensitive_execute_records.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_sensitive_execute_records.csv',
                                    'sensitive_execute_records_{}.csv'.format(date.today()))

        return public.success(ret)

    # 危险端口暴露
    def danger_port_apperence(self, args):
        '''
            @name 危险端口暴露
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
        '''
        server_list = g.get("server_list", [])

        cache_key = 'BT_MONITOR_CACHE__DANGER_PORT_APPERENCE'

        cached_data = public.cache_get(cache_key)

        if cached_data:
            return public.success(cached_data)

        server_details = basic_monitor_obj.db_easy('server_details sd') \
            .join('servers s', 'sd.sid=s.sid') \
            .field('s.ip', 's.remark', 'sd.firewall_info') \
            .where_in("sd.sid", server_list) \
            .select()

        anywhere_rules = []
        i = 0

        for server_detail in server_details:
            firewall_info = json.loads(server_detail['firewall_info'])

            if 'is_running' not in firewall_info or not firewall_info[
                'is_running']:
                continue

            for rule in firewall_info['rules']:
                if rule['source'].lower(
                ) == 'anywhere' and rule['release_port'] not in ['80', '443']:
                    d = {
                        'ip': server_detail['ip'],
                        'remark': server_detail['remark'],
                    }
                    d.update(rule)
                    anywhere_rules.append(d)

                    i += 1

                    if i >= 20:
                        break

            if i >= 20:
                break
        # 缓存两分钟
        public.cache_set(cache_key, anywhere_rules, 120)

        return public.success(anywhere_rules)

    # 危险端口暴露详情
    def danger_port_apperence_detail(self, args):
        '''
            @name 危险端口暴露详情(所有主机)
            @author lt<2022-12-10>
            @param args<dict> 请求参数
            @return dict
        '''
        access = args.get('access', None)
        protocol = args.get('protocol', None)
        keyword = args.get('keyword', None)
        server_list = g.get("server_list", [])

        query = basic_monitor_obj.db_easy('server_details sd') \
            .join('servers s', 'sd.sid=s.sid') \
            .field('s.ip', 's.remark', 'sd.firewall_info') \
            .where_in("sd.sid", server_list)\
            .order('sd.create_time', 'desc')
        server_details = query.select()

        anywhere_rules = []
        for server_detail in server_details:
            firewall_info = json.loads(server_detail['firewall_info'])
            if 'is_running' not in firewall_info or not firewall_info['is_running']:
                continue
            for rule in firewall_info.get('rules', []):
                # 筛选协议
                if protocol and protocol not in rule['protocol']:
                    continue
                # 筛选规则
                if access:
                    if rule['access'] not in access.split(','):
                        continue
                # 筛选关键字  source 主机源str   release_port 端口
                if keyword and keyword not in rule.get('release_port', ''):
                    continue

                if rule['source'].lower(
                ) == 'anywhere' and rule['release_port'] not in ['80', '443']:
                    d = {
                        'ip': server_detail['ip'],
                        'remark': server_detail['remark'],
                    }
                    d.update(rule)
                    anywhere_rules.append(d)

        # 日志导出 export_log
        if args.get('export_log', None) == '1':
            if anywhere_rules is None or len(anywhere_rules) == 0:
                return public.error('没有可导出的数据')

            import pandas as pd
            # 处理数据
            for i in anywhere_rules:
                # 放行规则 处理
                if i['access']:
                    i['permit_through'] = '完全放行'
                else:
                    if i['source'] == 'anywhere':
                        i['permit_through'] = '完全放行'
                    else:
                        i['permit_through'] = '部分放行'

            # 将数据转换为DataFrame对象
            df = pd.DataFrame(anywhere_rules)
            #  选择需要导出的字段
            selected_columns = {"ip": "服务器", "release_port": "端口", "protocol": "协议","remark": "备注", "permit_through":"放行规则",}

            selected_df = df[list(selected_columns.keys())].rename(columns=selected_columns)

            # # 导出数据到CSV文件中
            export_file_path = "/tmp/exported_danger_port_apperence.csv"
            selected_df.to_csv(export_file_path, index=False)
            from datetime import date
            return public.send_file('/tmp/exported_danger_port_apperence.csv',
                                    'danger_port_apperence_{}.csv'.format(date.today()))
        # 分页
        # if 'p' in args:
        p = int(args.get('p', 1))
        p_size = int(args.get('p_size', 20))
        return public.success({
            'total': len(anywhere_rules),
            'list': anywhere_rules[(p - 1) * p_size:p * p_size],
        })


    # SSH登录统计(所有主机)
    def ssh_login_statistics(self, args):
        '''
            @name SSH登录统计(所有主机)
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @arg    query_date<string>  日期范围
            @arg    sid<int>            主机ID
            @return:
        '''
        # return self.ssh_login_statistics_v2(args)

        query_date = args.get('query_date', 'l5')
        sid = args.get('sid', None)

        server_list = g.get("server_list", [])

        query_start, query_end = public.get_query_timestamp(query_date)

        query = basic_monitor_obj.db_easy('ssh_login_total_daily') \
            .where('day_time >= ? ', query_start) \
            .where('day_time <= ?', query_end) \
            .where_in("sid", server_list)

        if sid is not None:
            query.where('sid', int(sid))

        ret = query.field(
            'SUM(`success` + `fail`) AS `login_total`',
            'SUM(`success`) AS `success_num`',
            'SUM(`fail`) AS `fail_num`',
            '`day_time` as `day_date`'
        ) \
            .group('day_date') \
            .order('day_date', 'asc') \
            .select()

        ret = basic_monitor_obj.pad_statistics_result(ret, query_start,
                                                      query_end, 86400, {
                                                          'login_total': 0,
                                                          'success_num': 0,
                                                          'fail_num': 0,
                                                      }, 'day_date')

        return public.success(ret)

    def ssh_login_statistics_v2(self, args):
        '''
            @name SSH登录统计V2(所有主机)
            @author Zhj<2023-01-09>
            @param args<dict> 请求参数列表
            @return dict
        '''
        query_date = args.get('query_date', 'l5')
        sid = args.get('sid', None)

        server_list = g.get("server_list", [])

        query_start, query_end = public.get_query_timestamp(query_date)

        query = basic_monitor_obj.db_easy('ssh_login_total_daily') \
            .where('day_time >= ? ', query_start) \
            .where('day_time <= ?', query_end) \
            .where_in("sid", server_list)

        if sid is not None:
            query.where('sid', int(sid))

        ret = query.field(
            'SUM(`success` + `fail`) AS `login_total`',
            'SUM(`success`) AS `success_num`',
            'SUM(`fail`) AS `fail_num`',
            '`day_time` as `day_date`'
        ) \
            .group('day_date') \
            .order('day_date', 'asc') \
            .select()

        sid_list = []

        for item in ret:
            # 查询当天TOP5
            item['top5'] = basic_monitor_obj.db_easy('ssh_login_total_daily') \
                .where('day_time ==? ', item['day_date']) \
                .where('day_time ==? ', item['day_date']) \
                .order('login_total', 'desc') \
                .limit(5) \
                .group('sid') \
                .field('sid',
                       'SUM(`success` + `fail`) AS `login_total`',
                       'SUM(`success`) AS `success_num`',
                       'SUM(`fail`) AS `fail_num`',
                       ) \
                .select()

            sid_list.extend(list(map(lambda x: x['sid'], item['top5'])))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sid_list) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for v in ret:
            for item in v['top5']:
                server_info = servers.get(item['sid'], {})
                item['ip'] = server_info.get('ip', '')
                item['remark'] = server_info.get('remark', '')
                del (item['sid'])

        ret = basic_monitor_obj.pad_statistics_result(ret, query_start,
                                                      query_end, 86400, {
                                                          'login_total': 0,
                                                          'top5': [],
                                                      }, 'day_date')

        return public.success(ret)

    # 敏感命令执行次数统计(所有主机)
    def sensitive_execute_statistics(self, args):
        '''
            @name 敏感命令执行次数统计(所有主机)
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
        '''
        server_list = g.get("server_list", [])

        query_date = args.get('query_date', 'l5')
        sid = args.get('sid', None)
        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        query = basic_monitor_obj.db_easy('command_execute_logs') \
            .where('is_sensitive', 1) \
            .where('create_time >= ? ', query_start) \
            .where('create_time <= ?', query_end) \
            .where_in("sid", server_list)
        # 与主机ID 加上限制条件
        if sid is not None:
            query.where('sid', int(sid))

        ret = query.field(
            'COUNT(*) AS `cnt`',
            "STRFTIME('%Y/%m/%d', `create_time`, 'unixepoch', 'localtime') AS `day_date`"
        ) \
            .group('day_date') \
            .order('day_date', 'asc') \
            .select()

        sid_list = []

        for item in ret:
            item['day_date'] = time.mktime(
                time.strptime(item['day_date'], '%Y/%m/%d'))

            # 查询当天TOP5
            item['top5'] = basic_monitor_obj.db_easy('command_execute_logs') \
                .where('is_sensitive', 1) \
                .where('create_time >= ? ', item['day_date']) \
                .where('create_time <= ?', item['day_date'] + 86399) \
                .order('cnt', 'desc') \
                .limit(5) \
                .group('sid') \
                .field('sid', 'count(*) as `cnt`') \
                .select()

            sid_list.extend(list(map(lambda x: x['sid'], item['top5'])))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', sid_list) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for v in ret:
            for item in v['top5']:
                server_info = servers.get(item['sid'], {})
                item['ip'] = server_info.get('ip', '')
                item['remark'] = server_info.get('remark', '')
                del (item['sid'],)

        ret = basic_monitor_obj.pad_statistics_result(ret, query_start,
                                                      query_end, 86400, {
                                                          'cnt': 0,
                                                          'top5': [],
                                                      }, 'day_date')

        return public.success(ret)

    # 硬盘状态
    def disk_health(self, args):
        server_list = g.get("server_list", [])

        cache_key = 'BT_MONITOR_CACHE__DISK_HEALTH'

        cached_data = public.cache_get(cache_key)

        if cached_data:
            return public.success(cached_data)

        server_details = basic_monitor_obj.db_easy('server_details sd') \
            .join('servers s', 'sd.sid=s.sid') \
            .field('s.sid', 's.ip', 's.remark', 'sd.disk_info') \
            .where_in("sd.sid", server_list) \
            .select()

        d = {
            'low': 0,
            'medium': 0,
            'most_high': 0,
            'high': 0,
        }

        servers = {
            'low': set(),
            'medium': set(),
            'most_high': set(),
            'high': set(),
        }

        server_map = {}

        for server_detail in server_details:
            disk_list = json.loads(server_detail['disk_info'])

            new_list = sorted(
                disk_list,
                key=lambda x: max(
                    (x['used_percent'], x['inodes_used_percent'])))

            mountpoint = '/'
            total = 0
            free = 0
            used_percent = 0
            inodes_used_percent = 0

            for disk_info in new_list:
                p = max(disk_info['used_percent'],
                        disk_info['inodes_used_percent'])
                mountpoint = disk_info['mountpoint']
                total = disk_info['total']
                free = disk_info['free']
                used_percent = disk_info['used_percent']
                inodes_used_percent = disk_info['inodes_used_percent']

                if p > 97:
                    d['high'] += 1
                    servers['high'].add(server_detail['sid'])
                    continue

                if p > 89:
                    d['most_high'] += 1
                    servers['most_high'].add(server_detail['sid'])
                    continue

                if p > 79:
                    d['medium'] += 1
                    servers['medium'].add(server_detail['sid'])
                    continue

                d['low'] += 1
                servers['low'].add(server_detail['sid'])

            server_map[server_detail['sid']] = {
                'sid': server_detail['sid'],
                'ip': server_detail['ip'],
                'remark': server_detail['remark'],
                'mountpoint': mountpoint,
                'total': total,
                'free': free,
                'used_percent': used_percent,
                'inodes_used_percent': inodes_used_percent
            }

        ret = {
            'health': 'low',
            'count': d['low'],
            'servers': [],
        }

        if d['medium'] > 0:
            ret = {
                'health': 'medium',
                'count': d['medium'],
                'servers': [server_map[sid] for sid in servers['medium']],
            }

        if d['most_high'] > 0:
            ret = {
                'health': 'most_high',
                'count': d['most_high'],
                'servers': [server_map[sid] for sid in servers['most_high']],
            }

        if d['high'] > 0:
            ret = {
                'health': 'high',
                'count': d['high'],
                'servers': [server_map[sid] for sid in servers['high']],
            }

        public.cache_set(cache_key, ret, 120)

        return public.success(ret)

    # 称号
    def rank_title(self, args):
        server_list = g.get("server_list", [])

        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE__RANK_TITLE__{}'.format(public.bt_auth('uid'))

        cached_data = public.cache_get(cache_key)

        if cached_data:
            # public.cache_remove(cache_key)
            return public.success(cached_data)

        sorted_ssh_login_logs = basic_monitor_obj.db_easy('ssh_login_total_daily') \
            .group('sid') \
            .field('sid', 'sum(`success` + `fail`) as cnt') \
            .where_in("sid", server_list) \
            .order('cnt', 'desc') \
            .select()

        if len(sorted_ssh_login_logs) == 0:
            return public.success({
                'ip': '',
                'remark': '',
                'ssh_login_count': 0,
                'rank_title': '无',
            })

        most_login_info = sorted_ssh_login_logs[0]

        rank_title = 'SSH登录最多次'

        # if most_login_info['cnt'] > 0:
        #     rank_title = '初级标兵'
        #
        # if most_login_info['cnt'] > 30:
        #     rank_title = '中级标兵'
        #
        # if most_login_info['cnt'] > 100:
        #     rank_title = '高级标兵'
        #
        # if most_login_info['cnt'] > 300:
        #     rank_title = '特级标兵'
        #
        # if most_login_info['cnt'] > 1000:
        #     rank_title = '炮灰级标兵'

        server_info = basic_monitor_obj.db_easy('servers') \
            .where('sid', int(most_login_info['sid'])) \
            .field('sid', 'ip', 'remark') \
            .find()

        if server_info is None:
            return public.success({
                'ip': '',
                'remark': '',
                'ssh_login_count': 0,
                'rank_title': '无',
            })

        ret = {
            'ip': server_info['ip'],
            'remark': server_info['remark'],
            'ssh_login_count': most_login_info['cnt'],
            'rank_title': rank_title,
        }

        # 缓存2分钟
        public.cache_set(cache_key, ret, 120)

        return public.success(ret)

    # 获取最新SSH登录日志
    def latest_ssh_login_logs(self, args):
        return public.success(self._latest_ssh_login_logs_help())

    # 获取最新SSH登录日志(帮助函数)
    def _latest_ssh_login_logs_help(self):
        ret = copy.deepcopy(basic_monitor_obj.LATEST_SSH_LOGIN_LOGS)

        server_list = g.get("server_list", [])

        # 当列表为空时，尝试填充
        if len(ret) == 0:
            sid = basic_monitor_obj.db_easy('ssh_login_total_daily') \
                .where_in('sid', server_list) \
                .order('day_time', 'desc') \
                .column('sid')

            limit = 20
            ret = []
            for temp in sid:
                # 第一次limit 20
                # 第2-n次limit 20 - 总数
                db_mgr = monitor_db_manager.MonitorDbManager(temp)
                with db_mgr.db_sgl('ssh_login_logs') as db:
                    temp_ret = db.query().name('ssh_login_logs') \
                        .order('login_time', 'desc') \
                        .limit(limit) \
                        .field('{} as sid'.format(temp), 'ip', 'ip_place', 'port', 'user', 'success', 'login_time') \
                        .select()
                # public.print_log(f"******************************************{type(temp_ret)}")
                ret.extend(temp_ret)
                if len(ret) == 20:
                    break
                else:
                    limit = limit - len(ret)

                with basic_monitor_obj.UPDATE_LATEST_SSH_LOGIN_LOGS_LOCK:
                    basic_monitor_obj.LATEST_SSH_LOGIN_LOGS = copy.deepcopy(ret)

        ret = list(filter(lambda x: x['sid'] in server_list, ret))

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(set(map(lambda x: x['sid'], ret)))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret:
            s = servers.get(item['sid'], {})
            item['login_ip'] = '{}{}'.format(
                item['ip'],
                ':{}'.format(item['port']) if int(item['port']) > 0 else '')
            item['ip'] = s.get('ip', '')
            item['remark'] = s.get('remark', '')
            del (item['sid'])
            del (item['port'])

            # DEMO
            if basic_monitor_obj.in_demo():
                item['login_ip'] = '****'

        return sorted(ret, key=lambda x: x['login_time'], reverse=True)

    # 设置公开的服务器列表
    def set_public_server_list(self, args):
        '''
            @name 设置公开的服务器列表
            @param public_server_list <str> 需要公开的服务器列表 sid 逗号分隔
            @param public_port <str> 公开的端口 int
            @return string
        '''

        sids = args.get('sid', '')
        sids = sids.split(',') if sids != '' else []
        server_list = g.get("server_list", [])
        p_server_list = []
        # 检查服务器列表是否符合要求
        if len(sids) > 0:
            # 字符串转int
            sids = [int(sid) for sid in sids]
            for sid in sids:
                if sid in server_list:
                    p_server_list.append(sid)
        public_port = args.get('port', None)

        # 检测端口是否符合要求
        if public_port is None:
            return public.error('缺少参数：port')
        if not re.match("^\d+$", public_port):
            return public.error('端口应为纯数字')
        intport = int(public_port)
        if intport < 1 or intport > 65535:
            return public.error('端口超出范围,端口号为0-65535')

        # # 生成secret_key
        # secret_key = public.md5(str(time.time()) + public.GetRandomString(32))

        # 获取ip 备注信息
        server_info = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', p_server_list) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        p_server_detail = []
        log_info = []
        ip_divulge = []
        if len(p_server_list) > 0:
            for sid in p_server_list:
                server_detail = server_info.get(sid, {})
                server_detail['sid'] = sid
                server_detail['sort_key'] = 0

                p_server_detail.append(server_detail)
                if server_detail['remark'] == '':
                    ip_divulge.append(server_detail['ip'])
                    # server_detail['remark'] = server_detail['ip']
                # if server_detail['ip'] == server_detail['remark']:
                #     ip_divulge.append(server_detail['ip'])
                log_info.append('IP:【{}】 备注:【{}】'.format(server_detail['ip'], server_detail['remark']))

        # 存储json文件
        public_port_set = 0
        path = '{}/config/public_server_list.json'.format(public.get_panel_path())
        if os.path.exists(path):
            public_server_list = json.loads(public.readFile(path))
            # 判断服务器是否有变化
            sid_list = public_server_list.get('sid_list', [])
            public_port_set = public_server_list.get('public_port', 0)
            if sid_list != p_server_list or public_port_set != intport:
                public_server_list["sid_list"] = p_server_list
                public_server_list["p_server_detail"] = p_server_detail
                public_server_list["public_port"] = intport
                # public.print_log(f'4444444444{public_server_list}', _level='error')
        else:
            # public.print_log(f'cccccccc', _level='error')
            public_server_list = {
                "sid_list": p_server_list,
                "p_server_detail": p_server_detail,
                "public_port": intport,
                "open": True
            }

        # 检测端口是否被占用
        port_use = []
        ipport, _ = public.ExecShell("ss -unlpt |awk '{print $5}'")
        ipport = ipport.split("\n")
        list1 = [i for i in ipport if i.count(':') > 0]
        for p in list1:
            port_use.append(p.split(':')[1])
        port_use = list(set(port_use))
        if public_port in port_use and public_port_set != intport:
            return public.error('端口已被占用')

        # public.print_log(f'5555555555555{public_server_list}', _level='error')
        public.writeFile(path, json.dumps(public_server_list))
        os.chmod(path, 384)
        if len(log_info) > 0:
            log_info = json.dumps(log_info, ensure_ascii=False, indent=4)
            public.WriteLog('系统设置', '设置公开服务器列表: %s' % log_info)

        # 重启宝塔云安全监控
        if public_port_set != intport:
            public.reload()

        if len(ip_divulge) > 0:
            return public.return_data(True, "设置成功! 注:这些服务器未设置备注,有IP泄露风险: {}".format(ip_divulge))
        else:
            return public.return_data(True, "设置成功!")

    # 查看公开的服务器列表
    def get_config_public_server_list(self, args):
        '''
            @name 获取配置项 公开的服务器列表
            @return dict 服务器详情 开放端口  detail [{服务器详情: ip,remark,sid}, {}]
        '''
        # 随机端口号
        common_ports = [1080, 1433, 1521, 3306, 3389, 5432, 5800, 5900, 6379, 7001, 7002, 8000, 8001, 8080, 8081, 8888,
                        9000, 9090, 9200, 9300, 9418, 27017, 27018, 50000]
        while True:
            random_port = random.randint(1024, 65535)
            if random_port not in common_ports:
                break

        # 获取公开的服务器列表
        path = '{}/config/public_server_list.json'.format(public.get_panel_path())

        if not os.path.exists(path):
            data = {
                'detail': [],
                'port': random_port,
                'open': True
            }
            return public.return_data(True, data)
        else:
            public_server_list = json.loads(public.readFile(path))
        detail = public_server_list.get('p_server_detail', [])
        port = public_server_list.get('public_port', None)
        open_ = public_server_list.get('open', False)
        if port is None:
            port = random_port
        data = {
            'detail': detail,
            'port': port,
            'open': open_
        }
        return public.return_data(True, data)

    # 公开页开关
    def set_public_server_open(self, args):

        with Locker.acquire_with_file(timeout=60):
            open_ = args.get('status', '0')
            path = '{}/config/public_server_list.json'.format(public.get_panel_path())
            is_open = '关闭' if open_ == '0' else '开启'

            if os.path.exists(path):
                public_server_list = json.loads(public.readFile(path))
                public_server_list['open'] = False if open_ == '0' else True
                public.reload()
                # time.sleep(3)
                public.writeFile(path, json.dumps(public_server_list))
                public.WriteLog('系统设置', '%s公开服务器列表服务' % is_open)
                os.chmod(path, 384)
            else:
                return public.return_data(False, '请先设置公开的服务器列表')

            return public.return_data(True, '%s 成功'% is_open)

    # 公开页服务器排序
    def set_public_server_sort(self, args):
        sid_sort = args.get('sid_sort', None)
        # sid_sort1='75,2;73,4'
        # sid_sort2 = {73: 4, 75: 2}

        public.print_log(f'5555555555555{sid_sort}', _level='error')
        if sid_sort is None:
            return public.return_data(False, '参数不能为空')

        sid_sort2 = {}
        for item in sid_sort.split(';'):
            sid, sort = item.split(',')
            sid_sort2[int(sid)] = int(sort)

        path = '{}/config/public_server_list.json'.format(public.get_panel_path())
        if os.path.exists(path):
            public_server_list = json.loads(public.readFile(path))
            # 原服务器列表数据
            old = public_server_list.get('p_server_detail', [])
            # old = [
            #     {
            #         "sid": 75,
            #         "remark": "1111111",
            #         "ip": "127.0.0.1",
            #         "sort_key": 0
            #     },
            #     {
            #         "sid": 73,
            #         "remark": "aLLLLLLLT",
            #         "ip": "192.168.66.128",
            #         "sort_key": 0
            #     }
            # ],
            # 修改排序
            for i in old:
                i['sort_key'] = sid_sort2.get(i['sid'], 0)
            public_server_list['p_server_detail'] = old

            public.reload()
            # time.sleep(3)
            public.writeFile(path, json.dumps(public_server_list))
            # public.WriteLog('系统设置', '公开服务器 设置排序 ' % is_open)
            os.chmod(path, 384)
        else:
            return public.return_data(False, '请先设置公开的服务器列表')

        return public.return_data(True, '设置成功')

        ...



    # # 获取公开的服务器列表信息
    # def get_public_server_list(self, args):
    #     '''
    #          @name 获取公开的主机列表信息
    #          @arg    status<?integer>    主机状态 0-离线 1-在线 2-维护(弃用) 3-未授权 4-已授权
    #          @return list
    #      '''
    #     # 获取公开的服务器列表
    #     path = '{}/config/public_server_list.json'.format(public.get_panel_path())
    #     # public_server_list = {}
    #     if not os.path.exists(path):
    #         return public.return_data(False, "未设置公开的服务器列表!")
    #     else:
    #         public_server_list = json.loads(public.readFile(path))
    #     sid_list = public_server_list.get('sid_list', [])
    #
    #     from core.include.monitor_helpers import basic_monitor_obj
    #     query = basic_monitor_obj.db_easy('servers') \
    #         .alias('s') \
    #         .left_join('server_group sg', 's.group_id=sg.id') \
    #         .where_in("s.sid", sid_list) \
    #         .where('s.is_authorized=?', 1)
    #
    #     query.field(
    #         'sid',
    #         'group_id',
    #         'sg.name as group_name',
    #         'status',
    #         'is_authorized',
    #         'allow_notify',
    #         'ip',
    #         'remark',
    #         's.create_time',
    #         'last_active_time',
    #         "ssh_info",
    #         "panel_info",
    #         's.sampling',
    #         's.type'
    #     ).order('s.create_time', 'DESC')
    #
    #
    #     ret_list = query.select()
    #     ret = {'total': 0, 'list': []}
    #
    #     # 查询主机漏洞数
    #     server_bugs = basic_monitor_obj.db_easy('server_bug_total') \
    #         .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
    #         .field('sid', '`bugs` - `ignored` - `fixed` as `bugs`') \
    #         .column('bugs', 'sid')
    #
    #     # 查询主机挖矿木马数
    #     server_minings = basic_monitor_obj.db_easy('server_mining_total') \
    #         .where_in('sid', list(map(lambda x: x['sid'], ret_list))) \
    #         .field('sid', '`minings` - `ignored` - `fixed` as `minings`') \
    #         .column('minings', 'sid')
    #
    #     # 查询主机详细信息关联数据
    #     for item in ret_list:
    #         # 实时数据
    #         item.update(basic_monitor_obj.cache_realtime_server_info(item['sid']))
    #
    #         # 更新主机状态
    #         _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
    #
    #         # 显示主机漏洞数
    #         item['bugs'] = server_bugs.get(item['sid'], 0)
    #
    #         # 显示主机挖矿木马数
    #         item['minings'] = server_minings.get(item['sid'], 0)
    #
    #         if item['status'] == 0:
    #             # item['cpu_info'] = {}
    #             item['disk_info'] = [{'read_bytes_per_second': -1, 'write_bytes_per_second': -1}, ]
    #             # item['host_info'] = {}
    #             item['load_avg'] = {}
    #             # item['mem_info'] = {}
    #             item['net_info'] = [{'recv_per_second': -1, 'sent_per_second': -1, 'recv': -1, 'sent': -1}]
    #             item['bugs'] = -1
    #             item['minings'] = -1
    # #             # 去掉敏感信息
    #         del (item['cpu_info']['model_name'])
    #         del (item['host_info']['host_name'])
    #         del (item['host_info']['kernel_version'])
    #         del (item['host_info']['platform_version'])
    #         del (item['host_info']['platform_family'])
    #         del (item['ip'])
    #
    # #     ret['total'] = len(ret_list)
    #
    #     auth_info = basic_monitor_obj.get_auth_info()
    #
    #     if not auth_info:
    #         ret['available_auth_num'] = basic_monitor_obj.get_available_clients()
    #
    #         # 获取当前已授权的客户端数量
    #         ret['cur_auth_num'] = basic_monitor_obj.db_easy('servers') \
    #             .where('is_authorized=1') \
    #             .where_in('status', [0, 1]) \
    #             .count()
    #     else:
    #         ret['available_auth_num'] = auth_info.get('clients', 0)
    #         ret['cur_auth_num'] = auth_info.get('cur_auth_num', 0)
    #     ret['list'] = ret_list
    #     return public.return_data(True, ret)