import time
from filecmp import cmp

# import core.include.public as public

# data = [{'id': 1, 'name': '测试脚本1', 'sid': 73, 'frequency': 30, 'condition': 1, 'is_push': 1, 'push_methods': 'dingding', 'result_type': 1, 'result_match': 1, 'script': '111', 'result_key': 'aa', 'suspend': 0, 'update_time': 1684815277, 'create_time': 1684814886}, {'id': 2, 'name': '测试脚本1', 'sid': 73, 'frequency': 20, 'condition': 1, 'is_push': 1, 'push_methods': 'dingding', 'result_type': 1, 'result_match': 1, 'script': '111', 'result_key': 'aa', 'suspend': 0, 'update_time': 1684814959, 'create_time': 1684814959}]
# import json
# formatted_json = json.dumps(data, indent=3)
# from pygments import highlight, lexers, formatters
# colorful_json = highlight(formatted_json.encode('utf-8'), lexers.JsonLexer(), formatters.TerminalFormatter())
# print(colorful_json)

# a = '3123.37'
# b = '312'
# c = 3123.37
# d = 3123
# e = 'w3123'
# # 判断对象是否是数字或浮点数 要求a,b,c,d 都能通过判断  字符串类型的数字浮点数也能通过判断
# import re
# # 正则表达式判断字符串是否为数字或浮点数类型，返回布尔值
# def is_number(s):
#     pattern = re.compile(r'^(-?\d+)(\.\d+)?$')
#     return pattern.match(str(s)) is not None
#
# print(is_number(a))
# print(is_number(b))
# print(is_number(c))
# print(is_number(d))
# print(is_number(e))


# isdigit = isinstance(a, float)
#
# print(isdigit)
# key_int = 20
# result_match = 3
# match = {1: '>', 2: '<', 3: '=', 4: '>=', 5: '<='}
#
# flag = eval('99' + match[result_match] + str(key_int))
#
# print(flag)

# list1 = '99.9'
# list2 = 20
# if float(list1) > float(list2):
#     print('111')
# else:
#     print(22)
# result_key = 99.9
# result_type = 1
# # 判断关键词是否合法
# if result_type == 1 and not isinstance(result_key, str):
#     print('111')
# else:
#     print('pass')
#     print(isinstance(result_key, str))
# if result_type == 0 and result_key.isdigit() is False:
#     print('222')
# else:
#     print('pass2')


# a = ''
# b = ['ss', 'dd']
# if a in b:
#     print('111')
# else:
#     print('222')

# Custom = public.import_via_loader('{}/modules/customModule/main.py'.format(public.get_panel_path())).main
# # 自定义监控任务
# custom_obj = Custom()
# # 脚本执行
# MonitorTaskQueue().run().add_task(MonitorTask(custom_obj, 'execute_script_task').delay(60).set_interval(periodic=1))
# new_data = {}
# new_data["result_type"] = 1
# new_data["result_match"] = 1
# new_data["result_key"] = 'aa'
#
# dicts = {}
# types = {0: '数值', 1: '字符串'}
# match = {1: '包含', 2: '不包含', 3: '大于', 4: '小于', 5: '等于'}
# dicts['匹配方式修改为'] = types[new_data["result_type"]] + match[new_data["result_match"]] + new_data["result_key"]
#
# print(dicts)
# a = '123 '
# # a = a.strip()
# b = a+'123'
# print(b)


# def is_number(s):
#     '''
#         @name 判断输入参数是否是一个数字
#         @author Zhj<2022-07-18>
#         @param  s<string|integer|float> 输入参数
#         @return bool
#     '''
#     try:
#         float(s)
#         return True
#     except ValueError:
#         pass
#
#     try:
#         import unicodedata
#         unicodedata.numeric(s)
#         return True
#     except (TypeError, ValueError):
#         pass
#
#     return False
#
#
# a = 123
# b = 'q123.1'
# print(is_number(a))
# print(is_number(b))
# key_list = ['a']
# x = 1
# res = 'a\n'
# # 判断结果是否包含
# for key in key_list:
#     if str(res).find(key) > -1:  # 包含
#         flag = True if x == 1 else False
#         break
#     else:  # 不包含
#         flag = True if x == 2 else False
#
#
#
# print(flag)

# import requests
# from bs4 import BeautifulSoup
# # url = "https://blog.csdn.net/qhsy2016/article/details/83014561"
#
# url = "https://www.baidu.com"
# response = requests.get(url)
# response.encoding = "utf-8"  # 指定网页的编码方式为UTF-8
# html = response.text
# soup = BeautifulSoup(html, "html.parser")
# # 获取网页的标题
# title = soup.title.string
# # 获取网页的图标
# icon_link = soup.find("link", rel="shortcut icon")
# if icon_link:
#     icon_url = icon_link["href"]
# else:
#     icon_link = soup.find("link", rel="icon")
#     if icon_link:
#         icon_url = icon_link["href"]
#     else:
#         icon_url = None
# print("网页标题：", title)
# print("网页图标URL：", icon_url)
p_server_detail = [
    {
      "sid": 75,
      "remark": "1111111",
      "ip": "127.0.0.1",
      "sort_key": 2
    },
    {
      "sid": 73,
      "remark": "aLLLLLLLT",
      "ip": "192.168.66.128",
      "sort_key": 4
    }
  ]

p_server_detail_new = {}
for item in p_server_detail:
    p_server_detail_new[item["sid"]] = item["sort_key"]
ret_list = [{'sampling': 3, 'sid': 75}, {'sampling': 2, 'sid': 73}]

# 列表内加入排序字段
for item in ret_list:
    item['sort_key'] = p_server_detail_new.get(item['sid'], 0)

print(ret_list)





