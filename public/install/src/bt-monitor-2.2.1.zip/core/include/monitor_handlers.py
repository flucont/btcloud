# encoding: utf-8
#
# 监听器模块
# Author Zhj<2023-03-23>

import json
import core.include.public as public
from core.include.monitor_helpers import monitor_db_manager, basic_monitor_obj


class BaseHandler:
    '''
        @name 监听器基类
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        raise RuntimeError('method handle() must be implements.')


class SubmitStatistics(BaseHandler):
    '''
        @name 提交统计数据
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        from core.include.monitor_helpers import basic_monitor_obj, monitor_task_queue, MonitorTask
        # 提交至任务队列执行
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj.submit_statistics, args=(True,)))


class UpdateServerPosition(BaseHandler):
    '''
        @name 更新首页监控大屏主机位置信息
        @author Zhj<2023-04-11>
    '''
    def handle(self, event):
        server_position = None
        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'r') as fp:
            try:
                server_position = json.loads(fp.read())
            except:
                server_position = {}

        server_position.pop(str(event.server_info['sid']), None)

        with open('{}/data/server_position.json'.format(public.get_panel_path()), 'w') as fp:
            fp.write(json.dumps(server_position))


class DeleteProcessMonitoring(BaseHandler):
    """
        @name 删除进程监控数据
        @author Zhj<2023-05-18>
    """
    def handle(self, event):
        sid = event.server_info['sid']
        with monitor_db_manager.db_mgr('custom_process') as db, monitor_db_manager.db_mgr() as db_mgr:
            # 关闭事务自动提交
            db.autocommit(False)
            try:
                # 进程监控
                ids = db.query() \
                    .name('custom_process') \
                    .where('sid', int(sid)) \
                    .column('id')

                # 删除进程监控
                db.query() \
                    .name('custom_process') \
                    .where('sid', int(sid)) \
                    .delete()

                if len(ids) == 0:
                    return

                # 删除中间表
                query = db.query().name('custom_process_rule_script').where_in('pro_id', ids)
                rule_ids = query.fork().column('rule_id')

                query.delete()

                # 删除结果表
                db.query() \
                    .name('custom_process_script_result') \
                    .where_in('pro_id', ids) \
                    .delete()

                if len(rule_ids) > 0:
                    db_mgr.query().name('warning_configurations')\
                        .where_in('id', rule_ids)\
                        .delete()

                db.commit()
                db_mgr.commit()
            except BaseException as e:
                db.rollback()
                db_mgr.rollback()

                public.print_exc_stack(e)


class DeleteServerBugs(BaseHandler):
    """
        @name 删除主机漏洞统计
        @author Zhj<2023-05-19>
    """
    def handle(self, event):
        basic_monitor_obj.db_easy('server_bug_total')\
            .where('sid', int(event.server_info['sid']))\
            .delete()


class DeleteServerMinings(BaseHandler):
    """
        @name 删除主机挖矿木马统计
        @author Zhj<2023-05-19>
    """
    def handle(self, event):
        basic_monitor_obj.db_easy('server_mining_total') \
            .where('sid', int(event.server_info['sid'])) \
            .delete()


class DeleteServerMaliciousRecords(BaseHandler):
    """
        @name 删除主机病毒扫描任务
        @author Zhj<2023-05-20>
    """
    def handle(self, event):
        sid = int(event.server_info['sid'])
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.autocommit(False)

            try:
                # 删除扫描任务
                db.query().name('server_malicious_scan_task')\
                    .where('sid', sid)\
                    .delete()

                # 删除扫描结果
                db.query().name('malicious_scan_results') \
                    .where('sid', sid) \
                    .delete()

                db.commit()
            except BaseException as e:
                db.rollback()
                public.print_exc_stack(e)
