;                (function() {
                    ace.require(["ace/snippets/scss"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            