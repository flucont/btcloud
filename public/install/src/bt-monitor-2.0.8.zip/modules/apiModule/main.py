
import json,time,re,os
import core.include.public as public
from flask import Response,request
from core.include.monitor_helpers import basic_monitor_obj
from core.include.monitor_exceptions import BtMonitorException
monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
# from core import client_data_queue

class main:
    __plugin_path = '{}/plugin/'.format(public.get_panel_path())

    def __int__(self):
        access_key = None
        secret_key = None
        server_id = None
        sid = None


    def check_update(self,args):
        '''
            @name 检查更新
            @author hwliang
            @return dict
        '''
        return public.success('没有更新')


    def aes_decrypt(self,pdata):
        '''
            @name 数据解密
            @author hwliang
            @param pdata<string> 待解密数据
            @return dict
        '''
        iv = self.access_key[:8] + self.access_key[-8:]
        import core.include.aes as aes
        aes_obj = aes.aescrypt_py3(self.secret_key,"CBC",iv.encode())

        try:
            decode_data =  aes_obj.aesdecrypt(pdata)
            result = json.loads(decode_data)
            return result
        except Exception as e:
            return None


    def aes_encrypt(self,pdata):
        '''
            @name 数据加密
            @author hwliang
            @param pdata<dict> 待加密的数据
            @return string
        '''
        iv = self.access_key[:8] + self.access_key[-8:]
        import core.include.aes as aes
        aes_obj = aes.aescrypt_py3(self.secret_key,"CBC",iv.encode())
        result = aes_obj.aesencrypt(json.dumps(pdata))
        return result


    def check_token(self,token):
        '''
            @name 检查token是否合法
            @author hwliang
            @param token<string> token
            @return bool
        '''
        # date = public.md5(public.format_date("%Y-%m-%d"))
        # hour = public.md5(public.format_date("%H"))
        # src_token = public.md5(date + self.access_key + hour)
        src_token = public.md5(self.access_key)
        return src_token == token


    def send_client(self,status,code,msg,error_msg = ''):
        '''
            @name 发送消息到客户端
            @author hwliang
        '''
        pdata = public.return_data(status,msg,code,error_msg)
        if public.read_config('config')['API']['encrypt']:
            result = self.aes_encrypt(pdata)
        else:
            result = json.dumps(pdata)
        return result


    def bind(self, args):
        '''
            @name 绑定
            @author hwliang
            @return dict
        '''
        client_ip = public.get_client_ip()
        sid = basic_monitor_obj.db_easy('servers')\
            .where('ip=?', client_ip)\
            .order('sid', 'desc')\
            .value('sid')
        result = {}
        if not sid:
            # 如果不存在
            server_info = {
                "server_id": public.GetRandomString(24),
                "access_key": public.GetRandomString(48),
                "secret_key": public.GetRandomString(16),
                "address": client_ip,
                "status": 0,
                "ps": "",
                "addtime" : int(time.time())
            }

            sid = public.M('server_list').insert(server_info)

            with monitor_db_manager.db_mgr() as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    insert_data = {
                        'sid': sid,
                        'ip': server_info['address'],
                    }

                    if 'type' in args:
                        insert_data['type'] = int(args.get('type', 0))

                    # 新增服务器
                    db.query()\
                        .name('servers')\
                        .insert(insert_data)

                    # 新增服务器详情
                    db.query()\
                        .name('server_details')\
                        .insert({
                            'sid': sid,
                        })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

        server_info = public.M('server_list').where("sid=?", sid).find()

        # 返回数据
        result['server_id'] = server_info['server_id']
        result['access_key'] = server_info['access_key']
        result['secret_key'] = server_info['secret_key']
        result['server_ip'] = request.headers.get('host').split(':')[0]
        result['server_port'] = public.get_panel_port()

        from os import readlink

        result['tz'] = readlink('/etc/localtime')

        return result

    def __check_access(self,args):
        '''
            @name 检查权限
            @author hwliang
            @return string or dict
        '''

        server_id = args.get('server_id/s','').strip()
        if len(server_id) != 24: return '-1',None
        if not re.match(r"^\w+$",server_id): return '-1',None

        token = args.get('token/s','').strip()
        # request_time = args.get('time/d',0)

        # if int(time.time()) - request_time > 86400: return '-1',None
        if len(token) != 32: return '-1',None

        # 优先从缓存中获取
        cache_key = 'BT_MONITOR_API__CHECK_ACCESS_SERVER_INFO__{}'.format(server_id)
        server_info = public.cache_get(cache_key)

        if not server_info:
            server_info = public.M('server_list').where("server_id=?", server_id).find()

            if not basic_monitor_obj.is_empty_result(server_info):
                # 从数据库获取后存入缓存
                public.cache_set(cache_key, server_info, 600)

        if not server_info: return '-1',None
        if server_info['status'] in [0,'0']: return '0',None

        self.access_key = server_info.get('access_key', '')
        self.secret_key = server_info.get('secret_key', '')
        self.server_id = server_id
        self.sid = server_info.get('sid', '')

        # 检查token是否合法
        if not self.check_token(token):
            return '-2',None

        # 解密数据
        data = args.get('pdata/s','').strip()
        if data:
            data = self.aes_decrypt(data)
            # print('{} ----decrypt data {}'.format(self.sid, data))

        return server_info,data


    def query(self,args):
        '''
            @name 查询
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info

        # self.bind(args)

        return self.send_client(True, 1, "connect")

        # 返回数据
        # return self.send_client(True,1,"padding")


    def get_update_info(self,args):
        '''
            @name 获取更新信息
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        agent_info_file = '{}/agent/info.json'.format(public.get_panel_path())
        agent_update_file = '{}/agent/update.zip'.format(public.get_panel_path())
        if not os.path.exists(agent_info_file) or not os.path.exists(agent_update_file):
            agent_info = {'version':'1.0.0','name':'agent','md5':''}
        else:
            agent_info = json.loads(public.readFile(agent_info_file))
            if not 'md5' in agent_info:
                agent_info['md5'] = public.FileMd5(agent_update_file)
                public.writeFile(agent_info_file,json.dumps(agent_info,indent=4))

        _plugin_list = []
        # for plugin in os.listdir('{}/plugin'.format(public.get_panel_path())):
        #     plugin_info_file = '{}/plugin/{}/info.json'.format(public.get_panel_path(),plugin)
        #     plugin_update_file = '{}/plugin/{}/update.zip'.format(public.get_panel_path(),plugin)
        #     if not os.path.exists(plugin_info_file): continue
        #     if not os.path.exists(plugin_update_file): continue
        #     plugin_info = json.loads(public.readFile(plugin_info_file))
        #     if not 'md5' in plugin_info:
        #         plugin_info['md5'] = public.FileMd5(plugin_update_file)
        #         public.writeFile(plugin_info_file,json.dumps(plugin_info,indent=4))
        #     _plugin_list.append(
        #         {
        #         'name':plugin,
        #         'version':plugin_info['version'],
        #         'md5':plugin_info['md5']
        #         }
        #     )


        result = {
            "version": agent_info['version'],
            "agent_md5": agent_info['md5'],
            "plugin_list": _plugin_list
        }

        return self.send_client(True,1,result)


    def download_plugin(self,args):
        '''
            @name 下载插件
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        if not data: return self.send_client(False,0,"","参数: plugin_name不能为空")
        if 'plugin_name' not in data: return self.send_client(False,0,"","参数: plugin_name不能为空")
        plugin_name = data['plugin_name']
        if not re.match(r"^\w+$",plugin_name): return self.send_client(False,0,"","参数: plugin_name不合法")
        update_zip_file = '{}/{}/update.zip'.format(self.__plugin_path,plugin_name)
        if not os.path.exists(update_zip_file): return self.send_client(False,0,"","插件不存在")

        # from flask import send_file
        return public.send_file(update_zip_file, '{}.zip'.format(plugin_name))


    def download_agent(self,args):
        '''
            @name 下载agent
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        update_zip_file = '{}/agent/update.zip'.format(public.get_panel_path())
        if not os.path.exists(update_zip_file): return self.send_client(False,0,"","agent不存在")
        # from flask import send_file
        return public.send_file(update_zip_file, 'agent.zip')


    def request_plugin(self,args):
        '''
            @name 请求插件
            @author hwliang
            @return dict
        '''
        public.print_log(args)
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info
        if not 'module' in data: return self.send_client(False,0,"","参数: module不能为空")
        if not 'action' in data: return self.send_client(False,0,"","参数: action不能为空")

        module = data['module']
        action = data['action']

        if not re.match(r"^\w+$",module) or not re.match(r"^\w+$",action):
            return self.send_client(False,0,"参数: module或action不合法")

        plugin_file = '{}/{}/main.py'.format(self.__plugin_path,module)
        if not os.path.exists(plugin_file): return self.send_client(False,0,"","插件不存在")
        pyobj = public.get_script_object(plugin_file)
        plugin_obj = pyobj.main()
        if not hasattr(plugin_obj,action): return self.send_client(False,0,"","指定方法不存在")
        result = getattr(plugin_obj,action)(public.to_dict_obj(data['args']))

        # 如果是响应对象
        if isinstance(result,Response):
            return result
        return self.send_client(True,1,result)

    def recv_body(self,args):
        '''
            @name 接收上报数据（通用）
            @author hwliang
            @param stype<string> 数据类型
            @param body<string> 数据内容
            @return {'status': True, 'status_code': 1, 'error_msg': '', 'data': 'OK'}
        '''
        # print('--ws connection object: {}'.format(args.get('_ws', None)))

        server_info,data = self.__check_access(args)

        if isinstance(server_info,str): return server_info

        if not 'stype' in data: return self.send_client(False,0,"","参数: stype不能为空")

        if not 'body' in data: return self.send_client(False,0,"","参数: body不能为空")

        pdata = {
            'stype': data['stype'],
            'body': json.dumps(data['body']),
            'sid': self.sid,
            'addtime': int(time.time())
        }

        # public.print_log('[接收到数据]------[{}] ---[{}]---- [{}]'.format(self.sid, data['stype'], args['remote_addr']))
        
        if not re.match(r"^\w+$",pdata['stype']): return self.send_client(False,0,"","参数: stype不合法")

        # 将数据转发到对应的处理函数进行处理
        try:
            # 云监控过期后不处理
            # if not basic_monitor_obj.check_monitor_endtime():
            #     raise BtMonitorException('云监控授权已到期，请续费后使用')

            remote_addr = args.get('remote_addr', '')
            if remote_addr[:7] == '::ffff:':
                remote_addr = remote_addr[7:]

            cache_key = 'BT_MONITOR_CLIENT_AUTHORIZATION_STATUS__{}'.format(self.sid)

            is_authorized = public.cache_get(cache_key)

            if is_authorized is None:
                # 未授权的客户端仅接收心跳包数据
                is_authorized = basic_monitor_obj.db_easy('servers')\
                    .where('sid=?', self.sid)\
                    .where_in('status', [0, 1])\
                    .where('is_authorized=1')\
                    .field('sid')\
                    .exists()

                # 缓存客户端的授权状态，减少Sqlite查询次数
                public.cache_set(cache_key, is_authorized, 60)

            if not is_authorized and data['stype'] != 'Heartbeat':
                raise BtMonitorException('客户端未授权: {}'.format(remote_addr))

            public.invoke_func('core.include.ws_recv_functions', 'recv_'+data['stype'], [{
                'remote_addr': remote_addr,
                'sid': self.sid,
                'data': data['body'],
            }])

            # pdata["remote_addr"] = remote_addr
            # if data['stype'] == "Heartbeat":
            #     basic_monitor_obj.update_servers2(self.sid, True, remote_addr)
            # else:
            #     client_data_queue.put(pdata)
            # redis_client.rpush("CLIENT_DATA", json.dumps(pdata))
            # public.print_log("puted data from: {}/type:{}".format(args.get("remote_addr"), data['stype']))
            # client_data_queue.put(pdata)
            # public.invoke_func('core.include.ws_recv_functions', 'recv_'+data['stype'], [{
            #     'remote_addr': args.get('remote_addr', ''),
            #     'sid': self.sid,
            #     'data': data['body'],
            # }])
        except BaseException as e:
            # 每隔10分钟打印一次提示信息
            cache_recv_body_key = 'BT_MONITOR_RECV_BODY_ERROR'
            if isinstance(e, BtMonitorException) and public.cache_get(cache_recv_body_key) is None:
                public.print_log(e)
                public.cache_set(cache_recv_body_key, 1, 600)
            public.print_exc_stack(e)

        '''
        if data['stype'] != 'Heartbeat':
            db_obj = public.M('collect').dbfile('data')
            db_obj.insert(pdata)
            db_obj.close()
        '''

        return self.send_client(True,1,"OK")


    def connected(self,args):
        '''
            @name 连接成功
            @author hwliang
            @return dict
        '''
        server_info,data = self.__check_access(args)
        if isinstance(server_info,str): return server_info


        return self.send_client(True,1,"OK1")