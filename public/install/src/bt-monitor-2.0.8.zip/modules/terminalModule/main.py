import paramiko
import threading
import json
import time
from io import StringIO
import sys
import socket
import os
import simple_websocket

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core import my_terms

# from serverModule.main import main as serverModule
# from core.include.flask_session import Session
serverModule = public.import_via_loader('{}/modules/serverModule/main.py'.format(public.get_panel_path())).main
monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
from core.include.monitor_helpers import basic_monitor_obj


class main:
    __log_type = '被控面板终端'
    _coll_user = None
    _host = None
    _web_socket = None
    _ssh_info = None
    _ssh_socket = None
    _uid = 1
    _filepath = '/www/server/bt-monitor/data/asciinemadir'
    time = time.time()

    def __init__(self):
        if not os.path.exists(self._filepath):
            os.system('mkdir -p ' + self._filepath)
            os.system('chmod -R 600 %s' % self._filepath)
        self.SSH_SESSION = None
        self.DURATIONS = 0

    def connect(self, ssh_info=None):
        if ssh_info: self._ssh_info = ssh_info
        if not self._host: self._host = self._ssh_info['host']
        # if self._ssh_info['host'] in my_terms:
        #     if time.time() - my_terms[self._host].last_time < 86400:
        #         return True
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
            sock.connect((self._ssh_info['host'], int(self._ssh_info['port'])))
        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("服务器连接失败!")
            return False

        # 使用Transport连接
        p1 = paramiko.Transport(sock)
        p1.start_client()
        if 'pkey' not in self._ssh_info:
            self._ssh_info['pkey'] = None
        else:
            self._ssh_info['c_type'] = True
        try:
            # 如果有pkey时则使用RSA私钥登录
            if self._ssh_info['pkey'] and self._ssh_info['c_type']:
                # 将RSA私钥转换为io对象，然后生成rsa_key对象
                p_file = StringIO(self._ssh_info['pkey'])
                pkey = paramiko.RSAKey.from_private_key(p_file)
                p1.auth_publickey(username=self._ssh_info['username'], key=pkey)
            else:
                p1.auth_password(username=self._ssh_info['username'], password=self._ssh_info['password'])
        except Exception as e:
            public.print_exc_stack(e)
            self._web_socket.send("用户验证失败!")
            p1.close()
            return False

        self.SSH_SESSION = p1.open_session()
        self.connect_time = int(time.time())
        self.SSH_SESSION.get_pty(term='xterm', width=100, height=29)
        self.SSH_SESSION.invoke_shell()
        self.filename = self._ssh_info['host'] + '_' + \
            time.strftime('%Y_%m_%d_%H%M%S', time.localtime(self.connect_time))

        # my_terms[self._host] = public.dict_obj()
        # my_terms[self._host].last_time = time.time()
        # my_terms[self._host].connect_time = time.time()
        # 打开会话
        # my_terms[self._host].tty = p1.open_session()
        # 获取终端对象
        # my_terms[self._host].tty.get_pty(term='xterm', width=100, height=29)
        # my_terms[self._host].tty.invoke_shell()
        # 回放日志文件名
        # my_terms[self._host].filename = self._ssh_info['host'] + '_' + \
        #                                 time.strftime('%Y_%m_%d_%H%M%S',
        #                                               time.localtime(my_terms[self._host].connect_time))

        # 记录登陆记录
        public.M('ssh_records').add('coll_user,ssh_user,host,cmd,addtime', (
            self._coll_user, self._ssh_info['username'], self._ssh_info['host'], 'login', int(time.time())))

        with open(self._filepath + '/{}.cast'.format(self.filename), 'w') as fp:
            fp.write('{}\n'.format(json.dumps({
                "version": 2,
                "width": 120,
                "height": 40,
                "timestamp": int(time.time()),
                "env": {
                    "SHELL": "/bin/bash",
                    "TERM": "xterm"
                }
            })))
        # self.record('header', {
        #     "version": 1,
        #     "width": 120,
        #     "height": 40,
        #     "timestamp": int(my_terms[self._host].connect_time),
        #     "env": {
        #         "TERM": "xterm",
        #         "SHELL": "/bin/bash",
        #     },
        #     "stdout": []
        # })
        # self.time=my_terms[self._host].connect_time
        return True

    def resize(self, data):
        try:
            data = json.loads(data)
            if "width" in data:
                self.SSH_SESSION.resize_pty(width=data['width'], height=data['height'],
                                                    width_pixels=data['width_px'], height_pixels=data['height_px'])
            else:
                self.SSH_SESSION.resize_pty(width=data['cols'], height=data['rows'])
            return True
        except BaseException as e:
            public.print_exc_stack(e)
            print(public.get_error_info())
            return False

    def send(self):
        try:
            while self._web_socket.connected:
                c_data = self._web_socket.receive()
                if not c_data: continue
                if len(c_data) > 10:
                    if c_data.find('{"id":"') != -1:
                        continue
                    if c_data.find('{"host":"') != -1:
                        continue
                    if c_data.find('"resize":1') != -1:
                        self.resize(c_data)
                        continue
                    if c_data.find('resize_pty') != -1:
                        if self.resize(c_data): continue
                    elif c_data.find('"password"') != -1 and c_data.find('"host"') != -1:
                        continue
                # if self._host in my_terms:
                #     my_terms[self._host].last_time = time.time()
                # else:
                #     return
                self.SSH_SESSION.send(c_data)
        except simple_websocket.ws.ConnectionClosed: pass
        except BaseException as e:
            public.print_exc_stack(e)
            # print(public.get_error_info())
        finally:
            try:
                self.SSH_SESSION.close()
            except: pass

    def recv(self):
        try:
            # n = 0
            while self._web_socket.connected:
                # self.not_send()
                # if n == 0: self.last_send()
                data = self.SSH_SESSION.recv(1024)
                # self.not_send()
                if not data:
                    self.close()
                    self._web_socket.send('连接已断开,按回车将尝试重新连接!')
                    # self._web_socket.send('连接已断开,请重新打开SSH终端!')
                    return

                try:
                    result = data.decode('utf-8', 'ignore')
                except:
                    try:
                        result = data.decode()
                    except:
                        result = str(data)
                if not result: continue
                if not self._web_socket.connected:
                    # my_terms[self._host].not_send = result
                    return

                # self.set_last_send(result)
                # self.record('iodata', result)

                # if not n: n = 1
                # TODO 写入回放日志
                with open(self._filepath + '/{}.cast'.format(self.filename), 'a') as fp:
                    self.DURATIONS = round(time.time() - self.connect_time, 6)
                    fp.write('{}\n'.format(json.dumps([self.DURATIONS, 'o', str(result)])))
                self._web_socket.send(result)

        except simple_websocket.ws.ConnectionClosed: pass
        except BaseException as e:
            public.print_exc_stack(e)

        finally:
            try:
                self.SSH_SESSION.close()
            except: pass

    # def record(self, rtype, data):
    #
    #     if rtype == 'header':
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'w') as fw:
    #             fw.write(json.dumps(data) + '\n')
    #             return True
    #     else:
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'r') as fr:
    #             content = json.loads(fr.read())
    #             stdout = content["stdout"]
    #         atime = time.time()
    #         iodata = [atime - self.time, data]
    #         stdout.append(iodata)
    #         content["stdout"] = stdout
    #         with open(self._filepath + '/{}.json'.format(my_terms[self._host].filename), 'w') as fw:
    #             fw.write(json.dumps(content) + '\n')
    #             self.time = atime
    #             return True
    #     return True

    def set_last_send(self, result):
        last_size = 1024
        if 'last_send' not in my_terms[self._host]:
            my_terms[self._host].last_send = []

        my_terms[self._host].last_send.append(result)
        last_len = len(my_terms[self._host].last_send)
        if last_len > last_size:
            my_terms[self._host].last_send = my_terms[self._host].last_send[last_len - last_size:]

    def not_send(self):
        if 'not_send' in my_terms[self._host]:
            if my_terms[self._host].not_send:
                self._web_socket.send(my_terms[self._host].not_send)
                my_terms[self._host].not_send = ""

    def last_send(self):
        if 'last_send' in my_terms[self._host]:
            for d in my_terms[self._host].last_send:
                self._web_socket.send(d)

    def close(self):
        try:
            self.SSH_SESSION.close()
        except:
            pass
        if self._host in my_terms:
            del my_terms[self._host]

    def run(self, args):
        sid = args.sid
        self._web_socket = args.ws
        sm = serverModule()
        args = public.dict_obj()
        args.sid = sid
        res = sm.get_ssh_info(args)

        if not res or not res["status"]:
            return

        self._ssh_info = res["data"]

        if not self._ssh_info:
            return

        result = self.connect()
        time.sleep(0.1)
        if result:
            sendt = threading.Thread(target=self.send)
            recvt = threading.Thread(target=self.recv)
            sendt.start()
            recvt.start()
            sendt.join()
            recvt.join()
            # if time.time() - my_terms[self._host].last_time > 86400:
            #     self.close()
            # self._web_socket = None

        try:
            self._web_socket.close()

        except: pass

        # close_time = time.time()
        login_mode = 'pkey'
        # if self._ssh_info.get('pkey') is None:
        #     login_mode = 'password'
        if self._ssh_info['pkey'] == '':
            login_mode = 'password'

        play_info = {
            "host": self._ssh_info['host'],
            "playback": self.filename,
            "username": self._ssh_info['username'],
            'uid' : public.bt_auth('uid'),
            "port": self._ssh_info['port'],
            "login_mode": login_mode,
            "count_time": int(self.DURATIONS),
            "create_time": int(self.connect_time),
        }

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('playrecords') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("playrecords") \
                        .insert(play_info)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)

                    raise e

        return public.success('添加信息成功')

    def player(self, args):
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('playrecords') as db:
            query = db.query()\
                .name('playrecords') \
                .field('id', 'host', 'playback', 'username','uid','port', 'login_mode', 'count_time', 'create_time') \
                .order('create_time', 'desc')

            if query_date is not None and len(query_date) > 0 :
                query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

            ret = public.simple_page(query, args)

        with monitor_db_manager.db_mgr('safety') as db:
            uid_username_map = db.query()\
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['uid'], ret['list']))))\
                .field('uid', 'username')\
                .column('username', 'uid')

        for item in ret['list']:
            item['systemname'] = uid_username_map.get(item['uid'], '')

        # # 统计及获取使用终端回放功能次数统计
        # basic_monitor_obj.set_module_logs('terminal', 'player')
        return public.success(ret)