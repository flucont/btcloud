
class sms:
	pass