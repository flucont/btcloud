# encoding: utf-8
import re, time, json
import core.include.public as public
from core.include.monitor_helpers import monitor_db_manager, basic_monitor_obj
from concurrent.futures import ThreadPoolExecutor


class main:
    '''
        @name 安全监控
        @author Zhj<2023-03-21>
    '''
    def get_bug_list(self, args):
        '''
            @name 获取漏洞扫描列表
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        bug_type = args.get('bug_type', None)
        level = args.get('level', None)
        status = args.get('status', None)
        usable = args.get('usable', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            query = db.query().name('server_bugs')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if level is not None:
                query.where('level', int(level))

            if bug_type is not None:
                query.where('type', bug_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`vuln_name` like ?',
                    '`soft_name` like ?',
                    '`file_path` like ?',
                    '`tag` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None
        handled_operators = None

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query()\
                .name('users')\
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list']))))\
                .field('uid', 'username')\
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['tag'] = json.loads(item['tag'])
            except:
                item['tag'] = []

        return public.success(ret)

    def ignore_bug(self, args):
        '''
            @name 忽略漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            db.query()\
                .name('server_bugs')\
                .where_in('vuln_id', vuln_id)\
                .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def handle_bug(self, args):
        '''
            @name 处理漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            db.query()\
                .name('server_bugs')\
                .where_in('vuln_id', vuln_id)\
                .update({
                    'status': 2 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'fix_remark': remark,
                    'handled_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def re_scan_bug(self, args):
        '''
            @name 重新扫描漏洞
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        server_id = public.get_serverid_bysid(sid)

        ret = []

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for v in vuln_id:
                params = {
                    'vuln_id': v,
                }
                f = t.submit(self.__re_scan_bug_helper, server_id, params)
                fs.append(f)

            for f in fs:
                if ret is None:
                    continue
                ret.append(f.result())

        if len(ret) == 0:
            return public.error('扫描失败，请重试~')

        new_ret = []
        for item in ret:
            if isinstance(item, str):
                try:
                    item = json.loads(item)
                except: continue

            if 'body' not in item or not isinstance(item['body'], list) or len(item['body']) < 1:
                continue

            new_ret.extend(item['body'])

        if len(new_ret) > 0:
            # 更新主机漏洞列表
            basic_monitor_obj.update_server_bugs(sid, new_ret)

        return public.success('扫描成功')

    def re_scan_bug_all(self, args):
        '''
            @name 重新扫描漏洞(全部)
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'vul_scan',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机漏洞列表
        basic_monitor_obj.update_server_bugs(sid, data.get('body', []))

        return public.success('扫描成功')

    # 重新扫描漏洞(子线程处理函数)
    def __re_scan_bug_helper(self, server_id, params):
        res = public.send_agent_msg(
            server_id,
            'vul_scan',
            'ScanOne',
            timeout=60,
            pdata=public.g_pdata(params))

        data = public.get_agent_msg(res)

        if not data:
            return None

        return data

    # 挖矿木马扫描

    def get_mining_list(self, args):
        '''
            @name 获取主机挖矿木马列表
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        mining_type = args.get('mining_type', None)
        status = args.get('status', None)
        usable = args.get('usable', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            query = db.query().name('server_minings')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if mining_type is not None:
                query.where('type', mining_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`title` like ?',
                    '`ps` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None
        handled_operators = None

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['process_info'] = json.loads(item['process_info'])
            except:
                item['process_info'] = None

        return public.success(ret)

    def ignore_mining(self, args):
        '''
            @name 忽略主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def handle_mining(self, args):
        '''
            @name 处理主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                    'status': 2 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'fix_remark': remark,
                    'handled_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def re_scan_mining_all(self, args):
        '''
            @name 重新扫描主机挖矿木马
            @author Zhj<2023-03-28>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'detect_mining',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机挖矿木马列表
        basic_monitor_obj.update_server_minings(sid, data.get('body', []))

        return public.success('扫描成功')
