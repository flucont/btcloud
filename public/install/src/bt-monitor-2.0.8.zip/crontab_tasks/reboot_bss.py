#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, time

os.chdir('/www/server/bt-monitor')

if __name__ == '__main__':
    print('[{}]'.format(time.strftime('%Y-%m-%d %X')))
    os.system('./init.sh stop')
    time.sleep(30)
    os.system('./sqlite-server.sh restart')
    os.system('./init.sh start')
    print('')