# encoding: utf-8
#
# 监听器模块
# Author Zhj<2023-03-23>

import core.include.public as public


class BaseHandler:
    '''
        @name 监听器基类
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        raise RuntimeError('method handle() must be implements.')


class SubmitStatistics(BaseHandler):
    '''
        @name 提交统计数据
        @author Zhj<2023-03-23>
    '''
    def handle(self, event):
        from core.include.monitor_helpers import basic_monitor_obj, monitor_task_queue, MonitorTask
        # 提交至任务队列执行
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj.submit_statistics))
