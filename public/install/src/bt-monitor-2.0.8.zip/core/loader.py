#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------

#--------------------------------
# 加载器
#--------------------------------
import os, queue, time
import json
import threading
from flask import g,Response
import core.include.public as public
import core.include.rbac as rbac
from core import get_input,not_login_modules,not_login_uri,mod_action_match,check_login,check_csrf,session,cache
# import core.include.c_loader.PluginLoader as plugin_loader


monitor_task = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path()))

count_data = [
    # comproxy  代理
    # 'cmproxy/webssh','comproxy/proxy',

    # 漏洞扫描
    'safetymonitor/get_bug_list', 'safetymonitor/ignore_bug', 'safetymonitor/handle_bug', 'safetymonitor/re_scan_bug',
    'safetymonitor/re_scan_bug_all',

    # 挖矿木马扫描
    'safetymonitor/get_mining_list','safetymonitor/ignore_mining','safetymonitor/handle_mining','safetymonitor/re_scan_mining_all',

    #  availability 监控port ping http(s)
    'availability/add_port_task','availability/update_port_task','availability/remove_port_task','availability/get_port_result',
    'availability/add_ping_task','availability/update_ping_task','availability/remove_ping_task','availability/get_ping_result',
    'availability/add_http_task','availability/update_http_task','availability/remove_http_task','availability/get_http_result',

    # config  系统配置
    'config/modify_two_step_auth',

    # msg 通知
    'msg/get_msg_config','msg/set_msg_config','msg/send_test_msg',

    # rbac 用户权限
    'rbac/get_user_list','rbac/create_user','rbac/set_user_status','rbac/modify_user',
    'rbac/remove_user','rbac/get_role_list',
    'rbac/create_role','rbac/set_role_status','rbac/set_role_access',
    'rbac/set_role_server_access','rbac/modify_role','rbac/remove_role',

    # server  服务器列表
    'server/add_server','server/remove_server','server/add_panel_info','server/get_panel_info',
    'server/add_ssh_info','server/get_ssh_info','server/modify_ssh_info','server/delete_ssh_info',
    'server/add_server_group','server/remove_server_group','server/edit_server_group',
    # Nginx进程详情
    'server/get_nginx_stats_info',
    # 主机概览
    'dashboard/get_raid_info','dashboard/repair_agent','dashboard/get_agent_info',
    # 基础监控
    'server/cpu_info_statistics',
    # 进程监控
    'dashboard/get_processes_list','server/set_sampling_global',
    # 端口监控
    'dashboard/get_host_port_info',
    # 日志监控
    'dashboard/get_logs_path_list','dashboard/get_log_content',
    # 防火墙监控
    'dashboard/get_host_firewall_info',
    # 系统监控
    'dashboard/get_installed_soft_info',
    # 危险命令执行 详情页
    'dashboard/sensitive_listpage',
    # terminal
    'terminal/player',
    # wanrning 模块
    'warning/get_server_list','warning/clear_tasks','warning/handled_task','warning/update_rules_by_templates',
    'warning/get_rules','warning/add_rule','warning/modify_rule','warning/remove_rules','warning/save_rules_to_template',
    'warning/modify_template','warning/apply_template_package','warning/remove_apply_template_packages',
    'warning/add_template','warning/export_templates','warning/import_templates','warning/remove_template_packages',
]


rbac_obj = rbac.Rbac()
class loader:
    '''
        @name 加载模块
        @author hwliang
    '''
    __module = None
    __action = None
    __module_path = "{}/modules".format(public.get_panel_path())
    __action_object = None
    __module_object = None
    __plugin_path = "{}/plugin".format(public.get_panel_path())

    def __init__(self,module,action):
        '''
            @name 初始化模块加载
            @author hwliang
            @param module 模块名称
            @param action 方法名称
        '''
        self.__module = module
        self.__action = action

    def run(self, args):
        '''
            @name 加载并执行
            @author hwliang
            @param args 外部参数
            @return mixed
        '''
        return getattr(public.import_via_loader('{}/modules/{}Module/main.py'.format(public.get_panel_path(), self.__module)).main(), self.__action)(args)
        # return plugin_loader.module_run(self.__module,self.__action, args)


def http_run(module, action, args = None):
    '''
        @name http请求处理
        @author hwliang
        @param module: 模块名
        @param action: 方法名
        @param args<?dict_obj> 参数
        @return mixed
    '''
    args = args or get_input()
    if not rbac_obj.AccessDecision(args): # rbac
        return public.response(False,'无权限!请向管理员申请权限!')

    if not rbac_obj.AccessTwoStepAuth(args): # 二次动态认证
        return public.response(False,'无权限!请先认证动态口令!')

    from core.include.monitor_helpers import basic_monitor_obj
    if '{}/{}'.format(g.module, g.action) in count_data:
        basic_monitor_obj.set_module_logs(f'{g.module}',f'{g.action}')


    loader_obj = loader(module,action)
    result = loader_obj.run(args)
    if isinstance(result,Response):
        return result
    if isinstance(result,str):
        return Response(result)
    return Response(json.dumps(result,ensure_ascii=False),mimetype='application/json')

# ws消息体队列
ws_body_queue = monitor_task.MonitorTaskQueue().blocking().run(16)

# 心跳包消息队列
heartbeat_queue = monitor_task.MonitorTaskQueue().blocking().run()

# ws消息发送队列
ws_send_queue = monitor_task.MonitorTaskQueue().blocking().run()

def ws_run(ws):
    '''
        @name websocket请求处理
        @author hwliang
        @param ws: websocket对象
        @return void
    '''
    # ws监听
    while ws.connected:
        ws_body = ws.receive()
        if not ws_body: continue

        # try:
        #     ws_dict = json.loads(ws_body)
        # except Exception as e:
        #     public.print_log("receive exception: {}".format(e))
        #     del (ws_body,)
        #     continue

        # # 心跳包单独队列处理
        # if 'stype' in ws_dict and ws_dict['stype'] == 'Heartbeat':
        #     heartbeat_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))
        #     # heartbeat_queue.put(ws_body)
        #     del (ws_body, ws_dict)
        #     continue

        # public.print_log('recv ws: {}'.format(ws_dict['stype']))

        # 将ws消息体放入队列中
        # ws_body_queue.put(ws_body)
        # ws_body_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))

        ws_thread(ws_body, ws)

        del (ws_body,)

    ws.close()


def ws_send(ws,status,msg):
    '''
        @name 发送消息
        @author hwliang
        @param ws: websocket对象
        @param status: 状态码
        @param msg: 消息体
        @return void
    '''
    ws_send_help(ws, json.dumps(public.return_data(status, msg), ensure_ascii=False))
    # ws.send(json.dumps(public.return_data(status,msg),ensure_ascii=False))

# ws消息发送帮助函数
def ws_send_help(ws, msg):
    if not ws.connected:
        public.print_log('----ws{} is closed {}'.format(ws, msg))
        return False
    # 使用队列发送消息
    ws_send_queue.add_task(monitor_task.MonitorTask(ws, 'send', args=(msg,)))
    return True


def ws_thread(ws_body, ws):
    '''
        @name websocket消息处理线程
        @author hwliang
        @param ws_body: websocket消息
        @return void
    '''
    # 将接收到的消息体写入日志
    # public.print_log('recv ws_body: '+ws_body)
    if not ws_body: return
    try:
        # 解析数据
        ws_dict = json.loads(ws_body)

        args = public.to_dict_obj(ws_dict)

        # 获取模块、方法、回调
        module = args.get('module',None)
        action = args.get('action',None)
        callback = args.get('callback',None)
        server_id = args.get('server_id',None)

        # 如果是响应数据，则从callback中获取调用的模块、方法
        if callback and server_id and callback.find('recv/') == 0:
            result = public.agent_decrypt(server_id,args.pdata)
            if 'args' in result:
                result = result['args']
            if 'data' in result:
                result = result['data']

            try:
                if isinstance(result,str):
                    cache.set(callback,json.loads(result))
                else:
                    cache.set(callback,result)
            except:
                cache.set(callback,result)
            return


        # 模块名和方法名是否为空？
        if not module or not action: return

        # 检查URI格式
        if not mod_action_match.match(module) or not mod_action_match.match(action):
            return

        # 检查登录
        uri = "{}/{}".format(module,action)
        if not module in not_login_modules and not uri in not_login_uri:
            if not check_login(): return ws_send(ws,False,'请先登录')
            if not check_csrf(): return ws_send(ws,False,'CSRF验证失败')

        # print('--recv message from ws action[{}] server_id[{}] server_ip[{}]'.format(action, server_id, ws.environ['REMOTE_ADDR']))

        # 缓存ws会话
        if server_id and action == 'connected':
            public.set_server_ws(ws, server_id)
            # from core import servers_ws
            # public.print_log("{}".format(servers_ws))

        # 加载模块
        loader_obj = loader(module, action)

        # 执行模块方法
        args._ws = ws
        args.remote_addr = ws.environ['REMOTE_ADDR']

        # 心跳包单独队列处理
        if 'stype' in ws_dict and ws_dict['stype'] == 'Heartbeat':
            heartbeat_queue.add_task(monitor_task.MonitorTask(ws_thread_help, args=(loader_obj, args)))
            return

        # ws通用队列处理
        ws_body_queue.add_task(monitor_task.MonitorTask(ws_thread_help, args=(loader_obj, args)))

    except BaseException as e:
        try:
            public.print_exc_stack(e)

            del (e,)

            if ws.connected:
                ws_send_help(ws, public.get_error_info())
                # ws.send(public.get_error_info())
        except BaseException as e:
            del (e,)

# websocket消息处理函数
def ws_thread_help(loader_obj, args):
    result = loader_obj.run(args)

    # 如果返回侧为空？
    if not result:
        return

    if not args._ws.connected:
        return

    # 如果响应值不是dict
    if isinstance(result, dict):
        result['callback'] = args.get('callback', None)
        ws_send_help(args._ws, json.dumps(result, ensure_ascii=False))
    elif isinstance(result, str):
        ws_send_help(args._ws, result)
    else:
        ws_send_help(args._ws, json.dumps(result, ensure_ascii=False))
