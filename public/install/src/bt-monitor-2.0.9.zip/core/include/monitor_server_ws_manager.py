#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-
#
# 客户端websocket连接管理模块
# Author Zhj<2022-11-30>

import threading
from contextlib import contextmanager
from core.include.Locker import acquire

# 存储所有已连接的websocket连接对象
_conns = threading.local()

def set_conn(ws, server_id):
    pass

def send(ws, data):
    pass
