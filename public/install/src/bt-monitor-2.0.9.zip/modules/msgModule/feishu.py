#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2020 宝塔软件(http://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: lx
# | 消息通道飞书通知模块
# +-------------------------------------------------------------------

import sys, os, json, requests
# from turtle import title
panelPath = '/www/server/bt-monitor'
import core.include.public as public
from requests.packages import urllib3
# 关闭警告

urllib3.disable_warnings()
import socket
import requests.packages.urllib3.util.connection as urllib3_cn
import core.include.c_loader.PluginLoader as plugin_loader


main = plugin_loader.get_module('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main


class feishu(main):
    __info = None
    __msg_type = 'feishu'

    def __init__(self):
        self.__info = self.get_config(None)

    def get_config(self,get):
        """
        获取飞书配置
        """
        return self._get_base_config(self.__msg_type)

    def set_config(self,get):
        """
        设置飞书配置
        @url 飞书URL
        @atall 默认@全体成员
        @user
        """
        if not hasattr(get, 'url'):
            return public.returnMsg(False, '请填写完整信息')

        isAtAll = True
        if hasattr(get, "atall"):
            if get.atall.lower() == "false":
                isAtAll = False

        title = '默认'
        if hasattr(get, 'title'):
            title = get.title
            if len(title) > 7:
                return public.returnMsg(False, '备注名称不能超过7个字符')

        self.__info  = {
            "feishu_url": get.url.strip(),
            "isAtAll": isAtAll,
            "user": 1,
            "title": title,
        }

        return self._set_base_config(self.__msg_type, self.__info)

    def is_configured(self):
        '''
            @name 检查飞书是否配置
            @author Zhj<2022-08-02>
            @return bool
        '''
        if self.__info is None \
                or not isinstance(self.__info, dict) \
                or 'feishu_url' not in self.__info \
                or self.__info['feishu_url'] is None\
                or self.__info['feishu_url'] == '':
            return False

        return True

    def get_send_msg(self,msg):
        """
        @name 处理md格式
        """
        try:
            import re
            title = '云监控告警通知'
            if msg.find("####") >= 0:
                try:
                    title = re.search(r"####(.+)", msg).groups()[0]
                except:pass

                msg = msg.replace("####",">").replace("\n\n","\n").strip()
                s_list = msg.split('\n')

                if len(s_list) > 3:
                    s_title = s_list[0].replace(" ","")
                    s_list = s_list[3:]
                    s_list.insert(0,s_title)
                    msg = '\n'.join(s_list)

            reg = '<font.+>(.+)</font>'
            tmp = re.search(reg,msg)
            if tmp:
                tmp = tmp.groups()[0]
                msg = re.sub(reg,tmp,msg)
        except:pass
        return msg,title

    def send_msg(self, minfo):
        """
        飞书发送信息
        """
        if not self.__info :
            return public.returnMsg(False,'未正确配置飞书信息。')

        msg, title = self.get_send_msg(minfo['msg'])

        if self.__info["isAtAll"]:
            msg += "<at userid='all'>所有人</at>"

        data = {
            "msg_type": "text",
            "content": {
                "text": msg
            }
        }
        headers = {'Content-Type': 'application/json'}
        # res = {}

        conf = self.get_config(None)

        try:

            allowed_gai_family_lib=urllib3_cn.allowed_gai_family
            def allowed_gai_family():
                family = socket.AF_INET
                return family
            urllib3_cn.allowed_gai_family = allowed_gai_family
            rdata = requests.post(url = conf['feishu_url'], data = json.dumps(data),verify=False, headers=headers,timeout=10).json()
            urllib3_cn.allowed_gai_family=allowed_gai_family_lib

            # if "StatusCode" in rdata and rdata["StatusCode"] == 0:
            #     pass
        except:
            public.print_log(public.get_error_info(), need_write_log=False)

        ret = self._return_data(self.__msg_type, True, '发送完成')

        return ret