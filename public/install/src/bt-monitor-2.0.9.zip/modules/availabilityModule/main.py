# encoding: utf-8
import json, os, sys, re, time, random
import socket

from core import g
import requests
from concurrent.futures import ThreadPoolExecutor

# 禁用requests安全请求警告
# from requests.packages import urllib3
# urllib3.disable_warnings()

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from core.include.rbac import AccessIntersection
from core.include.monitor_helpers import basic_monitor_obj, warning_obj

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
MsgModule = public.import_via_loader('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main


class main():
    '''
        @name 可用性监控
        @author Law Lt <2023-02-24>
    '''

    def get_task_wanrning_log(self, args):
        """
            @name   获取任务告警信息
            @author lt <2023-03-29>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @arg    id<integer> 任务id
            @arg    type<string> 任务类型 'http' 'port' 'ping'
            @return dict
        """
        keyword = args.get('keyword', None)
        id_ = args.get('id')
        type_ = args.get('type')
        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)
        # 数据库查询
        query = basic_monitor_obj.db_easy('availability_wanrning_log') \
            .where('task_id=?', id_) \
            .where('type=?', type_) \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        if keyword is not None:
            query.where('create_time like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        # 分页查询
        ret = public.simple_page(query, args)

        return public.success(ret)

    def get_server_list(self, args):
        '''
            @name   获取服务器列表 只有 sid,ip,remark
            @return list
        '''

        server_list = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').select()
        # 获取当前服务器内外网IP
        internal_ips, published_ip = basic_monitor_obj.get_server_ip()
        s_list = [i for i in server_list if not i["ip"] == '127.0.0.1']
        s_list.append({
            # "ip": internal_ips,
            "ip": published_ip,
            "remark": '主控节点',
            "sid": 0
        })
        return public.success(s_list)

    def get_port_task(self, args):
        '''
            @name 获取port监控任务列表
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        keyword = args.get('keyword', None)
        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            query = basic_monitor_obj.db_easy('availability_port') \
                .order('create_time', 'desc')
        else:
            # 数据库查询
            query = basic_monitor_obj.db_easy('availability_port') \
                .where('uid=?', uid) \
                .order('create_time', 'desc')

        if keyword is not None:
            query.where('port like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        # 分页查询
        ret = public.simple_page(query, args)
        # 上线 离线 数量  上线 id 查 详情表 最近一次连接状态
        on_line = 0
        off_line = 0
        data = ret['list']
        for i in data:
            # 执行任务详情
            port_ = basic_monitor_obj.db_easy('availability_port_info') \
                .where('`port_id` = ?', [i['id']]) \
                .order('create_time', 'desc')

            # 最近一次
            port_info = port_.fork().find()
            # 最近十次
            port_result = port_.fork().limit(10).select()

            if port_info is not None:
                i['is_ok'] = port_info['is_connect']
                # 离线时长 延迟后边加
                # i['last_offline_time'] = 0
                # i['delay'] = 0
                i['port_result'] = port_result

                if port_info['is_connect'] == 0:
                    off_line += 1
                else:
                    on_line += 1
            else:
                i['is_ok'] = 2
                i['port_result'] = []
        # 上线时长 下线时长
        ret['on_line'] = on_line
        ret['off_line'] = off_line
        return public.success(ret)

    def get_port_result(self, args):
        """
            @name 获取port监控任务结果
            @author Law Lt <2023-03-01>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        """
        # keyword = args.get('keyword', None)
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            task = basic_monitor_obj.db_easy('availability_port') \
                .where('id=?', id_) \
                .find()
        else:
            # 数据库查询任务详情
            task = basic_monitor_obj.db_easy('availability_port') \
                .where('uid=? AND id=?', [uid, id_]) \
                .find()

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        port_info = basic_monitor_obj.db_easy('availability_port_info') \
            .where('`port_id` = ?', id_) \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # 检查区间内是否有执行结果
        if not port_info.fork().exists():
            ret = public.simple_page(port_info, args)
            ret['task'] = task
            ret['available_rate'] = 0
            ret['avg_delay'] = 0
            ret['last_offline_time'] = 0
            return public.success(ret)

        # 获取端口连接成功率 除法需要转浮点数才能计算
        rate = port_info.fork().value(
            'ROUND(1.0 * SUM(CASE `is_connect` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')

        # 上次离线时间
        cur_time = int(time.time())
        if port_info.fork().where('is_connect=1').exists():
            # 最新的失败状态
            last_off = port_info.fork().where('is_connect=0').find()

            # 存在失败状态 计算时间
            if last_off:

                # 失败是最新一条    当前时间-最新的成功时间
                if last_off['id'] == port_info.fork().value('id'):
                    last_offline_time = cur_time - port_info.fork().where('is_connect=1').value('create_time')
                # 不是最新的
                else:
                    end_time = port_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
                    last_on_line = port_info.fork().where('id<? ', last_off['id']).where('is_connect=1').find()
                    # 失败前没有在线状态
                    if last_on_line is None:
                        start_time = port_info.fork().value('min(create_time)')
                    else:
                        start_time = port_info.fork().where('id > ?', last_on_line['id']).where('is_connect', 0).value('min(create_time)')

                    last_offline_time = end_time - start_time

            else:
                last_offline_time = 0
        else:
            last_offline_time = None

        # 分页查询
        ret = public.simple_page(port_info, args)

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '本地'
                i['node_ip'] = '127.0.0.1'
            else:
                server = warning_obj.db_easy('servers').field('ip', 'remark').where('sid=?', i['node']).find()
                i['node_remark'] = server['remark']
                i['node_ip'] = server['ip']

        ret['available_rate'] = float(rate)
        ret['task'] = task
        # 上次离线时间
        ret['last_offline_time'] = last_offline_time
        # 平均延迟
        ret['avg_delay'] = "%.2f" % (port_info.fork().avg('delay'))
        return public.success(ret)

    # 执行port
    def __port_task_help(self, temp):
        """
            @name 执行port
            @author  <2023-03-22>
            @arg    temp 判断告警的条件
            @return dict
        """
        cur_time = int(time.time())
         # 跳过没到时间的
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        last_ececute_time = public.cache_get(f"port_ececute_time:{temp['id']}")
        if last_ececute_time:
            if cur_time <= int(last_ececute_time) + temp['frequency']:
                return None

        # 在信息表查时间   当前时间<=创建时间+频率
        else:
            port_info = basic_monitor_obj.db_easy('availability_port_info').where('port_id=?', temp['id'])
            if port_info.fork().exists():
                info = port_info.fork().order('create_time', 'desc').find()
                if cur_time <= int(info['create_time'] + temp['frequency']):
                    return None

        n = 0
        flag = True
        delay = 0
        ececute_time = 0
        lst = []
        nodes = temp['nodes'].split(',')
        node_list = [int(num) for num in nodes]

        for q in node_list:
            if q == 0:  # 当前服务器
                while n < temp['count']:
                    n += 1
                    # is_connect, delay = self.test_port_connection_socket(temp['ip'], int(temp['port']))
                    is_connect, delay = self.test_port_connection(temp['ip'], int(temp['port']))
                    # 连接成功 构造数据 跳出循环
                    if is_connect:
                        flag = True
                        break
                    else:
                        flag = False
                ececute_time = int(time.time())
                lst.append({
                    'uid': temp['uid'],
                    'port_id': temp['id'],
                    'node': q,
                    'is_connect': int(flag),
                    'delay': delay,
                    'create_time': ececute_time,
                })

            else:  # 调用其他节点
                while n < temp['count']:
                    n += 1
                    res = public.send_agent_msg(
                        public.get_serverid_bysid(q),
                        'vocationalwork copy',
                        'GetPortInfoByServer',
                        pdata=public.g_pdata({
                            'ip': temp['ip'],
                            'port': temp['port'],
                        }))
                    # data = public.get_agent_msg(res)
                    # res = {
                    #     'is_connect': False,  # 是否连通  bool
                    #     'delay': 10,          # 运行时间ms  str
                    # }
                    if res['is_connect']:
                        flag = True
                        break
                    else:
                        flag = False
                    ececute_time = int(time.time())
                    lst.append({
                        'uid': temp['uid'],
                        'port_id': temp['id'],
                        'node': q,
                        'is_connect': int(flag),
                        'delay': res['delay'],
                        'create_time': ececute_time,
                    })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        public.cache_set(f"port_ececute_time:{temp['id']}", ececute_time, 600)

        # 开启了告警  成功告警  失败告警
        if temp['warning']:
            # 扫描添加
            if temp['add_type'] == 0:
                warning_rules = warning_obj.get_warning_rules(temp['sid'], 'port', 'port_[]', 'connection')

                for warning_rule in warning_rules:
                    bool_ = warning_obj.warn(warning_rule, 'success' if flag else 'fail')
                    if bool_:
                        # 更新上一次告警时间
                        basic_monitor_obj.db_easy('availability_port') \
                            .where('id', temp['id']) \
                            .update({'last_warning_time': cur_time})

            # 自定义添加
            if temp['add_type'] == 1:

                warning_type = 'port监控告警'
                notify_content = ''
                ok = 0
                # 检查上一次告警时间 满足条件
                if temp['last_warning_time'] == 0 or int(temp['last_warning_time'] + 1800) < int(
                        time.time()):

                    # 失败时告警  设置了失败且失败
                    if temp['warning_mode'] == 0 and int(flag) == 0:
                        notify_content = '匹配失败'
                        ok = 1

                    # 成功时告警 设置了成功且成功
                    if temp['warning_mode'] == 1 and int(flag) == 1:
                        notify_content = '匹配成功'
                        ok = 1

                    # 满足告警条件 进行告警
                    if ok == 1:
                        public.print_log(
                            f'$$$$$$$$$$$$$$$$$-------满足告警条件 进行告警-----$$$$$$$$$$$$$$$$$$$$$$$$')
                        # 时间格式转换 秒时间戳改格式
                        times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
                        send_msg = [
                            f'> 告警类型：{warning_type}',
                            f'> 推送时间: {times}',
                            f'> 告警任务名: {temp["task_name"]}',
                            f'> 告警端口: {temp["ip"]}:{temp["port"]}',
                            f'> 告警消息：{notify_content}',
                            '',
                            '请尽快处理',
                        ]

                        warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','))

                        # 更新上一次告警时间
                        basic_monitor_obj.db_easy('availability_port') \
                            .where('id', temp['id']) \
                            .update({'last_warning_time': cur_time})

                        res['warning_logs'] = {
                            'task_id': temp['id'],
                            'type': warning_type,
                            'content': '\n'.join(send_msg),
                            'task_name': temp['task_name'],
                            'push_methods': temp['push_methods'],
                            'subject': f'告警端口: {temp["ip"]}:{temp["port"]}',
                            'message': notify_content,

                        }

        return res

    def execute_port_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取检测监控列表          暂停   .where('suspend=?', 0) \
        port_list = basic_monitor_obj.db_easy('availability_port') \
            .where('suspend=?', 0) \
            .order('update_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in port_list:
                f = t.submit(self.__port_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录端口监控结果
        with monitor_db_manager.db_mgr('availability_port_info') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('availability_port_info') \
                    .insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("availability_wanrning_log") \
                        .insert_all(warning_logs)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        return True

    def add_port_task(self, args):
        '''
        @name 添加port监控任务
        @author Law Lt <2023-02-24>
        @return dict
        '''

        # 扫描和添加两种方式 扫描
        uid = public.bt_auth('uid')
        add_type = int(args.get('add_type', 0))  # 0扫描 1自定义
        sid = args.get('sid', None)
        # node = args.get('node', 0)
        nodes = args.get('nodes', '0')    # 不选节点 默认当前节点测试 0
        task_name = args.get('task_name', '')
        frequency = args.get('frequency', 20)
        count = args.get('count', 2)
        protocol = args.get('protocol', 0)  # 0tcp 1udp
        warning = args.get('warning', 0)  # 0 不开启
        warning_mode = args.get("warning_mode", 0)
        push_methods = args.get("push_methods", '')
        # 添加的ip和端口
        ip_port_list = args.get('ip_port_list', '')

        if not uid:
            return public.error('请先登录')

        if add_type not in [0, 1]:
            return public.error('add_type参数不正确')

        if basic_monitor_obj.db_easy('availability_port').where("uid=? AND task_name=?", [uid, task_name]).exists():
            return public.error('任务名已存在')

        cur_time = int(time.time())

        # 组织添加数据
        port_data = []
        server_port_data = []

        # 扫描添加
        if add_type == 0:
            if not ip_port_list:
                return public.error('缺少参数：ip_port_list')
            ip_port_list = ip_port_list.split(';')  # port_list:  'ip,port;ip,port; ...'

            # 选中的主机端口数据
            n = len(ip_port_list)
            for i in ip_port_list:
                # i : 'ip,port'
                ip_port = i.split(',')  # [ip, port]

                # "hash(主机ID|监听IP|端口号|通信协议)":
                key = "{}|{}|{}|{}".format(str(sid), str(ip_port[0]), str(ip_port[1]), str(protocol))
                port_hash = public.mmh3_hash64(key)
                # task_name = task_name if n == 1 else task_name + str(n)

                task_n = str(ip_port[0]) + ':' + str(ip_port[1]) if n > 1 else task_name
                # 重复的跳过
                if basic_monitor_obj.db_easy('availability_port').where("uid=? AND task_name=?",
                                                                        [uid, task_n]).exists():
                    continue
                # 限制端口数据类型 如果不能转数字跳过当前
                try:
                    p = int(ip_port[1])
                    if p < 1 or p > 65535:
                        continue
                except:
                    continue

                port_data.append({
                    'uid': uid,
                    'sid': sid,
                    'ip': str(ip_port[0]),
                    'port': int(ip_port[1]),
                    'task_name': task_n,
                    'frequency': frequency,
                    'count': count,
                    'protocol': protocol,
                    'warning': warning,
                    'nodes': nodes,
                    'port_hash': port_hash,
                    'create_time': cur_time,
                    'add_type': 0,
                })

                server_port_data.append({
                    'id': port_hash,
                    'sid': sid,
                    'create_time': cur_time,
                })

            # 添加 服务器端口连接测试表
            with monitor_db_manager.db_mgr('server_port_connection_test') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('server_port_connection_test') \
                        .insert_all(server_port_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 添加 端口配置表
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .insert_all(port_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 自定义添加  单个 或 多个
        if add_type == 1:
            if not ip_port_list:
                return public.error('缺少参数：ip_port_list')
            ip_port_list = ip_port_list.split(';')  # port_list:  'ip,port;ip,port; ...'

            # 选中的主机端口数据
            n = len(ip_port_list)
            for i in ip_port_list:
                # i : 'ip,port'
                ip_port = i.split(',')  # [ip, port]
                # task_name = task_name if n == 1 else task_name + str(n)
                task_n = str(ip_port[0]) + ':' + str(ip_port[1]) if n > 1 else task_name
                # 重复的跳过
                if basic_monitor_obj.db_easy('availability_port').where("uid=? AND task_name=?",
                                                                        [uid, task_n]).exists():
                    continue

                # 限制端口数据类型 如果不能转数字跳过当前
                try:
                    p = int(ip_port[1])
                    if p < 1 or p > 65535:
                        continue
                except:
                    continue

                port_data.append({
                    'uid': uid,
                    'ip': str(ip_port[0]),
                    'port': int(ip_port[1]),
                    'task_name': task_n,
                    'frequency': frequency,
                    'count': count,
                    'protocol': protocol,
                    'warning': warning,
                    'nodes': nodes,
                    'create_time': cur_time,
                    'add_type': 1,
                    'warning_mode': warning_mode,
                    'push_methods': push_methods,
                })
                # n += 1
            # 添加 端口配置表
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .insert_all(port_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        public.WriteLog('业务监控', '添加[%s]端口监控任务成功' % task_name)
        return public.success('添加端口监控任务成功')

    def remove_port_task(self, args):
        '''
        @name 删除port监控任务
        @author Law Lt <2023-02-24>
        @return dict
        '''
        # 接收任务id     ids = '1,2,3,4,5'
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')  # ['1','2','3','4','5']
        for i in id_list:
            port_info = basic_monitor_obj.db_easy('availability_port').where('id=?', int(i)).find()

            # 删除任务
            basic_monitor_obj.db_easy('availability_port') \
                .where('id=?', int(i)) \
                .delete()

            if port_info['sid'] is not None:
                key = "{}|{}|{}|{}".format(str(port_info['sid']), str(port_info['ip']), str(port_info['port']),
                                           str(port_info['protocol']))
                server_port_id = public.mmh3_hash64(key)
                # 删除主机端口连接表
                basic_monitor_obj.db_easy('server_port_connection_test') \
                    .where('id=?', server_port_id) \
                    .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_port_info') \
                .where('port_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('task_id=?', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除端口监控任务[%s] 成功' % (port_info['task_name']))

        return public.success('删除端口监控任务成功')

    def update_port_task(self, args):
        '''
        @name 编辑/修改端口监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''

        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')

        old = basic_monitor_obj.db_easy('availability_port').where("id=?", id_).find()
        dicts = {}
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_port') \
                            .where("uid=? AND task_name=?", [uid, ta_name]) \
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')
        if "warning_mode" in args:
            new_data["warning_mode"] = args.get('warning_mode')

        new_data["update_time"] = int(time.time())

        # 自定义添加的 可以改端口和ip
        if old['add_type'] == 1:
            public.print_log(f'*********************')
            public.print_log(f'自定义添加的 可以改端口和ip')
            if "ip" in args:
                new_data["ip"] = args.get('ip')
                if old['ip'] != new_data["ip"]:
                    dicts['IP修改为'] = new_data["ip"]

            if "port" in args:
                new_data["port"] = int(args.get('port'))
                if old['port'] != new_data["port"]:
                    dicts['端口修改为'] = new_data["port"]

            if "protocol" in args:
                new_data["protocol"] = args.get('protocol')
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", id_) \
                        .update(new_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 扫描添加的 不可以改端口和ip
        if old['add_type'] == 0:
            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", id_) \
                        .update(new_data)
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

        # 修改过后的
        info = basic_monitor_obj.db_easy('availability_port') \
            .where("id=?", id_) \
            .find()
        # IP 端口 被修改
        if dicts:
            public.WriteLog('业务监控', '修改端口监控任务成功!  原名[%s] 现为[%s]  %s' % (old['task_name'],info['task_name'], dicts))
        else:
            public.WriteLog('业务监控', '修改端口监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改端口监控任务成功')

    def suspend_port_task(self, args):
        '''
        @name 批量暂停port监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_port').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_port') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_port') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停端口监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停端口监控任务成功')
    
    def get_server_host_port(self, args):
        '''
            @name 获取主机监听端口列表
            @return list
        '''
        # 获取主机端口列表
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        server_host_port_ = public.cache_get(f"get_server_host_port")
        if server_host_port_:
            # public.print_log(f'有缓存 从缓存取')
            server_host_port = json.loads(server_host_port_)
        else:
            # public.print_log(f' 无缓存 查数据库')
            sid_list = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').select()
            server_host_port = []
            for i in sid_list:

                port_info_str = basic_monitor_obj.db_easy('server_details') \
                    .field('id', 'port_info') \
                    .where('sid', i['sid']) \
                    .value('port_info')
                if port_info_str is None:
                    continue
                # a = {"-1513031083116919484": {
                #     "ip": "127.0.0.1",
                #     "port": 6379,
                #     "protocol": "tcp",
                #     "pne_id": -6880937732970142474
                # }, 'id': {'ip': 'ip', 'port': 80}}

                try:
                    port_info_str = json.loads(port_info_str)
                except:
                    pass
                # 结果集(处理前)
                raw_ret = []

                for k, v in port_info_str.items():
                    ip = v.get('ip', '')
                    port = v.get('port', None)
                    protocol = v.get('protocol', '')

                    tmp = {
                        'id': k,
                        'ip': ip,
                        'port': port,
                        'protocol': protocol,
                    }
                    raw_ret.append(tmp)

                host_port_info = {'sid': i['sid'],
                                  's_ip': i['ip'],
                                  's_remark': i['remark'],
                                  "port_list": raw_ret}

                server_host_port.append(host_port_info)
            server_host_port_ = json.dumps(server_host_port, ensure_ascii=False)

            # 缓存执行完的时间
            public.cache_set("get_server_host_port", server_host_port_, 600)
        return public.success(server_host_port)

    def test_port_connection_socket(self, ip, port):
        '''
            @name    socket测试端口连通性
            @author  lt<2023-03-28>
            @param   ip<string>  IP|域名
            @param   port<integer>    端口号
            @return (端口是否连通<bool>,任务执行时间<float>)
        '''
        start_time = time.time()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.2)
        try:
            result = sock.connect_ex((ip, port))
            if result == 0:
                connect_status = True
            else:
                connect_status = False
        except Exception as e:
            connect_status = False
        finally:
            sock.close()
            end_time = time.time()
            elapsed_time = "%.2f" % ((end_time - start_time) * 1000)
        return connect_status, elapsed_time

    def test_port_connection(self, address, port, method='telnet'):
        '''
            @name 测试端口连通性
            @author Zhj<2022-07-04>
            @param address<string>  IP|域名
            @param port<integer>    端口号
            @param method<string>   测试方式 telnet|nc
            @return (端口是否连通<bool>, 测试方式<string>)
        '''
        start_time = time.time()
        if method is None:
            ok, _ = self.test_port_connection_via_telnet2(address, port)
            if ok:
                return True

            ok = self.test_port_connection_via_nc(address, port)
            if ok:
                return True

            return False

        if method not in ['telnet', 'nc']:
            return False

        if method == 'telnet':
            connect_status = self.test_port_connection_via_telnet2(address, port)
            end_time = time.time()
            elapsed_time = "%.2f" % ((end_time - start_time) * 1000)
            return connect_status, elapsed_time
            # return self.test_port_connection_via_telnet2(address, port), 'telnet'
        elif method == 'nc':
            return self.test_port_connection_via_nc(address, port)

        return False

    def test_port_connection_via_telnet2(self, address, port, timeout=0.2):
        '''
            @name 使用telnet的方式测试端口
            @author lx<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        import telnetlib
        try:
            info = telnetlib.Telnet(host=address, port=port, timeout=timeout)
            # print(info)
            public.print_log('--telnet的方式测试端口--')
            # public.print_log(info)

            return True, "telnet"
        except:
            return False, 'telnet'

    def test_port_connection_via_nc(self, address, port):
        '''
            @name 使用nc的方式测试端口
            @author Zhj<2022-07-08>
            @param  address<string>  IP|域名
            @param  port<integer>    端口号
            @return bool
        '''
        res = public.ExecShell('nc -w 1 {} {} && echo ok || echo no'.format(address, port))
        # public.print_log('--nc的方式测试端口--')
        # public.print_log(res)

        if len(res) < 1:
            return False

        if res[0].find('ok') < 0:
            return False

        return True



    def get_ping_task(self, args):
        '''
            @name 获取ping监控任务列表
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''
        keyword = args.get('keyword', None)
        # sid = args.get('sid', None)

        # if not sid:
        #     return public.error('缺少参数：sid')
        # server_list = g.get("server_list", [])
        # if sid not in server_list:
        #     public.response(False, '您没有权限访问该服务器 !')

        # 数据库查询
        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            query = basic_monitor_obj.db_easy('availability_ping') \
                .order('update_time', 'desc')
        else:
            # 数据库查询
            query = basic_monitor_obj.db_easy('availability_ping') \
                .where('uid=?', uid) \
                .order('update_time', 'desc')

        if keyword is not None:
            query.where('ip_dsc like ? or task_name like ?', ['%{}%'.format(keyword), '%{}%'.format(keyword)])

        # 分页查询
        ret = public.simple_page(query, args)

        # 在线 离线
        on_line = 0
        off_line = 0
        data = ret['list']
        for i in data:
            ping_ = basic_monitor_obj.db_easy('availability_ping_info') \
                .where('`ping_id` = ?', [i['id']]) \
                .order('create_time', 'desc')

            ping_info = ping_.fork().find()
            ping_result = ping_.fork().limit(10).select()

            if ping_info is not None:
                i['is_ping'] = ping_info['is_ping']
                i['ping_result'] = ping_result

                # 离线时长 后边加
                # i['last_offline_time'] = 0
                if ping_info['is_ping'] == 0:
                    off_line += 1
                else:
                    on_line += 1
            else:
                i['is_ping'] = 2
                i['ping_result'] = []

            # 上线时长 下线时长
        ret['on_line'] = on_line
        ret['off_line'] = off_line

        return public.success(ret)

    def get_ping_result(self, args):
        """
            @name 获取ping监控任务结果
            @author Law Lt <2023-03-01>
            @arg    keyword<string> 关键字
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')
        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            task = basic_monitor_obj.db_easy('availability_ping') \
                .where('id=?', id_) \
                .find()
        else:
            # 数据库查询任务详情
            task = basic_monitor_obj.db_easy('availability_ping') \
                .where('uid=? AND id=?', [uid, id_]) \
                .find()

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        ping_info = basic_monitor_obj.db_easy('availability_ping_info') \
            .where('`ping_id` = ?', id_) \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # 查询数据
        # ping_info = basic_monitor_obj.db_easy('availability_ping_info') \
        #     .where('`create_time` BETWEEN ? AND ?', [id_, cur_time - query_date]) \
        #     .field('is_ping', 'create_time')

        # 检查区间内是否有执行结果
        if not ping_info.fork().field('id').exists():

            ret = public.simple_page(ping_info, args)
            ret['task'] = task
            ret['available_rate'] = 0
            ret['avg_delay'] = 0
            ret['last_offline_time'] = 0
            return public.success(ret)

        # 获取区间内任务执行结果
        info = ping_info.fork().order('create_time', 'desc')

        # 成功率转换
        p = ping_info.fork().value(
            'ROUND(1.0 * SUM(CASE `is_ping` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')

        # # 上次离线时间
        cur_time = int(time.time())
        if ping_info.fork().where('is_ping=1').exists():
            # 最新的失败状态
            last_off = ping_info.fork().where('is_ping=0').find()

            # 存在失败状态 计算时间
            if last_off is not None:

                # 失败是最新一条    当前时间-最新的成功时间
                if last_off['id'] == ping_info.fork().value('id'):
                    last_offline_time = cur_time - ping_info.fork().where('is_ping=1').value('create_time')
                # 不是最新的
                else:
                    end_time = ping_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
                    last_on_line = ping_info.fork().where('id<? ', last_off['id']).where('is_ping=1').find()
                    # 失败前没有在线状态
                    if last_on_line is None:
                        start_time = ping_info.fork().value('min(create_time)')
                    else:
                        start_time = ping_info.fork().where('id > ?', last_on_line['id']).where('is_ping', 0).value('min(create_time)')

                    last_offline_time = end_time - start_time

            else:
                last_offline_time = 0
        else:
            last_offline_time = None

        ret = public.simple_page(info, args)
        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '本地'
                i['node_ip'] = '127.0.0.1'
            else:
                server = warning_obj.db_easy('servers').field('ip', 'remark').where('sid=?', i['node']).find()
                i['node_remark'] = server['remark']
                i['node_ip'] = server['ip']
        ret['task'] = task
        ret['available_rate'] = float(p)
        # 上次离线时间
        ret['last_offline_time'] = last_offline_time
        # 平均延迟
        ret['avg_delay'] = "%.2f" % (ping_info.fork().avg('delay'))
        return public.success(ret)

    # 执行ping
    def __ping_task_help(self, temp, packet_reg, package_delay_avg_reg_obj):
        cur_time = int(time.time())
        # 跳过没到时间的
        # 先从缓存取上次执行时间 缓存没有 取数据库取
        last_ececute_time = public.cache_get(f"ping_ececute_time:{temp['id']}")
        if last_ececute_time:
            if cur_time <= int(last_ececute_time) + temp['frequency']:
                return None

        # 在信息表查时间   当前时间<=创建时间+频率
        else:
            ping_info = basic_monitor_obj.db_easy('availability_ping_info').where('ping_id', temp['id'])
            if ping_info.fork().exists():
                info = ping_info.fork().order('create_time', 'desc').find()
                if cur_time <= int(temp['frequency'] + info['create_time']):
                    return None

        n = 0
        flag = True
        loss_percent = None
        avg_num = None

        lst = []
        nodes = temp['nodes'].split(',')

        node_list = [int(num) for num in nodes]
        ececute_time = 0
        for q in node_list:
            if q == 0:  # 当前服务器
                while n < temp['count']:
                    n += 1
                    # 构造连接结构
                    # 连接成功 构造数据 跳出循环
                    # 解析内容
                    ping_text, _ = public.ExecShell(f'ping -c50 -W1 -i 0.2 {temp["ip_dsc"]}')
                    public.print_log(f'%%%%%%%%%%%%%%%%ping_text%%%%%%%%%%%%%%%%%%%%%%{ping_text}')
                    # 获取不到数据  如：输入错误的ip 0~255   192.168.1.266
                    if ping_text is not None:
                        public.print_log(f'%%%%%%%%%%%%%%%%ping_text%%%%%%%%%%%%%%%%%%%%%%{ping_text}')
                        ping_text = ping_text.split("\n")
                        # public.print_log(f'%%%%%++++++ping_text++++++%%%%%{ping_text}')
                        # ping_text = list(set(ping_text))
                        # ping_text.remove("")

                        ping_text_len = len(ping_text)

                        for i in range(ping_text_len-1, -1, -1):
                            text = ping_text[i]
                            public.print_log(f'{text}')

                            # 优先匹配平均延迟
                            # if not avg_num:
                            avg_obj = package_delay_avg_reg_obj.search(text)
                            if avg_obj:
                                public.print_log(f'------------temp_text-------------{avg_obj.group(0)}')
                                avg_num = avg_obj.group(1)
                                public.print_log(f'***************avg_num******************{avg_num}')
                                continue

                            # 匹配丢包率
                            packet_obj = packet_reg.search(text)
                            if packet_obj:
                                public.print_log(f'++++++++++++temp_text++++++++++++++{packet_obj.group(0)}')
                                loss_percent = packet_obj.group(1)
                                public.print_log(f'++++++++++++loss_percent++++++++++++++{loss_percent}')
                                break

                    # 连接失败 重试
                    if avg_num is None or loss_percent == "100":
                        flag = False
                        continue
                    # 测试通过
                    flag = True
                    break

                ececute_time = int(time.time())
                lst.append({
                    'uid': temp['uid'],
                    'ping_id': temp['id'],
                    'ip_dsc': temp['ip_dsc'],
                    'delay': 0 if avg_num is None else float(avg_num),
                    'loss_ratio': 0 if loss_percent is None else float(loss_percent),
                    'is_ping': int(flag),
                    'node': q,
                    'create_time': ececute_time,
                })

            else:  # 调用其他节点
                while n < temp['count']:
                    n += 1
                    res = public.send_agent_msg(
                        public.get_serverid_bysid(q),
                        'vocationalwork copy',
                        'GetPingInfoByServer',
                        pdata=public.g_pdata({
                            'ip_dsc': temp['ip_dsc']
                        }))
                    # data = public.get_agent_msg(res)
                    # res = {
                    #     'delay': 0,  # 延迟时间 ms
                    #     'loss_ratio': 0,  # 丢包率  %
                    #     'is_ping': Ture  # 是否连通 bool
                    # }
                    if res['is_ping']:
                        flag = True
                        break
                    else:
                        flag = False
                    ececute_time = int(time.time())
                    lst.append({
                        'uid': temp['uid'],
                        'ping_id': temp['id'],
                        'ip_dsc': temp['ip_dsc'],
                        'delay': 0 if avg_num is None else float(res['delay']),
                        'loss_ratio': 0 if loss_percent is None else float(res['loss_percent']),
                        'is_ping': int(flag),
                        'node': q,
                        'create_time': ececute_time,
                    })

        res = {'insert_data': lst}

        # 缓存执行完的时间
        public.cache_set(f"ping_ececute_time:{temp['id']}", ececute_time, 600)

        # 告警  如果开启了告警
        if temp['warning']:
            # 检查上一次告警时间
            if temp['last_warning_time'] == 0 or int(temp['last_warning_time'] + 1800) < int(time.time()):
                warning_type = 'ping监控告警'
                notify_content = ''
                status = 0
                # 如果添加方式是传统 1
                if temp['add_type']:
                    public.print_log(f'*************************{temp.keys()}')
                    if loss_percent and float(loss_percent) >= float(temp['w_loss_ratio']):
                        # warning_type = 'ping丢包率'
                        notify_content = '丢包率大于或等于{}%'.format(temp['w_loss_ratio'])
                        status = 1
                    elif avg_num and float(avg_num) > float(temp['w_delay']):
                        # warning_type = 'ping延迟'
                        notify_content = '延迟大于{}毫秒'.format(temp['w_delay'])
                        status = 1
                        # else:  # 快速添加  默认规则
                #     if temp['w_loss_ratio'] > 10:
                #         warning_type = 'ping丢包率'
                #         notify_content = '丢包率大于10%'
                #     elif temp['w_delay'] > 1000:
                #         warning_type = 'ping延迟'
                #         notify_content = '延迟大于1000毫秒'
                if status == 1:
                    # 进行告警
                    times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
                    # address = public.get_local_ip()

                    send_msg = [
                        f'> 告警类型：{warning_type}',
                        f'> 推送时间: {times}',
                        f'> 告警任务名: {temp["task_name"]}',
                        f'> 主机: {temp["ip_dsc"]}',
                        f'> 告警消息：{notify_content}',
                        '',
                        '请尽快处理',
                    ]

                    warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','))

                    # 更新上一次告警时间
                    basic_monitor_obj.db_easy('availability_ping') \
                        .where('id', temp['id']) \
                        .update({'last_warning_time': cur_time})

                    res['warning_logs'] = {
                        'task_id': temp['id'],  # 新加任务id
                        'type': warning_type,
                        'content': '\n'.join(send_msg),
                        'task_name': temp['task_name'],
                        'push_methods': temp['push_methods'],
                        'subject': f'主机: {temp["ip_dsc"]}',
                        'message': notify_content,
                    }
        end_time = time.time() - cur_time
        public.print_log(f'~~~~~~~~~~~~~~~~~~~~~~~{end_time}')
        return res

    def execute_ping_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取ping检测监控列表
        ping_list = basic_monitor_obj.db_easy('availability_ping') \
            .order('create_time', 'desc') \
            .where('suspend=?', 0) \
            .select()
        # cloudip = public.GetLocalIp()
        # hostip = public.get_ip()
        # meip = public.get_local_ip()
        # public.print_log(f'***************************************{cloudip}')
        # public.print_log(f'***************************************{hostip}')
        # public.print_log(f'***************************************{meip}')

        packet_reg = re.compile(r"(\d+(?:\.\d+)?)% packet loss")
        package_delay_avg_reg_obj = re.compile(r"\d+(?:\.\d+)?/(\d+(?:\.\d+)?)")

        insert_data = []
        warning_logs = []
        start_time = time.time()
        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in ping_list:
                f = t.submit(self.__ping_task_help, temp, packet_reg, package_delay_avg_reg_obj)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录ping监控结果  写入信息表
        with monitor_db_manager.db_mgr('availability_ping_info') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            db.query() \
                .name("availability_ping_info") \
                .insert_all(insert_data)

            # 提交事务
            db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        end_time = time.time() - start_time
        # public.print_log(f'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{end_time}')
        return public.success()

    def add_ping_task(self, args):
        '''
        @name 添加ping监控
        @author Law Lt <2023-02-24>
        @arg    ip<string> 服务器IP
        @return dict
        '''
        uid = public.bt_auth('uid')
        add_type = int(args.get('add_type', 1))  # 0 快速 1传统
        task_name = args.get('task_name', '')
        ip_src = args.get('ip_src', 0)
        network = args.get('network', '')
        ip_dsc = args.get('ip_dsc', '')
        warning = args.get('warning', 1)
        w_loss_ratio = args.get('w_loss_ratio', 20)
        w_delay = args.get('w_delay', 0)
        nodes = args.get('nodes', '0')
        frequency = args.get('frequency', 20)
        count = args.get('count', 2)
        push_methods = args.get("push_methods", '')

        if not ip_dsc:
            return public.error('缺少参数：ip_dsc')
        if basic_monitor_obj.db_easy('availability_ping').where("uid=? AND task_name=?", [uid, task_name]).exists():
            return public.error('任务名已存在')

        cur_time = int(time.time())
        # ping_data = []

        # 快速添加方式
        # if add_type == 0:
        #     if sid is not None:
        #         sid_list = sid.split(',')
        #         ip_list = basic_monitor_obj.db_easy('servers') \
        #             .field('ip','sid') \
        #             .order('create_time', 'desc') \
        #             .where_in("sid", sid_list) \
        #             .select()
        #
        #         for ip in ip_list:
        #             ping_data.append({
        #                 'uid': uid,
        #                 'task_name': task_name,
        #                 'add_type': 0,
        #                 'ip_src': ip_src,
        #                 'network': network,
        #                 'ip_dsc': ip['ip'],
        #                 'warning': warning,
        #                 'w_loss_ratio': w_loss_ratio,
        #                 'w_delay': w_delay,
        #                 'node': node,
        #                 'frequency': frequency,
        #                 'count': count,
        #                 'push_methods': push_methods,
        #                 'create_time': cur_time,
        #             })
        #
        #     with monitor_db_manager.db_mgr('availability_ping') as db:
        #         try:
        #             # 关闭事务自动提交
        #             db.autocommit(False)
        #
        #             db.query() \
        #                 .name('availability_ping') \
        #                 .insert_all(ping_data)
        #
        #             # 提交事务
        #             db.commit()
        #         except BaseException as e:
        #             # 回滚事务
        #             db.rollback()
        #
        #             # 打印异常堆栈
        #             public.print_exc_stack(e)
        #             raise e

        # 传统添加方式
        ping_data = []
        if add_type == 1:
            # # 数据库操作
            # basic_monitor_obj.db_easy('availability_ping') \
            #     .insert({
            #         'uid': uid,
            #         'task_name': task_name,
            #         'add_type': 1,
            #         'ip_src': ip_src,
            #         'network': network,
            #         'ip_dsc': ip_dsc,
            #         'warning': warning,
            #         'w_loss_ratio': w_loss_ratio,
            #         'w_delay': w_delay,
            #         'node': node,
            #         'frequency': frequency,
            #         'count': count,
            #         'push_methods': push_methods,
            #         'create_time': cur_time,
            # })
            if ip_dsc is not None:
                ip_dsc = ip_dsc.split(';')
                ip_des_len = len(ip_dsc)
                # n = 1
                for temp in ip_dsc:
                    # task_name = task_name if n == 1 else task_name + str(n)
                    if basic_monitor_obj.db_easy('availability_ping').where("uid=? AND task_name=?",
                                                                            [uid, temp]).exists():
                        continue
                    ping_data.append({
                        'uid': uid,
                        # 'task_name': task_name + str(n) if ip_des_len > 1 else task_name,
                        'task_name': temp,
                        'add_type': 1,
                        'ip_src': ip_src,
                        'network': network,
                        'ip_dsc': temp,
                        'warning': warning,
                        'w_loss_ratio': w_loss_ratio,
                        'w_delay': w_delay,
                        'nodes': nodes,
                        'frequency': frequency,
                        'count': count,
                        'push_methods': push_methods,
                        'create_time': cur_time,
                    })
                    # n+=1

                # 添加 端口配置表
                with monitor_db_manager.db_mgr('availability_ping') as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        db.query() \
                            .name('availability_ping') \
                            .insert_all(ping_data)
                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 打印异常堆栈
                        public.print_exc_stack(e)
                        raise e

        public.WriteLog('业务监控', '添加Ping监控任务[%s] 成功' % task_name)
        return public.success('添加Ping监控任务成功')

    def remove_ping_task(self, args):
        '''
        @name 删除ping监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''
        # 接收
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')

        for i in id_list:
            data = basic_monitor_obj.db_easy('availability_ping') \
                .where('id=?', int(i)) \
                .find()

            # 删除任务
            basic_monitor_obj.db_easy('availability_ping') \
                .where('id=?', int(i)) \
                .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_ping_info') \
                .where('ping_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('task_id=?', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除Ping监控任务[%s] 成功' % (data['task_name']))
        return public.success('删除Ping监控任务成功')

    def update_ping_task(self, args):
        '''
        @name 编辑/修改ping监控任务
        @author Law Lt <2023-02-25>
        @return dict
        '''
        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')
        dicts = {}
        old = basic_monitor_obj.db_easy('availability_ping').where("id=?", id_).find()
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_ping')\
                            .where("uid=? AND task_name=?", [uid, ta_name])\
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "ip_dsc" in args:
            new_data["ip_dsc"] = args.get('ip_dsc')
            if old['ip_dsc'] != new_data["ip_dsc"]:
                dicts['目标IP修改为'] = new_data["ip_dsc"]

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "w_loss_ratio" in args:
            new_data["w_loss_ratio"] = int(args.get('w_loss_ratio'))
            if old['w_loss_ratio'] != new_data["w_loss_ratio"]:
                dicts['丢包率修改为'] = new_data["w_loss_ratio"]

        if "w_delay" in args:
            new_data["w_delay"] = int(args.get('w_delay'))
            if old['w_delay'] != new_data["w_delay"]:
                dicts['延迟修改为'] = str(new_data["w_delay"]) + 'ms'

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')
        # if "warning_mode" in args:
        #     new_data["warning_mode"] = args.get('warning_mode')

        new_data["update_time"] = int(time.time())
        with monitor_db_manager.db_mgr('availability_ping') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('availability_ping') \
                    .where("id=?", id_) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        # 记录日志
        info = basic_monitor_obj.db_easy('availability_ping') \
            .where("id=?", id_) \
            .find()
        if dicts:
            public.WriteLog('业务监控', '修改Ping监控任务成功!  原名[%s] 现为[%s]  %s' % (old['task_name'], info['task_name'], dicts))
        else:
            public.WriteLog('业务监控', '修改Ping监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改Ping监控任务成功')
    
    def suspend_ping_task(self, args):
        '''
        @name 批量暂停ping监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_ping').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_ping') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_ping') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停ping监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停ping监控任务成功')


    def get_http_task(self, args):
        '''
            @name 获取http/https监控任务列表
            @author  <2023-03-2>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    协议 http/https
            @return list
        '''
        keyword = args.get('keyword', None)
        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            query = basic_monitor_obj.db_easy('availability_http') \
                .order('update_time', 'desc')
        else:
            # 数据库查询
            query = basic_monitor_obj.db_easy('availability_http') \
                .where('uid=?', uid) \
                .order('update_time', 'desc')

        if keyword is not None:
            query.where('url = ? or task_name like ?', (keyword, f"%{keyword}%"))
        # 分页查询
        ret = public.simple_page(query, args)

        # 上线 离线 数量  上线 id 查 详情表 最近一次连接状态
        on_line = 0
        off_line = 0
        data = ret['list']
        for i in data:

            # 执行任务详情
            http_ = basic_monitor_obj.db_easy('availability_http_info') \
                .where('`http_id` = ?', [i['id']]) \
                .order('create_time', 'desc')

            # 最近一次
            http_info = http_.fork().find()
            # 最近十次
            http_result = http_.fork().limit(10).select()

            if http_info is not None:
                i['is_ok'] = http_info['is_ok']
                # 离线时长 后边加
                # i['last_offline_time'] = 0
                # 响应时间
                i['response_time'] = http_info['response_time']
                i['http_result'] = http_result

                if http_info['is_ok'] == 0:
                    off_line += 1
                else:
                    on_line += 1
            else:
                i['is_ok'] = 2
                i['response_time'] = 0
                i['http_result'] = []

        # 上线时长 下线时长
        ret['on_line'] = on_line
        ret['off_line'] = off_line

        return public.success(ret)

    def get_http_result(self, args):
        """
            @name 获取http/https监控任务结果
            @author  <2023-03-02>
            @arg    keyword<string> 关键字
            @return dict
        """
        id_ = int(args.get('id', None))
        if not id_:
            return public.error('缺少参数：id')

        uid = public.bt_auth('uid')
        # 管理员获取全部
        if uid == 1:
            task = basic_monitor_obj.db_easy('availability_http') \
                .where('id=?', id_) \
                .find()
        else:
            # 数据库查询任务详情
            task = basic_monitor_obj.db_easy('availability_http') \
                .where('uid=? AND id=?', [uid, id_]) \
                .find()

        # 查询时间
        query_date = args.get('query_date', 'l1')

        # 开始时间 与 结束时间的时间戳
        query_start, query_end = public.get_query_timestamp(query_date)

        http_info = basic_monitor_obj.db_easy('availability_http_info') \
            .where('`http_id` = ?', id_) \
            .where('create_time >= ?', query_start) \
            .where('create_time <= ?', query_end) \
            .order('create_time', 'desc')

        # http_info = basic_monitor_obj.db_easy('availability_http_info') \
        #     .where(
        #     '`http_id` = ? AND `create_time` > ?', [id_, cur_time - query_date]
        # )

        # 检查区间内是否有执行结果
        if not http_info.fork().field('id').exists():
            ret = public.simple_page(http_info, args)
            ret['task'] = task
            ret['available_rate'] = 0
            ret['avg_response_time'] = 0
            ret['last_offline_time'] = 0
            return public.success(ret)

        # 获取区间内任务执行结果
        info = http_info.fork().order('create_time', 'desc')

        # 获取端口连接成功率
        rate = http_info.fork().value(
            'ROUND(1.0 * SUM(CASE `is_ok` WHEN 1 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS `ok_percent`')
        # 上次离线时间
        cur_time = int(time.time())
        if http_info.fork().where('is_ok=1').exists():
            # 最新的失败状态
            last_off = http_info.fork().where('is_ok=0').find()

            # 存在失败状态 计算时间
            if last_off:

                # 失败是最新一条    当前时间-最新的成功时间
                if last_off['id'] == http_info.fork().value('id'):
                    last_offline_time = cur_time - http_info.fork().where('is_ok=1').value('create_time')
                # 不是最新的
                else:
                    end_time = http_info.fork().where('id > ?', (last_off['id'])).value('min(create_time)')
                    last_on_line = http_info.fork().where('id<? ', last_off['id']).where('is_ok=1').find()
                    # 失败前没有在线状态
                    if last_on_line is None:
                        start_time = http_info.fork().value('min(create_time)')
                    else:
                        start_time = http_info.fork().where('id > ?', last_on_line['id']).where('is_ok', 0).value('min(create_time)')

                    last_offline_time = end_time - start_time

            else:
                last_offline_time = 0
        else:
            last_offline_time = None
        # 分页查询
        ret = public.simple_page(info, args)

        # 补充节点信息
        for i in ret['list']:
            if i['node'] == 0:
                i['node_remark'] = '本地'
                i['node_ip'] = '127.0.0.1'
            else:
                server = warning_obj.db_easy('servers').field('ip', 'remark').where('sid=?', i['node']).find()
                i['node_remark'] = server['remark']
                i['node_ip'] = server['ip']
        ret['available_rate'] = float(rate)
        ret['task'] = task
        # 上次离线时间
        ret['last_offline_time'] = last_offline_time
        # 平均响应时间
        ret['avg_response_time'] = "%.2f" % (http_info.fork().avg('response_time'))
        return public.success(ret)

    # 执行http
    def __http_task_help(self, temp):
        """
            @name 执行http
            @author  <2023-03-22>
            @arg    temp 两个判断告警的条件
            @return dict
        """
        cur_time = int(time.time())
        # 跳过没到时间的 先从缓存取上次执行时间 缓存没有 取数据库取
        last_ececute_time = public.cache_get(f"http_ececute_time:{temp['id']}")
        if last_ececute_time:
            if cur_time <= int(last_ececute_time) + temp['frequency']:
                return None

        # 在信息表查时间   当前时间<=创建时间+频率
        else:
            http_info = basic_monitor_obj.db_easy('availability_http_info').where('http_id', temp['id'])
            if http_info.fork().exists():
                info = http_info.fork().order('create_time', 'desc').find()
                if cur_time <= int(temp['frequency'] + info['create_time']):
                    return None

        n = 0
        flag = True
        status = None
        response_time = None
        # 获取证书详情
        start_time = 0
        end_time = 0
        issuer = ''
        subject = ''
        certificate = warning_obj.get_domain_cert_info(temp['url'])
        request_methods = (requests.get, requests.post)
        if certificate is not None:
            start_time = int(certificate['start_time'])
            end_time = int(certificate['end_time'])
            issuer = json.dumps(certificate['issuer'], ensure_ascii=False)
            subject = json.dumps(certificate['subject'], ensure_ascii=False)
        # name = temp['task_name']

        lst = []
        ececute_time = 0
        nodes = temp['nodes'].split(',')
        node_list = [int(num) for num in nodes]

        for q in node_list:
            if q == 0:  # 当前服务器
                while n < temp['count']:
                    status = None
                    response_time = None
                    n += 1
                    # public.print_log(f'-------------------- {name}执行第{n}次>_< ------------------------------')
                    # 自定义user-agent头
                    headers = {
                        "User-Agent":
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
                    }
                    # 开启basic认证
                    if temp['is_basic']:
                        import base64
                        user = public.decrypt_password(temp['bs_user'])
                        pwd = public.decrypt_password(temp['bs_pwd'])
                        serect = user + ":" + pwd
                        bs = str(base64.b64encode(serect.encode("utf-8")), "utf-8")
                        headers.update({"Authorization": "Basic {}".format(bs)})

                    public.print_log(f'开启basic认证 --- {headers}')
                    mtd = request_methods[int(temp['method'])]
                    s_type = ('get', 'post')[int(temp['method'])]
                    public.print_log(f'--- {s_type}请求 ---')
                    post_data = {}
                    # 捕获异常 跳过本次
                    try:
                        # 传入了参数
                        if temp['body'] is not None:
                            if len(temp['body']) > 1:
                                list_k_v = temp['body'].split(';')  # temp['body'] = 'key1,value1;key2,value2;key3,value3'
                                # list1 = ['key1,value1', 'key2,value2', 'key3,value3']

                                for i in list_k_v:
                                    k_v = i.split(',')  # [key, value]
                                    post_data[k_v[0]] = k_v[1]
                                # public.print_log(f'=========={s_type}传入参数{post_data}')
                            # basic 参数: auth=(temp['bs_user'], temp['bs_pwd'])
                            result = mtd(temp['url'], verify=False, params=post_data, headers=headers, timeout=(3, 120))
                        else:
                            result = mtd(temp['url'], params=None, verify=False, headers=headers, timeout=(3, 120))
                        status = result.status_code
                        res_time = int(result.elapsed.total_seconds() * 1000)  # 时间为秒*1000 毫秒
                        response_time = res_time if res_time else 0
                        # data = None
                        # try:
                        #     data = json.loads(result.json())
                        # except:
                        #     pass

                        # 两个同时存在
                        # if temp['status'] is not None and len(temp['keyword']) > 0:
                        #     # public.print_log(f'|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||')
                        #     n = 0
                        #     text = result.content.decode('utf-8')
                        #     # 没返回状态码 用关键字查
                        #     if status is None:
                        #         if str(text).find(temp['keyword']) > -1:
                        #             n = 1
                        #             break
                        #     # 有状态码 和 关键字
                        #     # text = result.content.decode('utf-8')
                        #     if str(text).find(temp['keyword']) > -1:
                        #         n = 1
                        #         break
                        #
                        #     stu_list = temp['status'].split(',')  # ['200-299', '300-300']
                        #     for i in stu_list:
                        #         start_end = i.split('-')  # ['200', '299']
                        #         n = 1 if int(start_end[0]) <= int(status) <= int(start_end[1]) else 0
                        #         # 成功停止重试
                        #         if n == 1:
                        #             break
                        #         else:
                        #             continue
                        #     flag = True if n == 1 else False

                        # 只有状态码
                        if temp['status'] is not None:
                            public.print_log('____只有状态码 配置:{}_______响应:{}'.format(temp['status'], status))
                            # 状态码为空 不能比较
                            if status is None:
                                flag = False
                                continue
                            s = temp['status']
                            stu_list = s.split(',')
                            for i in stu_list:
                                start_end = i.split('-')  # ['200', '299']
                                if int(start_end[0]) <= int(status) <= int(start_end[1]):
                                    flag = True
                                    break
                                else:
                                    flag = False

                        # 只有关键字
                        # if len(temp['keyword']) > 0:
                        #     public.print_log(f'_______________________只有关键字判断________________________________')
                        #     text = result.content.decode('utf-8')
                        #     if str(text).find(temp['keyword']) > -1:
                        #         flag = True
                        #         break
                    except BaseException as e:
                        print('Unfortunitely -- An Unknow Error Happened')
                        public.print_exc_stack(e)
                        flag = False
                        continue
                    if flag:
                        break

                ececute_time = int(time.time())
                lst.append({
                    'uid': temp['uid'],
                    'http_id': temp['id'],
                    'response': status,
                    'response_time': response_time,
                    'start_time': start_time,  # 证书开始时间
                    'end_time': end_time,  # 证书结束时间
                    'issuer': issuer,  # 证书签发信息
                    'subject': subject,  # 证书信息
                    'is_ok': int(flag),
                    'node': q,
                    'create_time': ececute_time,
                })

            else:  # 调用其他节点
                while n < temp['count']:
                    n += 1
                    res = public.send_agent_msg(
                        public.get_serverid_bysid(q),
                        'vocationalwork copy',
                        '方法名',
                        pdata=public.g_pdata({
                            'url': temp['url'],
                            'status': temp['status'],
                            'body': temp['body'],
                            'method': ('get', 'post')[int(temp['method'])],
                            'keyword': temp['keyword'],
                            'is_basic': temp['is_basic'],
                            'bs_user': temp['bs_user'],
                            'bs_pwd': temp['bs_pwd'],
                        }))
                    # data = public.get_agent_msg(res)
                    # res = {
                    #     'response': status,  # 响应状态码
                    #     'response_time': response_time,  # 响应时间 ms
                    #     'is_ok': Ture  # 是否连通 bool
                    # }
                    if res['is_ok']:
                        flag = True
                        break
                    else:
                        flag = False
                    ececute_time = int(time.time())
                    lst.append({
                        'uid': temp['uid'],
                        'http_id': temp['id'],
                        'response': res['status'],
                        'response_time': res['response_time'],
                        'start_time': start_time,
                        'end_time': end_time,
                        'issuer': issuer,
                        'subject': subject,
                        'is_ok': int(flag),
                        'node': q,
                        'create_time': ececute_time,
                    })

        res = {'insert_data': lst}
        # 缓存执行完的时间
        public.cache_set(f"http_ececute_time:{temp['id']}", ececute_time, 600)
        if temp['warning']:
            warning_type = 'http监控告警'
            notify_content = ''
            ok = 0
            # 检查上一次告警时间 满足条件
            if temp['last_warning_time'] == 0 or int(temp['last_warning_time'] + 1800) < int(
                    time.time()):

                # 失败时告警  设置了失败且失败
                if temp['warning_mode'] == 0 and int(flag) == 0:
                    # monitor_mode = '响应状态码' if temp['monitor_mode'] == 0 else '关键字'
                    notify_content = f'匹配失败'
                    ok = 1

                # 成功时告警 设置了成功且成功
                if temp['warning_mode'] == 1 and int(flag) == 1:
                    # monitor_mode = '响应状态码' if temp['monitor_mode'] == 0 else '关键字'
                    notify_content = f'匹配成功'
                    ok = 1

                # 满足告警条件 进行告警
                if ok == 1:
                    public.print_log(f'$$$$$$$$$$$$$$$$$-------满足告警条件 进行告警-----$$$$$$$$$$$$$$$$$$$$$$$$')

                    # 更新上一次告警时间
                    basic_monitor_obj.db_easy('availability_http') \
                        .where('id', temp['id']) \
                        .update({'last_warning_time': cur_time})

                    # 时间格式转换 秒时间戳改格式
                    times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
                    send_msg = [
                        f'> 告警类型：{warning_type}',
                        f'> 推送时间: {times}',
                        f'> 告警任务名: {temp["task_name"]}',
                        f'> 告警域名: {temp["url"]}',
                        '> 告警消息：[{}]:{}'.format(temp["url"], notify_content),
                        '',
                        '请尽快处理',
                    ]

                    warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','))

                    # 更新上一次告警时间
                    basic_monitor_obj.db_easy('availability_http') \
                        .where('id', temp['id']) \
                        .update({'last_warning_time': cur_time})

                    res['warning_logs'] = {
                        'task_id': temp['id'],
                        'type': warning_type,
                        'content': '\n'.join(send_msg),
                        'task_name': temp['task_name'],
                        'push_methods': temp['push_methods'],
                        'subject': f'告警域名: {temp["url"]}',
                        'message': notify_content,
                    }

        return res

    def execute_http_task(self, args=None):
        '''
            @name 执行ping监控任务
            @author Law Lt <2023-02-24>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @arg    keyword<string> 关键字
            @return dict
        '''

        # 获取检测监控列表          暂停
        http_list = basic_monitor_obj.db_easy('availability_http') \
            .where('suspend=?', 0) \
            .order('create_time', 'desc') \
            .select()

        insert_data = []
        warning_logs = []

        with ThreadPoolExecutor(max_workers=100) as t:
            ts = []

            for temp in http_list:
                f = t.submit(self.__http_task_help, temp)
                ts.append(f)

            for f in ts:
                res = f.result()

                if not res:
                    continue

                if 'insert_data' in res:
                    insert_data.extend(res['insert_data'])

                if 'warning_logs' in res:
                    warning_logs.append(res['warning_logs'])

        # 记录http监控结果  写入信息表
        with monitor_db_manager.db_mgr('availability_http_info') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            db.query() \
                .name("availability_http_info") \
                .insert_all(insert_data)

            # 提交事务
            db.commit()

        # 批量写入告警日志
        if len(warning_logs) > 0:
            # 记录warning结果  写入表
            with monitor_db_manager.db_mgr('availability_wanrning_log') as db:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name("availability_wanrning_log") \
                    .insert_all(warning_logs)

                # 提交事务
                db.commit()

        return True

    def add_http_task(self, args):
        '''
        @name 添加监控http/https任务
        @author <2023-03-2>
        @arg    协议 http/https
        @return dict
        '''
        uid = public.bt_auth('uid')
        add_type = args.get("add_type", 0)
        task_name = args.get("task_name", '')
        url = args.get("url", None)
        method = args.get("method", 0)
        frequency = args.get("frequency", 20)
        status = args.get("status", '')
        count = args.get("count", 2)
        body = args.get("body", None)
        head = args.get("head", None)
        warning = args.get("warning", 0)
        nodes = args.get("nodes", '0')
        keyword = args.get("keyword", None)
        warning_mode = args.get("warning_mode", 0)
        push_methods = args.get("push_methods", '')
        is_basic = args.get("is_basic", 0)
        bs_user = args.get("bs_user", '')
        bs_pwd = args.get("is_basic", '')
        ase_bs_user = public.encrypt_password(bs_user) if len(bs_user) > 0 else ''
        ase_bs_pwd = public.encrypt_password(bs_pwd) if len(bs_pwd) > 0 else ''

        if int(add_type) not in [0, 1]:
            return public.error("add_type 参数错误！")
        if basic_monitor_obj.db_easy('availability_http').where("uid=? AND task_name=?", [uid, task_name]).exists():
            return public.error('任务名已存在')
        if url is None:
            return public.error("缺少参数：url")
        if int(method) not in [0, 1, 2, 3]:
            return public.error("缺少参数：method")
        temp = {
            "uid": uid,
            "method": int(method),
            "status": status,
            "frequency": int(frequency),
            "count": int(count),
            "body": body,
            "head": head,
            "warning": int(warning),
            "nodes": nodes,
            "keyword": keyword,
            "warning_mode": int(warning_mode),
            'push_methods': push_methods,
            'is_basic': int(is_basic),
            'bs_user': ase_bs_user,
            'bs_pwd': ase_bs_pwd,
        }

        # 扫描添加 可能批量
        if int(add_type) == 1:
            url_list = url.split(',')  # https://111,https://222
            for i in url_list:
                temp['add_type'] = 1
                temp['url'] = i
                temp['task_name'] = i
                with monitor_db_manager.db_mgr('availability_http') as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        db.query().name('availability_http').insert(temp)

                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 打印异常堆栈
                        public.print_exc_stack(e)
                        return public.error(f'添加失败:{e}')
                public.WriteLog('业务监控', '添加HTTP监控任务[%s] 成功' % i)
        else:
            temp['add_type'] = 0
            temp['url'] = url
            temp['task_name'] = task_name
            # 添加 http配置表
            with monitor_db_manager.db_mgr('availability_http') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query().name('availability_http').insert(temp)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    return public.error(f'添加失败:{e}')
            public.WriteLog('业务监控', '添加HTTP监控任务[%s] 成功' % task_name)
        return public.success("添加http监控任务成功!")

    def remove_http_task(self, args):
        '''
        @name 删除http/https监控任务
        @author <2023-02-25>
        @return dict
        '''
        # 接收要删除的任务列表 逗号隔开
        ids = args.get('ids', None)

        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')

        # 批量删除
        for i in id_list:
            data = basic_monitor_obj.db_easy('availability_http') \
                .where('id=?', int(i)) \
                .find()

            basic_monitor_obj.db_easy('availability_http') \
                .where('id=?', int(i)) \
                .delete()

            # 删除任务相关的记录表
            basic_monitor_obj.db_easy('availability_http_info') \
                .where('http_id=?', int(i)) \
                .delete()

            # 删除任务告警记录表
            basic_monitor_obj.db_easy('availability_wanrning_log') \
                .where('task_id=?', int(i)) \
                .delete()

            # 记录日志
            public.WriteLog('业务监控', '删除HTTP监控任务[%s] 成功' % data['task_name'])
        return public.success('删除HTTP监控任务成功')

    def update_http_task(self, args):
        '''
        @name 编辑/修改http/https监控任务
        @author <2023-02-25>
        @return dict
        '''
        uid = public.bt_auth('uid')
        new_data = {}
        id_ = args.get('id')
        dicts = {}
        old = basic_monitor_obj.db_easy('availability_http').where("id=?", id_).find()
        # old = basic_monitor_obj.db_easy('availability_http').where("uid=? AND id=?", [uid, id_]).find()
        if "task_name" in args:
            ta_name = args.get('task_name')
            # 修改了任务名
            if old['task_name'] != ta_name:
                # 管理员跳过重名检测
                if uid == 1:
                    new_data["task_name"] = ta_name
                else:
                    # 修改后的任务名在当前用户数据库是否有重名
                    if basic_monitor_obj.db_easy('availability_http')\
                            .where("uid=? AND task_name=?", [uid, ta_name])\
                            .exists():
                        return public.error('任务名已存在')
                    new_data["task_name"] = ta_name

        if "url" in args:
            new_data["url"] = args.get('url')
            if old['url'] != new_data["url"]:
                dicts['url修改为'] = new_data["url"]

        if "method" in args:
            new_data["method"] = int(args.get('method'))
            if old['method'] != new_data["method"]:
                dicts['请求方法修改为'] = 'get' if new_data["method"] == 0 else 'post'

        if "status" in args:
            new_data["status"] = args.get('status')
            if old['status'] != new_data["status"]:
                dicts['匹配的状态码修改为'] = new_data["status"]

        if "warning" in args:
            new_data["warning"] = int(args.get('warning'))
            if old['warning'] != new_data["warning"]:
                dicts['告警'] = '关闭' if new_data["warning"] == 0 else '开启'

        if "keyword" in args:
            new_data["keyword"] = args.get('keyword')
            if old['keyword'] != new_data["keyword"]:
                dicts['关键字修改为'] = new_data["keyword"]

        if "suspend" in args:
            new_data["suspend"] = int(args.get('suspend'))
            if old['suspend'] != new_data["suspend"]:
                dicts['任务'] = '执行' if new_data["suspend"] == 0 else '暂停'

        if "is_basic" in args:
            new_data["is_basic"] = int(args.get('is_basic'))
            if old['is_basic'] != new_data["is_basic"]:
                dicts['basic认证'] = '关闭' if new_data["is_basic"] == 0 else '开启'

        if "nodes" in args:
            new_data["nodes"] = args.get('nodes')
            if old['nodes'] != new_data["nodes"]:
                dicts['节点修改为'] = new_data["nodes"]

        if "bs_user" in args:
            bs_user = args.get('bs_user')
            new_data["bs_user"] = public.encrypt_password(bs_user)
            if old['bs_user'] != new_data["bs_user"]:
                dicts['basic认证'] = '修改用户名'

        if "bs_pwd" in args:
            bs_pwd = args.get('bs_pwd')
            new_data["bs_pwd"] = public.encrypt_password(bs_pwd)
            if old['bs_pwd'] != new_data["bs_pwd"]:
                dicts['basic认证'] = '修改密码'

        if "frequency" in args:
            new_data["frequency"] = args.get('frequency')
        if "count" in args:
            new_data["count"] = args.get('count')
        if "body" in args:
            new_data["body"] = args.get('body')
        if "head" in args:
            new_data["head"] = args.get('head')
        if "warning_mode" in args:
            new_data["warning_mode"] = args.get('warning_mode')
        if "push_methods" in args:
            new_data["push_methods"] = args.get('push_methods')

        new_data["update_time"] = int(time.time())
        with monitor_db_manager.db_mgr('availability_http') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('availability_http') \
                    .where("id=?", id_) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e
            # 记录日志
            info = basic_monitor_obj.db_easy('availability_http') \
                .where("id=?", id_) \
                .find()
            # IP 端口 被修改
            if dicts:
                public.WriteLog('业务监控', '修改HTTP监控任务成功!  原名[%s] 现为[%s]  %s' % (old['task_name'], info['task_name'], dicts))
            else:
                public.WriteLog('业务监控', '修改HTTP监控任务[%s] 成功 ' % info['task_name'])

        return public.success('修改HTTP监控任务成功')

    def suspend_http_task(self, args):
        '''
        @name 批量暂停ping监控任务
        @arg    ids<str>  需要暂停的任务id 逗号隔开
        '''
        ids = args.get('ids', None)
        if ids is None:
            return public.return_error('缺少参数: ids')
        id_list = ids.split(',')
        for i in id_list:
            info = basic_monitor_obj.db_easy('availability_http').where('id=?', int(i)).find()
            suspend = 1 if info['suspend'] == 0 else 0

            with monitor_db_manager.db_mgr('availability_http') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name('availability_http') \
                        .where("id=?", int(i)) \
                        .update({"suspend": suspend})
                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)
                    raise e

            # 记录日志
            public.WriteLog('业务监控', '暂停http监控任务[%s] 成功' % (info['task_name']))

        return public.success('批量暂停http监控任务成功')

    def get_server_urls(self, args):
        '''
        @name 获取服务器下的域名
        @args
        '''

        # 先从缓存取上次执行时间 缓存没有 取数据库取
        server_url_ = public.cache_get(f"get_server_urls")
        if server_url_:
            # public.print_log(f'有缓存 从缓存取')
            server_url = json.loads(server_url_)

        else:
            # public.print_log(f' 无缓存 查数据库')
            sid_list = warning_obj.db_easy('servers').field('sid', 'ip', 'remark').select()
            server_url = []
            for i in sid_list:
                with monitor_db_manager.MonitorDbManager(i['sid']).db_mgr('nginx_stats_info') as db:
                    # nginx_stats_info = db.query().name('nginx_stats_info').find()
                    website_list = db.query().name('nginx_stats_info').value('website_list')

                    if website_list is None:
                        continue
                    nginx_stats_info = {'sid': i['sid'],
                                        's_ip': i['ip'],
                                        's_remark': i['remark'],
                                        "website_list": json.loads(website_list) if isinstance(website_list,
                                                                                               str) else website_list}

                    server_url.append(nginx_stats_info)
            server_url_ = json.dumps(server_url, ensure_ascii=False)

            # 缓存执行完的时间
            public.cache_set("get_server_urls", server_url_, 600)

        return public.success(server_url)


