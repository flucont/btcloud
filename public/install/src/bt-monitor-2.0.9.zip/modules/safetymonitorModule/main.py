# encoding: utf-8
import re, time, json, os
import core.include.public as public
from core.include.monitor_helpers import monitor_db_manager, basic_monitor_obj
from concurrent.futures import ThreadPoolExecutor


class main:
    '''
        @name 安全监控
        @author Zhj<2023-03-21>
    '''
    def get_bug_list(self, args):
        '''
            @name 获取漏洞扫描列表
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        bug_type = args.get('bug_type', None)
        level = args.get('level', None)
        status = args.get('status', None)
        usable = args.get('usable', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            query = db.query().name('server_bugs')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if level is not None:
                query.where('level', int(level))

            if bug_type is not None:
                query.where('type', bug_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询cve编号
                if re.match(r'^cve-\d+-\d+', keyword, flags=re.IGNORECASE):
                    query.where('`cve_id` like ?', '{}%'.format(keyword))
                    return

                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`vuln_name` like ?',
                    '`soft_name` like ?',
                    '`file_path` like ?',
                    '`tag` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None
        handled_operators = None

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query()\
                .name('users')\
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list']))))\
                .field('uid', 'username')\
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['tag'] = json.loads(item['tag'])
            except:
                item['tag'] = []

        return public.success(ret)

    def ignore_bug(self, args):
        '''
            @name 忽略漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            db.query()\
                .name('server_bugs')\
                .where_in('vuln_id', vuln_id)\
                .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def handle_bug(self, args):
        '''
            @name 处理漏洞
            @author Zhj<2023-03-21>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db:
            db.query()\
                .name('server_bugs')\
                .where_in('vuln_id', vuln_id)\
                .update({
                    'status': 2 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'fix_remark': remark,
                    'handled_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def re_scan_bug(self, args):
        '''
            @name 重新扫描漏洞
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：bug_id格式错误')

        vuln_id = str(vuln_id).split(',')

        server_id = public.get_serverid_bysid(sid)

        ret = []

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for v in vuln_id:
                params = {
                    'vuln_id': v,
                }
                f = t.submit(self.__re_scan_bug_helper, server_id, params)
                fs.append(f)

            for f in fs:
                if ret is None:
                    continue
                ret.append(f.result())

        if len(ret) == 0:
            return public.error('扫描失败，请重试~')

        new_ret = []
        for item in ret:
            if isinstance(item, str):
                try:
                    item = json.loads(item)
                except: continue

            if 'body' not in item or not isinstance(item['body'], list) or len(item['body']) < 1:
                continue

            new_ret.extend(item['body'])

        if len(new_ret) > 0:
            # 更新主机漏洞列表
            basic_monitor_obj.update_server_bugs(sid, new_ret)

        return public.success('扫描成功')

    def re_scan_bug_all(self, args):
        '''
            @name 重新扫描漏洞(全部)
            @author Zhj<2023-03-22>
            @param  args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'vul_scan',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机漏洞列表
        basic_monitor_obj.update_server_bugs(sid, data.get('body', []))

        return public.success('扫描成功')

    # 重新扫描漏洞(子线程处理函数)
    def __re_scan_bug_helper(self, server_id, params):
        res = public.send_agent_msg(
            server_id,
            'vul_scan',
            'ScanOne',
            timeout=60,
            pdata=public.g_pdata(params))

        data = public.get_agent_msg(res)

        if not data:
            return None

        return data

    # 挖矿木马扫描

    def get_mining_list(self, args):
        '''
            @name 获取主机挖矿木马列表
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        mining_type = args.get('mining_type', None)
        status = args.get('status', None)
        usable = args.get('usable', None)

        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            query = db.query().name('server_minings')

            if status is not None and len(str(status)) > 0:
                query.where('status', int(status))

            if mining_type is not None:
                query.where('type', mining_type)

            if usable is not None:
                query.where('usable', int(usable))

            # 添加关键字查询
            def query_handler(query, keyword):
                # 查询标题 OR 软件名称或工具名称 OR 文件路径 OR 漏洞特征 OR 漏洞描述 OR 修复建议 OR 处理人备注
                where_or = [
                    '`title` like ?',
                    '`ps` like ?',
                    '`suggestions` like ?',
                    '`fix_remark` like ?',
                ]

                query.where(' OR '.join(where_or), ['%{}%'.format(keyword) for i in range(len(where_or))])

            public.add_retrieve_keyword_query(query, args, query_handler)

            # 添加排序
            public.add_retrieve_sort_query(query, args)

            # 分页查询
            ret = public.simple_page(query, args)

        # 添加操作人信息
        ignore_operators = None
        handled_operators = None

        with monitor_db_manager.db_mgr('safety') as db:
            ignore_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['ignore_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

            handled_operators = db.query() \
                .name('users') \
                .where_in('uid', list(set(map(lambda x: x['handle_operator'], ret['list'])))) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['ignore_operator_username'] = ignore_operators.get(item['ignore_operator'], '--')
            item['handle_operator_username'] = handled_operators.get(item['handle_operator'], '--')
            try:
                item['process_info'] = json.loads(item['process_info'])
            except:
                item['process_info'] = None

        return public.success(ret)

    def ignore_mining(self, args):
        '''
            @name 忽略主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                    'status': int(ignored),
                    'ignore_operator': uid,
                    'ignore_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def handle_mining(self, args):
        '''
            @name 处理主机挖矿木马
            @author Zhj<2023-03-27>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)
        vuln_id = args.get('vuln_id', None)
        remark = args.get('remark', '')
        handled = args.get('handled', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if vuln_id is None:
            return public.error('缺少参数：vuln_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(vuln_id)):
            return public.error('参数：vuln_id格式错误')

        vuln_id = str(vuln_id).split(',')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db:
            db.query() \
                .name('server_minings') \
                .where_in('vuln_id', vuln_id) \
                .update({
                    'status': 2 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'fix_remark': remark,
                    'handled_time': int(time.time()),
                })

        # TODO 操作日志
        # public.WriteLog('安全监控', '')

        return public.success('操作成功')

    def re_scan_mining_all(self, args):
        '''
            @name 重新扫描主机挖矿木马
            @author Zhj<2023-03-28>
            @param args<dict> 请求参数
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'detect_mining',
            'VulScan',
            timeout=60)

        data = public.get_agent_msg(res)

        if not data:
            return public.error('扫描失败，请重试~')

        # 更新主机挖矿木马列表
        basic_monitor_obj.update_server_minings(sid, data.get('body', []))

        return public.success('扫描成功')

    # 病毒扫描
    def __scan_task_help(self, sid, action, params=None):
        '''
            @name 病毒扫描帮助函数
            @author Zhj<2023-04-03>
            @param sid<int>         主机ID
            @param action<string>   接口名称
            @param params<?dict>    请求参数
            @return None|dict
        '''
        pdata = {}

        if params is not None and isinstance(params, dict):
            pdata.update(params)

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            'scanning',
            action,
            timeout=60,
            pdata=public.g_pdata(pdata))

        if not res:
            return None

        return res.get('body', {}).get('body', None)

    # 打印日志
    def __log(self, content):
        with open('/www/server/bt-monitor/logs/ppp.log', 'a') as fp:
            fp.write('{}\n'.format(content))

    # 更新扫描任务进度
    def __update_scan_task_progress(self, task_id, sid_list=None):
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 没有传主机ID列表时从数据库获取
            if sid_list is None:
                sid_list = db.query()\
                    .name('server_malicious_scan_task')\
                    .where('task_id', task_id)\
                    .column('sid')

            total_progress = db.query()\
                .name('server_malicious_scan_task')\
                .where_in('sid', sid_list)\
                .where('status > ?', 0)\
                .value('sum(`progress`)')

            if total_progress is None:
                total_progress = 0

            sid_list_len = len(sid_list)
            sid_list = db.query()\
                .name('server_malicious_scan_task')\
                .where('task_id', task_id)\
                .where_in('sid', sid_list)\
                .where('status', 0)\
                .column('sid')

        # 扫描任务已经完成
        if not sid_list or len(sid_list) == 0:
            return

        cur_time = int(time.time())
        update_data = {}
        finished_count = sid_list_len - len(sid_list)
        latest_finished_time = 0
        result_insert_data = []
        malicious_file_set = set()
        malicious_dir_set = set()
        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []
            fs2 = []

            # 获取任务进度
            for sid in sid_list:
                fs.append((t.submit(self.__scan_task_help, sid, 'GetIDInfo', {
                    'id': str(task_id),
                }), sid))

            for (f, sid) in fs:
                res = f.result()

                if not res:
                    continue

                # self.__log(res)

                update_data[sid] = {
                    'scan_pid': res['scan_pid'],
                    'scan_process_exists': int(res['pid_status']),
                    'progress': 0 if int(res['count']) == 0 else round(res['scan_count'] / res['count'] * 10000),
                    'start_time': res['start_time'],
                    'finish_time': 0 if res['pid_status'] else res['end_time'],
                }

                total_progress += update_data[sid]['progress']

                if update_data[sid]['finish_time'] > latest_finished_time:
                    latest_finished_time = update_data[sid]['finish_time']

                # 当扫描完成时，获取扫描结果
                if not res['pid_status']:
                    if int(res['count']) > 0 and int(res['scan_count']) >= int(res['count']):
                        update_data[sid]['status'] = 1
                    else:
                        update_data[sid]['status'] = 2

                    finished_count += 1
                    fs2.append((t.submit(self.__scan_task_help, sid, 'GetRe', {
                        'id': str(task_id),
                    }), sid, update_data[sid]['finish_time'] or cur_time))

            fs = None
            del (fs,)

            for (f, sid, finish_time) in fs2:
                res = f.result()

                if not res or 'data' not in res:
                    continue

                # 恶意文件集合
                malicious_files = set()

                for item in res.get('data', '').split('\n'):
                    try:
                        malicious_file = json.loads(item.strip())
                    except:
                        continue

                    if 'path' not in malicious_file or len(malicious_file['path']) == 0:
                        continue

                    malicious_files.add(malicious_file['path'])

                for malicious_file in malicious_files:
                    malicious_dir = os.path.dirname(malicious_file)
                    result_insert_data.append({
                        'sid': sid,
                        'task_id': task_id,
                        'level': 2,
                        'file_path': malicious_file,
                        'file_dir': malicious_dir,
                        'create_time': finish_time,
                    })
                    malicious_file_set.add(malicious_file)
                    malicious_dir_set.add(malicious_dir)

            fs2 = None
            del (fs2,)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            try:
                # 扫描任务状态
                task_status = 0
                task_finish_time = 0
                if finished_count == sid_list_len:
                    task_status = 1 if round(total_progress / sid_list_len) > 0 else 2
                    task_finish_time = latest_finished_time

                # 更新扫描任务状态与进度
                db.query() \
                    .name('malicious_scan_tasks') \
                    .where('id', task_id) \
                    .update({
                        'status': task_status,
                        'scan_progress': round(total_progress / sid_list_len),
                        'finish_time': task_finish_time,
                    })

                for (sid, up_data) in update_data.items():
                    db.query()\
                        .name('server_malicious_scan_task')\
                        .where('task_id', task_id)\
                        .where('sid', sid)\
                        .update(up_data)

                # 新增扫描结果
                if len(result_insert_data) > 0:
                    # 检查白名单
                    white_list_file = db.query()\
                        .name('malicious_white_lists')\
                        .where('is_dir', 0)\
                        .where_in('file_path', list(malicious_file_set))\
                        .field('id', 'file_path')\
                        .column('id', 'file_path')

                    white_list_dir = db.query()\
                        .name('malicious_white_lists')\
                        .where('is_dir', 1)\
                        .where_in('file_path', list(malicious_dir_set))\
                        .field('id', 'file_path')\
                        .column('id', 'file_path')

                    # self.__log(white_list_file)
                    # self.__log(white_list_dir)

                    for item in result_insert_data:
                        # self.__log(item)
                        try:
                            # 检查文件
                            if item['file_path'] in white_list_file:
                                item['white_list_id'] = white_list_file[item['file_path']]
                                continue

                            # 检查目录
                            if item['file_dir'] in white_list_dir:
                                item['white_list_id'] = white_list_dir[item['file_path']]
                                continue

                            # 没有在白名单内
                            item['white_list_id'] = 0
                        finally:
                            del (item['file_dir'],)

                    # 批量插入扫描结果
                    db.query()\
                        .name('malicious_scan_results')\
                        .insert_all(result_insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

    # 统计病毒扫描
    def get_scan_dashboard(self, args):
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 统计扫描任务
            task_statistics = db.query()\
                .name('malicious_scan_tasks')\
                .field('sum(case `status` when 0 then 1 else 0 end) as `scanning`',
                       'sum(case `status` when 1 then 1 else 0 end) as `finish`',
                       'sum(case `status` when 2 then 1 else 0 end) as `fail`',
                       'max(`create_time`) as `last_time`')\
                .find()

            # 统计扫描结果
            result_statistics = db.query()\
                .name('malicious_scan_results')\
                .field('count(*) as `total`',
                       'sum(case when `level` = 3 and `status` = 0 then 1 else 0 end) as `danger`',
                       'sum(case when `level` = 2 and `status` = 0 then 1 else 0 end) as `high`',
                       'sum(case when `level` = 1 and `status` = 0 then 1 else 0 end) as `middle`',
                       'sum(case when `level` = 0 and `status` = 0 then 1 else 0 end) as `low`',
                       'sum(case `status` when 2 then 1 else 0 end) as `ignored`',
                       'sum(case `status` when 1 then 1 else 0 end) as `handled`',
                       'sum(case `status` when 0 then 1 else 0 end) as `unhandled`',
                       'sum(case when `white_list_id` > 0 then 1 else 0 end) as `in_white`')\
                .find()

            # 统计白名单数量
            whites = db.query()\
                .name('malicious_white_lists')\
                .count()

        ret = {
            'whites': whites,
        }

        ret.update(task_statistics)
        ret.update(result_statistics)

        return public.success(ret)

    def add_scan_task(self, args):
        '''
            @name 添加扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        scan_dir = args.get('scan_dir', None)
        scan_type = args.get('scan_type', 0)  # 扫描类型 0-全盘扫描 1-快速扫描 2-指定目录扫描
        name = args.get('name', None)
        uid = public.bt_auth('uid')

        if sid is None:
            return public.error('缺少参数：sid')

        if name is None:
            return public.error('缺少参数：name')

        if len(name) == 0:
            return public.error('任务名称不能为空')

        if scan_dir is None or len(scan_dir) == 0:
            if int(scan_type) == 0:
                scan_dir = '/'
            elif int(scan_type) == 1:
                scan_dir = '/www'
            else:
                return public.error('缺少参数：scan_dir')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
            return public.error('参数：sid格式错误')

        sid = str(sid).split(',')

        # 添加扫描任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            if db.query().name('malicious_scan_tasks').where('name', name).exists():
                return public.error('任务名称【{}】已经存在'.format(name))

            # 关闭事务自动提交
            db.autocommit(False)

            try:
                task_id = db.query().name('malicious_scan_tasks').insert({
                    'creator': uid,
                    'scan_dir': scan_dir,
                    'scan_type': int(scan_type),
                    'name': name,
                })

                insert_data = []

                for item in sid:
                    insert_data.append({
                        'task_id': task_id,
                        'sid': item,
                    })

                db.query().name('server_malicious_scan_task').insert_all(insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for item in sid:
                fs.append(t.submit(self.__scan_task_help, item, 'ScanDir', {
                    'dir': scan_dir,
                    'id': str(task_id),
                }))

            for f in fs:
                f.result()

        return public.success('添加扫描任务成功')

    def get_scan_task_list(self, args):
        '''
            @name 获取扫描任务列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 第一次查询出任务ID
            query = db.query()\
                .name('malicious_scan_tasks') \
                .field('id', 'scan_type', 'creator', 'status', 'scan_progress / 100 as scan_progress',
                       'finish_time', 'create_time', 'scan_dir', 'name')
            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('smst.sid', db.query()\
                    .name('server_malicious_scan_task')\
                    .where_in('sid', str(sid).split(','))\
                    .column('distinct `task_id`'))

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('name like ? OR scan_dir like ?', [tmp, tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

            # 任务ID
            task_id_list = list(set(map(lambda x: x['id'], ret['list'])))

            # 查询任务下主机数
            server_count = db.query()\
                .name('server_malicious_scan_task')\
                .where_in('task_id', task_id_list)\
                .field('task_id', 'count(*) as cnt')\
                .group('task_id')\
                .column('cnt', 'task_id')

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['creator'], ret['list'])))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['creator_username'] = users.get(item['creator'], '')
            item['server_count'] = server_count.get(item['id'], 0)

        return public.success(ret)

    def get_server_scan_task_list(self, args):
        '''
            @name 获取扫描任务下的主机列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        task_id = args.get('task_id', None)

        if task_id is None:
            return public.error('缺少参数：task_id')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            server_tasks = db.query()\
                .name('server_malicious_scan_task')\
                .where('task_id', int(task_id))\
                .field('sid', 'scan_pid', 'scan_process_exists', 'progress / 100 as progress', 'start_time',
                       'status', 'finish_time', 'stop_operator', 'stop_time')\
                .select()

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers')\
            .where_in('sid', list(map(lambda x: x['sid'], server_tasks)))\
            .field('sid', 'ip', 'remark')\
            .column(None, 'sid')

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['stop_operator'], server_tasks)))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query()\
                .name('users')\
                .where_in('uid', uid_list)\
                .field('uid', 'username')\
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in server_tasks:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            item['stop_operator_username'] = users.get(item['stop_operator'], '')

        return public.success(server_tasks)

    def get_scan_task_result(self, args):
        '''
            @name 获取扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        task_id = args.get('task_id', None)
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        in_white = args.get('in_white', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query()\
                .name('malicious_scan_results')\
                .alias('msr')\
                .join('malicious_scan_tasks as mst', 'msr.task_id=mst.id', 'left')\
                .field('msr.id', 'sid', 'task_id', 'mst.name as task_name', 'msr.status', 'level', 'white_list_id',
                       'handle_operator', 'handled_time', 'ignore_operator', 'ignore_time', 'msr.create_time',
                       'file_path', 'fix_remark', 'scan_dir')

            if task_id is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
                    return public.error('参数：task_id格式错误')
                query.where_in('task_id', str(task_id).split(','))

            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('sid', str(sid).split(','))

            if in_white is not None:
                if int(in_white) == 1:
                    query.where('`white_list_id` > 0')
                else:
                    query.where('white_list_id', 0)

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('name like ? OR scan_dir like ?', [tmp, tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('msr.create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('msr.create_time >= ? and msr.create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

        # 查询操作人信息
        uid_list = []
        map(lambda x: uid_list.extend([x['handle_operator'], x['ignore_operator']]), ret['list'])
        uid_list = list(set(uid_list))

        # 查询服务器信息
        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret['list']))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret['list']:
            item['handle_operator_username'] = users.get(item['handle_operator'], '')
            item['ignore_operator_username'] = users.get(item['ignore_operator'], '')
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')

        return public.success(ret)

    def stop_scan_task(self, args):
        '''
            @name 结束扫描任务
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        task_id = args.get('task_id', None)
        sid = args.get('sid', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if task_id is None:
            return public.error('缺少参数：task_id')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
            return public.error('参数：task_id格式错误')

        # 获取正在扫描中的任务
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query() \
                .name('server_malicious_scan_task') \
                .field('id', 'task_id', 'sid',  'status')\
                .where('status', 0)\
                .where_in('task_id', str(task_id).split(','))

            if sid is not None:
                if not re.match(r'^-?\d+(?:,-?\d+)*$', str(sid)):
                    return public.error('参数：sid格式错误')
                query.where_in('sid', str(sid).split(','))

            tasks = query.select()

        with ThreadPoolExecutor(max_workers=10) as t:
            fs = []

            for task in tasks:
                fs.append(t.submit(self.__scan_task_help, task['sid'], 'Kill', {'id': str(task['task_id'])}))

            for f in fs:
                f.result()

        task_id_set = set()
        id_set = set()

        task_id_set.add(int(task_id))

        for item in tasks:
            task_id_set.add(item['task_id'])
            id_set.add(item['id'])

        # 更新扫描任务状态
        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            db.query()\
                .name('server_malicious_scan_task')\
                .where('status', 0)\
                .where_in('id', list(id_set))\
                .update({
                    'status': 2,
                    'scan_process_exists': 0,
                    'stop_operator': uid,
                    'stop_time': cur_time,
                    'finish_time': cur_time,
                })

            db.query() \
                .name('malicious_scan_tasks') \
                .where('status', 0) \
                .where_in('id', list(task_id_set)) \
                .update({
                    'status': 2,
                    'stop_operator': uid,
                    'stop_time': cur_time,
                    'finish_time': cur_time,
                })

            # 提交事务
            db.commit()

        return public.success('操作成功')

    def ignore_scan_task_result(self, args):
        '''
            @name 忽略扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        result_id = args.get('result_id', None)
        ignored = args.get('ignored', None)
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if result_id is None:
            return public.error('缺少参数：result_id')

        if ignored is None:
            return public.error('缺少参数：ignored')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.query()\
                .name('malicious_scan_results')\
                .where_in('id', str(result_id).split(','))\
                .update({
                    'status': 2 if int(ignored) == 1 else 0,
                    'ignore_operator': uid,
                    'ignore_time': cur_time,
                })

        return public.success('操作成功')

    def handle_scan_task_result(self, args):
        '''
            @name 处理扫描结果
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        result_id = args.get('result_id', None)
        handled = args.get('handled', None)
        remark = args.get('remark', '')
        uid = public.bt_auth('uid')
        cur_time = int(time.time())

        if result_id is None:
            return public.error('缺少参数：result_id')

        if handled is None:
            return public.error('缺少参数：handled')

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(result_id)):
            return public.error('参数：result_id格式错误')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            db.query() \
                .name('malicious_scan_results') \
                .where_in('id', str(result_id).split(',')) \
                .update({
                    'status': 1 if int(handled) == 1 else 0,
                    'handle_operator': uid,
                    'handled_time': cur_time,
                    'fix_remark': remark,
                })

        return public.success('操作成功')

    def add_white_list(self, args):
        '''
            @name 目录/文件 加入白名单
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        name = args.get('name', None)
        ps = args.get('ps', '')
        file_path = args.get('file_path', None)
        only_dir = args.get('only_dir', 0)
        uid = public.bt_auth('uid')

        if name is None:
            return public.error('缺少参数：name')

        if file_path is None:
            return public.error('缺少参数：file_path')

        if int(only_dir) == 1:
            file_path = os.path.dirname(file_path)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            if db.query().name('malicious_white_lists').where('name', name).exists():
                return public.error('名称【{}】已存在'.format(name))

            # 关闭事务自动提交
            db.autocommit(False)

            try:
                white_id = db.query()\
                    .name('malicious_white_lists')\
                    .insert({
                        'file_path': file_path,
                        'is_dir': int(only_dir),
                        'creator': uid,
                        'name': name,
                        'ps': ps,
                    })

                opt = 'like' if int(only_dir) == 1 else '='

                # 检查结果，将符合条件的结果放入白名单中
                db.query()\
                    .name('malicious_scan_results')\
                    .where('white_list_id', 0)\
                    .where('`file_path` {} ?'.format(opt), file_path+('%' if int(only_dir) == 1 else ''))\
                    .update({
                        'white_list_id': white_id,
                    })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

                return public.error('添加失败：{}'.format(str(e)))


        return public.success('操作成功')

    def remove_white_list(self, args):
        '''
            @name 删除白名单
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        white_id = args.get('white_id', None)

        if not re.match(r'^-?\d+(?:,-?\d+)*$', str(white_id)):
            return public.error('参数：white_id格式错误')

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            # 关闭事务自动提交
            db.autocommit(False)

            try:
                db.query()\
                    .name('malicious_white_lists')\
                    .where('id > 0')\
                    .where_in('id', white_id)\
                    .delete()

                db.query()\
                    .name('malicious_scan_results')\
                    .where('white_list_id > 0')\
                    .where_in('white_list_id', white_id)\
                    .update({
                        'white_list_id': 0,
                    })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)

                return public.error('删除失败：{}'.format(str(e)))

        return public.success('操作成功')

    def get_white_list(self, args):
        '''
            @name 获取白名单列表
            @author Zhj<2023-04-04>
            @param args<dict> 请求参数列表
            @return dict
        '''
        query_date = args.get('query_date', None)

        with monitor_db_manager.db_mgr('malicious_scan') as db:
            query = db.query().name('malicious_white_lists')

            # 添加关键字查询
            def query_handler(query, keyword):
                tmp = '%{}%'.format(keyword)
                query.where('`name` like ? OR `ps` like ?', [tmp, tmp])

            public.add_retrieve_keyword_query(query, args, query_handler)

            query.order('create_time', 'desc')

            # 添加时间范围查询
            if query_date is not None and len(query_date) > 0:
                query.where('create_time >= ? and create_time <= ?', public.get_query_timestamp(query_date))

            # 分页查询
            ret = public.simple_page(query, args)

        # 查询操作人信息
        uid_list = list(set(map(lambda x: x['creator'], ret['list'])))

        with monitor_db_manager.db_mgr('safety') as db:
            users = db.query() \
                .name('users') \
                .where_in('uid', uid_list) \
                .field('uid', 'username') \
                .column('username', 'uid')

        # 组装服务器信息和操作人信息
        for item in ret['list']:
            item['creator_username'] = users.get(item['creator'], '')

        return public.success(ret)

    # 更新扫描任务进度
    def update_scan_task_progress(self, args=None):
        task_id = None

        if args is not None:
            task_id = args.get('task_id', None)
        
        task_id_list = None

        if task_id is not None and re.match(r'^-?\d+(?:,-?\d+)*$', str(task_id)):
            task_id_list = str(task_id).split(',')

        if task_id_list is None:
            with monitor_db_manager.db_mgr('malicious_scan') as db:
                # 获取扫描中的任务ID
                task_id_list = db.query()\
                    .name('malicious_scan_tasks')\
                    .where('status', 0)\
                    .column('id')

        for item in task_id_list:
            self.__update_scan_task_progress(int(item))

        return public.success('更新成功')
