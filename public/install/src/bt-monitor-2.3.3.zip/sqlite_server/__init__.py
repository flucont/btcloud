# -*- coding: utf-8 -*-

# from core.include.public import get_panel_path, import_via_loader

# from sqlite_server.sqlite_server import SqliteServer, SqliteClient, SqliteEasy, Db
# def import_via_loader(real_py_path):
#     import sqlite_server.PluginLoader as plugin_loader
#
#     module_obj = plugin_loader.get_module(real_py_path)
#
#     if not module_obj:
#         raise Exception('importError: {}'.format(real_py_path))
#
#     if isinstance(module_obj, dict):
#         if 'msg' not in module_obj:
#             raise Exception('importError: {}'.format(real_py_path))
#
#         raise Exception('importError: {}\n{}'.format(real_py_path, module_obj['msg']))
#
#     return module_obj
#
#
# import sqlite_server.sqlite_server
# sqlite_server = import_via_loader('/www/server/bt-monitor/sqlite_server/sqlite_server.py')
# SqliteServer = sqlite_server.SqliteServer
# SqliteClient = sqlite_server.SqliteClient
# SqliteEasy = sqlite_server.SqliteEasy
# Db = sqlite_server.Db
# acquire = sqlite_server.acquire

from sqlite_server.sqlite_server import SqliteServer, SqliteClient, SqliteEasy, Db, acquire
