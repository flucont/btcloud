# encoding: utf-8
import base64

from inspect import CO_ITERABLE_COROUTINE
import os, sys, re, time, json
from core import g
import core.include.public as public
from core.include.monitor_helpers import basic_monitor_obj, monitor_events
from core.include.monitor_exceptions import BtMonitorException
import core.include.monitor_enums as monitor_enums
from core.include.rbac import AccessDifference
import core.include.monitor_db_manager as monitor_db_manager

# monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))

from core.include.rbac import AccessIntersection


class main:
    '''
        @name 主机模块
        @author Zhj<2022-07-08>
    '''

    def set_status(self, args):
        '''
            @name 设置主机状态
            @auhtor Zhj<2022-07-08>
            @arg    sid<integer>    主机ID
            @arg    status<integer> 主机状态 0-离线 2-维护(关闭告警通知)
            @return dict
        '''
        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sid = args.get('sid', None)
        status = args.get('status', None)

        if sid is None:
            return public.return_error('缺少参数：sid')

        if status is None:
            return public.return_error('缺少参数：status')

        if int(status) not in [0, 2]:
            return public.return_error('无效的参数：status')

        # 查询主机信息
        server_info = basic_monitor_obj.db_easy('servers') \
            .where('sid=?', int(sid)) \
            .field('sid,is_authorized') \
            .find()

        # 查询主机是否存在
        if basic_monitor_obj.is_empty_result(server_info):
            return public.error('主机不存在')

        # 检查主机授权状态
        if int(server_info['is_authorized']) == 0:
            return public.error('主机未授权')

        update_data = {
            'update_time': int(time.time()),
        }

        # 设置离线
        if int(status) == 0:
            update_data['status'] = 0

        # 关闭告警检测
        elif int(status) == 2:
            update_data['allow_notify'] = 0

        # 更新主机状态
        basic_monitor_obj.db_easy('servers') \
            .where('sid=?', int(sid)) \
            .update(update_data)

        return public.success('操作成功')

    def set_remark(self, args):
        '''
            @name   设置主机备注
            @author Zhj<2022-07-13>
            @arg    sid<integer>    主机ID
            @arg    remark<string>  主机备注
            @return dict
        '''
        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sid = args.get('sid', None)
        remark = args.get('remark', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if remark is None:
            return public.error('缺少参数：remark')

        if len(remark) == 0:
            return public.error('备注不能为空')

        server_info = basic_monitor_obj.db_easy('servers') \
            .where('`sid` = ?', int(sid)) \
            .field('sid', 'is_authorized') \
            .find()

        if basic_monitor_obj.is_empty_result(server_info):
            return public.error('主机不存在')

        # 主机未授权
        if int(server_info['is_authorized']) == 0:
            return public.error('主机未授权')

        # 修改备注
        basic_monitor_obj.db_easy('servers') \
            .where('`sid` = ?', int(sid)) \
            .update({
            'remark': remark,
            'update_time': int(time.time()),
        })

        return public.success('操作成功')

    def cancel_maintence(self, args):
        '''
            @name 取消主机维护状态(启用告警通知)
            @author Zhj<2022-07-11>
            @arg    sid<integer>    主机ID
            @return dict
        '''
        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        basic_monitor_obj.db_easy('servers') \
            .where('`sid` = ?', int(sid)) \
            .where('`allow_notify` = 0') \
            .update({
            # 'status': 1 if public.cache_get('SERVER_CONNECTION_'+str(sid)) else 0,
            'allow_notify': 1,
            'update_time': int(time.time()),
        })

        return public.success('操作成功')

    def get_server_ip(self, args):
        '''
            @name 获取服务端IP信息
            @author Zhj<2022-07-08>
            @return dict
        '''
        ip_list = []

        internal_ips, published_ip = basic_monitor_obj.get_server_ip()

        ip_list.append(published_ip)
        ip_list += internal_ips

        # 获取最后一个输入IP
        last_ip = basic_monitor_obj.db_easy('server_ip_records') \
            .order('create_time', 'desc') \
            .value('ip')

        if last_ip is not None:
            ip_list.append(last_ip)

        return public.success(list(set(ip_list)))

    def add_server(self, args):
        '''
            @name 添加主机（获取安装脚本）
            @author Zhj<2022-07-08>
            @arg    server_ip<string> 服务器IP
            @return dict
        '''
        server_ip = args.get('server_ip', None)
        system = int(args.get('system', 0))

        if server_ip is None:
            return public.error('缺少参数：server_ip')

        if not public.is_ipv4(server_ip) and not public.is_ipv6(server_ip):
            return public.error('无效的IP地址')

        # public.print_log("++++++++++++++++{}".format(server_ip),_level="error")

        # 记录新IP
        if not basic_monitor_obj.db_easy('server_ip_records').where('ip=?', server_ip).field('id').exists():
            basic_monitor_obj.db_easy('server_ip_records') \
                .insert({
                'ip': server_ip,
            })

        token_path = '{}/config/token.pl'.format(public.get_panel_path())
        token = public.readFile(token_path) if os.path.exists(token_path) else ''
        if system == 0:
            ret = 'curl -sSO https://download.bt.cn/install/btmonitoragent.sh && bash btmonitoragent.sh https://{}:{} {}'.format(
                server_ip,
                public.get_panel_port(),
                token
            )
        else:
            ret = 'curl -sSO https://download.bt.cn/install/btmonitoragent.go  && btmonitoragent.go -h https://{}:{}'.format(
                server_ip,
                public.get_panel_port(),
                token
            )

        # 统计及获取客户端安装命令次数
        # basic_monitor_obj.set_module_logs('cloud_monitor', 'add_server')

        return public.success(ret)

    # 获取安装脚本(Linux/Windows)
    def add_server_both(self, args):
        system = int(args.get('system', 0))

        if system == 0:
            s = 'curl -sSO https://download.bt.cn/install/btmonitoragent.sh && bash btmonitoragent.sh https://{}:{} {}'
        else:
            s = 'curl -sSO https://download.bt.cn/install/btmonitoragent.go  && btmonitoragent.go -h https://{}:{}'

        internal_ip, published_ip = basic_monitor_obj.get_server_ip()
        token_path = '{}/config/token.pl'.format(public.get_panel_path())
        token = public.readFile(token_path) if os.path.exists(token_path) else ''

        return public.success({
            'published': s.format(
                published_ip.strip(),
                public.get_panel_port(),
                token
            ),
            'internal': s.format(
                internal_ip[0].strip(),
                public.get_panel_port(),
                token
            ),
        })

    def remove_server(self, args):
        '''
            @name 删除主机
            @author Zhj<2022-08-24>
            @arg    sid<integer>        主机ID
            @arg    server_ip<?string>  主机IP[可选]
            @return dict
        '''
        # DEMO
        if basic_monitor_obj.in_demo():
            return public.error('DEMO不支持此操作')

        sid = args.get('sid', None)
        server_ip = args.get('server_ip', None)

        if sid is None:
            sid = basic_monitor_obj.db_easy('servers') \
                .where('ip=?', server_ip) \
                .value('sid')

            if sid is None:
                return public.error('缺少参数：sid')
        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')
        # 主机信息
        server_info = None

        with monitor_db_manager.db_mgr() as db_monitor, public.sqlite_easy('safety') as db_safety:
            try:
                # 关闭事务自动提交
                db_monitor.autocommit(False)
                db_safety.autocommit(False)

                # 开启自动释放空间
                db_monitor.auto_vacuum()
                db_safety.auto_vacuum()

                # 获取主机信息
                server_info = db_monitor.query() \
                    .name('servers') \
                    .where('sid=?', sid) \
                    .field('sid', 'ip', 'is_authorized', 'remark') \
                    .find()

                public.print_log('|--正在删除主机 {} {}'.format(server_info['ip'], server_info['remark']))
                public.print_log('|--正在删除主机绑定信息')

                # 删除主机相关的所有数据
                # 删除主机绑定信息
                db_safety.query().name('server_list').where('sid=?', int(sid)).delete()

                public.print_log('|--主机绑定信息删除成功')
                public.print_log('|--正在删除主机信息')

                # 删除主机信息
                db_monitor.query().name('servers').where('sid=?', int(sid)).delete()

                public.print_log('|--主机绑定信息删除成功')
                public.print_log('|--正在删除主机详情')

                # 删除主机详情
                db_monitor.query().name('server_details').where('sid=?', int(sid)).delete()

                public.print_log('|--主机详情删除成功')

                public.print_log('|--正在删除主机告警规则')

                # 删除主机告警规则
                db_monitor.query().name('warning_configurations').where('sid=?', sid).delete()

                public.print_log('|--主机告警规则删除成功')
                public.print_log('|--正在删除主机告警模板关联记录')

                # 删除主机告警模板关联记录
                db_monitor.query().name('server_warning_template_package_merge').where('sid=?', sid).delete()

                public.print_log('|--主机告警模板关联记录删除成功')

                # 提交事务
                db_monitor.commit()
                db_safety.commit()
            except BaseException as e:
                # 回滚事务
                db_monitor.rollback()
                db_safety.rollback()

                public.print_log('|--删除主机失败')

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error('删除失败')

        # 删除主机相关的信息
        # 删除SSH登录日志
        # with monitor_db_manager.db_mgr('ssh_login_logs') as db:
        #     try:
        #         # 关闭事务自动提交
        #         db.autocommit(False)
        #
        #         # 开启自动释放空间
        #         db.auto_vacuum()
        #
        #         public.print_log('|--正在删除SSH登录日志')
        #         db.query()\
        #             .name('ssh_login_logs')\
        #             .where('sid=?', sid)\
        #             .delete()
        #
        #         # 提交事务
        #         db.commit()
        #     except BaseException as e:
        #         # 回滚事务
        #         db.rollback()
        #
        #         public.print_log('|--SSH登录日志删除失败')
        #
        #         # 记录异常堆栈
        #         public.print_exc_stack(e)

        # 删除端口信息
        with monitor_db_manager.db_mgr('server_ports') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                public.print_log('|--正在删除端口信息')
                db.query() \
                    .name('server_ports') \
                    .where('sid=?', sid) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                public.print_log('|--端口信息删除失败')

                # 记录异常堆栈
                public.print_exc_stack(e)

        # 删除主机告警任务
        with monitor_db_manager.db_mgr('warning_tasks') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                public.print_log('|--正在删除主机告警任务')
                db.query() \
                    .name('warning_tasks') \
                    .where('sid=?', sid) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                public.print_log('|--主机告警任务删除失败')

                # 记录异常堆栈
                public.print_exc_stack(e)

        # 删除主机命令执行记录
        with monitor_db_manager.db_mgr('command_execute_logs') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                public.print_log('|--正在删除主机命令执行记录')
                db.query() \
                    .name('command_execute_logs') \
                    .where('sid=?', sid) \
                    .delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                public.print_log('|--主机命令执行记录删除失败')

                # 记录异常堆栈信息
                public.print_exc_stack(e)

        public.print_log('|--正在删除主机收集数据')

        # 删除主机收集数据
        monitor_db_manager.MonitorDbManager(sid).remove()

        public.print_log('|--主机收集数据删除成功')
        public.print_log('|--主机删除成功')

        # 记录操作日志
        public.WriteLog('主机管理', '用户【{}】删除主机【{} {}】'.format(public.bt_auth('username'), server_info['ip'],
                                                           server_info['remark']))

        # 更新当前授权数缓存
        if int(server_info['is_authorized']) == 1:
            cache_key = 'BT_MONITOR_CACHE__CUR_AUTH_NUM'
            cur_auth_num = public.cache_get(cache_key)
            if cur_auth_num is not None:
                public.cache_set('BT_MONITOR_CACHE__CUR_AUTH_NUM', cur_auth_num - 1, 120)

        # 触发主机删除成功事件
        public.event(monitor_events.ServerRemoved(server_info))

        return public.success('操作成功')

    def get_server_list_simple(self, args):
        '''
            @name 获取主机列表(简易数据)
            @author Zhj<2023-01-10>
            @param args<dict> 请求参数列表
            @return dict
        '''
        server_authorized = g.get("server_list", [])

        if not server_authorized:
            return public.success({
                'total': 0,
                'list': [],
            })

        group_id = args.get('group_id', None)
        server_type = args.get('type', None)

        query = basic_monitor_obj.db_easy('servers s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .left_join('server_warning_template_package_merge m', 's.sid=m.sid') \
            .left_join('warning_template_packages p', 'm.package_id=p.id') \
            .left_join('server_details sys', 's.sid = sys.sid') \
            .where_in('s.sid', server_authorized) \
            .order('s.sid', 'desc') \
            .field('s.sid', 'sg.name as group_name', 's.ip', 's.remark', 's.is_authorized', 's.status',
                   'ifnull(p.name, \'\') as cur_template', 's.type', 'sys.host_info', 's.ssh_info')

        if server_type is not None:
            query.where('s.type', int(server_type))

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('s.remark like ? OR s.ip like ?', (k, k,))

        public.add_retrieve_keyword_query(query, args, query_handler)

        ret = public.simple_page(query, args)

        for item in ret['list']:
            # 更新主机状态
            _, _, item['status'] = basic_monitor_obj.cache_server_status(item['sid'])
            item['host_info'] = json.loads(item['host_info'])

        return public.success(ret)

    # def remove_server(self, args):
    #     '''
    #         @name 删除主机
    #         @author Zhj<2022-07-08>
    #         @arg    sid<integer>        主机ID
    #         @arg    server_ip<?string>  主机IP[可选]
    #         @return dict
    #     '''
    #     sid = args.get('sid', None)
    #     server_ip = args.get('server_ip', None)
    #
    #     if sid is None:
    #         sid = basic_monitor_obj.db_easy('servers')\
    #             .where('ip=?', server_ip)\
    #             .value('sid')
    #
    #         if sid is None:
    #             return public.error('缺少参数：sid')
    #
    #     # 打开数据库
    #     with public.sqlite_easy('monitor') as db_monitor, public.sqlite_easy('safety') as db_safety:
    #         try:
    #             # 关闭事务自动提交
    #             db_monitor.autocommit(False)
    #             db_safety.autocommit(False)
    #
    #             # 删除主机相关的所有数据
    #             # 删除主机绑定信息
    #             db_safety.query().name('server_list').where('sid=?', int(sid)).delete()
    #
    #             # 删除主机信息
    #             db_monitor.query().name('servers').where('sid=?', int(sid)).delete()
    #
    #             # 删除主机详情
    #             db_monitor.query().name('server_details').where('sid=?', int(sid)).delete()
    #
    #             # 删除CPU收集信息
    #             # db_monitor.query().name('server_cpu_info_list').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_cpu_info_list', 'sid=?', int(sid))
    #
    #             # 删除内存收集信息
    #             # db_monitor.query().name('server_mem_info_list').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_mem_info_list', 'sid=?', int(sid))
    #
    #             # 删除swap收集信息
    #             # db_monitor.query().name('server_swap_info_list').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_swap_info_list', 'sid=?', int(sid))
    #
    #             # 删除网卡收集信息
    #             # db_monitor.query().name('server_net_info_list').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_net_info_list', 'sid=?', int(sid))
    #
    #             # 删除磁盘收集信息
    #             # db_monitor.query().name('server_disk_info_list').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_disk_info_list', 'sid=?', int(sid))
    #
    #             # 删除SSH登录日志
    #             # db_monitor.query().name('ssh_login_logs').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'ssh_login_logs', 'sid=?', int(sid))
    #
    #             # 删除端口收集记录
    #             # db_monitor.query().name('server_ports').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_ports', 'sid=?', int(sid))
    #
    #             # 删除端口连接测试记录
    #             # db_monitor.query().name('port_connection_logs').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'port_connection_logs', 'sid=?', int(sid))
    #
    #             # 删除系统防火墙启停记录
    #             # db_monitor.query().name('firewall_start_stop_logs').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'firewall_start_stop_logs', 'sid=?', int(sid))
    #
    #             # 删除系统防火墙规则修改记录
    #             # db_monitor.query().name('firewall_rule_change_logs').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'firewall_rule_change_logs', 'sid=?', int(sid))
    #
    #             # 删除进程及进程相关记录
    #             for item in db_monitor.query().name('processes').where('sid=?', int(sid)).field('id').select():
    #                 process_id = int(item['id'])
    #                 # db_monitor.query().name('process_cpu_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_mem_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_disk_io_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_network_io_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_opened_files_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_opened_connections_info_list').where('process_id=?', process_id).delete()
    #                 # db_monitor.query().name('process_opened_threads_info_list').where('process_id=?', process_id).delete()
    #
    #                 self.__remove_server_helper(db_monitor, 'process_cpu_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_mem_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_disk_io_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_network_io_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_opened_files_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_opened_connections_info_list', 'process_id=?', process_id)
    #                 self.__remove_server_helper(db_monitor, 'process_opened_threads_info_list', 'process_id=?', process_id)
    #
    #             # db_monitor.query().name('processes').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'processes', 'sid=?', int(sid))
    #
    #             # 删除告警任务
    #             # db_monitor.query().name('warning_tasks').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'warning_tasks', 'sid=?', int(sid))
    #
    #             # 删除告警规则
    #             # db_monitor.query().name('warning_configurations').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'warning_configurations', 'sid=?', int(sid))
    #
    #             # 删除告警模板关联记录
    #             # db_monitor.query().name('server_warning_template_package_merge').where('sid=?', int(sid)).delete()
    #             self.__remove_server_helper(db_monitor, 'server_warning_template_package_merge', 'sid=?', int(sid))
    #
    #             # 提交事务
    #             db_monitor.commit()
    #             db_safety.commit()
    #
    #             # 释放空间
    #             db_safety.query().execute('vacuum')
    #             db_monitor.query().execute('vacuum')
    #         except BaseException as e:
    #             # 回滚事务
    #             db_monitor.rollback()
    #             db_safety.rollback()
    #
    #             # 记录异常堆栈
    #             public.print_exc_stack(e)
    #
    #             return public.error('删除失败')
    #
    #     return public.success('操作成功')
    #
    # def __remove_server_helper(self, db, table_name, where, bind_params=(), pk='id', chunk_size=5000):
    #     '''
    #         @name 删除主机帮助方法
    #         @author Zhj<2022-08-06>
    #         @param db<core.include.sqlite_easy.Db>  数据库对象
    #         @param table_name<string>               表名
    #         @param where<string>                    where条件
    #         @param bind_params<?list|tuple>         绑定参数[可选]
    #         @param pk<?string>                      主键名称[可选]
    #         @param chunk_size<?integer>             每次删除的条数[可选 默认5000]
    #         @return integer
    #     '''
    #     total_rows = 0
    #     sub_query = db.query() \
    #         .name(table_name) \
    #         .field(pk) \
    #         .where(where, bind_params) \
    #         .limit(chunk_size) \
    #         .build_sql(True)
    #
    #     deleted_rows = db.query() \
    #         .name(table_name) \
    #         .where('{} IN {}'.format(pk, sub_query)) \
    #         .delete()
    #
    #     total_rows += deleted_rows
    #
    #     while deleted_rows == chunk_size:
    #         deleted_rows = db.query() \
    #             .name(table_name) \
    #             .where('{} IN {}'.format(pk, sub_query)) \
    #             .delete()
    #
    #         total_rows += total_rows
    #
    #     return total_rows

    def set_port_testing(self, args):
        '''
            @name 设置主机端口定时测试状态
            @author Zhj<2022-07-11>
            @arg    port_id<integer>    端口ID
            @arg    status<integer>     定时测试状态 0-关闭 1-启用
            @return dict
        '''
        port_id = args.get('port_id', None)
        status = args.get('status', None)

        if port_id is None:
            return public.error('缺少参数：port_id')

        if status is None:
            return public.error('缺少参数：status')

        if int(status) not in [0, 1]:
            return public.error('无效参数：status')

        port_info = basic_monitor_obj.db_easy('server_ports') \
            .where(
            '`port_id` = ? AND `status` = 1',
            [int(port_id)]
        ) \
            .field('ip', 'port') \
            .find()

        if basic_monitor_obj.is_empty_result(port_info):
            return public.error('该主机未监听此端口')

        # 更新主机端口定时测试状态
        basic_monitor_obj.db_easy('server_ports').where('`port_id` = ? AND `status` = 1', [int(port_id)]).update({
            'test_connection': int(status),
            'update_time': int(time.time()),
        })

        # 记录操作日志
        public.WriteLog('主机端口', '用户【{}】设置主机【{}】端口【{}】 {} 连接测试'.format(
            public.bt_auth('username'),
            basic_monitor_obj.get_server_describe(port_info['sid']),
            port_info['port'],
            '启用' if int(status) == 1 else '关闭'))

        return public.success('操作成功')

    def disk_info_statistics(self, args):
        '''
            @name   磁盘统计信息
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    name<string>        磁盘设备名称
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        try:
            name = args.get('name', None)

            if name is None:
                raise public.PanelError('缺少参数：name')

            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_disk_info_list',
                    'used_percent,inodes_used_percent,io_percent,create_time',
                    '`name` = ?',
                    [name]
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def cpu_info_statistics(self, args):
        '''
            @name   CPU占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''

        return self.cpu_info_statistics_v2(args)
        try:
            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_cpu_info_list',
                    'percent,create_time'
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def mem_info_statistics(self, args):
        '''
            @name   内存占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        return self.mem_info_statistics_v2(args)
        try:
            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_mem_info_list',
                    'percent,create_time'
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def swap_info_statistics(self, args):
        '''
            @name   swap占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        return self.swap_info_statistics_v2(args)
        try:
            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_swap_info_list',
                    'percent,create_time'
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def loadavg_info_statistics(self, args):
        '''
            @name   主机负载统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        return self.loadavg_info_statistics_v2(args)
        try:
            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_loadavg_info_list',
                    'last_1_min,last_5_min,last_15_min,create_time'
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def disk_io_info_statistics(self, args):
        '''
            @name   磁盘IO统计信息
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    name<string>        磁盘设备名称
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        return self.disk_io_info_statistics_v2(args)
        try:
            name = args.get('name', None)

            if name is None:
                raise public.PanelError('缺少参数：name')

            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_disk_info_list',
                    'read_bytes_per_second,write_bytes_per_second,create_time',
                    '`name` = ?',
                    [name]
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def net_info_statistics(self, args):
        '''
            @name   网卡IO统计信息
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    name<string>        网卡设备名称
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        return self.net_info_statistics_v2(args)
        try:
            name = args.get('name', None)

            if name is None:
                raise public.PanelError('缺少参数：name')

            return public.success(
                basic_monitor_obj.server_statistics_helper(
                    args,
                    'server_net_info_list',
                    'sent_per_second,recv_per_second,create_time',
                    '`name` = ?',
                    [name]
                )
            )
        except public.PanelError as e:
            return public.error(str(e))

    def mem_info_statistics_v2(self, args):
        '''
            @name   内存占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        sid = args.get('sid', None)
        if sid is None:
            return public.error('缺少参数：sid')
        try:
            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')
            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_mem_info_list',
                'percent,create_time'
            )

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 2) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            # public.print_log('333333333333 top~~ data{}----类型{}'.format(data, type(data)), _level='error')
            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['mem_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['mem_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)
        except public.PanelError as e:
            return public.error(str(e))

    def cpu_info_statistics_v2(self, args):
        '''
            @name   cpu占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        # fields = ['id', 'process_id', 'percent', 'create_time']
        # table_name = 'process_cpu_info_list'
        # order_field = 'percent'
        sid = args.get('sid', None)
        if sid is None:
            return public.error('缺少参数：sid')

        try:
            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')

            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_cpu_info_list',
                'percent,create_time'
            )
            # public.print_log('333333333333{}----类型{}'.format(ret, type(ret)), _level='error')
            # public.print_log('333333333333 sid{}----类型{}'.format(sid, type(sid)), _level='error')

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 1) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            # public.print_log('333333333333 top~~ data{}----类型{}'.format(data, type(data)), _level='error')
            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['cpu_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['cpu_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)
        except public.PanelError as e:
            return public.error(str(e))

    def swap_info_statistics_v2(self, args):
        '''
            @name   swap占用率统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        sid = args.get('sid', None)
        if sid is None:
            return public.error('缺少参数：sid')

        try:
            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')
            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_swap_info_list',
                'percent,create_time'
            )

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 2) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            # public.print_log('333333333333 top~~ data{}----类型{}'.format(data, type(data)), _level='error')
            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['mem_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['mem_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)
        except public.PanelError as e:
            return public.error(str(e))

    def loadavg_info_statistics_v2(self, args):
        '''
            @name   主机负载统计
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''
        sid = args.get('sid', None)
        if sid is None:
            return public.error('缺少参数：sid')
        try:
            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')
            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')
            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_loadavg_info_list',
                'last_1_min,last_5_min,last_15_min,create_time'
            )

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 1) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            # public.print_log('333333333333 top~~ data{}----类型{}'.format(data, type(data)), _level='error')
            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['cpu_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['cpu_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)
        except public.PanelError as e:
            return public.error(str(e))

    def disk_io_info_statistics_v2(self, args):
        '''
            @name   磁盘统计信息
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    name<string>        磁盘设备名称
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''

        try:
            name = args.get('name', None)
            if name is None:
                raise public.PanelError('缺少参数：name')
            sid = args.get('sid', None)
            if sid is None:
                return public.error('缺少参数：sid')

            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')
            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')
            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_disk_info_list',
                'read_bytes_per_second,write_bytes_per_second,create_time',
                '`name` = ?',
                [name]
            )

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 3) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['disk_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['disk_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)

        except public.PanelError as e:
            return public.error(str(e))

    def net_info_statistics_v2(self, args):
        '''
            @name   网卡IO统计信息
            @author Zhj<2022-07-12>
            @arg    sid<integer>        主机ID
            @arg    name<string>        网卡设备名称
            @arg    query_date<string>  日期筛选字符串
            @return dict
        '''

        try:
            name = args.get('name', None)

            if name is None:
                raise public.PanelError('缺少参数：name')
            sid = args.get('sid', None)
            if sid is None:
                return public.error('缺少参数：sid')

            pne_id = basic_monitor_obj.db_easy('processes') \
                .field('id', 'pne_id') \
                .order('update_time', 'desc') \
                .limit(500) \
                .column('pne_id', 'id')
            # 查询进程基本信息
            pnes = basic_monitor_obj.db_easy('process_name_exe') \
                .field('id', 'name', 'exe') \
                .column(None, 'id')

            ret = basic_monitor_obj.server_statistics_helper(
                args,
                'server_net_info_list',
                'sent_per_second,recv_per_second,create_time',
                '`name` = ?',
                [name]
            )

            data = {}

            if len(ret) > 1:
                data = basic_monitor_obj.db_easy('process_top_list') \
                    .where('sid', sid) \
                    .where('type', 4) \
                    .where('time_slot > ?', int(ret[0]['create_time'] / 450) - 1) \
                    .where('time_slot < ?', int(ret[-1]['create_time'] / 450) + 1) \
                    .column('data', 'time_slot')

            for item in ret:
                item_slot = int(item['create_time'] / 450)
                # public.print_log('222 aa{}----类型{}'.format(aa, type(aa)), _level='error')
                item['disk_top'] = json.loads(data[item_slot]) if item_slot in data else []

                for item2 in item['disk_top']:
                    process_id = item2.get('process_id', None)
                    if process_id in pne_id:
                        item2['pne_id'] = pne_id[process_id]
                        if item2['pne_id'] in pnes:
                            item2['pne_name'] = pnes[item2['pne_id']]['name']
                            # item2['pne_exe'] = pnes[item2['pne_id']]['exe']

                    del item2['process_id']
                    item2.pop('pne_id', None)

            return public.success(ret)
        except public.PanelError as e:
            return public.error(str(e))

    def get_panel_info(self, args):
        """获取服务器面板信息

        Args:
            args (dict): 包含sid
        """
        try:
            error_msg = ""
            db = None
            se = None
            from core.include.sqlite_easy import Db
            from core.include.sqlite_easy import SqliteEasy

            sid = args.sid
            db = Db("monitor_mgr")
            se = SqliteEasy(db)

            res = se.name("panel_info").where("sid=?", (sid,)).find()
            if res:
                return public.success(res)
        except Exception as e:
            error_msg = "未找到服务器面板信息: {}".format(e)
        finally:
            self.close_db(db)
            self.close_db(se)
        if not error_msg:
            error_msg = "未找到服务器面板信息。"
        return public.error(error_msg)

    def sync_panel_info(self, args):
        """通过token请求面板GetNetwork接口获取面板最新基础信息

        Args:
            args (dict_obj): 请求面板信息

        Returns:
            dict: public.error/success
        """
        try:
            import json
            db = None
            se = None
            error_msg = ""
            from core.include.sqlite_easy import Db
            from core.include.sqlite_easy import SqliteEasy

            sid = int(args.sid)
            p_uri = args.p_uri
            pdata = json.loads(args.pdata)
            # print("pdata:", pdata)

            db = Db("monitor_mgr")
            se = SqliteEasy(db)

            info = se.name("panel_info").where("sid=?", (sid,)).find()
            # print("info:", info)

            if not info:
                return public.error("未找到面板信息。")

            token = info["token"]
            panel_address = info["panel_address"]
            if panel_address[-1] == "/":
                panel_address = panel_address[:-1]
            ori_panel_version = info["panel_version"]

            pdata = public.get_panel_key_data(pdata, token)
            pdata["sid"] = sid

            result = None
            request_url = panel_address + '/' + p_uri
            try:
                res_text = public.HttpPost(request_url, pdata, timeout=30)
                result = json.loads(res_text)
                if "status" in result:
                    error_msg = result["msg"]
                    return public.error("面板信息请求失败: {}".format(error_msg))
            except:
                error_msg = res_text
                return public.error("面板信息请求失败: {}".format(error_msg))

            if "version" in result:
                new_version = result["version"]
                update_data = {}
                to_update = False
                if new_version != ori_panel_version:
                    to_update = True
                    update_data["panel_version"] = new_version
                    # from BT_COLL import update_queue
                if to_update and update_data:
                    se.name("panel_info").where("sid=?", (sid,)).update(update_data)
                    try:
                        from core import cache
                        server_info_cache_key = "SERVER_INFO_" + str(sid)
                        cache.delete(server_info_cache_key)
                    except:
                        public.print_log("更新缓存失败。")
                    return public.success("面板信息更新成功。")
                return public.success("面板信息无修改，无需更新。")
        except Exception as e:
            error_msg = str(e)
        return public.error("更新面板信息失败: {}".format(error_msg))

    def add_panel_info(self, args):
        """添加被控面板信息

        Args:
            args (dict): 面板信息
        """
        try:
            sid = args.get('sid', None)
            panel_address = args.get('panel_address', None)
            token = args.get('token', None)
            panel_version = args.get('panel_version', '')

            if sid is None:
                raise BtMonitorException('缺少参数：sid')

            if panel_address is None:
                raise BtMonitorException('缺少参数：panel_address')
            else:
                rule = re.compile(
                    r'^https?://'
                    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                    r':[0-9]{1,5}$', flags=re.IGNORECASE)
                # r'([0-9]{1,3}\.){3}[0-9]{1,3}|'
                # r'([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,}'
                # r':[0-9]{1,5}$',flags=re.IGNORECASE)
                if not re.match(rule, panel_address):
                    raise BtMonitorException('请填写正确的面板地址')

            if token is None:
                raise BtMonitorException('缺少参数：token')

            if int(sid) < 1:
                raise BtMonitorException('无效的参数：sid')

            if panel_address == '':
                raise BtMonitorException('请填写面板地址')

            if token == '':
                raise BtMonitorException('请填写面板API密钥')

            # if not re.match(r'^https?://', str(panel_address), flags=re.IGNORECASE):
            ##     raise BtMonitorException('请填写正确的面板地址')

            panel_info = {
                "sid": sid,
                "panel_address": panel_address,
                "panel_version": panel_version,
                "token": token
            }

            with public.sqlite_easy('monitor_mgr') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    db.query() \
                        .name("panel_info") \
                        .insert(panel_info)

                    db.query() \
                        .name('servers') \
                        .where('sid=?', sid) \
                        .update({
                        'panel_info': 1,
                        'update_time': int(time.time()),
                    })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 打印异常堆栈
                    public.print_exc_stack(e)

                    raise e

            return public.success('添加面板信息成功')
        except BtMonitorException as e:
            return public.error(str(e))
        except BaseException as e:
            return public.error('添加面板信息异常: {}'.format(str(e)))

    def modify_panel_info(self, args):
        """修改面板信息

        Args:
            args (dict): 新面板信息
        """
        try:
            db = None
            se = None
            error_msg = ""
            from core.include.sqlite_easy import Db
            from core.include.sqlite_easy import SqliteEasy

            new_data = {}
            sid = args.sid
            if "panel_address" in args:
                rule = re.compile(
                    r'^https?://'
                    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                    r':[0-9]{1,5}$', flags=re.IGNORECASE)
                if not re.match(rule, args.panel_address):
                    raise BtMonitorException('请填写正确的面板地址')
                else:
                    new_data["panel_address"] = args.panel_address

            if "token" in args:
                new_data["token"] = args.token
            if "panel_version" in args:
                new_data["panel_version"] = args.panel_version

            db = Db("monitor_mgr")
            se = SqliteEasy(db)

            res = se.name("panel_info").where("sid=?", (sid,)).update(new_data)
            # print("modify res:")
            # print(res)
            if res and res == 1:
                try:
                    from core import cache
                    server_info_cache_key = "SERVER_INFO_" + str(sid)
                    cache.delete(server_info_cache_key)
                except:
                    public.print_log("更新缓存失败。")
                return public.success("修改面板信息成功。")
        except Exception as e:
            error_msg = "修改面板信息异常: {}".format(e)
        finally:
            self.close_db(db)
            self.close_db(se)
        if not error_msg:
            error_msg = "修改面板信息异常。"
        return public.error(error_msg)

    def delete_panel_info(self, args):
        """删除面板信息

        Args:
            args (dict): 至少包含sid
        """
        try:
            error_msg = ""
            db = None
            se = None

            from core.include.sqlite_easy import Db
            from core.include.sqlite_easy import SqliteEasy

            sid = args.sid

            db = Db("monitor_mgr")
            se = SqliteEasy(db)

            res = se.name("panel_info").where("sid=?", (sid,)).delete()
            if res and res == 1:
                res_update = se.name("servers").where("sid=?", (sid,)).update(
                    {"panel_info": 0}
                )
                if res_update == 1:
                    return public.success("面板信息删除成功。")
        except Exception as e:
            error_msg = "删除面板信息异常: {}".format(e)
        finally:
            self.close_db(db)
            self.close_db(se)
        if not error_msg:
            error_msg = "删除面板信息异常。"
        return public.error(error_msg)

    #   取指定服务器的ssh登陆信息
    def get_ssh_info(self, args):
        with monitor_db_manager.db_mgr() as db:
            id = args.get('id', None)
            sid = args.get("sid", None)
            uid = public.bt_auth('uid')
            ssh_info_ids = self.__uid_check(uid, 2)
            if uid > 1 and int(id) not in ssh_info_ids:
                return public.error('没有权限,操作失败！')

            query = db.query().name('ssh_info')

            if sid is not None and int(sid) > 0:
                query.where('sid', int(sid))

            if id is not None and int(id) > 0:
                query.where('id', int(id))

            return public.success(query.find())

            # if not data:
            #     return None
            #
            # if data['password']:
            #     # data['password'] = public.decrypt_password(data['password'])
            #     data['password'] = data['password']
            #
            # if data['pkey']:
            #     # data['pkey'] = public.decrypt_password(data['pkey'])
            #     data['pkey'] = data['pkey']
            #
            # return public.success(data)

    #   添加ssh登陆信息
    def add_ssh_info(self, args):
        """
        Args:
            args (dict): ssh登录信息
        """
        with monitor_db_manager.db_mgr() as db:
            new_data = {}
            sid = args.get('sid', 0)
            remark = args.get('remark', '')
            new_data["sid"] = sid
            new_data["username"] = args.username
            new_data["host"] = args.host
            new_data["uid"] = public.bt_auth('uid')
            pwd_check = False
            if "password" in args:
                new_data["password"] = public.encrypt_password(args.password)
                pwd_check = True
            if "pkey" in args:
                new_data['pkey'] = public.encrypt_password(args.pkey)
                pwd_check = True
            # if not pwd_check:
            #     return public.error("登录密码不能为空。")
            if "port" in args:
                new_data["port"] = int(args.port)
            else:
                new_data['port'] = 22
            new_data['addtime'] = time.time()
            new_data['remark'] = remark

            # 如果主机ip已经添加过了
            if db.query().name("ssh_info").where('host', new_data["host"]).where('port', new_data['port']).exists():
                return public.error('主机IP【{}】已经存在,如需修改请点击修改'.format(new_data["host"]))

            db.query().name("ssh_info").insert(new_data)

            if int(sid) > 0:
                db.query() \
                    .name("servers") \
                    .where("sid", sid) \
                    .update({"ssh_info": 1})

            # if int(sid) == 0 :
            #     # 统计添加堡垒机次数
            #     basic_monitor_obj.set_module_logs('fortress', 'add_server')

        return public.success("SSH信息添加成功。")

    #   修改服务器ssh登录信息
    def modify_ssh_info(self, args):
        """
        Args:
            args (dict): ssh登录信息
        """
        from core import my_terms
        with monitor_db_manager.db_mgr() as db:
            new_data = {}
            sid = args.get('sid', None)
            id = args.get('id', None)
            uid = public.bt_auth('uid')
            ssh_info_ids = self.__uid_check(uid, 4)
            if uid > 1 and int(id) not in ssh_info_ids:
                return public.error('没有权限,操作失败！')
            query = db.query().name('ssh_info')

            if sid is not None and int(sid) > 0:
                query.where('sid', int(sid))

            if id is not None and int(id) > 0:
                query.where('id', int(id))

            query_dup = query.fork()

            data = query.find()

            # if data['password']:
            #     data['password'] = data['password']
            #
            # if data['pkey']:
            #     data['pkey'] = data['pkey']

            if "host" in args:
                new_data["host"] = args.host
            if "username" in args:
                new_data["username"] = args.username
            if "password" in args:
                new_data['password'] = args.password
            if "pkey" in args:
                new_data['pkey'] = args.pkey
            if "port" in args:
                new_data["port"] = int(args.port)
            if "remark" in args:
                new_data["remark"] = args.remark

            status = False

            if new_data.get('username', None) and data['username'] != new_data["username"]:
                status = True
            if new_data.get('password', None) and data['password'] != args.get("password"):
                new_data["password"] = public.encrypt_password(args.password)
                status = True
            if new_data.get('pkey', None) and data['pkey'] != args.get("pkey"):
                new_data["pkey"] = public.encrypt_password(args.pkey)
                status = True
            if new_data.get('port', None) and data['port'] != new_data["port"]:
                status = True
            if new_data.get('remark', None) and data['remark'] != new_data["remark"]:
                status = True

            if status:
                try:
                    my_terms[new_data['host']].tty.close()
                except:
                    pass
                if new_data['host'] in my_terms:
                    del my_terms[new_data['host']]

            query_dup.update(new_data)

        return public.success("SSH信息修改成功。")

    #   删除服务器ssh登录信息
    def delete_ssh_info(self, args):
        """删除服务器ssh登录信息

        Args:
            args (dict): ssh登录信息
        """
        with monitor_db_manager.db_mgr() as db:
            sid = args.get('sid', None)
            id = args.get('id', None)
            uid = public.bt_auth('uid')

            query = db.query().name('ssh_info')
            ssh_info_ids = self.__uid_check(uid, 8)
            if uid > 1 and int(id) not in ssh_info_ids:
                return public.error('没有权限,操作失败！')

            if sid is not None and int(sid) > 0:
                query.where('sid', int(sid)).delete()
                db.query() \
                    .name("servers") \
                    .where("sid", int(sid)).update({
                    "ssh_info": 0,
                })

            if id is not None and int(id) > 0:
                sid_field = query.where('id', id).field('sid').find()
                if int(sid_field['sid']) > 0:
                    db.query() \
                        .name("servers") \
                        .where("sid", int(sid_field['sid'])).update({
                        "ssh_info": 0,
                    })

                query.where('id', int(id)).delete()

        return public.success("SSH信息删除成功。")

    #   删除所有服务器ssh登录信息
    def delete_all_ssh_info(self, args):
        """删除所有服务器ssh登录信息

        Args:
            args (dict): ssh登录信息
        """
        with monitor_db_manager.db_mgr() as db:
            db.query().name("ssh_info").delete()
            db.query() \
                .name("servers") \
                .update({
                "ssh_info": 0,
            })

        return public.success("清空所有SSH信息成功。")

    def close_db(self, db_obj):
        try:
            db_obj and db_obj.close()
        except:
            pass

    def get_server_groups(self, args):
        '''
            @name 获取主机组列表
            @author Zhj<2022-09-21>
            @return dict
        '''
        ret = basic_monitor_obj.db_easy('server_group') \
            .field('id', 'name') \
            .select()

        # 统计分组下的主机数
        for item in ret:
            item['servers'] = basic_monitor_obj.db_easy('servers') \
                .where('group_id=?', int(item['id'])) \
                .count()

        return public.success(ret)

    def add_server_group(self, args):
        '''
            @name 新增主机组
            @author Zhj<2022-09-21>
            @arg    group_name<string> 分组名称
            @return dict
        '''
        # 获取组名
        group_name = args.get('name', None)

        if group_name is None:
            return public.error('缺少参数：group_name')

        with monitor_db_manager.db_mgr() as db:
            if db.query().name('server_group').where('name=?', group_name).field('id').exists():
                return public.error('分组名【{}】已被使用'.format(group_name))

            db.query() \
                .name('server_group') \
                .insert({
                'name': group_name,
            })

        return public.success('操作成功')

    def remove_server_group(self, args):
        '''
            @name 删除主机组
            @author Zhj<2022-09-21>
            @arg    group_id<string>            分组ID列表
            @arg    remove_servers<?integer>    是否删除分组下所有主机[可选]
            @return dict
        '''
        # 获取分组ID列表
        group_id = args.get('group_id', None)

        # 删除分组下所有主机
        remove_servers = args.get('remove_servers', None)

        if group_id is None:
            return public.error('缺少参数：group_id')

        if not re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            return public.error('参数 group_id 格式错误')

        # 转为列表
        group_id = group_id.split(',')

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                # 开启自动释放空间
                db.auto_vacuum()

                # 删除
                db.query().name('server_group').where_in('id', group_id).delete()

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈信息
                public.print_exc_stack(e)

        # 删除对应的主机信息
        if remove_servers is not None and int(remove_servers) == 1:
            sid_list = db.query() \
                .name('servers') \
                .where_in('group_id', group_id) \
                .column('sid')

            for sid in sid_list:
                self.remove_server(public.to_dict_obj({'sid': sid}))

        # 触发主机分组删除事件
        public.event(monitor_events.ServerGroupRemoved(group_id))

        return public.success('操作成功')

    def edit_server_group(self, args):
        '''
            @name 修改主机组
            @author Zhj<2022-09-21>
            @arg   group_id<integer>   分组ID
            @arg   group_name<string>  分组名称
            @return dict
        '''
        # 获取分组ID
        group_id = args.get('group_id', None)

        # 获取分组名称
        group_name = args.get('name', None)

        if group_id is None:
            return public.error('缺少参数：group_id')

        if group_name is None:
            return public.error('缺少参数：group_name')

        with monitor_db_manager.db_mgr() as db:
            if db.query() \
                    .name('server_group') \
                    .where('name=?', group_name) \
                    .where_not_in('id', [int(group_id)]) \
                    .field('id') \
                    .exists():
                return public.error('分组名【{}】已被使用'.format(group_name))

            # 更新分组名
            db.query() \
                .name('server_group') \
                .where('id=?', int(group_id)) \
                .update({
                'name': group_name,
                'update_time': int(time.time()),
            })

        return public.success('操作成功')

    # 设置主机分组
    def set_server_group(self, args):
        '''
            @name 设置主机分组
            @author Zhj<2022-09-21>
            @arg    sid<string>         主机ID列表
            @arg    group_id<?integer>  分组ID
            @return dict
        '''
        # 获取主机ID
        sid = args.get('sid', None)

        # 获取分组ID
        group_id = args.get('group_id', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if group_id is None:
            group_id = 0

        if not re.match(r'^\d+(?:,\d+)*$', str(sid)):
            return public.error('参数 sid 格式错误')

        # sid转为列表
        sid_list = sid.split(',')

        server_list = g.get("server_list", [])
        sid_list = AccessIntersection(sid_list, server_list)

        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('servers') \
                    .where_in('sid', sid_list) \
                    .update({
                    'group_id': int(group_id),
                    'update_time': int(time.time()),
                })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return public.error('操作失败')

        # 触发主机分组设置成功事件
        public.event(monitor_events.ServerGroupSetting(group_id, sid_list))

        return public.success('操作成功')

    def get_command_execute_logs(self, args):
        '''
            @name 获取命令执行记录
            @author Zhj<2022-09-28>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        # 获取主机ID
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')
        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')
        # 组装查询构造器
        query = basic_monitor_obj.db_easy('command_execute_logs') \
            .where('sid=?', sid) \
            .field('user', '{} as command'.format("'****'" if basic_monitor_obj.in_demo() else 'command'),
                   'create_time')

        # 添加关键字查询
        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)
            query.where('user like ?', k) \
                .where_or('command like ?', k)

        public.add_retrieve_keyword_query(query, args, query_handler)

        # 没有执行排序时的默认排序
        if 'sort' not in args:
            query.order('create_time', 'desc')

        # 添加排序
        public.add_retrieve_sort_query(query, args)

        return public.success(public.simple_page(query, args))

    def parse_raid_info(self, txt, ):
        """从命令行输出内容中提取设备信息

        Args:
            txt (string): $cmd /call/eall/sall show all命令行输出信息

        Returns:
            list: 每个控制器的详细信息列表
        """
        data = []
        if not txt:
            return data
        lines = txt.split("\n")
        import re
        data = []
        controller = None
        pd_info = None
        pd_id = None
        for line in lines:
            if line.startswith("Controller"):
                new_controller_index = line.split(" ")[2]
                exist_controller = False
                for xobj in data:
                    if xobj["controller_index"] == new_controller_index:
                        exist_controller = True
                        break
                if not exist_controller:
                    controller = {}
                    controller["controller_index"] = new_controller_index
                    data.append(controller)
                continue

            if re.search("Status\s=", line):
                controller["status"] = line.split(" ")[2]
                continue

            sor = re.search("Drive\s(/c\d+(/e\d+)*/s\d+)\s:", line)
            if sor:
                # print(sor)
                _pd_id = sor.groups()[0]
                if _pd_id != pd_id:
                    pd_id = _pd_id
                    if "pds" not in controller:
                        controller["pds"] = []
                    pd_info = {
                        "id": pd_id
                    }
                    # print(pd_info)
                    controller["pds"].append(pd_info)
                    continue

            searchor = re.search("^\d+:\d+ ", line)
            if searchor:
                line_arr = [x for x in line.split(" ") if x]
                device_id, slot_num = line_arr[0].split(":")
                state = line_arr[2]
                size = str(round(float(line_arr[4]), 1)) + line_arr[5]
                pd_type = line_arr[6]
                pd_info["device_id"] = device_id
                pd_info["slot_num"] = slot_num
                if state.lower() == 'failed' or state.lower() == 'fault':
                    pd_info["state"] = 'Failed'
                else:
                    pd_info["state"] = "Onln"

                pd_info["size"] = size
                pd_info["pd_type"] = pd_type
                # if line.find("Onln") == -1:
                # 	line = "<span style=\"color:red\">" + line + "</span>"
                continue

            searchor2 = re.search("Link\sSpeed", line)
            if searchor2:
                pd_info["link_speed"] = line.split(" ")[3]
                continue

            searchor = re.search("Raw\ssize", line)
            if searchor:
                pd_info["raw_size"] = "".join(line.split(" ")[3:5])
                continue

            searchor = re.search("Drive\sTemperature", line)
            if searchor:
                pd_info["temperature"] = "".join(line.split(" ")[3:])
                continue

            searchor = re.search("SN\s=", line)
            if searchor:
                pd_info["sn"] = "".join(line.split(" ")[2:])
                continue

            searchor = re.search("Model\sNumber\s=", line)
            if searchor:
                pd_info["model"] = "".join(line.split(" ")[3:])
                continue

        return data

    def parse_raid_infov2(self, txt, ):
        """从命令行输出内容中提取设备信息
        Args:
            txt (string): $cmd /call/eall/sall show all命令行输出信息

        Returns:
            list: 每个控制器的详细信息列表
        """
        data = []
        if not txt:
            return data
        import re
        controller = {}
        pd_info = None
        pd_id = None

        controller["pds"] = []
        data.append(controller)

        # 需要正则获取的的字段
        re_num_dict = {  # 数字
            "device_id": r"Device\s*Id:\s*\d+\n",
            "slot_num": r"Slot\s*Number:\s*\d+\n",
            # 追加
        }

        re_str_dict = {  # 字符串
            # "model": r"Inquiry\s*Data:\s*\w+[^\s][\w+]",
            "link_speed": r"Port's\s*Linkspeed:\s*\d+.\d+\w+.+\n",
            "pd_type": r"PD\s*Type:\s*[\d\w]+\n",
            "raw_size": r"Raw\s*Size:\s*\d+.\d+\s\w+",
            "size": r"Raw\s*Size:\s*\d+.\d+\s\w+",
            "sn": r"Inquiry\s*Data:\s*\w+-*\w+\s*\s*\w+-*\w+\s*\s*\w+-*\w+\s*\s*\w*-*\w*\s*\n",
            "state": r"Firmware\s*state:\s*\w+",
            "temperature": r"Drive\s*Temperature\s*:.+\n",
            # 追加
        }

        for disk_info in txt.split("\n\n\nEnclosure Device ID"):
            temp_dict = {}
            # 获取数值
            for name, re_txt in re_num_dict.items():
                re_obj = re.search(re_txt, disk_info)

                if re_obj is None:
                    continue

                temp_txt = re_obj.group()

                re_temp = re.search("\d+", temp_txt)

                if re_temp is None:
                    continue

                temp_dict[name] = re_temp.group()

            # 获取字符串
            for name, re_txt in re_str_dict.items():
                if name != "sn":
                    re_obj = re.search(re_txt, disk_info)

                    if re_obj is None:
                        continue

                    temp_txt = re_obj.group()
                    re_temp = temp_txt.split(":")[1]
                    re_temp = re_temp.strip()
                    temp_dict[name] = re_temp
                if name == "state":
                    if temp_dict['state'].lower() != 'failed' or temp_dict['state'].lower() != 'fault':
                        temp_dict['state'] = 'Onln'
                    else:
                        temp_dict['state'] = 'Failed'

                if name == "size":
                    tmp_size_list = temp_dict['size'].split(" ")
                    temp_dict['size'] = str(round(float(tmp_size_list[0].strip()), 1)) + tmp_size_list[1]
                    # public.print_log(f'++++++++++++++++++{temp_dict}')
                if name == "sn":
                    disk_info_list = disk_info.split("\n")
                    str_list = 0
                    snstr = ""
                    model = ""
                    for temp in disk_info_list:
                        if "Inquiry Data:" in temp:
                            tmp_data = temp.split(":")[1].strip()
                            snstr = tmp_data.split(" ")[0]
                            model = re.split(r"\s+", tmp_data)[1]
                            tmp_data = tmp_data.replace(tmp_data.split(" ")[0], "").strip()
                            tmp_data = tmp_data.replace(tmp_data.split(" ")[0], "").strip()

                            if tmp_data:
                                str_list = 4
                            else:
                                str_list = 3
                    if str_list == 3:
                        temp_dict['sn'] = snstr[:8]
                        temp_dict['model'] = snstr[8:]
                    elif str_list == 4:
                        temp_dict['sn'] = snstr
                        temp_dict['model'] = model

            controller["pds"].append(temp_dict)
        return data

    def refresh_raid_info(self, sid):
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(
            server_id,
            "raidcheck",
            "RefreshRaidInfo",
            "recv/raidcheck/RefeshRaidInfo/" + server_id,
            pdata={},
            timeout=60
        )
        data = public.get_agent_msg(res)

        public.print_log("客户端返回数据:")
        public.print_log(data)
        if not isinstance(data, dict) or not isinstance(data.get('body', {}), dict):
            return public.success([])
        if not data or 'body' not in data:
            return None
        return data['body']

    def get_server_raid_info(self, args):
        """获取服务器磁盘阵列信息"""
        sid = args.get("sid", None)
        if not sid:
            return public.error("错误的参数。")
        if "refesh" in args:
            result = self.refresh_raid_info(sid)
            if not result:
                return public.error("未获取到数据，刷新失败。")
            output = result["checkOutput"]
            detail = result["checkDetail"]
            ctrlcount = result["controllerCount"]
            check_res = result["checkResult"]
            check_dell = result["checkdell"]
            update_time = time.time()
        else:
            result = basic_monitor_obj.db_easy('server_raid_info') \
                .field('detail', 'output', 'ctrlcount', 'update_time', "check_result", 'check_dell') \
                .where('sid=?', (sid,)).find()
            if not result:
                return public.success([])
            output = result["output"]
            detail = result["detail"]
            ctrlcount = result["ctrlcount"]
            update_time = result["update_time"]
            check_res = result["check_result"]
            check_dell = result["check_dell"]

        cache_time = public.cache_get("RAID_INFO_UPDATE_{}".format(sid))
        if cache_time and cache_time > update_time:
            update_time = cache_time

        detail_desc = ""
        arr = detail.split("|")
        not_online_count = 0
        total_pd = 0
        total_online = 0
        pd_count = 0
        for info_str in arr:
            if not info_str or info_str.find(",") == -1:
                continue
            no, pd_count, online_count = info_str.split(",")
            pd_count = int(pd_count)
            online_count = int(online_count)
            diff = pd_count - online_count
            not_online_count += diff
            total_pd += pd_count
            total_online += online_count

        public.print_log(result['check_dell'])
        if result['check_dell'] == 1:
            res = self.parse_raid_info(output)
        else:
            res = self.parse_raid_infov2(output)

        online_count = 0
        flags = True
        for temp in res:
            for pds in temp['pds']:
                if pds['state'] == 'Onln':
                    online_count += 1
                else:
                    flags = False
                    check_res = "异常"
                    continue
            if not flags:
                break

        if check_res == "OK" or output is not None:
            check_res = "正常"
            # detail_desc = "控制器数量: {}, 总共 {} 块磁盘状态正常。".format(ctrlcount, total_pd)
            detail_desc = "控制器数量: {}, 总共 {} 块磁盘状态正常。".format(ctrlcount, pd_count)
        else:
            check_res = "异常"
            detail_desc = "共 {} 块磁盘，检测到 {} 块硬盘状态异常。".format(pd_count, pd_count - online_count)

        detail_desc = "共 {} 块磁盘，检测到 {} 块硬盘状态异常。".format(pd_count, pd_count - online_count)

        # res = self.parse_raid_info(output)

        # flags = True
        # for temp in res:
        #     for pds in temp['pds']:
        #         if pds['state'] != 'Onln':
        #             flags = False
        #             check_res = "异常"
        #             break
        #     if not flags:
        #         break
        # detail_desc = "共 {} 块磁盘，检测到 {} 块硬盘状态异常。".format(pd_count, not_online_count)

        data = {
            "content": res,
            "last_check_time": update_time,
            "check_res": check_res,
            "check_detail": detail_desc,
            "check_dell": check_dell
        }

        return public.success(data)

    def set_sampling_global(self, args):
        '''
            @name 全局监控数据采样设置
            @author Zhj<2023-01-11>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid_list = args.get('sid', None)
        sampling = args.get('sampling', None)
        status = args.get('status', None)

        if sid_list is None:
            return public.error('缺少参数：sid')

        if sampling is None:
            return public.error('缺少参数：sampling')

        if status is None:
            return public.error('缺少参数：status')

        if not re.match(r'^\d+(?:\d+)*$', str(sid_list)):
            return public.error('参数格式错误：sid')

        sid_list = str(sid_list).split(',')

        server_list = g.get("server_list", [])
        if not AccessDifference(sid_list, server_list):
            public.response(False, '您没有权限访问!')

        with monitor_db_manager.db_mgr() as db:
            # 关闭事务自动提交
            db.autocommit(False)

            sampling_global = db.query() \
                .name('servers') \
                .where_in('sid', sid_list) \
                .field('sid', 'sampling') \
                .column('sampling', 'sid')

            for sid in sid_list:
                sid = int(sid)

                if sid not in sampling_global:
                    continue

                db.query() \
                    .name('servers') \
                    .where('sid', sid) \
                    .update({
                    'sampling': int(sampling_global[sid]) | int(sampling) if int(status) == 1 else int(
                        sampling_global[sid]) & ~int(sampling),
                })

            # 提交事务
            db.commit()

        return public.success('设置成功')

    def get_sampling_global(self, args):
        '''
            @name 获取全局监控数据采样设置
            @author Zhj<2023-01-11>
            @param args<dict> 请求参数列表
            @return dict
        '''

        sid = args.get('sid', None)
        sampling = args.get('sampling', None)

        if sid is None:
            return public.error('缺少参数：sid')
        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')

        if sampling is None:
            return public.error('缺少参数：sampling')

        return public.success(basic_monitor_obj.sampling_global(sid, sampling))

    def set_sampling(self, args):
        '''
            @name 监控数据采样设置
            @author Zhj<2023-01-06>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sampling_open = args.get('open', None)

        if sampling_open is None:
            return public.error('缺少参数：open')

        sampling_types = args.get('types', None)

        if sampling_types is None:
            return public.error('缺少参数：types')

        if not re.match(r'^\d+(?:,\d+)*$', str(sampling_types)):
            return public.error('参数格式错误：types')

        k = None

        sid_list = args.get('sid', None)
        process_id_list = args.get('pid', None)

        if sid_list is None and process_id_list is None:
            return public.error('缺少参数：sid或process_id')

        if sid_list is not None:
            sid_list = sid_list.split(',')
            server_list = g.get("server_list", [])
            if not AccessDifference(sid_list, server_list):
                public.response(False, '您没有权限访问!')

        kn = 'sid'
        ks = sid_list
        prefix = 'server'

        if process_id_list is not None:
            kn = 'pid'
            ks = process_id_list
            prefix = 'process'

        if not re.match(r'^\d+(?:,\d+)*$', str(ks)):
            return public.error('参数格式错误：{}'.format(kn))

        insert_data = []

        for k in str(ks).split(','):
            for sampling_type in sampling_types.split(','):
                insert_data.append({
                    'id': public.mmh3_hash64('{}|{}|{}'.format(prefix, k, sampling_type)),
                    'status': int(sampling_open),
                })

        with monitor_db_manager.db_mgr('sampling_settings') as db:
            db.query() \
                .name('sampling_settings') \
                .insert_all(insert_data, option='replace')

        return public.success('设置成功')

    def get_server_sampling_settings(self, args):
        '''
            @name 获取主机基础监控数据采样设置列表
            @author Zhj<2023-01-07>
            @param args<dict> 请求参数列表
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        return public.success(self._get_sampling_settings(sid, 'server'))

    def get_process_sampling_settings(self, args):
        '''
            @name 获取进程监控数据采样设置列表
            @author Zhj<2023-01-07>
            @param args<dict> 请求参数列表
            @return dict
        '''
        process_id = args.get('pid', None)

        if process_id is None:
            return public.error('缺少参数：pid')

        return public.success(self._get_sampling_settings(process_id, 'process'))

    #   获取监控数据采样设置帮助函数
    def _get_sampling_settings(self, key, p_type='server'):
        '''
            @name 获取监控数据采样设置帮助函数
            @author Zhj<2023-01-07>
            @param key<int>         主机ID或进程ID
            @param p_type<string>   分类(server|process)
            @return dict
        '''
        d = {
            'server': [
                monitor_enums.SAMPLING_TYPE__GLOBAL,
                monitor_enums.SAMPLING_TYPE__CPU,
                monitor_enums.SAMPLING_TYPE__MEM,
                monitor_enums.SAMPLING_TYPE__SWAP,
                monitor_enums.SAMPLING_TYPE__LOAD_AVG,
                monitor_enums.SAMPLING_TYPE__DISK,
                monitor_enums.SAMPLING_TYPE__DISK_IO,
                monitor_enums.SAMPLING_TYPE__NET_IO,
            ],
            'process': [
                monitor_enums.SAMPLING_TYPE__GLOBAL,
                monitor_enums.SAMPLING_TYPE__CPU,
                monitor_enums.SAMPLING_TYPE__MEM,
                monitor_enums.SAMPLING_TYPE__DISK_IO,
                monitor_enums.SAMPLING_TYPE__NET_IO,
                monitor_enums.SAMPLING_TYPE__OPENED_THREADS,
                monitor_enums.SAMPLING_TYPE__OPENED_FILES,
            ],
        }

        d_global = {
            'server': monitor_enums.SAMPLING_GLOBAL__SERVER,
            'process': monitor_enums.SAMPLING_GLOBAL__PROCESS,
        }

        if p_type not in d:
            raise RuntimeError('Invalid argument: p_type')

        sampling_settings = {}

        for sampling_type in d[p_type]:
            sampling_settings[public.mmh3_hash64('{}|{}|{}'.format(p_type, int(key), sampling_type))] = {
                'type': sampling_type,
                'status': 1,
            }

        res = basic_monitor_obj.db_easy('sampling_settings') \
            .where_in('id', sampling_settings.keys()) \
            .field('id', 'status') \
            .column('status', 'id')

        ret = {}
        for k, v in sampling_settings.items():
            ret[v['type']] = res.get(k, 1)

        # 获取全局状态
        sid = int(key)

        if p_type == 'process':
            sid = basic_monitor_obj.db_memory('processes') \
                .where('id', int(key)) \
                .value('sid')

        global_sampling = basic_monitor_obj.db_easy('servers') \
            .where('sid', sid) \
            .value('sampling')

        # 当全局处于关闭状态时，全部更新为关闭状态
        if (int(global_sampling) & d_global[p_type]) != d_global[p_type] or ret[
            monitor_enums.SAMPLING_TYPE__GLOBAL] == 0:
            for k in ret.keys():
                ret[k] = 0

        return ret

    #   nginx 信息
    def get_nginx_stats_info(self, args):
        '''
            @name nginx监控
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
            @permission:False
        '''
        sid = args.get('sid', None)
        if sid is None:
            return public.error('缺少参数：sid')

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('nginx_stats_info') as db:
            query = db.query().name('nginx_stats_info')
            nginx_stats_info = query.find()

        if nginx_stats_info is None:
            nginx_stats_info = {
                "version": "",
                "start_cmd": "",
                "conf_path": "",
                "ports": "",
                "modules": "",
                "worker_processes": "",
                "worker_connections": 0,
                "keepalive_timeout": 0,
                "gzip": "",
                "gzip_min_length": 0,
                "gzip_comp_level": 0,
                "client_max_body_size": 0,
                "server_names_hash_bucket_size": 0,
                "client_header_buffer_size": 0,
                "client_body_buffer_size": 0,
                "process": 0,
                "website": 0,
                "website_list": [
                    {
                        "port": "",
                        "domain_list": [
                            " "
                        ],
                        "config_url": "",
                        "log_url": ""
                    },
                ],
                "create_time": 0,
                "network_io": {
                    "sent_bytes_per_second": 0,
                    "recv_bytes_per_second": 0
                },
                "requests": 0,
                "accepts": 0,
                "cpu_percent": 0,
                "mem_percent": 0
            }

        if 'network_io' not in nginx_stats_info:
            nginx_stats_info["network_io"] = {
                "sent_bytes_per_second": 0,
                "recv_bytes_per_second": 0
            }

        pne_id = basic_monitor_obj.db_easy('process_name_exe').where('name', 'nginx').value('id')
        if pne_id is not None:
            process_id = basic_monitor_obj.db_memory('processes') \
                .where('sid', sid) \
                .where('pne_id', pne_id) \
                .order('update_time', 'desc') \
                .value('id')

            proc_info = basic_monitor_obj.cache_realtime_proc_info(process_id)

            nginx_stats_info["network_io"]["sent_bytes_per_second"] = proc_info.get('net_sent_per_second', 0)
            nginx_stats_info["network_io"]["recv_bytes_per_second"] = proc_info.get('net_recv_per_second', 0)

        # network_io = public.cache_get("NGINX_NETWORK_IO_" + str(sid))
        requests = public.cache_get("NGINX_REQUESTS_" + str(sid))
        accepts = public.cache_get("NGINX_ACCEPTSS_" + str(sid))
        cpu = public.cache_get("NGINX_CPU_" + str(sid))
        mem = public.cache_get("NGINX_MEM_" + str(sid))

        # nginx_stats_info["network_io"] = network_io if network_io else {"sent_bytes_per_second":0,"recv_bytes_per_second":0}
        nginx_stats_info["requests"] = requests if requests else 0
        nginx_stats_info["accepts"] = accepts if accepts else 0
        nginx_stats_info["cpu_percent"] = cpu if cpu else 0
        nginx_stats_info["mem_percent"] = mem if mem else 0
        website_list = nginx_stats_info.get("website_list")
        nginx_stats_info["website_list"] = json.loads(website_list) if isinstance(website_list, str) else website_list
        return public.success(nginx_stats_info)

    def get_nginx_stats_connect(self, args):
        '''
            @name nginx监控获取连接详情
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
            @permission:False
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')
        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')

        pne_id = basic_monitor_obj.db_easy('process_name_exe') \
            .where('name', "nginx") \
            .value('id')

        # 获取进程ID
        pid = basic_monitor_obj.db_memory('processes') \
            .where('sid=?', sid) \
            .where('pne_id', pne_id) \
            .value('id')
        if pid is None:
            pid = basic_monitor_obj.db_easy('processes') \
                .where('sid=?', sid) \
                .where('pne_id', pne_id) \
                .value('id')
            if pid is None:
                pid = 0
        args["pid"] = pid

        # nginx 连接数据
        nginx_list = {
            "requests": {
                "fields": ['id', 'requests', 'create_time'],
                "pad_el": {'id': 0, 'requests': 0, 'create_time': 0}
            },  # 连接数据-请求数
            "accepts": {
                "fields": ['id', 'accepts', 'create_time'],
                "pad_el": {'id': 0, 'accepts': 0, 'create_time': 0}
            },  # 连接数据-总连接
            "waiting": {
                "fields": ['id', 'waiting', 'create_time'],
                "pad_el": {'id': 0, 'waiting': 0, 'create_time': 0}
            },  # 连接数据-等待连接数
            "active_connections": {
                "fields": ['id', 'active_connections', 'create_time'],
                "pad_el": {'id': 0, 'active_connections': 0, 'create_time': 0}
            },  # 连接数据-活动连接数
        }
        process_info_data = {}
        for key, desc in nginx_list.items():
            fields = desc.get("fields")
            pad_el = desc.get("pad_el")
            temp_list = basic_monitor_obj.process_statistics_helper(
                args,
                "process_nginx_stats_list",
                fields,
                pad_el=pad_el
            )

            process_info_data[key] = temp_list
        return public.success(process_info_data)

    def get_stats_list(self, args):
        '''
            @name 获取指定进程 信息
            @author Zhj<2022-12-10>
            @param args<dict> 请求参数
            @return dict
            @permission:False
        '''
        sid = args.get('sid', None)
        p_name = args.get('p_name', None)

        if sid is None:
            return public.error('缺少参数：sid')
        if p_name is None:
            return public.error('缺少参数：p_name')

        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')

        pne_id = basic_monitor_obj.db_easy('process_name_exe') \
            .where('name', p_name) \
            .value('id')

        # 获取进程ID
        pid = basic_monitor_obj.db_memory('processes') \
            .where('sid=?', sid) \
            .where('pne_id', pne_id) \
            .value('id')
        if pid is None:
            pid = basic_monitor_obj.db_easy('processes') \
                .where('sid=?', sid) \
                .where('pne_id', pne_id) \
                .value('id')
            if pid is None:
                pid = 0

        args["pid"] = pid

        process_info_dict = {
            "process_cpu_info_list": {
                "fields": ['id', 'process_id', 'percent', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'percent': 0, 'create_time': 0}
            },  # 进程CPU占用详情
            "process_mem_info_list": {
                "fields": ['id', 'process_id', 'percent', 'used', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'percent': 0, 'used': 0, 'create_time': 0}
            },  # 进程MEM占用详情
            "process_network_io_info_list": {
                "fields": ['id', 'process_id', 'recv_bytes_per_second', 'sent_bytes_per_second', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'recv_bytes_per_second': 0, 'sent_bytes_per_second': 0,
                           'create_time': 0}
            },  # 进程网络IO占用详情
            "process_disk_io_info_list": {
                "fields": ['id', 'process_id', 'read_bytes_per_second', 'write_bytes_per_second', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'read_bytes_per_second': 0, 'write_bytes_per_second': 0,
                           'create_time': 0}
            },  # 进程磁盘占用详情
            "process_opened_threads_info_list": {
                "fields": ['id', 'process_id', 'opened_threads', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'opened_threads': 1, 'create_time': 0}
            },  # 进程打开线程数
            "process_opened_files_info_list": {
                "fields": ['id', 'process_id', 'opened_files', 'create_time'],
                "pad_el": {'id': 0, 'process_id': 0, 'opened_files': 0, 'create_time': 0}
            },  # 进程打开文件数
        }
        ###
        process_info_data = {}
        for table_name, desc in process_info_dict.items():
            fields = desc.get("fields")
            pad_el = desc.get("pad_el")
            temp_list = basic_monitor_obj.process_statistics_helper(
                args,
                table_name,
                fields,
                'process_id=?',
                [int(pid)],
                pad_el=pad_el
            )

            process_info_data[table_name] = temp_list

        return public.success(process_info_data)

    #   堡垒机列表
    def fortress_list(self, args):
        '''
            @author law<2023-05-15>
            @param args<dict> 请求参数
            @return dict
        '''
        uid = public.bt_auth('uid')
        keyword = args.get('keyword', None)
        with public.sqlite_easy('monitor_mgr') as db:
            ssh_db = db.query() \
                .name('ssh_info') \
                .field('sid', 'addtime', 'host', 'port', 'username', 'uid', 'id', 'last_login_time', 'remark',
                       'password', 'pkey') \
                .order('addtime', 'desc')

            if uid > 1:
                ssh_info_ids = self.__uid_check(uid, 1)
                ssh_db.where_in('id', ssh_info_ids)

            ret = ssh_db.select()

            if keyword is not None:
                tmp = '%{}%'.format(keyword)
                ret.where('host like ? OR remark ?', [tmp, tmp])

            # ret = public.simple_page(query, args)

        uids = [d['uid'] for d in ret]

        with monitor_db_manager.db_mgr('safety') as db:
            uid_username_map = db.query() \
                .name('users') \
                .where_in('uid', uids) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in ret:
            item['systemname'] = uid_username_map.get(item['uid'], '')

        return public.success(ret)

    #   创建常用命令
    def create_command(self, args):
        '''
            @author law<2023-05-20>
            @param  args<dict_obj>{
                title<string> 标题
                shell<string> 命令文本
            }
            @return dict
        '''
        title = args.get('title', '')
        shell = args.get('shell', '')
        uid = public.bt_auth('uid')
        order_number = args.get('order_number', '')

        cmd = [{
            "title": title,
            "shell": shell.strip(),
            "uid": uid,
            "order_number": order_number
        }]

        with monitor_db_manager.db_mgr('fortress_command') as db:
            if db.query().name('fortress_command').where('title', title).exists():
                return public.error('名称【{}】已存在'.format(title))
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('fortress_command') \
                    .insert_all(cmd)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        public.WriteLog("堡垒机", '添加常用命令[{}]'.format(title))
        return public.returnMsg(True, '添加成功')

    #   修改常用命令
    def modify_command(self, args):
        '''
            @author law<2023-05-20>
            @param  args<dict_obj>{
                command_id  命令id
                title<string> 标题
                shell<string> 命令文本
            }
            @return dict
        '''
        command_id = args.get('id', '')
        uid = public.bt_auth('uid')

        new_data = {}
        old_data = basic_monitor_obj.db_easy('fortress_command').where("id=?", command_id).find()

        if "title" in args:
            # 修改了命令标题
            title = args.get('title', '')
            if old_data['title'] != title:
                if basic_monitor_obj.db_easy("fortress_command") \
                        .where("title=?", title) \
                        .exists():
                    return public.error("任务名已存在")
                new_data['title'] = title

        if "shell" in args:
            shell = args.get('shell', '')
            # 修改了命令
            if old_data['shell'] != shell:
                new_data['shell'] = shell

        if "order_number" in args:
            order_number = args.get('order_number', '')
            # 修改了排序顺序
            if old_data['order_number'] != order_number:
                new_data['order_number'] = order_number

        if len(new_data) > 0:
            new_data['update_time'] = int(time.time())
        with monitor_db_manager.db_mgr('fortress_command') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('fortress_command') \
                    .where('id=?', int(command_id)) \
                    .update(new_data)
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        public.WriteLog("堡垒机", '修改常用命令[{}为{}成功!]'
                        .format(old_data.get('title', ''), new_data.get('title', '')))
        return public.returnMsg(True, '修改成功')

    #   删除指定命令
    def remove_command(self, args):
        '''
            @author law<2023-05-20>
            @param  args<dict_obj>{
                title<string> 标题
            }
            @return dict
        '''
        command_id = args.get('id', '')
        uid = public.bt_auth('uid')

        data = basic_monitor_obj.db_easy('fortress_command') \
            .where('id=?', int(command_id)) \
            .find()

        with monitor_db_manager.db_mgr('fortress_command') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('fortress_command') \
                    .where('id=?', int(command_id)) \
                    .delete()
                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 打印异常堆栈
                public.print_exc_stack(e)
                raise e

        public.WriteLog("堡垒机", '删除常用命令[{}成功!]'.format(data['title']))
        return public.returnMsg(True, '删除成功')

    #   获取常用命令列表
    def get_command_list(self, args):
        '''
            @author law<2023-05-20>
            @param  args<dict_obj>
            @return list
        '''

        with monitor_db_manager.db_mgr('fortress_command') as db:
            query = db.query() \
                .name('fortress_command') \
                .field("*") \
                .order("order_number", 'desc') \
                .select()

        uids = [d['uid'] for d in query]

        with monitor_db_manager.db_mgr('safety') as db:
            uid_username_map = db.query() \
                .name('users') \
                .where_in('uid', uids) \
                .field('uid', 'username') \
                .column('username', 'uid')

        for item in query:
            item['systemname'] = uid_username_map.get(item['uid'], '')

        return public.success(query)

    #   批量添加堡垒机简易数据
    def simple_host_info(self, args):
        '''
           @author law<2023-05-31>
           @param  args<dict_obj>
           @return list
       '''

        with monitor_db_manager.db_mgr() as db:
            ret = db.query() \
                .name('servers') \
                .field('ip', 'sid', 'ssh_info', 'remark') \
                .where('is_authorized = 1') \
                .where('type = 0') \
                .order('ssh_info') \
                .select()

        return public.success(ret)

    #   服务器列表快速添加堡垒机
    def quick_add(self, args):
        '''
            @author law<2023-05-31>
            @param  args<dict_obj>
            @return list
        '''
        sids = args.get('sid', '').split(',')
        if len(sids) == 0: return public.success('添加成功！')
        with monitor_db_manager.db_mgr() as db:
            info = db.query() \
                .name('servers') \
                .field('ip', 'sid', 'remark') \
                .where_in('sid', sids) \
                .where('ssh_info = 0') \
                .select()

            query = db.query() \
                .name('server_details') \
                .field('port_info', 'sid') \
                .where_in('sid', sids) \
                .select()

        search_by_pne_id = basic_monitor_obj.db_easy('process_name_exe') \
            .where('name', 'sshd') \
            .value('id')

        data = {}
        for temp in query:
            for item in json.loads(temp['port_info']).values():
                if item['pne_id'] == search_by_pne_id:
                    data[temp['sid']] = item['port']
                    break

        insert_data = []
        for item in info:
            insert_data.append({
                'host': item['ip'],
                'port': data[item['sid']],
                'username': 'root',
                'sid': item['sid'],
                'remark': item['remark']
            })

        with monitor_db_manager.db_mgr() as db:

            db.query().name("ssh_info") \
                .insert_all(insert_data)

            db.query() \
                .name("servers") \
                .where_in("sid", sids) \
                .update({"ssh_info": 1})

        return public.success('添加成功！')

    #   堡垒机权限检查调用
    def __uid_check(self, uid, number):
        """
            查询uid关联role_id
            @param  uid<string>  关联字段    uid查询出 role_id
            @param  number<int>  操作类型
            0-无权限 1-可查看 2-可连接 4-可编辑 8-可删除 16-录像回放查看
            @return
        """
        with monitor_db_manager.db_mgr('safety') as db:
            role_id = db.query() \
                .name('users') \
                .where('`uid`=?', uid) \
                .value('gid')

        with monitor_db_manager.db_mgr() as db:
            ssh_ids = db.query() \
                .name('fortress_role') \
                .where('`role_id` = ?', int(role_id)) \
                .where(' `type` & {} = {}'.format(number, number)) \
                .column('ssh_id')

        return ssh_ids

    # 查询数据帮助
    def get_proc_data(self, sid, fields, table_name, query_start, query_end, order_field, process_ids=None):
        """
        查询进程数据
        """

        # public.print_log('||', _level='error')
        # public.print_log('table_name{}-- 字段{}'.format(table_name,fields), _level='error')

        # 查询数据
        def query_handler(query):
            query.field(*fields)

            if process_ids:
                query.where_in('process_id', process_ids)


        return monitor_db_manager.MonitorDbManager(sid).query(table_name, query_handler, query_start, query_end, order_field=order_field, reverse=True)

    # 处理数据帮助
    def get_time_slot_limit5(self, res, sid, type):
        """
         将数据处理成可以插入数据库的格式
        :param res: 进程监控数据
        :return:  insert_data

        """
        # 将数据时间分组
        query_data = {}
        for row in res:
            del row['id']
            time_slot = row['time_slot']
            if time_slot not in query_data:
                query_data[time_slot] = []
            query_data[time_slot].append(row)

        # 只留每组前五条数据(时间分组)
        for key in query_data:
            query_data[key] = query_data[key][:5]

        # public.print_log('||', _level='error')
        # public.print_log('***************query_data{}-- 类型{}'.format(query_data, type(query_data)), _level='error')
        insert_data = []
        for k, v in query_data.items():
            insert = {
                'sid': sid,
                'type': type,
                'time_slot': k,
                'data': json.dumps(v)
            }
            insert_data.append(insert)
        # public.print_log('||', _level='error')
        # public.print_log('$$$$$$$$$$$$$$$$$$${}-- 类型{}'.format(insert_data, type(insert_data)), _level='error')
        return insert_data

    # 获取进程监控数据
    def get_processes_list(self, date):
        """主机详情-进程监控列表 指定时间内的数据

        Args:
            args (dict_obj): 查询参数对象
                sid<integer>            主机ID
                date<?string>           时间戳 (三月前/上次同步时间)

        """
        # import time
        query_start = date
        query_end = int(time.time())

        # 当前已授权服务器sid
        sids = basic_monitor_obj.db_easy('servers') \
            .field('sid') \
            .where('is_authorized', 1) \
            .column('sid')

        # 查询数据
        # insert_data_all = []
        fields1 = ['id', 'process_id', 'percent', '`create_time` / 450  as `time_slot`']
        fields2 = ['id', 'process_id', 'percent', 'used', '`create_time` / 450  as `time_slot`']
        fields3 = ['id', 'process_id', 'read_bytes_per_second', 'write_bytes_per_second',
                   '`create_time` / 450  as `time_slot`']
        fields4 = ['id', 'process_id', 'recv_bytes_per_second', 'sent_bytes_per_second',
                   '`create_time` / 450  as `time_slot`']
        table_name1 = 'process_cpu_info_list'
        table_name2 = 'process_mem_info_list'
        table_name3 = 'process_disk_io_info_list'
        table_name4 = 'process_network_io_info_list'

        from core.include.monitor_helpers import async_call_queue

        for sid in sids:
            process_ids = basic_monitor_obj.db_memory('processes')\
                .where('sid', sid)\
                .column('id')

            if len(process_ids) == 0:
                continue

            cpu_res = self.get_proc_data(sid, fields1, table_name1, query_start, query_end, 'percent', process_ids)
            mem_res = self.get_proc_data(sid, fields2, table_name2, query_start, query_end, 'percent', process_ids)
            disk_res = self.get_proc_data(sid, fields3, table_name3, query_start, query_end,
                                          '{}+{}'.format('read_bytes_per_second', 'write_bytes_per_second'), process_ids)
            network_res = self.get_proc_data(sid, fields4, table_name4, query_start, query_end,
                                             '{}+{}'.format('recv_bytes_per_second', 'sent_bytes_per_second'), process_ids)

            cpu_data = self.get_time_slot_limit5(cpu_res, sid, 1)
            mem_data = self.get_time_slot_limit5(mem_res, sid, 2)
            disk_data = self.get_time_slot_limit5(disk_res, sid, 3)
            network_data = self.get_time_slot_limit5(network_res, sid, 4)

            insert_data = cpu_data + mem_data + disk_data + network_data
            basic_monitor_obj.db_easy('process_top_list').insert_all(insert_data, blocking=False)

        return True

    # 同步进程top5
    def sync_process_top(self, args=None):
        # 查询所有主机的进程top5 (第一次同步最近30天的数据) 之后每次同步大于上次同步时间的数据 (同步时间*7.5*60)

        # 30天前的时间戳
        last_30_day_time = int(time.time()) - 30 * 24 * 60 * 60

        # top表中最近一次同步的时间
        time_slot = basic_monitor_obj.db_easy('process_top_list').field('time_slot').value('max(`time_slot`)')
        if not time_slot:
            self.get_processes_list(last_30_day_time)
        else:
            # 有同步记录
            last_sync_time = time_slot * 450
            self.get_processes_list(last_sync_time)

        # public.print_log('进程top数据同步完成', _level='error')

        # 删除30天前的数据  计算间隔时间
        tttime = last_30_day_time / 450
        basic_monitor_obj.db_easy('process_top_list').where('time_slot < ?', tttime).delete()
        return True

    # 主动调用同步进程top5
    def sync_process_top5(self, args):
        # 推到队列
        from core.include.monitor_helpers import async_call_queue
        async_call_queue.add_task_easy(self.sync_process_top, args)
        return True

    def test_test(self, args):
        # 测试接口
        query = basic_monitor_obj.db_easy('warning_configurations') \
            .where('is_push = 1 ') \
            .where("push_methods != ''") \
            .where('template_id  > 0') \
            .count()

        rules = basic_monitor_obj.db_easy('warning_configurations') \
            .where('is_push = 1 ') \
            .where("push_methods != ''") \
            .where('template_id  > 0') \
            .select()

        # query = basic_monitor_obj.db_easy('warning_configurations') \
        # .where('is_push = 1 ') \
        # .where("push_methods != ''") \
        # .count()
        #
        # rules = basic_monitor_obj.db_easy('warning_configurations') \
        #     .where('is_push = 1 ') \
        #     .where("push_methods != ''") \
        #     .select()

        # 统计有效告警数量
        basic_monitor_obj.set_module_logs('warning_push_rules', 'query')

        return (query, rules)



