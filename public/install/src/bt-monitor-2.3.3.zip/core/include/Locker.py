import time
import fcntl
from contextlib import contextmanager
from sqlite_server import acquire

@contextmanager
def acquire_with_file(filename='/tmp/bt_monitor.lock', timeout=-1):
    with open(filename, 'w') as fp:
        fd = fp.fileno()

        # 加锁
        if timeout < 0:
            fcntl.flock(fd, fcntl.LOCK_EX)
        else:
            end_time_milli = (int(time.time()) + timeout) * 1000
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    time.sleep(0.025)
                    if end_time_milli <= int(time.time() * 1000):
                        raise Exception('Waiting Lock [{}] with timeout.'.format(filename))

        try:
            yield
        finally:
            # 释放锁
            fcntl.flock(fd, fcntl.LOCK_UN)
