#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------

#--------------------------------
# 加载器
#--------------------------------
import os, queue, time
import json
import threading
from flask import g,Response
import core.include.public as public
import core.include.rbac as rbac
from core import get_input,not_login_modules,not_login_uri,mod_action_match,check_login,check_csrf,session,cache
from hook_import import hook_import
hook_import()


import core.include.monitor_task as monitor_task
# monitor_task = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path()))

count_data = [
    # comproxy  代理
    # 'cmproxy/webssh','comproxy/proxy',#

    # 公开页
    'dashboard/get_public_server_list',

    # 病毒扫描
    'safetymonitor/immediate_scan',
    'safetymonitor/add_scan_task',
    'safetymonitor/get_server_scan_task_list',
    'safetymonitor/get_scan_task_result',
    'safetymonitor/stop_scan_task',
    'safetymonitor/handle_scan_task_result',
    'safetymonitor/ignore_scan_task_result',
    'safetymonitor/add_white_list',
    'safetymonitor/remove_white_list',
    'safetymonitor/get_white_list',
    'safetymonitor/get_scan_dashboard',
    'safetymonitor/join_isolatore',
    'safetymonitor/restore_files',
    'safetymonitor/get_isolators_list',
    'safetymonitor/isolatore_file',
    'safetymonitor/rescan_task',
    'safetymonitor/clear_scan_result',
    'safetymonitor/remove_scan_task',
    'safetymonitor/immediate_scan',
    'safetymonitor/get_scan_task_progress',
    'safetymonitor/add_virus_scan_rule',
    'safetymonitor/get_virus_scan_rule',

    # 漏洞扫描
    'safetymonitor/get_bug_count',
    'safetymonitor/get_bug_list',
    'safetymonitor/ignore_bug',
    'safetymonitor/handle_bug',
    'safetymonitor/re_scan_bug',
    'safetymonitor/re_scan_bug_all',

    # 挖矿木马扫描
    'safetymonitor/get_mining_list',
    'safetymonitor/ignore_mining',
    'safetymonitor/handle_mining',
    'safetymonitor/re_scan_mining_all',

    # ssh登录日志汇总
    'safetymonitor/get_ssh_login_logs_new',
    # ssh登录日志 统计
    'safetymonitor/ssh_login_logs_aggregation',

    # ssh命令执行汇总
    'safetymonitor/get_command_execute_logs',
    # ssh命令执行统计
    'safetymonitor/ssh_command_execute_logs_aggregation',

    # 入侵检测
    'safetymonitor/set_hids_status_simple',
    'safetymonitor/set_hids_status',
    'safetymonitor/get_hids_status',
    'safetymonitor/update_hids_status',
    'safetymonitor/get_hids_count',
    'safetymonitor/get_hids_list',
    'safetymonitor/set_hids_handle',
    'safetymonitor/del_hids',
    'safetymonitor/get_hids_white_list',
    'safetymonitor/del_hids_white_list',
    'safetymonitor/add_hids_white_list',
    'safetymonitor/get_hids_warning',
    'safetymonitor/hids_warning_all',
    'safetymonitor/set_hids_warning',
    'safetymonitor/update_hids_warning',
    'safetymonitor/set_hids_warning_simple',
    'safetymonitor/get_hids_warning_tasks',




    #  availability 监控port ping http(s)
    'availability/add_port_task',
    'availability/update_port_task',
    'availability/remove_port_task',
    'availability/get_port_result',
    'availability/add_ping_task',
    'availability/update_ping_task',
    'availability/remove_ping_task',
    'availability/get_ping_result',
    'availability/add_http_task',
    'availability/update_http_task',
    'availability/remove_http_task',
    'availability/get_http_result',
    'availability/suspend_http_task',
    'availability/suspend_ping_task',
    'availability/suspend_port_task',
    'availability/get_server_urls',
    'availability/get_server_host_port',
    'availability/get_server_list',


    # 自定义监控
    # 添加进程监控
    'custom/add_process',
    # 修改进程监控配置
    'custom/update_custom_process',
    # 删除进程监控任务
    'custom/delete_custom_process',
    # 获取脚本执行结果
    'custom/get_process_script_result',


    # 脚本监控
    # 添加
    'custom/add_custom_script',
    # 删除
    'custom/delete_custom_script',
    # 修改
    'custom/update_custom_script',
    # 暂停任务
    'custom/suspend_task',
    # 脚本执行结果
    'custom/get_custom_script_result',




    # config  系统配置
    'config/modify_two_step_auth',
    'config/modify_automatic_scan',

    # msg 通知
    'msg/get_msg_config',
    'msg/set_msg_config',
    'msg/send_test_msg',

    # rbac 用户权限
    'rbac/get_user_list',
    'rbac/create_user',
    'rbac/set_user_status',
    'rbac/modify_user',
    'rbac/remove_user',
    'rbac/get_role_list',
    'rbac/create_role',
    'rbac/set_role_status',
    'rbac/set_role_access',
    'rbac/set_role_server_access',
    'rbac/modify_role',
    'rbac/remove_role',
    'rbac/get_fortress_list',
    'rbac/set_fortress_list',

    # server  服务器列表
    'server/add_server','server/remove_server','server/add_panel_info','server/get_panel_info',
    'server/add_server_group','server/remove_server_group','server/edit_server_group',
    # Nginx进程详情
    'server/get_nginx_stats_connect',
    # 堡垒机
    'server/add_ssh_info', 'server/get_ssh_info', 'server/modify_ssh_info', 'server/delete_ssh_info',
    'server/delete_all_ssh_info', 'server/fortress_list', 'server/create_command', 'server/modify_command',
    'server/remove_command', 'server/get_command_list', 'terminal/test_connect', 'terminal/fortress_player',
    'server/quick_add','terminal/fortress_upload',


    # 主机概览
    'dashboard/get_raid_info','dashboard/repair_agent','dashboard/get_agent_info',
    # 基础监控
    'server/cpu_info_statistics',
    # 进程监控
    'server/get_sampling_global',
    # 端口监控
    'dashboard/get_host_port_info',
    # 日志监控
    'dashboard/get_logs_path_list',
    'dashboard/get_log_content',
    # 防火墙监控
    'dashboard/get_host_firewall_info',
    # 系统监控
    'dashboard/get_installed_soft_info',
    # 磁盘阵列
    'server/get_server_raid_info',
    # 危险命令执行 详情页
    'dashboard/sensitive_listpage',

    # 设置公开的服务器列表
    'dashboard/set_public_server_list',
    # 开启/关闭 公开页服务
    'dashboard/set_public_server_open',


    # terminal
    'terminal/player',

    # wanrning 模块
    'warning/get_server_list','warning/clear_tasks','warning/handled_task','warning/update_rules_by_templates',
    'warning/get_rules','warning/add_rule','warning/modify_rule','warning/remove_rules','warning/save_rules_to_template',
    'warning/modify_template','warning/apply_template_package','warning/remove_apply_template_packages',
    'warning/add_template','warning/export_templates','warning/import_templates','warning/remove_template_packages',
    'warning/add_rule_v2', 'warning/remove_rule_v2', 'warning/modify_rule_v2', 'warning/get_rule_v2',
    'warning/link_rule_to_server', 'warning/set_rule_push_status', 'warning/set_rule_push_methods',

    # 服务器列表告警事件/规则
    'dashboard/get_warning_tasks',
    'dashboard/get_server_list_rule'
]


rbac_obj = rbac.Rbac()
class loader:
    '''
        @name 加载模块
        @author hwliang
    '''
    __module = None
    __action = None
    __module_path = "{}/modules".format(public.get_panel_path())
    __action_object = None
    __module_object = None
    __plugin_path = "{}/plugin".format(public.get_panel_path())

    def __init__(self,module,action):
        '''
            @name 初始化模块加载
            @author hwliang
            @param module 模块名称
            @param action 方法名称
        '''
        self.__module = module
        self.__action = action

    def run(self, args):
        '''
            @name 加载并执行
            @author hwliang
            @param args 外部参数
            @return mixed
        '''
        m = __import__('modules.{}Module.main'.format(self.__module), fromlist=['main'])
        return getattr(m.main(), self.__action)(args)


def _check_win(uri, args):
    uri_list = [
        'dashboard/get_ssh_users_info',
        'server/cpu_info_statistics',
        'dashboard/get_installed_soft_info',
    ]

    if uri not in uri_list:
        return False

    if 'sid' not in args:
        return False

    cache_key = 'BT_MONITOR_CACHE__CHECK_WIN__{}'.format(args.get('sid'))
    is_win = public.cache_get(cache_key)

    if is_win is None:
        with public.sqlite_easy('monitor_mgr') as db:
            is_win = db.query()\
                .name('servers')\
                .where('sid', args.get('sid'))\
                .where('type', 1)\
                .exists()

        public.cache_set(cache_key, is_win)

    if not is_win:
        return False

    return True


def http_run(module, action, args=None):
    '''
        @name http请求处理
        @author hwliang
        @param module: 模块名
        @param action: 方法名
        @param args<?dict_obj> 参数
        @return mixed
    '''
    args = args or get_input()
    if not rbac_obj.AccessDecision(args): # rbac
        return public.response(False,'无权限!请向管理员申请权限!')

    if not rbac_obj.AccessTwoStepAuth(args): # 二次动态认证
        return public.response(False,'无权限!请先认证动态口令!')

    from core.include.monitor_helpers import basic_monitor_obj
    if '{}/{}'.format(module, action) in count_data:
        basic_monitor_obj.set_module_logs(module, '{}{}'.format(action, '(windows)' if _check_win('{}/{}'.format(module, action), args) else ''))

    from core.include.monitor_exceptions import BtMonitorException

    try:
        result = loader(module, action).run(args)
        if isinstance(result, Response):
            return result
        if isinstance(result, str):
            return Response(result)
        return Response(json.dumps(result, ensure_ascii=False), mimetype='application/json')
    except BtMonitorException as e:
        return Response(json.dumps(public.error(str(e)), ensure_ascii=False), mimetype='application/json')

# ws消息体队列
ws_body_queue = monitor_task.MonitorTaskQueue().blocking().run(100)
# ws_body_queue = monitor_task.MonitorTaskQueue().blocking().run_with_process(4)

# 心跳包消息队列
heartbeat_queue = monitor_task.MonitorTaskQueue().blocking().run()

# ws消息发送队列
ws_send_queue = monitor_task.MonitorTaskQueue().blocking().run()

def ws_run(ws):
    '''
        @name websocket请求处理
        @author hwliang
        @param ws: websocket对象
        @return void
    '''
    # ws监听
    while ws.connected:
        ws_body = ws.receive()
        if not ws_body: continue

        # try:
        #     ws_dict = json.loads(ws_body)
        # except Exception as e:
        #     public.print_log("receive exception: {}".format(e))
        #     del (ws_body,)
        #     continue

        # # 心跳包单独队列处理
        # if 'stype' in ws_dict and ws_dict['stype'] == 'Heartbeat':
        #     heartbeat_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))
        #     # heartbeat_queue.put(ws_body)
        #     del (ws_body, ws_dict)
        #     continue

        # public.print_log('recv ws: {}'.format(ws_dict['stype']))

        # 将ws消息体放入队列中
        # ws_body_queue.put(ws_body)
        # ws_body_queue.add_task(monitor_task.MonitorTask(ws_thread, args=(ws_body,ws)))

        ws_thread(ws_body, ws)

        del (ws_body,)

    ws.close()


def ws_send(ws,status,msg):
    '''
        @name 发送消息
        @author hwliang
        @param ws: websocket对象
        @param status: 状态码
        @param msg: 消息体
        @return void
    '''
    ws_send_help(ws, json.dumps(public.return_data(status, msg), ensure_ascii=False))
    # ws.send(json.dumps(public.return_data(status,msg),ensure_ascii=False))

# ws消息发送帮助函数
def ws_send_help(ws, msg):
    if not ws.connected:
        public.print_log('----ws{} is closed {}'.format(ws, msg))
        return False
    # 使用队列发送消息
    ws_send_queue.add_task(monitor_task.MonitorTask(ws, 'send', args=(msg,)))
    return True


# last_time = int(time.time())
def ws_thread(ws_body, ws):
    '''
        @name websocket消息处理线程
        @author hwliang
        @param ws_body: websocket消息
        @return void
    '''
    # 将接收到的消息体写入日志
    # public.print_log('recv ws_body: '+ws_body)
    if not ws_body: return
    try:
        # 解析数据
        ws_dict = json.loads(ws_body)

        args = public.to_dict_obj(ws_dict)

        # 获取模块、方法、回调
        module = args.get('module',None)
        action = args.get('action',None)
        callback = args.get('callback',None)
        server_id = args.get('server_id',None)

        # 如果是响应数据，则从callback中获取调用的模块、方法
        if callback and server_id and callback.find('recv/') == 0:
            result = public.agent_decrypt(server_id, args.pdata)

            if 'args' in result:
                result = result['args']

            if 'data' in result:
                result = result['data']

            # 缓存响应数据
            cache.set(callback, result, 120)

            return

        # 模块名和方法名是否为空？
        if not module or not action:
            return

        # 检查URI格式
        if not mod_action_match.match(module) or not mod_action_match.match(action):
            return

        # 检查登录
        uri = "{}/{}".format(module,action)
        if module not in not_login_modules and uri not in not_login_uri:
            if not check_login():
                return ws_send(ws,False,'请先登录')

            if not check_csrf():
                return ws_send(ws,False,'CSRF验证失败')

        # print('--recv message from ws action[{}] server_id[{}] server_ip[{}]'.format(action, server_id, ws.environ['REMOTE_ADDR']))

        # 缓存ws会话
        if server_id and action == 'connected':
            public.set_server_ws(ws, server_id)
            # from core import servers_ws
            # public.print_log("{}".format(servers_ws))

        # 加载模块
        loader_obj = loader(module, action)

        # 执行模块方法
        args._ws = ws
        args.remote_addr = ws.environ['REMOTE_ADDR']

        # 心跳包单独队列处理
        if 'stype' in ws_dict and ws_dict['stype'] == 'Heartbeat':
            heartbeat_queue.add_task(monitor_task.MonitorTask(ws_thread_help, args=(loader_obj, args)))
            return

        # global last_time
        # cur_time = int(time.time())
        # from core.include.monitor_helpers import counters

        # ws通用队列处理
        ws_body_queue.add_task(monitor_task.MonitorTask(ws_thread_help, args=(loader_obj, args)))
        # ws_body_queue_tasks = ws_body_queue.current_tasks()
        # if cur_time - last_time > 60:
        #     last_time = cur_time
        #     public.print_log('>>>> ws_body_queue rest tasks: {} <<<<<'.format(ws_body_queue_tasks), _level='error')
        #     public.print_log('>>>> ws_body_queue connect tasks: {} <<<<<'.format(len(counters['connect'])), _level='error')
        #     public.print_log('>>>> ws_body_queue systeminfo tasks: {} <<<<<'.format(len(counters['systeminfo'])), _level='error')
        #     public.print_log('>>>> ws_body_queue sshandsoft tasks: {} <<<<<'.format(len(counters['sshandsoft'])), _level='error')
        #     public.print_log('>>>> ws_body_queue firewall_info tasks: {} <<<<<'.format(len(counters['firewall_info'])), _level='error')
        #     public.print_log('>>>> ws_body_queue serverport tasks: {} <<<<<'.format(len(counters['serverport'])), _level='error')
        #     public.print_log('>>>> ws_body_queue loganalysis tasks: {} <<<<<'.format(len(counters['loganalysis'])), _level='error')
        #     public.print_log('>>>> ws_body_queue raidcheck tasks: {} <<<<<'.format(len(counters['raidcheck'])), _level='error')
        #     public.print_log('>>>> ws_body_queue intrusion_detection tasks: {} <<<<<'.format(len(counters['intrusion_detection'])), _level='error')
        #     public.print_log('>>>> ws_body_queue process tasks: {} <<<<<'.format(len(counters['process'])), _level='error')
        #     public.print_log('>>>> ws_body_queue networktraffic tasks: {} <<<<<'.format(len(counters['networktraffic'])), _level='error')
        #
        # if ws_dict['stype'] != '':
        #     if ws_dict['stype'] in counters:
        #         counters[ws_dict['stype']].append(None)
        # else:
        #     counters['connect'].append(None)

    except BaseException as e:
        try:
            public.print_exc_stack(e)

            del (e,)

            if ws.connected:
                ws_send_help(ws, public.get_error_info())
                # ws.send(public.get_error_info())
        except BaseException as e:
            del (e,)

# websocket消息处理函数
def ws_thread_help(loader_obj, args):
    result = loader_obj.run(args)

    # 如果返回侧为空？
    if not result:
        return

    if not args._ws.connected:
        return

    # 如果响应值不是dict
    if isinstance(result, dict):
        result['callback'] = args.get('callback', None)
        ws_send_help(args._ws, json.dumps(result, ensure_ascii=False))
    elif isinstance(result, str):
        ws_send_help(args._ws, result)
    else:
        ws_send_help(args._ws, json.dumps(result, ensure_ascii=False))
