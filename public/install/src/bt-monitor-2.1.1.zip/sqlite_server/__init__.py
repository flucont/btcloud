# -*- coding: utf-8 -*-

from core.include.public import get_panel_path, import_via_loader

# from sqlite_server.sqlite_server import SqliteServer, SqliteClient, SqliteEasy, Db

sqlite_server = import_via_loader('{}/sqlite_server/sqlite_server.py'.format(get_panel_path()))
SqliteServer = sqlite_server.SqliteServer
SqliteClient = sqlite_server.SqliteClient
SqliteEasy = sqlite_server.SqliteEasy
Db = sqlite_server.Db
acquire = sqlite_server.acquire
