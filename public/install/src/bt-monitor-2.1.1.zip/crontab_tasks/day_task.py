import os
import sys
import re

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
from modules.msgModule.main import main as msg_main


def check_disk():
    """检查安装目录空间是否足够"""
    disk_info = public.get_disk_info()
    # print(disk_info)
    find_path = "/www"
    threshold = 80
    # inode_threshold = 90
    if not disk_info:
        return -1
    notifi = False
    _root = None
    for d in disk_info: 
        if d["path"] == "/":
            _root = d
            continue
        if re.match("^{}/.+".format(d['path']),find_path):
            usage = float(d['size'][1]) * 1024
            total = float(d['size'][0]) * 1024
            rate = round(((usage/total) * 100), 2)
            print("Rate: {}".format(rate))
            if rate >= threshold:
                notifi = True
                break

            # inode_usage = float(d['inodes'])
    if not notifi:
        if _root:
            usage = float(_root["size"][1]) * 1024
            total = float(_root["size"][0]) * 1024
            rate = round(((usage/total) * 100), 2)
            print("Root rate: {}".format(rate))
            if rate >= threshold:
                notifi = True

    if notifi:
        send_notification()

def send_notification():
    print("发送磁盘占用过高通知。")
    mm = msg_main()
    get = public.dict_obj()
    get.msg_info = "云监控所在磁盘可用空间已少于20%，请及时清理或扩容出足够的空间，以免影响服务正常运行。"
    get.title = "云监控磁盘告警通知"
    send_res = mm.auto_send(get)
    if send_res["status"]:
        print("消息发送成功！")
    else:
        if "error_msg" in send_res:
            print("消息发送失败: {}".format(send_res["error_msg"]))
        else:
            print("消息发送失败。")

if __name__ == "__main__":
    check_disk()