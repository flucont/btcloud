#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, sys, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

import core.include.public as public
import core.include.monitor_helpers
import core.include.c_loader.PluginLoader as plugin_loader


def create_admin():
    '''
        @name 创建超级管理员账户admin
        @return string
    '''
    # username = public.gen_password(8)
    username = 'admin'
    pwd = public.gen_password(16)
    ret = plugin_loader.module_run('rbac', 'create_user', public.to_dict_obj({
        'username': username,
        'nickname': '超级管理员',
        'ps': '超级管理员',
        'pwd': pwd,
        'gid': 1,
    }))

    if not isinstance(ret, dict):
        return '用户创建失败'

    if not ret.get('status', False):
        return '用户创建失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return "用户创建成功\n用户名: {}\n密码: {}".format(username, pwd)

def reset_pwd(pwd = None):
    '''
        @name 重置admin密码
        @param pwd<?string> 新的密码
        @return string
    '''
    uid = None
    with public.sqlite_easy('safety') as db:
        uid = db.query()\
            .name('users')\
            .where('gid=1')\
            .order('uid', 'asc')\
            .value('uid')

    if not uid:
        return '密码重置失败: 账号不存在'

    pwd = pwd if pwd is not None else public.gen_password(16)
    ret = plugin_loader.module_run('rbac', 'set_user_pwd', public.to_dict_obj({
        'uid': uid,
        'pwd': pwd,
    }))

    if not isinstance(ret, dict):
        return '密码重置失败'

    if not ret.get('status', False):
        return '密码重置失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return "密码重置成功\n新密码: {}".format(pwd)

def adminpath(admin_path = None):
    '''
        @name 获取安全入口
        @param admin_path<?string> 新的安全入口
        @return string
    '''
    if admin_path is None:
        admin_path = public.get_admin_path()

        if admin_path not in ['', '/', '/login']:
            return admin_path[1:]
        else:
            admin_path = None

    admin_path = public.md5(public.GetRandomString(16))[:9] if admin_path is None else admin_path

    if len(admin_path) < 8:
        return '安全入口最小8位'

    ret = plugin_loader.module_run('config', 'modify_admin_path', public.to_dict_obj({
        'admin_path': '/{}'.format(admin_path),
    }))

    if not isinstance(ret, dict):
        return '获取安全入口失败'

    if not ret.get('status', False):
        return '获取安全入口失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return admin_path

def server_port(port = None):
    '''
        @name 获取端口号
        @param port<?integer> 新端口
        @return string
    '''
    if port is None:
        return public.get_panel_port()

    ret = plugin_loader.module_run('config', 'modify_port', public.to_dict_obj({
        'port': port,
    }))

    if not isinstance(ret, dict):
        return '设置端口号失败'

    if not ret.get('status', False):
        return '设置端口号失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return port

def accept_domain(acc_domain = None):
    '''
        @name 设置访问域名
        @param acc_domain<?string> 访问域名
        @return string
    '''
    if acc_domain is None:
        return public.get_config_value('config', 'accept_domain')

    if acc_domain == '0':
        acc_domain = ''

    ret = plugin_loader.module_run('config', 'modify_accept_domain', public.to_dict_obj({
        'bind_domain': acc_domain,
    }))

    if not isinstance(ret, dict):
        return '设置访问域名失败'

    if not ret.get('status', False):
        return '设置访问域名失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return 'ok'

def accept_ip(acc_ip = None):
    '''
        @name  设置授权IP
        @param acc_ip<?string> 授权IP列表 多个使用[,]分隔
        @return string
    '''
    if acc_ip is None:
        return ','.join(public.get_config_value('config', 'accept_ip'))

    if acc_ip == '0':
        acc_ip = ''

    ret = plugin_loader.module_run('config', 'modify_accept_ip', public.to_dict_obj({
        'accept_ip': acc_ip,
    }))

    if not isinstance(ret, dict):
        return '设置授权IP失败'

    if not ret.get('status', False):
        return '设置授权IP失败{}'.format(': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    return 'ok'

def basic_auth(status = None, username = '', pwd = ''):
    '''
        @name 设置basic_auth状态
        @param status<?integer>    basic_auth状态 1-开启 0-关闭
        @param username<string>    basic_auth用户名[可选]
        @param pwd<string>         basic_auth密码[可选]
        @return string
    '''
    if status is None:
        return '开启' if public.get_config_value('basic_auth', 'open') else '关闭'

    ret = plugin_loader.module_run('config', 'modify_basic_auth', public.to_dict_obj({
        'open': status,
        'basic_user': username,
        'basic_pwd': pwd,
    }))

    if not isinstance(ret, dict):
        return '设置basic auth失败'

    if not ret.get('status', False):
        return '设置basic auth失败{}'.format(': %s' % ret['msg'] if 'msg' in ret else '')

    return 'ok'

def remove_server(server_ip):
    '''
        @name 删除主机
        @param server_ip<string> 主机IP
        @return string
    '''
    s = time.time()
    print('--正在删除主机[{}]'.format(server_ip))

    ret = plugin_loader.module_run('server', 'remove_server', public.to_dict_obj({
        'server_ip': server_ip,
    }))

    if not isinstance(ret, dict):
        return '删除主机[{}]失败'.format(server_ip)

    if not ret.get('status', False):
        return '删除主机[{}]失败{}'.format(server_ip, ': %s' % ret['error_msg'] if 'error_msg' in ret else '')

    print('--删除主机[{}]成功 耗时：{}秒'.format(server_ip, time.time() - s))

    return 'ok'

if __name__ == '__main__':
    args = sys.argv[1:]

    if len(args) == 0:
        print('缺少参数')
        exit(0)

    m_obj = sys.modules.get(__name__)

    if not hasattr(m_obj, args[0]):
        print('无效的参数：{}'.format(args[0]))
        exit(0)

    print(getattr(m_obj, args[0])(*args[1:]))