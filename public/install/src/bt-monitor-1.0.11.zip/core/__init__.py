import logging
import sys
import json
import os
import threading
import time
import re
import uuid
import psutil
panel_path = '/www/server/bt-monitor'

os.chdir(panel_path)
if not 'modules/' in sys.path:
    sys.path.insert(0, 'modules/')


from flask import Config, Flask, session, render_template, send_file, request, redirect, g, make_response, \
    render_template_string, abort,stream_with_context, Response as Resp

from core.include.cachelib.simple import SimpleCache
from core.include.flask_session import Session
from core.include.flask_compress import Compress
from werkzeug.wrappers import Response
import core.include.public as public
from flask_sock import Sock
from multiprocessing import JoinableQueue

cache = SimpleCache()
# client_data_queue = JoinableQueue()

# 初始化Flask应用
app = Flask(__name__, template_folder="template/",static_folder="static/",root_path=panel_path)
Compress(app)
sockets = Sock(app)

# 初始化云监控
if not os.path.exists('{}/data/initialized'.format(public.get_panel_path())):
    import core.include.monitor_helpers

# 更新版本补丁
least_patch_version_pattern = re.compile(r'^(?:1\.0\.(?:[4-9]|[1-9]\d+)|1\.[1-9]\d*\.\d+|(?:[2-9]|[1-9]\d+)\.\d+\.\d+)$')
if least_patch_version_pattern.match(public.ReadFile('{}/version.pl'.format(public.get_panel_path()))):
    public.import_via_loader('{}/core/include/monitor_version_patch.py'.format(public.get_panel_path())).MonitorVersionPatch()

panel_config = public.read_config('config')
for key in panel_config.keys():
    app.config[str.upper(key)] = panel_config[key]

is_debug = app.config.get('DEBUG', False)

# 设置BasicAuth
basic_auth_conf = 'config/basic_auth.json'
app.config['BASIC_AUTH_OPEN'] = False
if os.path.exists(basic_auth_conf):
    try:
        ba_conf = json.loads(public.readFile(basic_auth_conf))
        app.config['BASIC_AUTH_USERNAME'] = ba_conf['basic_user']
        app.config['BASIC_AUTH_PASSWORD'] = ba_conf['basic_pwd']
        app.config['BASIC_AUTH_OPEN'] = ba_conf['open']
    except:
        pass

# 初始化SESSION服务
app.secret_key = public.md5('BT_MONITOR__' + str(os.uname()) + str(psutil.boot_time())) # uuid.UUID(int=uuid.getnode()).hex[-12:]
local_ip = None
my_terms = {}
servers_ws = {}

app.config['SESSION_MEMCACHED'] = SimpleCache(1000, 86400)
app.config['SESSION_TYPE'] = 'memcached'
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'BT_:'
app.config['SESSION_COOKIE_NAME'] = public.md5(app.secret_key)
app.config['PERMANENT_SESSION_LIFETIME'] = 86400 * 30
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = True

Session(app)

method_all = ['GET', 'POST']
method_get = ['GET']
method_post = ['POST']
json_header = {'Content-Type': 'application/json; charset=utf-8'}
text_header = {'Content-Type': 'text/plain; charset=utf-8'}
uri_match = re.compile(r"(^/static/[\w_\./\-]+\.(js|css|png|jpg|gif|ico|svg|woff|woff2|ttf|otf|eot|map)$|^/[\w_\./\-]*$)")
my_terms = {}

# =============================== 路由 ===============================
@app.route('/',methods=method_get)
def index():
    '''
        @name 首页
        @author hwliangG
        @return Response
    '''
    # 检查是否登录
    if not check_login():
        admin_path = public.get_admin_path()
        if admin_path in ['', '/', '/login']:
            return render_template('login.html')
        abort(403)
        # return redirect(public.get_admin_path())
    return render_template('index.html')

@app.route(public.get_admin_path(), methods=method_get)
def login():
    '''
        @name 登录页面
        @author hwliang
        @return Response
    '''
    return render_template('login.html')


mod_action_match = re.compile("^[\w\-]+$")
not_login_uri = app.config.get('NOT_LOGIN_URI',[])              # 免登录路由
not_login_modules = app.config.get('NOT_LOGIN_MODULES',[])    # 免登录模块
@app.route('/<module>/<action>', methods=method_all)
def http_route(module, action):
    '''
        @name HTTP入口
        @author hwliang
        @param module 模块名
        @param action 方法名
        @return Response
    '''
    # URI格式验证
    if not mod_action_match.match(module) or not mod_action_match.match(action):
        return public.response(False,'错误的模块名或方法名', 400)
    g.module = module
    g.action = action

    # 检查是否登录
    uri = '/{}/{}'.format(module, action)
    if not uri in not_login_uri and not module in not_login_modules:
        if not check_login():
            return public.response(False,'请先登录',401)

        # CSRF验证
        if not check_csrf():
            return public.response(False, 'CSRF验证失败',401)

    # 调用模块方法
    import core.loader as loader
    result =  loader.http_run(module, action)

    # 如果是登录后台，且登录成功，写cookie-token
    if module == 'user' and action == 'login':
        result = is_login(result)
    return result

@sockets.route('/ws')
def ws_route(ws):
    '''
        @name WebSocket入口
        @author hwliang
        @param ws: WebSocket对象
        @return void
    '''
    import core.loader as loader
    loader.ws_run(ws)


@app.route('/code',methods=method_get)
def code():
    '''
        @name 获取图形验证码
        @author hwliang
        @return Response
    '''
    # if not 'login_code' in session: return ''
    # if not session['login_code']: return ''
    # 获取图片验证码
    try:
        import core.include.vilidate as vilidate
    except:
        return "Pillow not install!"
    vie = vilidate.vieCode()
    codeImage = vie.GetCodeImage(80, 4)

    from io import BytesIO
    out = BytesIO()
    codeImage[0].save(out, "png")
    cache.set("codeStr", public.md5("".join(codeImage[1]).lower()), 180)
    cache.set("codeOut", 1, 0.1)
    out.seek(0)
    return public.send_file(out, mimetype='image/png')

@app.route('/tips', methods=method_get)
def tips():
    '''
        @name 浏览器兼容提示页面
        @author Zhj<2022-07-25>
        @return Response
    '''
    return render_template('tips.html')

# =============================== 路由 ===============================


# =============================== FLASK HOOK ===============================

auth_skip_pattern = re.compile(r'^\/(?:api\/\w+|ws\/?)$')
# Flask请求勾子
@app.before_request
def request_check():
    '''
        @name Flask请求前检查
        @author hwliang
        @return Response or None
    '''
    if request.method not in ['GET','POST']:return abort(404)

    if "Referer" in request.headers and not request.full_path.startswith("/static/panel"):
        referer = request.headers["Referer"]
        try:
            from urllib.parse import urlparse
        except:
            from urlparse import urlparse
        parse_result = urlparse(referer)
        match_res = re.search("cmproxy/(\d+)/", parse_result.path)
        if match_res:
            to_server_id = match_res[1]
            proxy_path = request.full_path
            if not proxy_path:
                proxy_path = "/"
            import core.loader as loader
            g.module = "cmproxy"
            g.action = "proxy"
            args = public.dict_obj()
            args.sid = to_server_id
            args.path_full = proxy_path
            return loader.http_run("cmproxy", "proxy", args)

    g.request_time = time.time()
    # 路由和URI长度过滤
    if len(request.path) > 256: return abort(403)
    if len(request.url) > 1024: return abort(403)
    # URI过滤
    if not uri_match.match(request.path): return abort(403)

    # POST参数过滤
    pdata = request.form.to_dict()
    for k in pdata.keys():
        if len(k) > 48: return abort(403)
        # if len(pdata[k]) > 256: return abort(403)

    if auth_skip_pattern.match(request.path) is None:
        # HTTP认证
        if app.config['BASIC_AUTH_OPEN']:
            auth = request.authorization
            if not auth: return send_authenticated()
            tips = '_bt.cn'
            if public.md5(auth.username.strip() + tips) != app.config['BASIC_AUTH_USERNAME'] \
                    or public.md5(auth.password.strip() + tips) != app.config['BASIC_AUTH_PASSWORD']:
                return send_authenticated()

        # 检查访问IP限制
        ip_check = public.check_ip_panel()
        if ip_check: return ip_check

        # 检查域名访问限制
        domain_check = public.check_domain_panel()
        if domain_check: return domain_check


# Flask 请求结束勾子
@app.teardown_request
def request_end(reques=None):
    '''
        @name Flask请求结束处理事项
        @author hwliang
        @return None
    '''
    if request.method not in ['GET','POST']:return

    # 写访问日志
    if request.full_path.find('/static/') == -1:
        public.write_request_log()




# Flask 404页面勾子
@app.errorhandler(404)
def error_404(e):
    if request.method not in ['GET','POST']:return
    if session.get('login',None):
        return render_template('index.html')
        # g.auth_error = True
        # return public.error_not_login()
    errorStr = '''<html>
<head><title>404 Not Found</title></head>
<body>
<center><h1>404 Not Found</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=404, headers=headers)


# Flask 403页面勾子
@app.errorhandler(403)
def error_403(e):
    if request.method not in ['GET','POST']:return
    # if not session.get('login',None):
    #     g.auth_error = True
    #     return public.error_not_login()
    errorStr = '''<html>
<head><title>403 Forbidden</title></head>
<body>
<center><h1>403 Forbidden</h1></center>
<hr><center>nginx</center>
</body>
</html>'''
    headers = {
        "Content-Type": "text/html"
    }
    return Response(errorStr, status=403, headers=headers)


# Flask 500页面勾子
@app.errorhandler(500)
def error_500(e):
    if request.method not in ['GET','POST']:return
    # if not session.get('login',None):
    #     g.auth_error = True
    #     return public.error_not_login()
    ss = '''404 Not Found: The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.

During handling of the above exception, another exception occurred:'''
    error_info = public.get_error_info().strip().split(ss)[-1].strip()
    _form = request.form.to_dict()
    if 'username' in _form: _form['username'] = '******'
    if 'password' in _form: _form['password'] = '******'
    if 'phone' in _form: _form['phone'] = '******'
    request_info = '''REQUEST_DATE: {request_date}
 PAN_VERSION: {panel_version}
  OS_VERSION: {os_version}
 REMOTE_ADDR: {remote_addr}
 REQUEST_URI: {method} {full_path}
REQUEST_FORM: {request_form}
  USER_AGENT: {user_agent}'''.format(
    request_date = public.getDate(),
    remote_addr = public.GetClientIp(),
    method = request.method,
    full_path = request.full_path,
    request_form = _form,
    user_agent = request.headers.get('User-Agent'),
    panel_version = public.version(),
    os_version = public.get_os_version()
)
    error_title = error_info.split("\n")[-1].replace('public.PanelError: ','').strip()
    if error_info.find('连接云端服务器失败') != -1:
        error_title = "连接云端服务器失败!"
    result = public.readFile(public.get_panel_path() + '/template/panel_error.html').format(error_title=error_title,request_info = request_info,error_msg=error_info)
    return Resp(result,500)
# =============================== FLASK HOOK ===============================


# =============================== 函数 ===============================
def send_authenticated():
    '''
        @name 发送HTTP认证信息
        @author hwliang
        @return Response
    '''
    request_host = public.GetHost()
    result = Response('', 401, {'WWW-Authenticate': 'Basic realm="%s"' % request_host.strip()})
    return result

def check_login():
    '''
        @name 检查登录状态
        @author hwliang
        @return bool
    '''
    if not session.get('login',None):
        return False

    # 检查会话是否过期
    stime = int(time.time())
    if stime - session.get('last_login_time',0) > app.config['SESSION_TIMEOUT']:
        # public.WriteLog("用户登录", "会话过期,请重新登录")
        public.print_log("{} 的会话过期,请重新登录, {}, {}".format(session.get('username'), session.get('last_login_time'), stime))
        session.clear()
        return False

    # 设置最后活动时间
    session['last_login_time'] = stime

    return True

def is_login(result):
    # 判断是否登录
    if 'login' in session:
        if session['login'] == True:
            result = make_response(result)
            request_token = public.GetRandomString(48)
            session['request_token'] = request_token
            samesite = app.config['SESSION_COOKIE_SAMESITE']
            secure = app.config['SESSION_COOKIE_SECURE']
            samesite = 'None'
            secure = True
            result.set_cookie('request_token__btm', request_token,
            max_age=86400 * 30,
            samesite= samesite,
            secure=secure
            )
    return result


def check_csrf():
    # CSRF校验
    if is_debug: return True

    request_token = request.cookies.get('request_token__btm','')
    if session.get('request_token','') == request_token: return True

    http_token = request.headers.get('x-http-token__btm')
    if not http_token: return False

    if http_token != session.get('request_token_head'): return False
    cookie_token = request.headers.get('x-cookie-token__btm')

    if cookie_token != session.get('request_token'): return False

    return True

# 获取输入数据
def get_input():
    data = public.dict_obj()
    exludes = ['blob']
    for key in request.args.keys():
        data[key] = str(request.args.get(key, ''))
    try:
        for key in request.form.keys():
            if key in exludes: continue
            data[key] = str(request.form.get(key, ''))
    except:
        try:
            post = request.form.to_dict()
            for key in post.keys():
                if key in exludes: continue
                data[key] = str(post[key])
        except:
            pass

    if 'form_data' in g:
        for k in g.form_data.keys():
            data[k] = str(g.form_data[k])

    if not hasattr(data, 'data'): data.data = []
    return data


# 取数据对象
def get_input_data(data):
    pdata = public.dict_obj()
    for key in data.keys():
        pdata[key] = str(data[key])
    return pdata

# =============================== 函数 ===============================


@sockets.route('/cmproxy/<int:sid>/webssh')
def panel_webssh(ws, sid=0):
    if not check_login():
        return abort(403)
    import core.loader as loader
    module = "terminal"
    action = "run"
    args = public.dict_obj()
    args.sid = sid
    args.ws = ws
    g.module = module
    g.action = module
    return loader.http_run(module, action, args)

@app.route("/cmproxy/<int:sid>/<path:path_full>", methods=method_all)
def cloud_monitor_proxy2(sid=0, path_full = None):
    """代理被控面板"""
    if not check_login():
        return abort(403)

    import core.loader as loader
    g.module = "cmproxy"
    g.action = "proxy"
    args = public.dict_obj()
    args.sid = sid
    args.path_full = path_full
    return loader.http_run("cmproxy", "proxy", args)