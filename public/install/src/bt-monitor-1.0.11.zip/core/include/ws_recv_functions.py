# encoding: utf-8
#
# Web Socket 各类型数据处理函数
# Author Zhj<2022-06-25>

import json, core.include.public as public
import core.include.c_loader.PluginLoader as plugin_loader
from core.include.monitor_helpers import basic_monitor_obj

# basic_monitor_obj = plugin_loader.get_module('{}/core/include/monitor_helpers.py'.format(public.get_panel_path())).basic_monitor_obj

def recv_Heartbeat(ret):
    '''
        @name 主机心跳包
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''

    # public.print_log('recv Heartbeat:' + json.dumps(ret))
    # public.print_log('recv Heartbeat: {}'.format(ret['remote_addr']))
    # public.cache_set('SERVER_CONNECTION_'+str(ret['sid']), 1, 600)
    basic_monitor_obj.update_servers(ret['sid'], True, ret['remote_addr'])

def recv_firewall_info(ret):
    '''
        @name 系统防火墙规则信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''

    # public.print_log('recv firewall_info:'+json.dumps(ret))
    basic_monitor_obj.store_firewall_info(ret['sid'], ret['data']['body'])

def recv_systeminfo(ret):
    '''
        @name 主机资源信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''

    # public.print_log('recv systeminfo: {}'.format(ret))

    basic_monitor_obj.store_systeminfo(ret['sid'], ret['data']['body'])

    # 缓存SSH在线用户
    # if 'ssh_info' in ret['data']['body']:
    #     basic_monitor_obj.cache_server_ssh_users(ret['sid'], ret['data']['body']['ssh_info'])

def recv_serverport(ret):
    '''
        @name 主机端口信息
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''

    # public.print_log('recv serverport:'+json.dumps(ret))
    basic_monitor_obj.store_port_info(ret['sid'], ret['data']['body'])

def recv_loganalysis(ret):
    '''
        @name 主机SSH登录日志
        @author Zhj<2022-06-27>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv loganalysis:'+json.dumps(ret))

    '''
    try:
        ssh_logs = json.loads(ret['data']['body'])
    except:
        ssh_logs = []
    '''

    # SSH登录日志
    if 'ssh_login_info' in ret['data']['body']:
        # public.print_log('recv loganalysis: {} {}'.format(ret['remote_addr'], ret['data']['body']['ssh_login_info']))
        basic_monitor_obj.store_ssh_login_logs(ret['sid'], ret['data']['body']['ssh_login_info'])

    # 系统日志路径列表
    if 'sys_log' in ret['data']['body']:
        basic_monitor_obj.cache_server_syslog_paths(ret['sid'], ret['data']['body']['sys_log'])

def recv_networktraffic(ret):
    '''
        @name   进程流量
        @author Zhj<2022-07-04>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv networktraffic:' + json.dumps(ret))
    basic_monitor_obj.update_process_network_io_info(ret['sid'], ret['data']['body'])

def recv_process(ret):
    '''
        @name 进程信息
        @author Zhj<2022-07-04>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv process:' + json.dumps(ret))
    basic_monitor_obj.store_process_info(ret['sid'], ret['data']['body'])

def recv_sshandsoft(ret):
    '''
        @name 命令执行日志、SSH在线用户、软件安装列表
        @author Zhj<2022-07-12>
        @param  ret<dict>   主机ID与消息体
        @return void
    '''
    # public.print_log('recv sshandsoft:' + json.dumps(ret))
    
    # 缓存命令执行日志
    if 'history' in ret['data']['body']:
        basic_monitor_obj.cache_server_command_history(ret['sid'], ret['data']['body']['history'])
    
    # 缓存SSH在线用户
    if 'ssh_info' in ret['data']['body']:
        basic_monitor_obj.cache_server_ssh_users(ret['sid'], ret['data']['body']['ssh_info'])
    
    # 缓存软件安装列表
    if 'soft_info' in ret['data']['body']:
        basic_monitor_obj.cache_server_installed_softs(ret['sid'], ret['data']['body']['soft_info'])

    # 存储命令执行记录
    if 'history_realtime' in ret['data']['body']:
        # public.print_log('recv history_realtime: {} {}'.format(ret['remote_addr'], ret['data']['body']['history_realtime']))
        basic_monitor_obj.store_command_history(ret['sid'], ret['data']['body']['history_realtime'])

def recv_raidcheck(ret):
    """接收磁盘阵列检测信息

    Args:
        ret (dict): 
        checkResult: OK或NO, 磁盘都在线为OK，否则为NO
        checkOutput: 空或者perccli/storcli命令的输出结果
        controllerCount: 阵列卡控制器数量
        checkDetail: 阵列卡0;磁盘数量,在线数|阵列卡1;磁盘数量,在线数...

    """
    # public.print_log("raid check info:")
    # public.print_log(ret)
    if "data" in ret and "body" in ret["data"]:
        check_res = ret["data"]["body"]
        if "checkResult" in check_res:
            import time
            public.cache_set("RAID_INFO_UPDATE_{}".format(ret["sid"]), time.time())
            r = check_res["checkResult"]
            to_update = False
            if r.strip() == "OK":
                output = ""
                if "checkOutput" in check_res:
                    output = check_res["checkOutput"]
                    if output:
                        to_update = True
            else:
                to_update = True

                detail = ""   
                if "checkDetail" in check_res:
                    detail = check_res["checkDetail"]
                
                if detail:
                    from core.include.monitor_helpers import warning_obj
                    warning_rules = warning_obj.get_warning_rules(
                        ret["sid"], "resource", 'disk_[all]', 'raid_check')
                    # public.print_log("raid check rule:")
                    # public.print_log(warning_rules)
                    check_detail = check_res["checkDetail"]
                    try:
                        for warning_rule in warning_rules:
                            # public.print_log("warning res: {}".format(warning_obj.warn(warning_rule, check_detail)))
                            warning_obj.warn(warning_rule, check_detail)
                    except BaseException as e:
                        public.print_exc_stack(e)

            if to_update:
                basic_monitor_obj.store_raidinfo(ret["sid"], check_res)

def recv_agentinfo(ret):
    if "data" in ret and "body" in ret["data"]:
        data = ret['data']['body']
        if "agentVersion" in data:
            agent_version = data["agentVersion"]
            agent_version_file = '{}/data/monitor_servers/{}/{}'.format(public.get_panel_path(), public.md5(str(ret["sid"])), "agentversion.pl") 
            # public.print_log("local agent version file:", agent_version_file)
            public.writeFile(agent_version_file, agent_version)
            public.cache_set("AGENT_VERSION_"+str(ret["sid"]), agent_version)
            # public.print_log("agent version:"+agent_version)
    # public.print_log("Agent info:", str(ret))

            