import fcntl
import threading
from contextlib import contextmanager

# 存储所有已排序的线程锁
_local = threading.local()

@contextmanager
def acquire(*locks):
    # 升序排序
    locks = sorted(locks, key=lambda x: id(x))

    # 确保按顺序加锁
    acquired = getattr(_local, 'acquired', [])
    if acquired and max(id(lock) for lock in acquired) >= id(locks[0]):
        raise RuntimeError('Lock Order Violation')

    # 加锁
    acquired.extend(locks)
    _local.acquired = acquired

    try:
        # 按顺序加锁
        for lock in locks:
            lock.acquire()

        # 转出程序控制权
        yield
    finally:
        # 倒序释放锁
        for lock in reversed(locks):
            lock.release()
        del(acquired[-len(locks):])

@contextmanager
def acquire_with_file(filename = '/tmp/bt_monitor.lock'):
        try:
            # 加锁
            with open(lock_file, 'w') as fp:
                fcntl.flock(fp, fcntl.LOCK_EX)
            yield
        finally:
            # 释放锁
            with open(lock_file, 'w') as fp:
                fcntl.flock(fp, fcntl.LOCK_UN)