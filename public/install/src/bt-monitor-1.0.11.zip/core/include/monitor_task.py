import time
import queue, threading
import core.include.public as public
from multiprocessing import Process

class MonitorTaskQueue:
    '''
        @name 云监控任务队列类
        @author Zhj<2022-09-17>
    '''
    def __init__(self):
        self.__TASK_QUEUE = queue.Queue()
        # self.__TASK_QUEUE = JoinableQueue()
        self.__IS_RUNNING = False
        self.__THREAD_OBJS = []
        self.__BLOCKING = False

    def blocking(self, blocking = True):
        '''
            @name 设置获取队列元素时是否阻塞
            @author Zhj<2022-09-19>
            @param  blocking<?bool> 是否阻塞[可选]
            @return self
        '''
        self.__BLOCKING = blocking
        return self

    # 任务队列处理函数
    def __task_queue_handler(self):
        while True:
            # 获取当前时间
            cur_time = int(time.time())
            task_list = []
            while True:
                try:
                    task = self.__TASK_QUEUE.get(self.__BLOCKING)

                    if not isinstance(task, MonitorTask):
                        continue

                    # 执行任务
                    task.handle(cur_time)

                    self.__TASK_QUEUE.task_done()

                    # 循环执行的任务或未完成的任务
                    # 需要在本次调度完成后重新放回队列
                    if task.is_interval() or not task.is_finished():
                        task_list.append(task)
                except queue.Empty:
                    break

            for task in task_list:
                self.__TASK_QUEUE.put(task)

            # 每次调度完成后休眠1秒钟
            time.sleep(1)

    def run(self, threads = 1):
        if self.__IS_RUNNING:
            raise RuntimeError('任务队列已启动')

        # 开启线程
        for i in range(threads):
            t = threading.Thread(target=self.__task_queue_handler, daemon=True)
            # t = Process(target=self.__task_queue_handler, daemon=True)
            t.start()
            self.__THREAD_OBJS.append(t)

        return self

    def add_task(self, task):
        '''
            @name 添加任务
            @author Zhj<2022-09-17>
            @param  task<MonitorTask> 任务对象
            @return self
        '''
        self.__TASK_QUEUE.put(task)
        return self

class MonitorTask:
    '''
        @name 任务类
        @author Zhj<2022-09-17>
    '''
    def __init__(self, obj, func_name = None, args = (), kwargs = None):
        self.__OBJ = obj
        self.__FUNC_NAME = func_name
        self.__ARGS = args
        self.__KWARGS = kwargs or {}
        self.__IS_INTERVAL = False   # 是否循环执行
        self.__IS_FINISHED = False   # 任务是否完成
        self.__HANDLE_PERIODIC = 60  # 任务循环执行间隔/秒
        self.__LAST_HANDLED_TIME = 0 # 上一次执行任务时间
        self.__EXEC_WITH_PROCESS = False # 是否在子进程中执行

    def set_interval(self, interval = True, periodic = 60):
        '''
            @name 设置任务循环执行状态
            @author Zhj<2022-09-17>
            @param  interval<?bool> 是否循环执行[可选 默认True]
            @param  periodic<?integer> 任务循环执行间隔/秒[可选 默认60]
            @return self
        '''
        self.__IS_INTERVAL = interval
        self.__HANDLE_PERIODIC = periodic
        return self

    def with_process(self):
        '''
            @name 设置本次任务在子进程中执行
            @return self
        '''
        self.__EXEC_WITH_PROCESS = True
        return self

    def is_interval(self):
        '''
            @name 检查任务是否需要循环执行
            @author Zhj<2022-09-17>
            @return bool
        '''
        return self.__IS_INTERVAL

    def is_finished(self):
        '''
            @name 检查任务是否完成
            @author Zhj<2022-09-17>
            @return bool
        '''
        return self.__IS_FINISHED

    def periodic(self, periodic = 60):
        '''
            @name 设置循环执行间隔
            @author Zhj<2022-09-17>
            @param  periodic<?integer> 任务循环执行间隔/秒[可选 默认60]
            @return self
        '''
        self.__HANDLE_PERIODIC = periodic
        return self

    def handle(self, cur_time = None):
        '''
            @name 执行任务
            @author Zhj<2022-09-17>
            @param cur_time<?integer> 当前时间[可选]
            @return void
        '''
        cur_time = cur_time or int(time.time())
        if self.__LAST_HANDLED_TIME > 0 and self.__LAST_HANDLED_TIME > cur_time - self.__HANDLE_PERIODIC:
            return

        try:
            fn = None
            from inspect import isfunction
            if self.__FUNC_NAME is None and isfunction(self.__OBJ):
                fn = self.__OBJ
            elif hasattr(self.__OBJ, self.__FUNC_NAME):
                fn = getattr(self.__OBJ, self.__FUNC_NAME)

            # 执行任务
            if fn is not None:
                # 是否在子进程中执行
                if self.__EXEC_WITH_PROCESS:
                    p = Process(target=fn, args=self.__ARGS, kwargs=self.__KWARGS)
                    p.start()
                    p.join()
                else:
                    # 在主线程中执行
                    fn(*self.__ARGS, **self.__KWARGS)
        except BaseException as e:
            public.print_exc_stack(e)
        finally:
            # 一次性任务执行完后标记已完成
            if not self.__IS_INTERVAL:
                self.__IS_FINISHED = True

            # 记录本次任务执行时间
            self.__LAST_HANDLED_TIME = cur_time