# coding: utf-8
import os.path, queue, threading
from contextlib import contextmanager
import re, json, time, core.include.public as public
import core.include.sqlite as sqlite
from core.include.monitor_exceptions import BtMonitorException
import core.include.cron_task as cron_task

# import core.include.monitor_db_manager as monitor_db_manager
# import core.include.c_loader.PluginLoader as plugin_loader


monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
AuthModule = public.import_via_loader('{}/modules/authModule/main.py'.format(public.get_panel_path())).main


class BasicMonitor:
    '''
        云监控基类
        @author Zhj<2022-06-23>
    '''

    # 数据库连接对象
    __DB = None

    # 数据库连接字典
    __DB_DICT = {}

    # __DB_FILE = 'monitor'
    __DB_FILE = 'monitor_mgr'
    __INITIALIZED_CACHE_KEY = 'BT_MONITOR_CACHE__INITIALIZED__'
    __INITIALIZED_FILENAME = '{}/data/initialized'.format(public.get_panel_path())

    # 使用In-Memory模式连接数据库并初始化
    __DB_MEMORY = monitor_db_manager.MonitorDbMemory()

    # 主机信息上一次存储时间 {'sid': 'last_store_time', ...}
    __SYSTEMINFO_LAST_STORE_TIME = {}

    # 进程信息上一次存储时间 {'sid': 'last_store_time', ...}
    __PROCESS_INFO_LAST_STORE_TIME = {}

    # 进程网络信息上一次存储时间 {'sid': 'last_store_time', ...}
    __PROCESS_NETWORK_IO_LAST_STORE_TIME = {}

    # 已缓存的进程信息 {'sid|process_name|boot_name': {process_id, boot_time}, ...}
    __CACHED_PROCESSES = {}

    # 已缓存的主机总内存大小 {'sid': mem_total, ...}
    __CACHED_SERVER_MEM_TOTAL = {}

    # 已缓存的进程网络信息
    __CACHED_PROCESS_NET = {}

    # 数据写入磁盘间隔/分钟
    __DISK_WRITE_PER_MINUTES = 7.5

    # 主机进程列表已加载入内存标志
    __PROCESS_LIST_STORED_IN_MEMORY = set()

    # 主机最近一次命令执行时间
    __LATEST_COMMAND_EXECUTE_TIME = {}

    def __init__(self):
        # 上锁后执行初始化操作
        # 检查是否需要进行初始化操作
        if not self.the_project_is_initialized():
            # 上锁
            with self.acquire('LOCK_PROJECT_INITIALIZE', 15000):
                s_time = time.time()
                public.print_log('--正在初始化云监控--')
                try:
                    public.print_log('--正在初始化配置--')
                    s_time_tmp = s_time
                    # 初始化配置
                    self.__init_config()
                    e_time_tmp = time.time()
                    public.print_log('--配置初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp))

                    public.print_log('--正在初始化数据库--')
                    s_time_tmp = e_time_tmp
                    # 创建数据表
                    self.__init_tables()
                    e_time_tmp = time.time()
                    public.print_log('--数据库初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp))

                    public.print_log('--正在初始化计划任务--')
                    s_time_tmp = e_time_tmp
                    # 创建计划任务
                    self.__create_tasks()
                    e_time_tmp = time.time()
                    public.print_log('--计划任务初始化完成-- 耗时：{}秒'.format(e_time_tmp - s_time_tmp))

                    # 标记初始化完成
                    self.__set_the_project_initialized()

                    public.print_log('--云监控初始化完成-- 耗时：{}秒'.format(time.time() - s_time_tmp))
                except BaseException as e:
                    public.print_log('--云监控初始化失败--')

                    # 记录异常堆栈
                    public.print_exc_stack(e)

    def store_systeminfo(self, sid, systeminfo):
        '''
            @name   将主机详细信息存入数据库
            @author Zhj<2022-06-28>
            @param  sid<integer>        主机ID
            @param  systeminfo<dict>    主机详细信息
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        # if not self.server_is_authorized(sid):
        #     return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(systeminfo, str):
            try:
                systeminfo = json.loads(systeminfo)
            except:
                return False

        # 过滤掉光驱设备
        systeminfo['disk_list'] = list(filter(lambda x: x['name'][:7] != '/dev/sr', systeminfo['disk_list']))

        ret_flag = True

        # 获取当前时间
        cur_time = int(time.time())

        # # 更新主机信息
        # with monitor_db_manager.db_mgr() as db:
        #     try:
        #         # 关闭事务自动提交
        #         db.autocommit(False)
        #
        #         # 首先尝试更新主机详细信息
        #         update_data = {
        #             'host_info': json.dumps(systeminfo['host']),
        #             'cpu_info': json.dumps(systeminfo['cpu']),
        #             'mem_info': json.dumps(systeminfo['mem']),
        #             'disk_info': json.dumps(systeminfo['disk_list']),
        #             'net_info': json.dumps(systeminfo['net_io_list']),
        #             'load_avg': json.dumps(systeminfo['loadavg']),
        #             'update_time': int(time.time()),
        #         }
        #
        #
        #         up_ret = db.query()\
        #             .name('server_details')\
        #             .where('`sid` = ?', int(sid))\
        #             .update(update_data)
        #         if up_ret == 0\
        #             and not db.query()\
        #                 .name('server_details')\
        #                 .where('`sid` = ?', int(sid))\
        #                 .field('sid')\
        #                 .exists():
        #             # 更新失败且数据不存在则插入
        #             update_data['sid'] = sid
        #             db.query()\
        #                 .name('server_details')\
        #                 .insert(update_data)
        #
        #         # 提交事务
        #         db.commit()
        #     except BaseException as e:
        #         # 回滚事务
        #         db.rollback()
        #
        #         # 记录异常堆栈信息
        #         public.print_exc_stack(e)
        #
        #         return False

        # 将信息写入临时表
        with self.__DB_MEMORY as db_tmp:
            # 主机CPU信息收集
            if float(systeminfo['cpu']['percent']) > 0:
                db_tmp.query() \
                    .name('server_cpu_info_list') \
                    .insert({
                    'sid': sid,
                    'percent': systeminfo['cpu']['percent'],
                })

            # 主机内存信息收集
            db_tmp.query() \
                .name('server_mem_info_list') \
                .insert({
                'sid': sid,
                'percent': systeminfo['mem']['used_percent'],
                'used': systeminfo['mem']['used'],
            })

            # 主机SWAP信息收集
            if float(systeminfo['mem']['swap_used_percent']) > 0:
                db_tmp.query() \
                    .name('server_swap_info_list') \
                    .insert({
                    'sid': sid,
                    'percent': systeminfo['mem']['swap_used_percent'],
                    'used': systeminfo['mem']['swap_used'],
                })

            disk_insert_data = []
            # 主机磁盘IO信息收集
            for disk_info in systeminfo['disk_list']:
                disk_insert_data.append({
                    'sid': sid,
                    'name': disk_info['name'],
                    'used': disk_info['used'],
                    'used_percent': disk_info['used_percent'],
                    'inodes_used': disk_info['inodes_used'],
                    'inodes_used_percent': disk_info['inodes_used_percent'],
                    'iops': disk_info['iops'],
                    'io_percent': disk_info['io_percent'],
                    'read_bytes_per_second': disk_info['read_bytes_per_second'],
                    'write_bytes_per_second': disk_info['write_bytes_per_second'],
                })

            if len(disk_insert_data) > 0:
                db_tmp.query() \
                    .name('server_disk_info_list') \
                    .insert_all(disk_insert_data)

            net_insert_data = []
            # 主机网卡IO信息收集
            for net_info in systeminfo['net_io_list']:
                net_insert_data.append({
                    'sid': sid,
                    'name': net_info['name'],
                    'sent_per_second': net_info['sent_per_second'],
                    'recv_per_second': net_info['recv_per_second'],
                })

            if len(net_insert_data) > 0:
                db_tmp.query() \
                    .name('server_net_info_list') \
                    .insert_all(net_insert_data)

            # 主机负载信息收集
            if float(systeminfo['loadavg']['last1min']) > 0 \
                    or float(systeminfo['loadavg']['last5min']) > 0 \
                    or float(systeminfo['loadavg']['last15min']) > 0:
                db_tmp.query() \
                    .name('server_loadavg_info_list') \
                    .insert({
                    'sid': sid,
                    'last_1_min': systeminfo['loadavg']['last1min'],
                    'last_5_min': systeminfo['loadavg']['last5min'],
                    'last_15_min': systeminfo['loadavg']['last15min'],
                })

        # 缓存实时主机信息
        self.cache_realtime_server_info(
            sid=sid,
            host_info=systeminfo['host'],
            cpu_info=systeminfo['cpu'],
            mem_info=systeminfo['mem'],
            disk_info=systeminfo['disk_list'],
            net_info=systeminfo['net_io_list'],
            load_avg=systeminfo['loadavg']
        )

        # 根据磁盘写入间隔写入数据
        time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
        save_time_line = cur_time - 60
        last_store_time = self.__SYSTEMINFO_LAST_STORE_TIME.get(sid, 0)
        if last_store_time == 0:
            self.__SYSTEMINFO_LAST_STORE_TIME[sid] = cur_time
        if self.__SYSTEMINFO_LAST_STORE_TIME.get(sid, 0) < time_line:
            # 主机CPU收集信息新增数据
            serv_cpu_insert_data = None

            # 主机内存收集信息新增数据
            serv_mem_insert_data = None

            # 主机swap收集信息新增数据
            serv_swap_insert_data = None

            # 主机磁盘收集信息新增数据
            serv_disk_insert_data = None

            # 主机网卡收集信息新增数据
            serv_net_insert_data = None

            # 主机负载收集信息新增数据
            serv_loadavg_insert_data = None

            # 从临时表中获取平均数据
            with self.__DB_MEMORY as db_tmp:
                # 计算cpu平均使用率
                cpu_percent_avg = db_tmp \
                    .query() \
                    .name('server_cpu_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .avg('percent', 2)

                # cpu平均使用大于0时记录
                if cpu_percent_avg > 0:
                    serv_cpu_insert_data = {
                        'sid': sid,
                        'percent': cpu_percent_avg,
                    }

                # 删除临时数据
                db_tmp.query() \
                    .name('server_cpu_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

                # 计算内存平均使用率与平均占用
                mem_avg_info = db_tmp \
                    .query() \
                    .name('server_mem_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .field('ifnull(round(avg(`percent`),2),0) as `percent_avg`',
                           'ifnull(round(avg(`used`)),0) as `used_avg`') \
                    .find()

                # 内存平均使用率或平均占用大于0时记录
                if mem_avg_info['percent_avg'] > 0 or mem_avg_info['used_avg'] > 0:
                    serv_mem_insert_data = {
                        'sid': sid,
                        'percent': mem_avg_info['percent_avg'],
                        'used': mem_avg_info['used_avg'],
                    }

                # 删除临时数据
                db_tmp.query() \
                    .name('server_mem_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

                # 计算swap平均使用率与平均占用
                swap_avg_info = db_tmp \
                    .query() \
                    .name('server_swap_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .field('ifnull(round(avg(`percent`),2),0) as `percent_avg`',
                           'ifnull(round(avg(`used`)),0) as `used_avg`') \
                    .find()

                # swap平均使用率或平均占用大于0时记录
                if swap_avg_info['percent_avg'] > 0 or swap_avg_info['used_avg'] > 0:
                    serv_swap_insert_data = {
                        'sid': sid,
                        'percent': swap_avg_info['percent_avg'],
                        'used': swap_avg_info['used_avg'],
                    }

                # 删除临时数据
                db_tmp.query() \
                    .name('server_swap_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

                # 计算磁盘IO平均信息
                serv_disk_insert_data = db_tmp.query() \
                    .name('server_disk_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .group('name, sid') \
                    .field('sid', 'name', 'ifnull(round(avg(`used`)),0) as `used`',
                           'ifnull(round(avg(`used_percent`),2),0) as `used_percent`',
                           'ifnull(round(avg(`inodes_used`)),2) as `inodes_used`',
                           'ifnull(round(avg(`inodes_used_percent`),2),0) as `inodes_used_percent`',
                           'ifnull(round(avg(`iops`)),0) as `iops`',
                           'ifnull(round(avg(`io_percent`),2),0) as `io_percent`',
                           'ifnull(round(avg(`read_bytes_per_second`)),0) as `read_bytes_per_second`',
                           'ifnull(round(avg(`write_bytes_per_second`)),0) as `write_bytes_per_second`') \
                    .select()

                # 删除临时数据
                db_tmp.query() \
                    .name('server_disk_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

                # 计算网卡IO平均信息
                net_avg_info = db_tmp.query() \
                    .name('server_net_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .group('name, sid') \
                    .having('`sent_per_second` + `recv_per_second` > 0') \
                    .field('sid', 'name', 'ifnull(round(avg(`sent_per_second`)),0) as `sent_per_second`',
                           'ifnull(round(avg(`recv_per_second`)),0) as `recv_per_second`') \
                    .select()

                if len(net_avg_info) > 0:
                    serv_net_insert_data = net_avg_info

                # 删除临时数据
                db_tmp.query() \
                    .name('server_net_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

                # 计算平均负载信息
                loadavg_avg_info = db_tmp.query() \
                    .name('server_loadavg_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time>=?', time_line) \
                    .field('sid', 'ifnull(round(avg(`last_1_min`),2),0) as `last_1_min`',
                           'ifnull(round(avg(`last_5_min`),2),0) as `last_5_min`',
                           'ifnull(round(avg(`last_15_min`),2),0) as `last_15_min`') \
                    .find()

                if loadavg_avg_info['last_1_min'] + loadavg_avg_info['last_5_min'] + loadavg_avg_info[
                    'last_15_min'] > 0:
                    serv_loadavg_insert_data = loadavg_avg_info

                # 删除临时数据
                db_tmp.query() \
                    .name('server_loadavg_info_list') \
                    .where('sid=?', sid) \
                    .where('create_time<?', save_time_line) \
                    .delete()

            # 更新主机信息
            with monitor_db_manager.db_mgr() as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 首先尝试更新主机详细信息
                    update_data = {
                        'host_info': json.dumps(systeminfo['host']),
                        'cpu_info': json.dumps(systeminfo['cpu']),
                        'mem_info': json.dumps(systeminfo['mem']),
                        'disk_info': json.dumps(systeminfo['disk_list']),
                        'net_info': json.dumps(systeminfo['net_io_list']),
                        'load_avg': json.dumps(systeminfo['loadavg']),
                        'update_time': cur_time,
                    }

                    up_ret = db.query() \
                        .name('server_details') \
                        .where('`sid` = ?', int(sid)) \
                        .update(update_data)
                    if up_ret == 0 \
                            and not db.query() \
                            .name('server_details') \
                            .where('`sid` = ?', int(sid)) \
                            .field('sid') \
                            .exists():
                        # 更新失败且数据不存在则插入
                        update_data['sid'] = sid
                        db.query() \
                            .name('server_details') \
                            .insert(update_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

                    return False

            # 获取数据库管理对象
            db_mgr = monitor_db_manager.MonitorDbManager(sid)

            # 写入数据
            if serv_cpu_insert_data is not None:
                db_mgr.add('server_cpu_info_list', serv_cpu_insert_data)

            if serv_mem_insert_data is not None:
                db_mgr.add('server_mem_info_list', serv_mem_insert_data)

            if serv_swap_insert_data is not None:
                db_mgr.add('server_swap_info_list', serv_swap_insert_data)

            if serv_disk_insert_data is not None:
                db_mgr.add('server_disk_info_list', serv_disk_insert_data)

            if serv_net_insert_data is not None:
                db_mgr.add('server_net_info_list', serv_net_insert_data)

            if serv_loadavg_insert_data is not None:
                db_mgr.add('server_loadavg_info_list', serv_loadavg_insert_data)

            # 记录本次存储时间
            self.__SYSTEMINFO_LAST_STORE_TIME[sid] = cur_time

        return ret_flag

    def store_ssh_login_logs(self, sid, ssh_login_logs):
        '''
            @name 将SSH登录信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param ssh_login_logs<list> SSH登录日志
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        if self.running_dir_used_percent_high():
            return False

        if isinstance(ssh_login_logs, str):
            try:
                ssh_login_logs = json.loads(ssh_login_logs)
            except:
                return False

        ret_flag = True

        # 获取本月开始时间
        # now_time = time.localtime()
        # month_begin = int(time.mktime((now_time.tm_year, now_time.tm_mon, 1, 0, 0, 0, 0, 0, 0)))

        # 获取数据库管理对象
        # db_mgr = monitor_db_manager.MonitorDbManager(sid)

        # SSH登录日志批量插入数据
        ssh_insert_data = []

        # SSH登录状态
        login_status = None

        # 登录IP与下标
        login_ip_idx_map = {}
        i = 0

        # 获取当前时间
        cur_time = int(time.time())

        for ssh_login_log in ssh_login_logs:
            # 跳过非本月数据
            # if ssh_login_log['time'] < month_begin:
            #     continue

            # SSH登录时间大于当前时间的跳过
            if cur_time < int(ssh_login_log.get('time', 0)):
                continue

            login_ip = ssh_login_log.get('IP', '')

            ssh_insert_data.append({
                'sid': sid,
                'ip': login_ip,
                'port': ssh_login_log.get('port', 0),
                'user': ssh_login_log.get('user', ''),
                'success': 1 if ssh_login_log['status'] else 0,
                'login_time': ssh_login_log['time'],
            })

            # 登录成功
            if ssh_login_log['status']:
                login_status = 'success'

            # 记录登录IP与下标
            if login_ip != '':
                if login_ip not in login_ip_idx_map:
                    login_ip_idx_map[login_ip] = []

                login_ip_idx_map[login_ip].append(i)

            i += 1

        # 批量插入SSH登录日志
        if len(ssh_insert_data) > 0:
            # 查询IP信息
            ip_info_dict = self.search_ip_info(list(login_ip_idx_map.keys()))

            # 将IP信息更新到SSH登录信息上
            for (login_ip, idx_list) in login_ip_idx_map.items():
                if login_ip not in ip_info_dict:
                    continue

                # 拼接IP归属地信息
                ip_place = ip_info_dict[login_ip]['country'] + ip_info_dict[login_ip]['province']

                for idx in idx_list:
                    ssh_insert_data[idx]['ip_place'] = ip_place

            with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 批量插入
                    db.query() \
                        .name('ssh_login_logs') \
                        .insert_all(ssh_insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

                    ret = False

        # SSH异地登录告警
        self.warn_server_ssh_login_place_other(sid, login_status)

        return ret_flag

    def store_firewall_info(self, sid, firewall_info):
        '''
            @name 将系统防火墙信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param firewall_info<dict>  系统防火墙信息
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(firewall_info, str):
            try:
                firewall_info = json.loads(firewall_info)
            except:
                return False

        # ret_flag = True
        #
        # # 获取数据库对象
        # with public.sqlite_easy(self.__DB_FILE) as db:
        #     try:
        #         # 关闭自动提交事务
        #         db.autocommit(False)
        #
        #         # 首先尝试更新主机详细信息
        #         update_data = {
        #             'firewall_info': json.dumps({
        #                 'is_running': firewall_info['firewall_status'],
        #                 'rules': firewall_info['firewalld_info_list'],
        #                 'rule_change': firewall_info['rule_change'],
        #             }),
        #             'update_time': int(time.time()),
        #         }
        #
        #         up_ret = db.query()\
        #             .name('server_details')\
        #             .where('sid=?', sid)\
        #             .update(update_data)
        #
        #         if up_ret == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
        #             # 更新失败且数据不存在则插入
        #             update_data['sid'] = sid
        #             db.query()\
        #                 .name('server_details')\
        #                 .insert(update_data)
        #
        #         # 系统防火墙规则修改收集
        #         if firewall_info['rule_change']['add'] is not None or firewall_info['rule_change']['del'] is not None:
        #             db.query()\
        #                 .name('firewall_rule_change_logs')\
        #                 .insert({
        #                     'sid': sid,
        #                     'add': None if firewall_info['rule_change']['add'] is None else json.dumps(firewall_info['rule_change']['add']),
        #                     'del': None if firewall_info['rule_change']['del'] is None else json.dumps(firewall_info['rule_change']['del']),
        #                 })
        #
        #         # 防火墙启停收集
        #         last_log = db.query()\
        #             .name('firewall_start_stop_logs')\
        #             .where('sid=?', sid)\
        #             .order('create_time', 'DESC')\
        #             .field('id', 'status')\
        #             .find()
        #
        #         if not last_log or int(last_log['status']) != (1 if firewall_info['firewall_status'] else 0):
        #             db.query()\
        #                 .name('firewall_start_stop_logs')\
        #                 .insert({
        #                     'sid': sid,
        #                     'status': 1 if firewall_info['firewall_status'] else 0,
        #                 })
        #
        #         # 提交事务
        #         db.commit()
        #     except BaseException as e:
        #         # 回滚事务
        #         db.rollback()
        #
        #         ret_flag = False
        #
        #         # 记录异常堆栈
        #         public.print_exc_stack(e)

        ret_flag = True

        # 获取数据库对象
        with public.sqlite_easy(self.__DB_FILE) as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 首先尝试更新主机详细信息
                update_data = {
                    'firewall_info': json.dumps({
                        'is_running': firewall_info['firewall_status'],
                        'rules': firewall_info['firewalld_info_list'],
                        'rule_change': firewall_info['rule_change'],
                    }),
                    'update_time': int(time.time()),
                }

                up_ret = db.query() \
                    .name('server_details') \
                    .where('sid=?', sid) \
                    .update(update_data)

                if up_ret == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
                    # 更新失败且数据不存在则插入
                    update_data['sid'] = sid
                    db.query() \
                        .name('server_details') \
                        .insert(update_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                return False

        # 系统防火墙规则修改记录
        rule_change_insert_data = None

        # 启停记录
        start_stop_insert_data = None

        # 系统防火墙规则修改收集
        if firewall_info['rule_change']['add'] is not None or firewall_info['rule_change']['del'] is not None:
            rule_change_insert_data = {
                'sid': sid,
                'add': '[]' if firewall_info['rule_change']['add'] is None else json.dumps(
                    firewall_info['rule_change']['add']),
                'del': '[]' if firewall_info['rule_change']['del'] is None else json.dumps(
                    firewall_info['rule_change']['del']),
            }

        # 获取上一次防火墙状态
        last_status_cache_key = 'BT_MONITOR_CACHE__SERVER_FIREWALL_STATUS__{}'.format(sid)
        last_status = public.cache_get(last_status_cache_key)

        # 防火墙状态发生变化
        # 新增启停记录
        if not last_status or int(last_status) != (1 if firewall_info['firewall_status'] else 0):
            last_status = 1 if firewall_info['firewall_status'] else 0
            start_stop_insert_data = {
                'sid': sid,
                'status': last_status,
            }

            # 将防火墙状态存入缓存
            public.cache_set(last_status_cache_key, last_status)

        # 写入数据
        if rule_change_insert_data is not None or start_stop_insert_data is not None:
            # 获取数据库管理对象
            db_mgr = monitor_db_manager.MonitorDbManager(sid)

            # 写入系统防火墙规则修改记录
            if rule_change_insert_data is not None:
                db_mgr.add('firewall_rule_change_logs', rule_change_insert_data)

            # 写入启停记录
            if start_stop_insert_data is not None:
                db_mgr.add('firewall_start_stop_logs', start_stop_insert_data)

        return ret_flag

    def store_port_info(self, sid, port_info_list):
        '''
            @name 将端口信息写入数据库
            @author Zhj<2022-06-28>
            @param sid<integer>         主机ID
            @param port_info_list<list> 端口监听列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():
        # return False
        if self.running_dir_used_percent_high():
            return False

        if isinstance(port_info_list, str):
            try:
                port_info_list = json.loads(port_info_list)
            except:
                return False

        # 去重
        distinct_ports = []
        s = set()
        for port_info in port_info_list['listening_port_list']:
            k = '{}|{}|{}|{}|{}'.format(
                port_info['protocol'],
                port_info['listen_address'],
                port_info['listen_port'],
                port_info.get('process_path', ''),
                port_info.get('process_name', '')
            )

            if k in s:
                continue

            s.add(k)
            distinct_ports.append(port_info)

        ret_flag = True

        # 获取数据库对象
        with public.sqlite_easy(self.__DB_FILE) as db:
            try:
                # 关闭自动提交事务
                db.autocommit(False)

                # 首先尝试更新主机详细信息
                update_data = {
                    'port_info': json.dumps(distinct_ports),
                    'update_time': int(time.time()),
                }

                up_ret = db.query() \
                    .name('server_details') \
                    .where('sid=?', sid) \
                    .update(update_data)
                if ret_flag == 0 and not db.query().name('server_details').where('sid=?', sid).exists():
                    # 更新失败且数据不存在则插入
                    update_data['sid'] = sid
                    db.query() \
                        .name('server_details') \
                        .insert(update_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                ret_flag = False

                # 记录异常堆栈
                public.print_exc_stack(e)

        # 写入端口数据
        with monitor_db_manager.db_mgr('server_ports') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                cur_time = int(time.time())

                # 更新该主机所有端口的状态为 无效
                db.query() \
                    .name('server_ports') \
                    .where('`sid` = ?', [int(sid)]) \
                    .update({
                        'status': 0,
                        'update_time': cur_time,
                    })

                # 端口批量插入数据
                port_insert_data = []

                for port_info in distinct_ports:
                    insert_data = {
                        'sid': int(sid),
                        'ip': port_info['listen_address'],
                        'port': port_info['listen_port'],
                        'protocol': port_info['protocol'],
                        'process_name': port_info.get('process_name', ''),
                        'process_path': port_info.get('process_path', ''),
                        'status': 1,
                        'update_time': cur_time
                    }

                    # 优先更新端口状态，否则新增
                    if db.query() \
                            .name('server_ports') \
                            .where('`sid` = ?', int(sid)) \
                            .where('`ip` = ?', port_info['listen_address']) \
                            .where('`port` = ?', port_info['listen_port']) \
                            .update(insert_data) == 0:
                        port_insert_data.append(insert_data)

                # 批量插入端口
                if len(port_insert_data) > 0:
                    db.query() \
                        .name('server_ports') \
                        .insert_all(port_insert_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

                ret_flag = False

        return ret_flag

    def store_process_info(self, sid, process_list):
        '''
            @name 将进程信息写入数据库
            @author Zhj<2022-07-04>
            @param  sid<integer>        主机ID
            @param  process_list<dict>  进程列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高

        if self.running_dir_used_percent_high():
            return False

        if type(process_list) == str:
            return False

        ret_flag = True

        # 上锁
        # with self.acquire('LOCK_PROCESS_COLLECTION__{}'.format(sid)):
        # 获取当前时间
        cur_time = int(time.time())

        # 进程磁盘IO收集批量插入数据
        disk_insert_data = []

        # 进程CPU使用率收集批量插入数据
        cpu_insert_data = []

        # 进程内存占用信息收集批量插入数据
        mem_insert_data = []

        # 进程文件打开数收集批量插入数据
        opened_files_insert_data = []

        # 进程网络连接数收集批量插入数据
        opened_connections_insert_data = []

        # 进程线程数收集批量插入数据
        opened_threads_insert_data = []

        # 各状态进程数量收集批量插入数据
        # process_infos_insert_data = {
        #     'sid': sid,
        #     'total': 0,
        #     'running': 0,
        #     'sleep': 0,
        #     'stop': 0,
        #     'zombie': 0,
        # }

        # 匹配已经被kill掉的进程
        # skip_boot_command_pattern = re.compile(r'\(deleted\)$')

        # 获取数据库对象
        # with public.sqlite_easy(self.__DB_FILE) as db:
        # with monitor_db_manager.db_mgr('processes') as db:
        try:
            mem_total = None

            # 优先从内存中获取主机内存总大小
            if sid in self.__CACHED_SERVER_MEM_TOTAL:
                mem_total = self.__CACHED_SERVER_MEM_TOTAL[sid]

            # 其次从数据库获取
            else:
                # 获取主机总内存
                mem_info = self.db_easy('server_details') \
                    .where('`sid` = ?', int(sid)) \
                    .value('mem_info')

                try:
                    mem_total = json.loads(mem_info)['total']
                except:
                    raise BtMonitorException('MEM TOTAL数据异常')

                # 存入内存中
                self.__CACHED_SERVER_MEM_TOTAL[sid] = mem_total

            mem_total = int(mem_total)

            data = []
            for k, v in process_list.items():
                v["key"] = k
                v["cpu_percent"] = round(v['cpu_percent'], 2)
                v["mem_percent"] = round(int(v['memory_used']) / mem_total * 100, 2)
                data.append(v)

            new_data = data

            # 当主机进程数超过50个时，排序取前50个
            if len(data) > 50:
                new_data = sorted(data, key=lambda i: (i["cpu_percent"] + i["mem_percent"]), reverse=True)[:50]

            # 将最近10分钟的进程列表写入内存
            if sid not in self.__PROCESS_LIST_STORED_IN_MEMORY \
                    and self.db_memory('processes') \
                    .where('sid=?', sid) \
                    .where('update_time > ?', cur_time - 600) \
                    .field('id') \
                    .exists():
                processes = self.db_easy('processes') \
                    .where('sid = ?', sid) \
                    .where('update_time > ?', cur_time - 600) \
                    .select()

                self.db_memory('processes').insert_all(processes, option='ignore')

                # 标记该主机进程列表已加载进内存中
                self.__PROCESS_LIST_STORED_IN_MEMORY.add(sid)

            # 处理进程数据
            for process_info in new_data:
                process_name, boot_command = process_info["key"].split('|', 1)

                # if skip_boot_command_pattern.search(boot_command):
                #     continue

                cpu_percent = process_info["cpu_percent"]
                mem_percent = process_info['mem_percent']
                mem_used = int(process_info['memory_used'])

                # if cpu_percent<1 or mem_percent<1:
                #    continue

                # public.print_log(process_name, ":", cpu_percent, mem_percent, mem_used)

                # 记录进程实时数据
                realtime_data = {
                    'cpu_percent': cpu_percent,
                    'mem_percent': mem_percent,
                    'mem_used': mem_used,
                }

                # 进程新增数据
                insert_data = {
                    'name': process_name,
                    'status': process_info['status'][1:-1],
                    'boot_time': int(process_info['create_time']),
                    'boot_command': boot_command,
                    'boot_user': process_info['user'],
                    'opened_files': int(process_info['open_files']),
                    'opened_connections': int(process_info['connects']),
                    'opened_threads': int(process_info['threads']),
                    'disk_read_bytes': int(process_info['io_read_bytes']),
                    'disk_write_bytes': int(process_info['io_write_bytes']),
                    'cpu_used_percent': realtime_data['cpu_percent'],
                    'mem_used_percent': realtime_data['mem_percent'],
                    'disk_read_bytes_per_second': 0,
                    'disk_write_bytes_per_second': 0,
                    'update_time': cur_time,
                }

                # 检查是否存在僵尸进程
                if 'zombie' in process_info and int(process_info['zombie']) > 0:
                    insert_data['status'] = 'zombie'

                # 查询进程ID
                process_info_cache_key = '{}|{}|{}'.format(sid, process_name, boot_command)

                # 优先从内存中获取
                if process_info_cache_key in self.__CACHED_PROCESSES:
                    res = self.__CACHED_PROCESSES[process_info_cache_key]

                # 其次从数据库获取
                else:
                    res = self.db_memory('processes') \
                        .where('`sid` = ?', int(sid)) \
                        .where('`name` = ?', process_name) \
                        .where('`boot_command` = ?', boot_command) \
                        .field(
                        'id',
                        'boot_time'
                    ).find()

                    # 写入内存
                    self.__CACHED_PROCESSES[process_info_cache_key] = res

                process_id = 0 if self.is_empty_result(res) else int(res['id'])

                # 收集进程磁盘信息
                # 获取上一次进程磁盘信息收集时间
                # last_disk_info = proc_disk_io.get(process_id, None)

                disk_info = {
                    'process_id': process_id,
                    'read_bytes_per_second': process_info.get('proc_io_read_bytes', 0),
                    'write_bytes_per_second': process_info.get('proc_io_write_bytes', 0),
                }

                # 查询到上一次收集进程磁盘信息时间
                # 计算磁盘每秒读写字节数
                # if not self.is_empty_result(last_disk_info)\
                #         and int(last_disk_info['create_time']) >= insert_data['boot_time']:
                #     time_diff = cur_time - int(last_disk_info['create_time'])
                #
                #     if time_diff < 1:
                #         disk_info['read_bytes_per_second'] = last_disk_info['read_bytes_per_second']
                #         disk_info['write_bytes_per_second'] = last_disk_info['write_bytes_per_second']
                #     else:
                #         disk_info['read_bytes_per_second'] = round(max(0, insert_data['disk_read_bytes'] - int(res['disk_read_bytes'])) / time_diff)
                #         disk_info['write_bytes_per_second'] = round(max(0, insert_data['disk_write_bytes'] - int(res['disk_write_bytes'])) / time_diff)

                insert_data['disk_read_bytes_per_second'] = disk_info['read_bytes_per_second']
                insert_data['disk_write_bytes_per_second'] = disk_info['write_bytes_per_second']

                # 查询到进程ID则更新，没有则新增
                if self.is_empty_result(res):
                    # 没有查询到进程ID，新增
                    insert_data['sid'] = int(sid)
                    process_id = self.db_memory('processes').insert(insert_data)
                else:
                    insert_data['disk_read_bytes_per_second'] = disk_info['read_bytes_per_second']
                    insert_data['disk_write_bytes_per_second'] = disk_info['write_bytes_per_second']

                    # 更新
                    self.db_memory('processes') \
                        .where('`id` = ?', process_id) \
                        .update(insert_data)

                # 将进程信息缓存更新到内存中
                self.__CACHED_PROCESSES[process_info_cache_key] = {
                    'id': process_id,
                    'boot_time': insert_data['boot_time'],
                }

                disk_info['process_id'] = process_id

                # 收集进程磁盘IO信息
                # 磁盘IO大于0时才收集
                if disk_info['read_bytes_per_second'] > 0 or disk_info['write_bytes_per_second'] > 0:
                    disk_insert_data.append(disk_info)

                # 收集进程CPU使用率
                # CPU使用率大于0时才收集
                if realtime_data['cpu_percent'] > 0:
                    cpu_insert_data.append({
                        'process_id': process_id,
                        'percent': realtime_data['cpu_percent'],
                    })

                # 收集进程内存信息
                mem_insert_data.append({
                    'process_id': process_id,
                    'percent': realtime_data['mem_percent'],
                    'used': realtime_data['mem_used'],
                })

                # 收集进程打开文件数
                # 文件打开数大于0时才收集
                if insert_data['opened_files'] > 0:
                    opened_files_insert_data.append({
                        'process_id': process_id,
                        'opened_files': insert_data['opened_files']
                    })

                # 收集进程网络连接数
                # 网络连接数大于0时才收集
                if insert_data['opened_connections'] > 0:
                    opened_connections_insert_data.append({
                        'process_id': process_id,
                        'opened_connections': insert_data['opened_connections']
                    })

                # 收集进程线程数
                # 线程数大于1时才收集
                if insert_data['opened_threads'] > 1:
                    opened_threads_insert_data.append({
                        'process_id': process_id,
                        'opened_threads': insert_data['opened_threads']
                    })

                # 将进程实时信息写入缓存
                self.cache_realtime_proc_info(
                    process_id=process_id,
                    cpu_percent=realtime_data['cpu_percent'],
                    mem_percent=realtime_data['mem_percent'],
                    mem_used=realtime_data['mem_used'],
                    disk_read_per_second=disk_info['read_bytes_per_second'],
                    disk_write_per_second=disk_info['write_bytes_per_second']
                )

                # 统计各状态进程数
                # process_infos_insert_data['total'] += 1

                # 获取进程状态
                # process_status = insert_data['status'].lower()

                # 统计对应状态的进程数
                # if process_status in process_infos_insert_data:
                #     process_infos_insert_data[process_status] += 1
            # e = time.time()
            # public.print_log("--存储进程耗时: {}".format(e-s))
        except BaseException as e:
            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

        # 将数据写入临时表
        with self.__DB_MEMORY as db:
            # 批量插入进程磁盘IO收集信息
            if len(disk_insert_data) > 0:
                db.query() \
                    .name('process_disk_io_info_list') \
                    .insert_all(disk_insert_data)

            # 批量插入进程CPU占用收集信息
            if len(cpu_insert_data) > 0:
                db.query() \
                    .name('process_cpu_info_list') \
                    .insert_all(cpu_insert_data)

            # 批量插入进程内存占用收集信息
            if len(mem_insert_data) > 0:
                db.query() \
                    .name('process_mem_info_list') \
                    .insert_all(mem_insert_data)

            # 批量插入进程打开文件数收集信息
            if len(opened_files_insert_data) > 0:
                db.query() \
                    .name('process_opened_files_info_list') \
                    .insert_all(opened_files_insert_data)

            # 批量插入进程网络连接数收集信息
            if len(opened_connections_insert_data) > 0:
                db.query() \
                    .name('process_opened_connections_info_list') \
                    .insert_all(opened_connections_insert_data)

            # # 批量插入进程线程数收集信息
            # if len(opened_threads_insert_data) > 0:
            #     db.query() \
            #         .name('process_opened_threads_info_list') \
            #         .insert_all(opened_threads_insert_data)
            #
            # # 插入各状态进程统计数据
            # db.query()\
            #     .name('server_process_info_list')\
            #     .insert(process_infos_insert_data)

            # 根据磁盘写入间隔写入数据
            time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
            save_time_line = cur_time - 240
            save_time_line_normal = cur_time - 60
            last_store_time = self.__PROCESS_INFO_LAST_STORE_TIME.get(sid, 0)
            if last_store_time == 0:
                self.__PROCESS_INFO_LAST_STORE_TIME[sid] = cur_time
            if self.__PROCESS_INFO_LAST_STORE_TIME.get(sid, 0) < time_line:
                # 获取该主机10分钟内所有进程信息
                processes_memory = self.db_memory('processes') \
                    .where('`sid` = ?', int(sid)) \
                    .where('update_time > ?', cur_time - 600) \
                    .select()

                process_id_list = [str(p['id']) for p in processes_memory]

                process_id_list_str = ','.join(process_id_list)

                # 清空十分钟前所有非活跃进程网络IO收集数据
                # 释放内存
                sub_sql = self.db_memory('processes') \
                    .where('sid=?', sid) \
                    .where('create_time <= ?', cur_time - 600) \
                    .field('id') \
                    .build_sql(True)

                self.db_memory('process_network_io_info_list') \
                    .where('process_id IN ({})'.format(sub_sql)) \
                    .delete()

                # 更新主机进程列表
                with monitor_db_manager.db_mgr('processes') as db:
                    try:
                        # 关闭事务自动提交
                        db.autocommit(False)

                        update_ids = db.query() \
                            .name('processes') \
                            .where('id IN ({})'.format(process_id_list_str)) \
                            .column('id')

                        insert_data = []

                        for p in processes_memory:
                            if p['id'] in update_ids:
                                process_id = p['id']
                                del (p['id'])
                                db.query() \
                                    .name('processes') \
                                    .where('id=?', process_id) \
                                    .update(p)
                                continue

                            insert_data.append(p)

                        if len(insert_data) > 0:
                            db.query() \
                                .name('processes') \
                                .insert_all(insert_data, option='replace')

                        # 提交事务
                        db.commit()
                    except BaseException as e:
                        # 回滚事务
                        db.rollback()

                        # 记录异常堆栈
                        public.print_exc_stack(e)

                # 进程磁盘IO收集批量插入数据
                disk_insert_data = []

                # 进程CPU使用率收集批量插入数据
                cpu_insert_data = []

                # 进程内存占用信息收集批量插入数据
                mem_insert_data = []

                # 进程文件打开数收集批量插入数据
                opened_files_insert_data = []

                # 进程网络连接数收集批量插入数据
                opened_connections_insert_data = []

                # 进程线程数收集批量插入数据
                opened_threads_insert_data = []

                # 各状态进程数量收集批量插入数据
                # process_infos_insert_data = []

                # 打开临时数据库
                with self.__DB_MEMORY as db:
                    # 计算进程磁盘IO平均信息
                    disk_insert_data = db.query() \
                        .name('process_disk_io_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .field('process_id', 'round(avg(`read_bytes_per_second`)) as `read_bytes_per_second`',
                               'round(avg(`write_bytes_per_second`)) as `write_bytes_per_second`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_disk_io_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line_normal) \
                        .delete()

                    # 计算进程CPU使用率平均信息
                    cpu_insert_data = db.query() \
                        .name('process_cpu_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .having('`percent` > 0') \
                        .field('process_id', 'round(avg(`percent`),2) as `percent`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_cpu_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line_normal) \
                        .delete()

                    # 计算进程内存占用平均信息
                    mem_insert_data = db.query() \
                        .name('process_mem_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .having('`percent` > 0') \
                        .field('process_id', 'round(avg(`percent`),2) as `percent`', 'round(avg(`used`)) as `used`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_mem_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line) \
                        .delete()

                    # 计算进程文件打开数平均信息
                    opened_files_insert_data = db.query() \
                        .name('process_opened_files_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .having('`opened_files` > 0') \
                        .field('process_id', 'round(avg(`opened_files`)) as `opened_files`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_opened_files_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line_normal) \
                        .delete()

                    # 计算进程网络连接数平均信息
                    opened_connections_insert_data = db.query() \
                        .name('process_opened_connections_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .having('`opened_connections` > 0') \
                        .field('process_id', 'round(avg(`opened_connections`)) as `opened_connections`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_opened_connections_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line_normal) \
                        .delete()

                    # 计算进程线程数平均信息
                    opened_threads_insert_data = db.query() \
                        .name('process_opened_threads_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time>=?', time_line) \
                        .group('process_id') \
                        .having('`opened_threads` > 1') \
                        .field('process_id', 'round(avg(`opened_threads`)) as `opened_threads`') \
                        .select()

                    # 删除临时数据
                    db.query() \
                        .name('process_opened_threads_info_list') \
                        .where('process_id IN ({})'.format(process_id_list_str)) \
                        .where('create_time<?', save_time_line_normal) \
                        .delete()

                    # # 计算各状态进程数平均信息
                    # process_infos_insert_data = db.query()\
                    #     .name('server_process_info_list')\
                    #     .field('sid', 'round(avg(`total`)) as `total`', 'round(avg(`running`)) as `running`', 'round(avg(`stop`)) as `stop`',
                    #            'round(avg(`sleep`)) as `sleep`', 'round(avg(`zombie`)) as `zombie`')\
                    #     .select()
                    #
                    # # 删除临时数据
                    # db.query()\
                    #     .name('server_process_info_list')\
                    #     .delete()

                # 获取数据库管理对象
                db_mgr = monitor_db_manager.MonitorDbManager(sid)

                # 写入进程IO收集数据
                if len(disk_insert_data) > 0:
                    db_mgr.add('process_disk_io_info_list', disk_insert_data)

                # 写入CPU使用率收集数据
                if len(cpu_insert_data) > 0:
                    db_mgr.add('process_cpu_info_list', cpu_insert_data)

                # 写入内存占用收集数据
                if len(mem_insert_data) > 0:
                    db_mgr.add('process_mem_info_list', mem_insert_data)

                # 写入文件打开数收集数据
                if len(opened_files_insert_data) > 0:
                    db_mgr.add('process_opened_files_info_list', opened_files_insert_data)

                # 写入网络连接数收集数据
                if len(opened_connections_insert_data) > 0:
                    db_mgr.add('process_opened_connections_info_list', opened_connections_insert_data)

                # 写入线程数收集数据
                if len(opened_threads_insert_data) > 0:
                    db_mgr.add('process_opened_threads_info_list', opened_threads_insert_data)

                # 记录本次进程信息存储时间
                self.__PROCESS_INFO_LAST_STORE_TIME[sid] = cur_time

        return ret_flag

    def store_command_history(self, sid, command_history):
        '''
            @name 将主机命令执行记录写入数据库
            @author Zhj<2022-09-28>
            @param  sid<integer>           主机ID
            @param  command_history<list>  命令执行记录
            @return void
        '''
        if self.running_dir_used_percent_high():
            return

        if isinstance(command_history, str):
            try:
                command_history = json.loads(command_history)
            except:
                return

        if len(command_history) < 1:
            return

        # 获取最近一次命令执行时间
        # latest_command_execute_time = self.__LATEST_COMMAND_EXECUTE_TIME.get(sid, None)

        # if latest_command_execute_time is None:
        #     latest_command_execute_time = self.db_easy('command_execute_logs')\
        #         .where('sid=?', sid)\
        #         .order('create_time', 'desc')\
        #         .value('create_time')
        #
        # if latest_command_execute_time is None:
        #     latest_command_execute_time = 0

        # 插入数据
        insert_data = []

        # 预编译正则表达式
        reg_obj = re.compile(r'^\d{10}$')

        # 本次最新的命令执行时间
        # cur_latest_execute_time = int(latest_command_execute_time)

        # 去重用的集合
        cmd_set = set()

        for exe_cmd in command_history:
            exe_time = exe_cmd.get('time', None)

            if exe_cmd.get('command', '') == '' \
                    or exe_time is None \
                    or not reg_obj.match(str(exe_time)) \
                    or '{}|{}'.format(exe_cmd['command'], exe_time) in cmd_set:
                # or int(latest_command_execute_time) > int(exe_time):
                continue

            # cur_latest_execute_time = max(cur_latest_execute_time, int(exe_time))

            insert_data.append({
                'sid': sid,
                'user': exe_cmd.get('user', ''),
                'command': exe_cmd.get('command', ''),
                'create_time': int(exe_time),
            })

            # 添加进集合，用于检测去重
            cmd_set.add('{}|{}'.format(exe_cmd['command'], exe_time))

        # 批量插入数据
        if len(insert_data) > 0:
            with monitor_db_manager.db_mgr('command_execute_logs') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    # 批量插入
                    db.query() \
                        .name('command_execute_logs') \
                        .insert_all(insert_data)

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

        # 更新最近一次命令执行时间
        # self.__LATEST_COMMAND_EXECUTE_TIME[sid] = cur_latest_execute_time

    def update_process_network_io_info(self, sid, process_network_info_list):
        '''
            @name 将进程网络信息写入数据库
            @author Zhj<2022-07-04>
            @param  sid<integer>                    主机ID
            @param  process_network_info_list<dict> 进程网络信息列表
            @return bool
        '''
        # 检查主机是否在线
        # 检查磁盘空间占用是否过高
        # if not self.server_is_online(sid) or self.running_dir_used_percent_high():

        if self.running_dir_used_percent_high():
            return False

        if type(process_network_info_list) == str:
            return False

        ret_flag = True

        # 上锁
        # with self.acquire('LOCK_PROCESS_COLLECTION__{}'.format(sid)):

        # 获取当前时间
        cur_time = int(time.time())

        # 进程网络IO收集插入数据
        net_insert_data = []

        # 已处理的进程ID列表
        handled_process_ids = []

        # 匹配已被kill掉的进程
        # skip_boot_command_pattern = re.compile(r'\(deleted\)$')

        # 更新进程网络IO信息
        # with monitor_db_manager.db_mgr('processes') as db:
        try:
            # 关闭事务自动提交
            # db.autocommit(False)

            # 将最近10分钟的进程列表写入内存
            if sid not in self.__PROCESS_LIST_STORED_IN_MEMORY \
                    and self.db_memory('processes') \
                    .where('sid=?', sid) \
                    .where('update_time > ?', cur_time - 600) \
                    .field('id') \
                    .exists():
                processes = self.db_easy('processes') \
                    .where('sid = ?', sid) \
                    .where('update_time > ?', cur_time - 600) \
                    .select()

                self.db_memory('processes').insert_all(processes, option='ignore')

                # 标记该主机进程列表已加载进内存中
                self.__PROCESS_LIST_STORED_IN_MEMORY.add(sid)

            data = []
            for k, v in process_network_info_list.items():
                if int(v['total_up']) + int(v['total_down']) < 1:
                    continue

                v['key'] = k
                v['total_up'] = int(v['total_up'])
                v['total_down'] = int(v['total_down'])
                data.append(v)

            new_data = data

            # 当主机进程数超过50个时，排序取前50个
            if len(data) > 50:
                new_data = sorted(data, key=lambda i: (i['total_up'] + i['total_down'],), reverse=True)[:50]

            for process_network_info in new_data:
                process_name, boot_command = process_network_info['key'].split('|', 1)

                # if skip_boot_command_pattern.search(boot_command):
                #     continue

                update_data = {
                    'name': process_name,
                    'boot_command': boot_command,
                    'net_sent_bytes': int(process_network_info['total_up']),
                    'net_recv_bytes': int(process_network_info['total_down']),
                    'update_time': cur_time,
                }

                # 查询进程ID
                process_info_cache_key = '{}|{}|{}'.format(sid, process_name, boot_command)

                # 优先从内存中获取
                if process_info_cache_key in self.__CACHED_PROCESSES:
                    res = self.__CACHED_PROCESSES[process_info_cache_key]

                # 其次从数据库获取
                else:
                    res = self.db_memory('processes') \
                        .where('`sid` = ?', int(sid)) \
                        .where('`name` = ?', process_name) \
                        .where('`boot_command` = ?', boot_command) \
                        .field(
                        'id',
                        'boot_time'
                    ).find()

                    # 写入内存
                    self.__CACHED_PROCESSES[process_info_cache_key] = res

                process_id = 0 if self.is_empty_result(res) else int(res['id'])
                boot_time = 0 if self.is_empty_result(res) else int(res['boot_time'])

                net_info = {
                    'sent_bytes_per_second': int(process_network_info['up']),
                    'recv_bytes_per_second': int(process_network_info['down']),
                }

                # last_net_info = db.query()\
                #     .name('process_network_io_info_list')\
                #     .where('`process_id` = ?', process_id)\
                #     .where('`create_time` >= ?', boot_time)\
                #     .field(
                #         'sent_bytes_per_second',
                #         'recv_bytes_per_second',
                #         'create_time'
                #     )\
                #     .order('create_time', 'desc')\
                #     .find()

                # 获取上一次进程网络信息
                last_net_info = self.__CACHED_PROCESS_NET.get(process_id, None)

                # 是否需要重置网络IO总数
                reset_net_info = self.is_empty_result(last_net_info)

                if not self.is_empty_result(last_net_info) and int(last_net_info['create_time']) >= boot_time:
                    time_diff = cur_time - int(last_net_info['create_time'])

                    if time_diff < 1:
                        net_info['sent_bytes_per_second'] = last_net_info['sent_bytes_per_second']
                        net_info['recv_bytes_per_second'] = last_net_info['recv_bytes_per_second']
                    else:
                        net_info['sent_bytes_per_second'] = round(update_data['net_sent_bytes'] / time_diff)
                        net_info['recv_bytes_per_second'] = round(update_data['net_recv_bytes'] / time_diff)

                if self.is_empty_result(res):
                    update_data['sid'] = int(sid)
                    process_id = self.db_memory('processes') \
                        .insert(update_data)
                else:
                    self.db_memory().execute('''
                        UPDATE `bt_processes`
                        SET `name` = '{name}',
                            `boot_command` = '{boot_command}',
                            `net_sent_bytes` = CASE WHEN {reset_net_info} THEN 0 ELSE `net_sent_bytes` END + {net_sent_bytes},
                            `net_recv_bytes` = CASE WHEN {reset_net_info} THEN 0 ELSE `net_recv_bytes` END + {net_recv_bytes},
                            `net_sent_bytes_per_second` = {net_sent_bytes_per_second},
                            `net_recv_bytes_per_second` = {net_recv_bytes_per_second},
                            `update_time` = {update_time}
                        WHERE `id` = ?
                    '''.format(
                        name=process_name,
                        boot_command=boot_command,
                        net_sent_bytes=int(process_network_info['total_up']),
                        net_recv_bytes=int(process_network_info['total_down']),
                        net_sent_bytes_per_second=int(net_info['sent_bytes_per_second']),
                        net_recv_bytes_per_second=int(net_info['recv_bytes_per_second']),
                        update_time=cur_time,
                        reset_net_info=1 if reset_net_info else 0
                    ), process_id)

                # 将进程网络信息更新到内存中
                self.__CACHED_PROCESS_NET[process_id] = {
                    'sent_bytes_per_second': int(net_info['sent_bytes_per_second']),
                    'recv_bytes_per_second': int(net_info['recv_bytes_per_second']),
                    'create_time': cur_time,
                }

                # 收集进程网络信息
                net_insert_data.append({
                    'process_id': process_id,
                    'sent_bytes_per_second': int(net_info['sent_bytes_per_second']),
                    'recv_bytes_per_second': int(net_info['recv_bytes_per_second']),
                })

                # 将进程实时网络信息写入缓存
                # public.print_log("set cache network io:")
                # public.print_log(int(net_info['sent_bytes_per_second']), int(net_info['recv_bytes_per_second']))
                self.cache_realtime_proc_info(
                    process_id=process_id,
                    net_sent_per_second=int(net_info['sent_bytes_per_second']),
                    net_recv_per_second=int(net_info['recv_bytes_per_second'])
                )

                # 记录已处理的进程ID
                handled_process_ids.append(process_id)

            # 更新未推送过来的进程网络即时IO
            # 仅更新最近10分钟的数据
            self.db_memory('processes') \
                .where('sid=?', int(sid)) \
                .where_not_in('id', handled_process_ids) \
                .where('update_time > ?', cur_time - 600) \
                .update({
                'net_sent_bytes_per_second': 0,
                'net_recv_bytes_per_second': 0,
            })

            # 提交事务
            # db.commit()
        except BaseException as e:
            # 回滚事务
            # db.rollback()

            # 记录异常堆栈
            public.print_exc_stack(e)

            return False

        # 写入临时数据
        with self.__DB_MEMORY as db:
            # 批量插入进程网络IO收集信息
            if len(net_insert_data) > 0:
                db.query() \
                    .name('process_network_io_info_list') \
                    .insert_all(net_insert_data)

        # 按磁盘写入间隔写入数据
        time_line = cur_time - (self.__DISK_WRITE_PER_MINUTES * 60)
        save_time_line = cur_time - 240
        last_store_time = self.__PROCESS_NETWORK_IO_LAST_STORE_TIME.get(sid, 0)
        if last_store_time == 0:
            self.__PROCESS_NETWORK_IO_LAST_STORE_TIME[sid] = cur_time
        if self.__PROCESS_NETWORK_IO_LAST_STORE_TIME.get(sid, 0) < time_line:
            # 获取该主机10分钟内所有进程信息
            processes_memory = self.db_memory('processes') \
                .where('`sid` = ?', int(sid)) \
                .where('update_time > ?', cur_time - 600) \
                .select()

            process_id_list = [str(p['id']) for p in processes_memory]

            process_id_list_str = ','.join(process_id_list)

            # 清空十分钟前所有非活跃进程网络IO收集数据
            # 释放内存
            sub_sql = self.db_memory('processes') \
                .where('sid=?', sid) \
                .where('create_time <= ?', cur_time - 600) \
                .field('id') \
                .build_sql(True)

            self.db_memory('process_network_io_info_list') \
                .where('process_id IN ({})'.format(sub_sql)) \
                .delete()

            # 更新主机进程列表
            with monitor_db_manager.db_mgr('processes') as db:
                try:
                    # 关闭事务自动提交
                    db.autocommit(False)

                    update_ids = db.query() \
                        .name('processes') \
                        .where('id IN ({})'.format(process_id_list_str)) \
                        .column('id')

                    insert_data = []

                    for p in processes_memory:
                        if p['id'] in update_ids:
                            process_id = p['id']
                            del (p['id'])
                            db.query() \
                                .name('processes') \
                                .where('id=?', process_id) \
                                .update(p)
                            continue

                        insert_data.append(p)

                    if len(insert_data) > 0:
                        db.query() \
                            .name('processes') \
                            .insert_all(insert_data, option='replace')

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈
                    public.print_exc_stack(e)

            # 进程网络IO收集插入数据
            net_insert_data = []

            with self.__DB_MEMORY as db:
                # 计算进程网络IO平均数据
                net_insert_data = db.query() \
                    .name('process_network_io_info_list') \
                    .where('process_id IN ({})'.format(process_id_list_str)) \
                    .where('create_time>=?', time_line) \
                    .group('process_id') \
                    .having('`sent_bytes_per_second` + `recv_bytes_per_second` > 0') \
                    .field('process_id', 'round(avg(`sent_bytes_per_second`)) as `sent_bytes_per_second`',
                           'round(avg(`recv_bytes_per_second`)) as `recv_bytes_per_second`') \
                    .select()

                # 删除临时数据
                db.query() \
                    .name('process_network_io_info_list') \
                    .where('process_id IN ({})'.format(process_id_list_str)) \
                    .where('create_time<?', save_time_line) \
                    .delete()

            # 获取数据库管理对象
            db_mgr = monitor_db_manager.MonitorDbManager(sid)

            # 写入数据
            if len(net_insert_data) > 0:
                db_mgr.add('process_network_io_info_list', net_insert_data)

            # 记录本次进程信息存储时间
            self.__PROCESS_NETWORK_IO_LAST_STORE_TIME[sid] = cur_time

        return ret_flag

    def update_servers2(self, sid=None, heartbeat=False, remote_addr=None, queue=None):
        '''
            @name   更新主机状态
            @author Zhj<2022-06-29>
            @param  sid<integer>    主机ID
            @param  heartbeat<bool> 是否来自心跳包
            @return bool
        '''
        if not queue:
            from core import client_data_queue as queue

        ret_flag = True

        warn_list = []
        update_list = []

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 获取当前时间
                cur_time = int(time.time())

                # 获取已授权主机
                query = db.query() \
                    .name('servers') \
                    .where('is_authorized=1') \
                    .field('sid', 'ip', 'remark', 'status', 'last_active_time')

                if sid is not None:
                    query.where('sid=?', sid)

                servers = query.select()

                if servers is None or len(servers) < 1:
                    raise BtMonitorException('无可更新的主机')

                # 关闭自动提交事务
                db.autocommit(False)

                for server_info in servers:
                    # 更新数据
                    update_data = {}

                    # 更新主机IP
                    if remote_addr is not None \
                            and remote_addr != '' \
                            and remote_addr != server_info['ip'] \
                            and public.check_ip(remote_addr):
                        update_data['ip'] = remote_addr

                    # 主机状态
                    server_status = 1 if heartbeat else int(server_info['status'])

                    # 非心跳包需计算上一次心跳开始到现在经过了多久
                    # 大于2分钟则视为离线
                    if not heartbeat:
                        # 获取上一次心跳包时间
                        last_heartbeat_time = public.cache_get(
                            'BT_MONITOR__SERVER_HEARTBEAT__{}'.format(server_info['sid'])) or server_info[
                                                  'last_active_time']

                        # 从上一次心跳包到现在超过2分钟则判定为离线
                        server_status = 1 if (cur_time - int(last_heartbeat_time)) < 120 else 0

                    # 心跳包需要更新最近一次通信时间
                    if heartbeat:
                        public.cache_set('BT_MONITOR__SERVER_HEARTBEAT__{}'.format(server_info['sid']), cur_time)

                    # 仅当主机状态发生改变时，更新主机状态
                    if int(server_info['status']) != server_status:
                        update_data['status'] = server_status
                        # 当主机上线时，更新最近一次活动时间
                        if server_status == 1:
                            update_data['last_active_time'] = cur_time

                    # 按需更新数据
                    if len(update_data.keys()) > 0:
                        update_data['update_time'] = cur_time
                        update_data['status'] = server_status
                        update_data['sid'] = server_info["sid"]
                        update_data["heartbeat"] = heartbeat
                        update_list.append(update_data)

                    # 判断是否需要写入系统日志
                    if int(server_info['status']) != server_status:
                        # 判断是离线还是上线
                        desc_text = '上线' if server_status == 1 else '离线'

                        warn_list.append({
                            'sid': server_info['sid'],
                            'server_status': server_status,
                            'desc': '主机【{}{}】已{}'.format(
                                server_info['ip'],
                                '' if server_info['remark'] == '' else '({})'.format(server_info['remark']),
                                desc_text)
                        })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                ret_flag = False

                # 记录异常堆栈
                public.print_exc_stack(e)
        d = {
            "stype": "update_server",
            "data": update_list
        }
        queue.put(json.dumps(d))

        # 写系统日志和告警
        if len(warn_list) > 0:
            for warn_info in warn_list:
                # 写一条系统日志
                public.WriteLog('主机管理', warn_info['desc'])

                # 主机上下线告警
                self.warn_server_status_on_off(warn_info['sid'], warn_info['server_status'])

        return ret_flag

    def update_servers(self, sid=None, heartbeat=False, remote_addr=None):
        '''
            @name   更新主机状态
            @author Zhj<2022-06-29>
            @param  sid<integer>    主机ID
            @param  heartbeat<bool> 是否来自心跳包
            @return bool
        '''
        ret_flag = True

        warn_list = []

        # 打开数据库
        with monitor_db_manager.db_mgr() as db:
            try:
                # 获取当前时间
                cur_time = int(time.time())

                # 获取已授权主机
                query = db.query() \
                    .name('servers') \
                    .where('is_authorized=1') \
                    .field('sid', 'ip', 'remark', 'status', 'last_active_time', 'is_authorized')

                if sid is not None:
                    query.where('sid=?', sid)

                servers = query.select()

                if servers is None or len(servers) < 1:
                    raise BtMonitorException('无可更新的主机')

                # 关闭自动提交事务
                db.autocommit(False)

                for server_info in servers:
                    # 更新数据
                    update_data = {}

                    # 更新主机IP
                    if remote_addr is not None \
                            and remote_addr != '' \
                            and remote_addr != server_info['ip'] \
                            and public.check_ip(remote_addr):
                        update_data['ip'] = remote_addr

                    # 主机状态
                    server_status = 1 if heartbeat else int(server_info['status'])

                    # 缓存键名
                    cache_key = 'SHM_:BT_MONITOR_SERVER_LAST_HEARTBEAT_TIME_{}'.format(server_info['sid'])

                    # 非心跳包需计算上一次心跳开始到现在经过了多久
                    # 大于2分钟则视为离线
                    if not heartbeat:
                        # 获取上一次心跳包时间
                        # last_heartbeat_time = self.db_memory('server_heartbeat').where('sid=?', server_info['sid']).value('last_heartbeat_time') or server_info['last_active_time']
                        last_heartbeat_time = public.cache_get(cache_key) or server_info['last_active_time']

                        # 从上一次心跳包到现在超过5分钟则判定为离线
                        server_status = 1 if (cur_time - int(last_heartbeat_time)) < 300 else 0

                        if server_status == 1:
                            continue

                    # update_data['status'] = server_status
                    # update_data['update_time'] = int(time.time())

                    # 心跳包需要更新最近一次通信时间
                    if heartbeat:
                        # last_heartbeat_time = self.db_memory('server_heartbeat').where('sid=?', server_info['sid']).value('last_heartbeat_time')
                        last_heartbeat_time = public.cache_get(cache_key) or server_info['last_active_time']
                        # self.db_memory('server_heartbeat').insert({
                        #     'sid': server_info['sid'],
                        #     'last_heartbeat_time': cur_time,
                        # }, option='replace')
                        public.cache_set(cache_key, cur_time, 600)

                        # 每隔一分钟更新一次心跳时间到数据库
                        if last_heartbeat_time is None or int(last_heartbeat_time) < cur_time - 60:
                            update_data['last_active_time'] = cur_time

                    # 仅当主机状态发生改变时，更新主机状态
                    if int(server_info['status']) != server_status:
                        # 判断是离线还是上线
                        desc_text = '离线'

                        # 更新主机状态
                        update_data['status'] = server_status

                        # 当主机上线时，更新最近一次活动时间
                        if server_status == 1:
                            desc_text = '上线'
                            update_data['last_active_time'] = cur_time

                        if int(server_info['is_authorized']) == 1:
                            warn_list.append({
                                'sid': server_info['sid'],
                                'server_status': server_status,
                                'desc': '主机【{}{}】已{}'.format(
                                    server_info['ip'],
                                    '' if server_info['remark'] == '' else '({})'.format(server_info['remark']),
                                    desc_text)
                            })

                    # 按需更新数据
                    if len(update_data.keys()) > 0:
                        update_data['update_time'] = cur_time
                        # 更新
                        db.query() \
                            .name('servers') \
                            .where('sid=?', server_info['sid']) \
                            .update(update_data)

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                ret_flag = False

                # 记录异常堆栈
                public.print_exc_stack(e)

        # 写系统日志和告警
        if len(warn_list) > 0:
            for warn_info in warn_list:
                # 写一条系统日志
                public.WriteLog('主机管理', warn_info['desc'])

                # 主机上下线告警
                self.warn_server_status_on_off(warn_info['sid'], warn_info['server_status'])

        return ret_flag

    def retrieve_server_detail(self, sid):
        '''
            @name 查询主机资源信息
            @author Zhj<2022-07-12>
            @param  sid<integer> 主机ID
            @return (主机资源信息或False<dict|bool>, err_msg<string>)
        '''
        # if not self.server_is_online(sid):
        #     return False, '主机已离线'

        # 获取主机信息
        server_detail = self.cache_realtime_server_info(sid)

        if self.is_empty_result(server_detail):
            return False, '获取主机信息失败'

        return server_detail, ''

    def the_project_is_initialized(self):
        '''
            @name 检查云监控是否已完成初始化操作
            @author Zhj<2022-07-23>
            @return bool
        '''
        return public.cache_get(self.__INITIALIZED_CACHE_KEY) or os.path.exists(self.__INITIALIZED_FILENAME)

    def __set_the_project_initialized(self):
        '''
            @name 标记云监控已初始化成功
            @author Zhj<2022-07-23>
            @return void
        '''
        public.WriteFile(self.__INITIALIZED_FILENAME, '')
        public.cache_set(self.__INITIALIZED_CACHE_KEY, 1)

    def __init_tables(self):
        '''
            创建数据表
            @author Zhj<2022-06-23>
        '''
        # safety数据表
        with public.sqlite_easy('safety') as db_safety:
            # 创建数据表
            db_safety.query().execute_script('''
                -- 开启事务
                begin;

                -- 设置Sqlite
                -- PRAGMA synchronous = 0;
                -- PRAGMA page_size = 4096;
                -- PRAGMA journal_mode = wal;

                -- 权限表
                CREATE TABLE IF NOT EXISTS `bt_access` (
                    `role_id` INTEGER NOT NULL DEFAULT 0,
                    `node_id` INTEGER NOT NULL DEFAULT 0,
                    `level`   INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS `access_nodeId`
                    on `bt_access` (`node_id`);

                CREATE INDEX IF NOT EXISTS `access_roleId`
                    on `bt_access` (`role_id`);

                -- 授权Token表
                CREATE TABLE IF NOT EXISTS `bt_auth_token` (
                    `auth_id`     INTEGER PRIMARY KEY AUTOINCREMENT,
                    `uid`         INTEGER NOT NULL DEFAULT 0,
                    `access_key`  TEXT NOT NULL DEFAULT '',
                    `secret_key`  TEXT NOT NULL DEFAULT '',
                    `address`     TEXT NOT NULL DEFAULT '',
                    `ps`          TEXT NOT NULL DEFAULT '',
                    `create_time` INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now'))
                );

                -- 系统日志表
                CREATE TABLE IF NOT EXISTS `bt_logs` (
                    `id`          INTEGER PRIMARY KEY AUTOINCREMENT,
                    `uid`         INTEGER NOT NULL DEFAULT 0,
                    `username`    TEXT NOT NULL DEFAULT '',
                    `type`        TEXT NOT NULL DEFAULT '',
                    `log`         TEXT NOT NULL DEFAULT '',
                    `addtime`     INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now')),
                    `status_code` INTEGER NOT NULL DEFAULT 1,
                    `error_info`  TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS `logs_uid`
                    ON `bt_logs` (`uid`);

                CREATE INDEX IF NOT EXISTS `logs_statusCode`
                    ON `bt_logs` (`status_code`);

                CREATE INDEX IF NOT EXISTS `logs_addtime_type`
                    ON `bt_logs` (`addtime`, `type`);

                -- 权限节点表
                CREATE TABLE IF NOT EXISTS `bt_node` (
                  `node_id` INTEGER PRIMARY KEY AUTOINCREMENT,
                  `name` TEXT NOT NULL DEFAULT '',
                  `title` TEXT NOT NULL DEFAULT '',
                  `status` INTEGER NOT NULL DEFAULT 0,
                  `ps` TEXT NOT NULL DEFAULT '',
                  `sort` INTEGER NOT NULL DEFAULT 0,
                  `pid` INTEGER NOT NULL DEFAULT 0,
                  `level` INTEGER NOT NULL DEFAULT 0,
                  `display` INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS `node_pid`
                    on `bt_node` (`pid`);

                CREATE INDEX IF NOT EXISTS `node_level`
                    on `bt_node` (`level`);

                CREATE INDEX IF NOT EXISTS `node_status`
                    on `bt_node` (`status`);

                CREATE INDEX IF NOT EXISTS `node_name`
                    on `bt_node` (`name`);

                -- 用户组表
                CREATE TABLE IF NOT EXISTS `bt_role` (
                  `role_id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                  `name` TEXT NOT NULL DEFAULT '',
                  `pid` INTEGER NOT NULL DEFAULT 0,
                  `status` INTEGER NOT NULL DEFAULT 0,
                  `ps` TEXT NOT NULL DEFAULT NULL
                );

                CREATE INDEX IF NOT EXISTS `role_pid`
                    on `bt_role` (`pid`);

                CREATE INDEX IF NOT EXISTS `role_status`
                    on `bt_role` (`status`);

                -- 用户与用户组关联表
                CREATE TABLE IF NOT EXISTS `bt_role_user` (
                  `role_id` INTEGER NOT NULL DEFAULT 0,
                  `uid` INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS `roleUser_roleId`
                    on `bt_role_user` (`role_id`);

                CREATE INDEX IF NOT EXISTS `roleUser_uid`
                    on `bt_role_user` (`uid`);

                -- 客户端列表
                CREATE TABLE IF NOT EXISTS `bt_server_list` (
                    `sid` INTEGER PRIMARY KEY AUTOINCREMENT,
                    `server_id`  TEXT NOT NULL DEFAULT '',
                    `access_key` TEXT NOT NULL DEFAULT '',
                    `secret_key` TEXT NOT NULL DEFAULT '',
                    `status`     INTEGER NOT NULL DEFAULT 0,
                    `address`    TEXT NOT NULL DEFAULT '',
                    `ps`         TEXT NOT NULL DEFAULT '',
                    `addtime`    INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now'))
                );

                CREATE INDEX IF NOT EXISTS `serverList_serverId`
                    on `bt_server_list` (`server_id`);

                CREATE INDEX IF NOT EXISTS `serverList_addtime`
                    on `bt_server_list` (`addtime`);

                CREATE INDEX IF NOT EXISTS `serverList_status`
                    on `bt_server_list` (`status`);

                -- 用户表
                CREATE TABLE IF NOT EXISTS `bt_users` (
                    `uid` INTEGER PRIMARY KEY AUTOINCREMENT,
                    `gid`             INTEGER NOT NULL DEFAULT 0,
                    `username`        TEXT NOT NULL DEFAULT '',
                    `username_hash`   TEXT NOT NULL DEFAULT '',
                    `password`        TEXT NOT NULL DEFAULT '',
                    `nickname`        TEXT NOT NULL DEFAULT '',
                    `salt`            TEXT NOT NULL DEFAULT '',
                    `status`          INTEGER NOT NULL DEFAULT 1,
                    `ps`              TEXT NOT NULL DEFAULT '',
                    `last_login_time` INTEGER,
                    `last_login_ip`   TEXT NOT NULL DEFAULT '',
                    `create_time`     INTEGER NOT NULL DEFAULT (STRFTIME('%s', 'now')),
                    `pwd_update_time` INTEGER NOT NULL DEFAULT 0,
                    `expire_day`      INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS `user_gid`
                    on `bt_users` (`gid`);

                CREATE INDEX IF NOT EXISTS `user_username`
                    on `bt_users` (`username`);

                CREATE INDEX IF NOT EXISTS `user_usernameHash_password`
                    on `bt_users` (`username_hash`, `password`);

                -- 提交事务
                commit;
            ''')

            # 创建默认用户组
            if not db_safety.query().name('role').where('role_id>0').exists():
                db_safety.query() \
                    .name('role') \
                    .insert_all([
                    {
                        'name': '超级管理员',
                        'status': 1,
                        'ps': '超级管理员',
                    }
                ])

        # monitor_mgr数据库
        monitor_db_manager._init_mgr_db()
        monitor_db_manager._init_single_db()

    def __create_tasks(self):
        '''
            @name 添加计划任务列表
            @author Zhj<2022-07-21>
        '''
        cron_task_obj = cron_task.main()

        # 每隔1分钟更新服务器列表状态
        # cron_task_obj.delete_task('update_servers')
        # cron_task_obj.create_task('update_servers', {
        #     'type': 'minute-n',
        #     'where1': 1,
        # })

        # 每隔2分钟扫描告警规则
        # cron_task_obj.delete_task('warn_task')
        # cron_task_obj.create_task('warn_task', {
        #     'type': 'minute-n',
        #     'where1': 2,
        # })

        # 每天00:00:00上报统计数据
        cron_task_obj.delete_task('report_task')
        cron_task_obj.create_task('report_task', {
            'type': 'day-n',
            'hour': 0,
            'minute': 0,
            'where1': 1,
        })

        # 每隔2分钟测试端口连接
        cron_task_obj.delete_task('port_test_task')
        cron_task_obj.create_task('port_test_task', {
            'type': 'minute-n',
            'where1': 2,
        })

        # 每天02:00:00归档数据库文件
        cron_task_obj.delete_task('database_archive')
        cron_task_obj.create_task('database_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档请求日志
        cron_task_obj.delete_task('request_log_archive')
        cron_task_obj.create_task('request_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

    def __init_config(self):
        '''
            @name 初始化配置
            @author Zhj<2022-07-23>
            @return void
        '''
        # 初始化配置文件
        public.save_config('config', {
            'API': {
                'encrypt': True,
                'open': True
            },
            'home': 'https://www.bt.cn',
            'admin_path': '/{}'.format(public.md5(public.GetRandomString(16))[:9]),
            'accept_ip': [],
            'accept_domain': '',
            'debug': False,
            'session_timeout': 86400,
            'password_expire': 180,
            'port': 806,
            'not_login_modules': ['plugin', 'api'],
            'not_login_uri': ['/user/login'],
        })

        # 初始化rbac配置文件
        public.save_config('rbac', {
            'USER_AUTH_ON': True,
            'USER_AUTH_TYPE': 2,
            'ADMIN_AUTH_KEY': 1,
            'USER_AUTH_KEY': 'uid',
            'REQUIRE_AUTH_MODULE': [],
            'NOT_AUTH_MODULE': ['rbac', 'user', 'plugin', 'api', 'config', 'logs', 'dashboard', 'warning', 'server',
                                'msg'],
            'REQUIRE_AUTH_ACTION': [],
            'NOT_AUTH_ACTION': [],
            'RBAC_ROLE_TABLE': 'bt_role',
            'RBAC_USER_TABLE': 'bt_role_user',
            'RBAC_ACCESS_TABLE': 'bt_access',
            'RBAC_NODE_TABLE': 'bt_node',
        })

        # 初始化basic_auth配置文件
        public.save_config('basic_auth', {
            'open': False,
        })

        # 初始化page配置文件
        public.save_config('page', {
            'PREV': '上一页',
            'NEXT': '下一页',
            'START': '首页',
            'END': '尾页',
            'COUNT_START': '共',
            'COUNT_END': '条',
            'FO': '从',
            'LINE': '条',
        })

        # 初始化status_code配置文件
        public.save_config('status_code', {
            '1': [True, '{}成功!'],
            '-1': [False, '{}失败!'],
            '1000': [False, '{}'],
            '1001': [False, '缺少必要参数: {}'],
            '1002': [False, '错误的参数格式: {}'],
            '1003': [False, '指定模块{}不存在!'],
            '1004': [False, '在指定模块中没有找到{}方法!'],
        })

    def lock(self, lock_key, max_wait_millisec=2500):
        '''
            @name 上锁
            @author Zhj<2022-07-04>
            @param  lock_key<string>            锁名称
            @param  max_wait_millisec<integer>  最长锁等待时间/毫秒[可选 默认2500毫秒]
            @return bool
        '''
        lock_key = 'BT_MONITOR_LOCKER__' + lock_key
        total_milliseconds = 0
        while public.cache_get(lock_key):
            if total_milliseconds > max_wait_millisec:
                return False

            total_milliseconds += 5
            time.sleep(0.005)

        public.cache_set(lock_key, 1, 3)
        return True

    def unlock(self, lock_key):
        '''
            @name 释放锁
            @author Zhj<2022-07-04>
            @param  lock_key:
            @return bool
        '''
        public.cache_remove('BT_MONITOR_LOCKER__' + lock_key)
        return True

    @contextmanager
    def acquire(self, lock_key, max_wait_millisec=2500):
        '''
            @name 基于上下文管理器的锁
            @author Zhj<2022-09-07>
            @param  lock_key<string>            锁名称
            @param  max_wait_millisec<integer>  最长锁等待时间/毫秒[可选 默认2500毫秒]
            @return generator
        '''
        try:
            # 上锁
            self.lock(lock_key, max_wait_millisec)
            yield
        finally:
            # 释放锁
            self.unlock(lock_key)

    def is_empty_result(self, res):
        '''
            @name 检查查询结果是否为空
            @author Zhj<2022-07-04>
            @param  res<None|list|dict> 查询结果
            @return bool
        '''
        if res is None or isinstance(res, str):
            return True

        if isinstance(res, list) and len(res) == 0:
            return True

        if isinstance(res, dict) and len(res.keys()) == 0:
            return True

        return False

    def db(self, table_name=None):
        '''
            @name 获取sqlite查询对象
            @param table_name<string> 表名[可选]
            @return sqlite.Sql
        '''
        sqlite_obj = sqlite.Sql().dbfile(self.__DB_FILE)

        if table_name != None:
            sqlite_obj.table(table_name)

        return sqlite_obj

    def db_easy(self, table_name=None):
        '''
            @name 获取SqliteEasy查询构造器对象
            @author Zhj<2022-07-18>
            @param  table_name<?string> 表名[可选]
            @return core.include.sqlite_easy.SqliteEasy
        '''
        db = None

        if table_name is not None:
            # 获取表名
            m = re.match(r'^([\w`]+)(?:(?:\s+AS\s+|\s+)([\w`]+))?$', table_name, flags=re.IGNORECASE)

            if m is None:
                raise Exception('表名格式错误: {}'.format(table_name))

            db = self.__DB_DICT.get(m.group(1),
                                    monitor_db_manager.db_mgr(m.group(1)) if monitor_db_manager.is_single_db(
                                        m.group(1)) else None)
            # self.__DB_DICT[m.group(1)] = db

        if db is None:
            db = public.sqlite_easy(self.__DB_FILE)
            # self.__DB = db

        # 提交事务
        # self.__DB.commit()

        # 开启自动提交事务
        query = db.autocommit().query()

        if table_name is not None:
            query.name(table_name)

        return query

    def db_memory(self, table_name=None):
        '''
            @name 连接内存数据库
            @author Zhj<2022-09-17>
            @param  table_name<?string> 表名[可选]
            @return core.include.sqlite_easy.SqliteEasy
        '''
        with self.__DB_MEMORY as db:
            query = db.query()

            if table_name is not None:
                query.name(table_name)

            return query

    def cache_server_command_history(self, sid, command_history=None):
        '''
            @name   缓存主机命令执行记录
            @author Zhj<2022-07-12>
            @param  sid<integer>            主机ID
            @param  command_history<?list>   命令执行记录
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_COMMAND_HISTORY__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if command_history is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(command_history), 240)

        return command_history

    def cache_server_installed_softs(self, sid, install_softs=None):
        '''
            @name   缓存主机软件安装列表
            @author Zhj<2022-07-12>
            @param  sid<integer>           主机ID
            @param  install_softs<?list>   软件安装列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_INSTALLED_SOFTS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if install_softs is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(install_softs), 240)

        return install_softs

    def cache_server_ssh_users(self, sid, ssh_users=None):
        '''
            @name   缓存主机SSH在线用户列表
            @author Zhj<2022-07-12>
            @param  sid<integer>       主机ID
            @param  ssh_users<?list>   SSH在线用户列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_SSH_USERS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if ssh_users is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(ssh_users), 240)

        return ssh_users

    def cache_server_syslog_paths(self, sid, syslog_paths=None):
        '''
            @name   缓存主机SSH在线用户列表
            @author Zhj<2022-07-12>
            @param  sid<integer>          主机ID
            @param  syslog_paths<?list>   系统日志路径列表
            @return list
        '''
        # 缓存键名
        cache_key = 'BT_MONITOR_CACHE_SERVER_SYSLOG_PATHS__' + str(sid)

        cache_data = public.cache_get(cache_key)

        default_cache_data = []

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                cache_data = default_cache_data

        # 获取缓存
        if syslog_paths is None:
            return cache_data

        # 写入缓存
        public.cache_set(cache_key, json.dumps(syslog_paths), 240)

        return syslog_paths

    def cache_realtime_proc_info(self,
                                 process_id,
                                 cpu_percent=None,
                                 mem_percent=None,
                                 mem_used=None,
                                 disk_read_per_second=None,
                                 disk_write_per_second=None,
                                 net_sent_per_second=None,
                                 net_recv_per_second=None):
        '''
            @name 将进程实时数据写入缓存
            @author Zhj<2022-07-06>
            @param  process_id<integer>             进程表ID
            @param  cpu_percent<float>              CPU使用率
            @param  mem_percent<float>              内存使用率
            @param  mem_used<integer>               已占用内存
            @param  disk_read_per_second<integer>   磁盘每秒读取字节数
            @param  disk_write_per_second<integer>  磁盘每秒写入字节数
            @param  net_sent_per_second<integer>    网络每秒发送字节数
            @param  net_recv_per_second<integer>    网络每秒接收字节数
            @return dict
        '''
        cache_key = 'BT_MONITOR_CACHE__REALTIME_PROC_INFO_{}'.format(process_id)
        # public.print_log("Cache key: {}".format(cache_key))

        # 获取缓存
        cache_data = public.cache_get(cache_key)
        # public.print_log("cahce data:")
        # public.print_log(cache_data)

        default_cache_data = {
            'cpu_percent': 0,
            'mem_percent': 0,
            'mem_used': 0,
            'disk_read_per_second': 0,
            'disk_write_per_second': 0,
            'net_sent_per_second': 0,
            'net_recv_per_second': 0,
        }

        if not cache_data:
            cache_data = default_cache_data
        else:
            try:
                cache_data = json.loads(cache_data)
            except:
                # public.print_log("exception:")
                # public.print_log(cache_data)
                cache_data = default_cache_data

        # 只传了process_id时为获取进程实时信息
        if cpu_percent is None \
                and mem_percent is None \
                and mem_used is None \
                and disk_read_per_second is None \
                and disk_write_per_second is None \
                and net_sent_per_second is None \
                and net_recv_per_second is None:
            return cache_data

        if cpu_percent is not None:
            cache_data['cpu_percent'] = cpu_percent

        if mem_percent is not None:
            cache_data['mem_percent'] = mem_percent

        if mem_used is not None:
            cache_data['mem_used'] = mem_used

        if disk_read_per_second is not None:
            cache_data['disk_read_per_second'] = disk_read_per_second

        if disk_write_per_second is not None:
            cache_data['disk_write_per_second'] = disk_write_per_second

        if net_sent_per_second is not None:
            cache_data['net_sent_per_second'] = net_sent_per_second
            # public.print_log("{}/ sent: {}".format(process_id, net_sent_per_second))

        if net_recv_per_second is not None:
            cache_data['net_recv_per_second'] = net_recv_per_second
            # public.print_log("{}/recv: {}".format(process_id, net_recv_per_second))

        # 重新写入缓存
        public.cache_set(cache_key, json.dumps(cache_data), 16)

        return cache_data

    def cache_realtime_server_info(self,
                                   sid,
                                   host_info=None,
                                   cpu_info=None,
                                   mem_info=None,
                                   disk_info=None,
                                   net_info=None,
                                   load_avg=None):
        '''
            @name  缓存主机实时信息
            @author Zhj<2022-07-15>
            @param sid<integer> 主机ID
            @param host_info<dict>  主机信息
            @param cpu_info<dict>   CPU信息
            @param mem_info<dict>   内存信息
            @param disk_info<list>  磁盘信息
            @param net_info<list>   网卡信息
            @param load_avg<dict>   负载信息
            @return dict
        '''
        cache_key = 'BT_MONITOR_CACHE_REALTIME_SERVER_INFO__{}'.format(str(sid))

        cached_data = public.cache_get(cache_key)

        if cached_data:
            try:
                cached_data = json.loads(cached_data)
            except:
                cached_data = None
        else:
            cached_data = None

        if cached_data is None:
            # 从数据库获取
            res_db = self.db_easy('server_details') \
                .where('`sid` = ?', int(sid)) \
                .field(
                'host_info',
                'cpu_info',
                'mem_info',
                'disk_info',
                'net_info,load_avg'
            ).find()

            if self.is_empty_result(res_db):
                cached_data = {}
            else:
                cached_data = {
                    'host_info': json.loads(res_db.get('host_info', '{}')),
                    'cpu_info': json.loads(res_db.get('cpu_info', '{}')),
                    'mem_info': json.loads(res_db.get('mem_info', '{}')),
                    'disk_info': json.loads(res_db.get('disk_info', '[]')),
                    'net_info': json.loads(res_db.get('net_info', '[]')),
                    'load_avg': json.loads(res_db.get('load_avg', '{}')),
                }

        # 获取缓存
        if host_info is None \
                and cpu_info is None \
                and mem_info is None \
                and disk_info is None \
                and net_info is None \
                and load_avg is None:
            return cached_data

        if host_info is not None:
            cached_data['host_info'] = host_info

        if cpu_info is not None:
            cached_data['cpu_info'] = cpu_info

        if mem_info is not None:
            cached_data['mem_info'] = mem_info

        if disk_info is not None:
            cached_data['disk_info'] = disk_info

        if net_info is not None:
            cached_data['net_info'] = net_info

        if load_avg is not None:
            cached_data['load_avg'] = load_avg

        # 写入缓存
        public.cache_set(cache_key, json.dumps(cached_data), 120)

        return cached_data

    def get_server_ip(self):
        '''
            @name 获取服务端内网IP与公网IP
            @author Zhj<2022-07-06>
            @return (内网IP列表<list>, 公网IP)
        '''
        internal_ips = []
        published_ip = None

        # 获取内网IP
        res = public.ExecShell('ip addr')

        if len(res) > 0:
            m = re.findall(r'inet ((?:25[0-5]|2[0-4]\d|1(?:[0-1]|[3-9])\d|12(?:[0-6]|[8-9])|\d{1,2})(?:\.\d{1,3}){3})',
                           res[0])

            if m:
                internal_ips += m

        if len(internal_ips) == 0:
            internal_ips.append('127.0.0.1')

        # 获取公网IP
        published_ip = public.GetLocalIp()

        return internal_ips, published_ip

    def server_is_authorized(self, sid):
        '''
            @name 检查主机是否已授权
            @author Zhj<2022-08-24>
            @param sid<integer> 主机ID
            @return bool
        '''
        return self.db_easy('servers') \
            .where('sid=?', sid) \
            .where('status', 1) \
            .field('sid') \
            .exists()

    def server_is_online(self, sid):
        '''
            @name 检查主机是否在线
            @author Zhj<2022-07-09>
            @param  sid<integer> 主机ID
            @return bool
        '''
        # 更新主机状态
        # self.update_servers(sid)

        # 检查主机是否维护中
        # if self.server_is_maintenance(sid):
        #    return True

        # 检查主机是否在线
        return True if public.cache_get('SERVER_CONNECTION_' + str(sid)) else False

    def server_is_maintenance(self, sid):
        '''
            @name 检查主机是否维护(关闭告警通知)
            @author Zhj<2022-07-09>
            @param  sid<integer> 主机ID
            @return bool
        '''
        return not self.db_easy('servers').where('`sid` = ? AND `allow_notify` = 0', int(sid)).exists()

    def running_dir_used_percent_high(self):
        '''
            @name 检查 /www 挂载点磁盘使用率 是否超过97%
            @author Zhj<2022-07-09>
            @return bool
        '''
        # 挂载点
        mount_point = '/www'

        # 阈值
        threshold = 80

        # 缓存键
        cache_key = 'BT_MONITOR_CACHE_RUNNING_DIR_USED_PERCENT'
        cached_percent = public.cache_get(cache_key)

        if cached_percent is not None:
            used_percent, inodes_used_percent = cached_percent.split('|', 1)

            return float(used_percent) > threshold or float(inodes_used_percent) > threshold

        # 预编译正则表达式对象
        re_obj = re.compile(r'((?:100(?:\.0{1,2})?|(?:[1-9]\d|\d)(?:\.\d{1,2})?))\%')

        # 获取磁盘占用率
        res = public.ExecShell('df {}'.format(mount_point))

        if len(res) < 1:
            return True

        m = re_obj.search(res[0])

        if m is None:
            return True

        used_percent = float(m.group(1))

        # 获取inode占用率
        res = public.ExecShell('df -i {}'.format(mount_point))

        if len(res) < 1:
            return True

        m = re_obj.search(res[0])

        if m is None:
            return True

        inodes_used_percent = float(m.group(1))

        public.cache_set(cache_key, '{}|{}'.format(str(used_percent), str(inodes_used_percent)), 120)

        return used_percent > threshold or inodes_used_percent > threshold

    def statistics_helper(self,
                          args,
                          table_name,
                          fields,
                          where=None,
                          binds=(),
                          order_field='create_time',
                          pad_el=None,
                          pad_step=1800,
                          sid=None):
        '''
            @name 图表数据统计帮助方法
            @author Zhj<2022-07-22>
            @param  args<dict>              请求参数列表
            @param  table_name<string>      表名
            @param  fields<tuple|list>      字段列表
            @param  where<?string>          where条件[可选]
            @param  binds<tuple|list>       绑定参数[可选]
            @param  order_field<?string>    排序字段[可选 默认'create_time']
            @param  pad_el<?dict>           填充数据模板[可选]
            @param  pad_step<?integer>      数据填充时间间隔/秒[可选 默认1200秒]
            @param  sid<?integer>           服务器ID[可选 指定时从分库查询]
            @return list
        '''
        # 参数列表必须是列表或者元组
        if not isinstance(fields, list) and not isinstance(fields, tuple):
            raise Exception('fields must a type of list or tuple')

        # 获取时间区间
        query_date = args.get('query_date', 'today')
        query_start, query_end = public.get_query_timestamp(query_date)

        # 默认填充数据模板
        if pad_el is None:
            pad_el = {}
            for field in fields:
                field = field.strip()
                pad_el[field] = 0

        # 从主库查询
        if sid is None:
            # 构建查询构造器
            query = self.db_easy(table_name) \
                .where('`{}` BETWEEN ? AND ?'.format(order_field), [query_start, query_end]) \
                .field(*fields) \
                .order(order_field, 'ASC')

            # 添加where条件
            if where is not None:
                query.where(where, binds)

            # 查询数据
            res = query.select()

        # 从分库查询
        else:
            # 查询构造器处理函数
            def query_handler(query):
                query.field(*fields)

                # 添加where条件
                if where is not None:
                    query.where(where, binds)

            # 查询数据
            res = monitor_db_manager.MonitorDbManager(sid).query(table_name, query_handler, query_start, query_end,
                                                                 order_field)

        if res is None:
            return []

        # 填充空缺数据并返回
        return self.pad_statistics_result(res, query_start, query_end, pad_step, pad_el)

    def server_statistics_helper(self, args, table_name, fields, where=None, binds=()):
        '''
            @name 主机统计帮助方法
            @author Zhj<2022-07-12>
            @param  args<dict>          请求参数列表
            @param  table_name<string>  表名
            @param  fields<string>      字段列表
            @param  where<string>       where条件[可选]
            @param  binds<list|tuple>   绑定参数[可选]
            @param  pad_el<?dict>       填充数据模板[可选]
            @return list
            @throws public.PanelError
        '''
        sid = args.get('sid', None)

        if sid is None:
            raise public.PanelError('缺少参数：sid')

        # 添加主机ID查询条件
        if where is not None:
            where += ' AND `sid` = ?'
        else:
            where = '`sid` = ?'

        binds += (int(sid),)

        return self.statistics_helper(
            args,
            table_name,
            list(map(lambda x: x.strip(), fields.split(','))),
            where,
            binds,
            sid=sid
        )

    def process_statistics_helper(self, args, table_name, fields, where=None, binds=(), pad_el=None):
        '''
            @name 进程统计帮助方法
            @author Zhj<2022-08-20>
            @param  args<dict>          请求参数列表
            @param  table_name<string>  表名
            @param  fields<string>      字段列表
            @param  where<string>       where条件[可选]
            @param  binds<list|tuple>   绑定参数[可选]
            @return list
            @throws public.PanelError
        '''
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        # 获取服务器ID
        sid = self.db_memory('processes') \
            .where('id=?', pid) \
            .value('sid')

        if sid is None:
            return public.error('无效的参数：pid')

        return self.statistics_helper(
            args,
            table_name,
            fields,
            where,
            binds,
            sid=sid,
            pad_el=pad_el
        )

    def pad_statistics_result(self, result, start_time, end_time, step, pad_el, field='create_time'):
        '''
            @name 填充统计数据
            @author Zhj<2022-07-21>
            @param  result<list>        统计数据(升序排列)
            @param  start_time<integer> 起始时间 时间戳
            @param  end_time<integer>   结束时间 时间戳
            @param  step<integer>       时间间隔/秒
            @param  pad_el<dict>        填充的数据模板
            @param  field<?string>      字段名[可选 默认'create_time']
            @return list
        '''
        # 让结束时间在有效范围内
        cur_time = int(time.time())
        end_time = cur_time if end_time > cur_time else end_time

        if start_time >= end_time:
            return result

        m = {}
        step = int(step)
        half_step = int(step / 2)
        # ninety_nine_percent_step = int(step * 0.99)

        for row in result:
            k = int(row[field] / step)

            if k not in m:
                m[k] = []

            m[k].append(row)

        new_result = []

        def pad_el_helper(t):
            el = {}
            el.update(pad_el)
            el[field] = t
            new_result.append(el)

        while start_time < end_time:
            k = int(start_time / step)

            if k in m:
                if m[k][0][field] > start_time + half_step:
                    pad_el_helper(start_time)
                new_result += m[k]
            else:
                pad_el_helper(start_time)
                # pad_el_helper(start_time + ninety_nine_percent_step)

            start_time += step

        k = int(start_time / step)

        if k in m:
            if m[k][0][field] > start_time + half_step:
                pad_el_helper(start_time)
            new_result += m[k]

        return new_result

    def check_monitor_endtime(self):
        '''
            @name 检查云监控是否在有效期内
            @author Zhj<2022-07-25>
            @return bool
        '''
        # 默认到期时间 2022-11-31 23:59:59
        end_time = 1669823999
        cur_time = int(time.time())

        # 获取授权信息
        # ret = AuthModule().check_auth_status(public.to_dict_obj({}))
        #
        # if not isinstance(ret, dict)\
        #     or 'status' not in ret\
        #     or not ret['status']\
        #     or 'data' not in ret\
        #     or not isinstance(ret['data'], dict)\
        #     or int(ret['data'].get('status', 0)) != 1:
        #     return False
        #
        # end_time = int(ret['data'].get('end_time', -1))
        #
        # if end_time < 0:
        #     return False
        #
        # if end_time == 0:
        #     return True

        return cur_time < end_time

    def get_available_clients(self):
        '''
            @name 获取有效的客户端数量
            @author Zhj<2022-10-25>
            @return integer
        '''
        # 获取当前时间
        cur_time = int(time.time())

        # 默认授权台数
        default_num = 5

        # 获取授权信息
        auth_info = self.get_auth_info()

        # 检查授权信息
        if not auth_info:
            return default_num

        end_time = int(auth_info.get('end_time', -1))

        # 无效授权
        if end_time < 0:
            return default_num

        # 授权已过期
        if end_time > 0 and cur_time >= end_time:
            return default_num

        return int(auth_info.get('clients', 0))

    def get_auth_info(self, force=False):
        '''
            @name 获取授权信息
            @author Zhj<2022-11-08>
            @param force<?bool> 强制同步云端授权数据
            @return dict|None
        '''
        # 获取授权信息
        ret = AuthModule().check_auth_status(public.to_dict_obj({
            'force': int(force),
        }))

        # 检查授权信息
        if not isinstance(ret, dict) \
                or 'status' not in ret \
                or not ret['status'] \
                or 'data' not in ret \
                or not isinstance(ret['data'], dict):
            return None

        return ret['data']

    def set_module_logs(self, mod_name, fun_name, count=1):
        """
            @模块使用次数
            @mod_name 模块名称
            @fun_name 函数名
        """
        import datetime
        data = {}
        path = '{}/data/mod_log.json'.format(public.get_panel_path())
        if os.path.exists(path):
            try:
                data = json.loads(public.readFile(path))
            except:
                pass

        key = datetime.datetime.now().strftime("%Y-%m-%d")
        if not key in data: data[key] = {}

        if not mod_name in data[key]:
            data[key][mod_name] = {}

        if not fun_name in data[key][mod_name]:
            data[key][mod_name][fun_name] = 0

        data[key][mod_name][fun_name] += count

        public.writeFile(path, json.dumps(data))
        return True

    def report_module_logs(self):
        return
        '''
            @name 提交模块统计信息
            @return void
        '''
        path = '{}/data/mod_log.json'.format(public.get_panel_path())
        if os.path.exists(path):
            mdata = {}
            sday = public.format_date()
            try:
                mdata = json.loads(public.readFile(path))
            except:
                pass

            nData = {}
            pdata = self.get_user_info()

            # 未绑定官网账号
            if pdata is None:
                return

            for key in mdata:
                if sday.find(key) >= 0:
                    nData[key] = mdata[key]
                    continue
                pdata['day_date'] = key
                pdata['data_list'] = json.dumps(mdata[key])
                try:
                    ret = json.loads(public.httpPost('http://www.example.com/api/v2/statistics/report_plugin_daily', pdata))
                    if not ret['success']: nData[key] = mdata[key]
                except:
                    nData[key] = mdata[key]
            public.writeFile(path, json.dumps(nData))

    def get_user_info(self):
        '''
            @name 获取官网绑定用户信息
            @author Zhj<2022-07-25>
            @return dict|None
        '''
        filename = '{}/data/user.json'.format(public.get_panel_path())
        data = None

        try:
            if os.path.exists(filename):
                data = json.loads(public.readFile(filename))
        except:
            pass

        return data

    def warn_server_status_on_off(self, sid, server_status):
        '''
            @name 主机上下线告警
            @author Zhj<2022-08-25>
            @param  sid<integer>           主机ID
            @param  server_status<integer> 主机状态 0-下线 1-上线
            @return void
        '''
        from core.include.monitor_helpers import warning_obj

        if server_status not in [0, 1]:
            return

        # 状态变更类型 上线 or 下线
        change_type = 'online' if server_status == 1 else 'offline'

        # 获取主机上下线告警规则
        warning_rules = warning_obj.get_warning_rules(sid, 'client', 'status', 'on_off')

        # 开始告警
        # s_time = time.time()
        # public.print_log('--开始主机上下线告警')
        for warning_rule in warning_rules:
            warning_obj.warn(warning_rule, change_type)
        # public.print_log('--主机上下线告警完成 耗时：{}s'.format(time.time() - s_time))

    def warn_server_ssh_login_place_other(self, sid, login_status):
        '''
            @name SSH异地登录告警
            @author Zhj<2022-10-11>
            @param  sid<integer>            主机ID
            @param  login_status<string>    SSH登录状态
            @return void
        '''
        from core.include.monitor_helpers import warning_obj

        if login_status not in ['success', 'fail']:
            return

        # 获取主机SSH异地登录提醒规则
        warning_rules = warning_obj.get_warning_rules(sid, 'log', 'ssh_login_logs', 'place_other')

        for warning_rule in warning_rules:
            warning_obj.warn(warning_rule, login_status)

    def get_server_describe(self, sid):
        '''
            @name 获取主机描述信息(IP+备注)
            @author Zhj<2022-08-25>
            @param  sid<integer> 主机ID
            @return string
        '''
        cache_key = 'BT_MONITOR_CACHE_SERVER_DESCRIBE__{}'.format(str(sid))

        # 优先从缓存中读取
        server_describe = public.cache_get(cache_key)

        if server_describe:
            return server_describe

        server_info = self.db_easy('servers') \
            .where('sid=?', sid) \
            .field('ip', 'remark') \
            .find()

        if server_info is None:
            return ''

        server_describe = '{}{}'.format(server_info['ip'],
                                        '（{}）'.format(server_info['remark']) if server_info['remark'] != '' else '')

        # 写入缓存
        public.cache_set(cache_key, server_describe, 120)

        return server_describe

    def search_ip_info(self, ips):
        '''
            @name IP归属地查询
            @author Zhj<2022-10-09>
            @param  ips<string|list> 单个IP或者多个IP
            @return dict
        '''
        if not isinstance(ips, list):
            ips = [ips]

        res = public.httpPost('https://www.bt.cn/api/panel/get_ip_info', {
            'ip': ','.join(ips),
            'nslookup': 1,
        })

        if not res:
            return {}

        ret = json.loads(res)

        for (k, v) in ret.items():
            if v['country'] == '保留':
                v['country'] = '局域网'

        return ret

    def store_raidinfo(self, sid, raid_info):
        """接收客户端阵列信息

        Args:
            sid (str): 服务器ID
            raid_info: 最新的磁盘阵列信息
        """
        data = {
            "detail": raid_info["checkDetail"],
            "output": raid_info["checkOutput"],
            "ctrlcount": raid_info["controllerCount"],
            "check_result": raid_info["checkResult"]
        }
        # public.print_log("存储阵列信息")
        # 写入数据
        # db_mgr = monitor_db_manager.MonitorDbManager(sid)

        with monitor_db_manager.db_mgr('server_raid_info') as db:
            record = db.query() \
                .name('server_raid_info') \
                .where('`sid` = ?', [int(sid)]) \
                .find()

            # public.print_log("record: {}".format(str(record)))
            if not record:
                data["sid"] = sid
                # public.print_log("add raid info.")
                # public.print_log(data)
                db.query().name('server_raid_info').insert(data)
            else:
                # public.print_log("update raid info.")
                # public.print_log(data)
                db.query().name('server_raid_info') \
                    .where('`sid` = ?', [int(sid)]).update(data)
