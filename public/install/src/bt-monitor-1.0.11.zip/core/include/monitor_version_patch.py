#!/www/server/bt-monitor/pyenv/bin/python3 -u
#  -*- coding: utf-8 -*-

import os, time
from contextlib import contextmanager
os.chdir('/www/server/bt-monitor')
import sys
sys.path.insert(0, "/www/server/bt-monitor")
import core.include.public as public
# import core.include.c_loader.PluginLoader as plugin_loader
# import core.include.monitor_db_manager as monitor_db_manager
from core.include.cron_task import main as CronTask
from core.include.monitor_helpers import monitor_task_queue, basic_monitor_obj, warning_obj


monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))
MonitorTask = public.import_via_loader('{}/core/include/monitor_task.py'.format(public.get_panel_path())).MonitorTask

class MonitorVersionPatch:
    '''
        @name 版本补丁类
        @author Zhj<2022-08-26>
    '''
    # 版本补丁链
    __PATCH_VERSIONS = [
        '1.0.4',
        '1.0.6',
        '1.0.10',
    ]

    def __init__(self):
        self.__CUR_VERSION = public.ReadFile('{}/version.pl'.format(public.get_panel_path()))

        # 尝试安装版本补丁
        self.attempt_install_patches()

        # 初始化数据库
        monitor_db_manager._init_mgr_db()
        monitor_db_manager._init_single_db()

        self.check_database_schema()
        # self.adjust_process_db()
        self.migrate_process_db()

        self.clear_cache_file()

        # 初始化任务
        self.init_monitor_tasks()
    
    def clear_cache_file(self):
        if os.path.exists("/www/server/bt-monitor/static/panel/static/js/term.js"):
            os.remove("/www/server/bt-monitor/static/panel/static/js/term.js")
        public.ExecShell("cd /www/server/bt-monitor/static/panel && rm -rf `ls | grep -v static`")

    def init_monitor_tasks(self):
        '''
            @name 初始化任务
            @author Zhj<2022-09-20>
            @return void
        '''
        # 删除计划任务
        cron_task_obj = CronTask()

        # 删除更新服务器列表状态计划任务
        cron_task_obj.delete_task('update_servers')

        # 删除扫描告警规则计划任务
        cron_task_obj.delete_task('warn_task')

        # 删除端口测试计划任务
        cron_task_obj.delete_task('port_test_task')

        # 每天02:00:00归档数据库文件
        cron_task_obj.delete_task('database_archive')
        cron_task_obj.create_task('database_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档请求日志
        cron_task_obj.delete_task('request_log_archive')
        cron_task_obj.create_task('request_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每天02:00:00归档错误日志
        cron_task_obj.delete_task('debug_log_archive')
        cron_task_obj.create_task('debug_log_archive', {
            'type': 'day-n',
            'hour': 2,
            'minute': 0,
            'where1': 1,
        })

        # 每隔6小时重启云监控
        # cron_task_obj.delete_task('reboot_monitor')
        # cron_task_obj.create_task('reboot_monitor', {
        #     'type': 'hour-n',
        #     'minute': 0,
        #     'where1': 6,
        # })

        # 更新主机状态任务
        monitor_task_queue.add_task(MonitorTask(basic_monitor_obj, 'update_servers').set_interval())

        # 主机告警任务
        monitor_task_queue.add_task(MonitorTask(warning_obj, 'warn_all').set_interval(periodic=120))

        # 端口测试任务
        monitor_task_queue.add_task(MonitorTask(warning_obj, 'test_ports').set_interval(periodic=120))

    def v_1_0_4(self):
        '''
            @name 1.0.4版本补丁
            @author Zhj<2022-08-26>
            @return void
        '''
        # 初始化独立数据库
        monitor_db_manager._init_single_db()

        if self.__is_patched('1.0.4'):
            return

        # 打补丁
        with self.__patching('1.0.4'):
            # 新增计划任务
            cron_task_obj = CronTask()

            # 每隔1分钟更新服务器列表状态
            cron_task_obj.delete_task('update_servers')
            cron_task_obj.create_task('update_servers', {
                'type': 'minute-n',
                'where1': 1,
            })

            # 每隔2分钟测试端口连接
            cron_task_obj.delete_task('port_test_task')
            cron_task_obj.create_task('port_test_task', {
                'type': 'minute-n',
                'where1': 2,
            })

            # 每天02:00:00归档数据库文件
            cron_task_obj.delete_task('database_archive')
            cron_task_obj.create_task('database_archive', {
                'type': 'day-n',
                'hour': 2,
                'minute': 0,
                'where1': 1,
            })

            # 每天02:00:00归档请求日志
            cron_task_obj.delete_task('request_log_archive')
            cron_task_obj.create_task('request_log_archive', {
                'type': 'day-n',
                'hour': 2,
                'minute': 0,
                'where1': 1,
            })

            # 初始化数据库
            monitor_db_manager._init_mgr_db()
            monitor_db_manager._init_single_db()

            old_db_file = '{}/data/monitor.db'.format(public.get_panel_path())

            if os.path.exists(old_db_file) and os.path.getsize(old_db_file) > 100:
                # 迁移基础数据
                public.print_log('--正在进行数据库迁移')

                with public.sqlite_easy('monitor') as db_old, monitor_db_manager.db_mgr() as db_new:
                    try:
                        # 关闭事务自动提交
                        db_new.autocommit(False)

                        # 迁移主机列表
                        if not db_new.query().name('servers').where('sid>0').exists():
                            public.print_log('--正在迁移服务器列表')

                            # 迁移数据
                            db_new.query().name('servers').insert_all(
                                db_old.query().name('servers').select())

                            public.print_log('--服务器列表迁移成功')

                        # 迁移告警模板规则
                        if not db_new.query().name('warning_templates').where('id>0').exists():
                            public.print_log('--正在迁移告警模板规则')

                            # 迁移数据
                            db_new.query().name('warning_templates').insert_all(
                                db_old.query().name('warning_templates').select())

                            public.print_log('--告警模板规则迁移成功')

                        # 迁移告警模板
                        if not db_new.query().name('warning_template_packages').where('id>0').exists():
                            public.print_log('--正在迁移告警模板')

                            # 迁移数据
                            db_new.query().name('warning_template_packages').insert_all(
                                db_old.query().name('warning_template_packages').select())

                            public.print_log('--告警模板迁移成功')

                        # 迁移告警模板与主机关联信息
                        if not db_new.query().name('server_warning_template_package_merge').where('id>0').exists():
                            public.print_log('--正在迁移告警模板与主机关联信息')

                            # 迁移数据
                            db_new.query().name('server_warning_template_package_merge').insert_all(
                                db_old.query().name('server_warning_template_package_merge').select())

                            public.print_log('--告警模板与主机关联信息迁移成功')

                        # 迁移主机告警规则
                        if not db_new.query().name('warning_configurations').where('id>0').exists():
                            public.print_log('--正在迁移主机告警规则')

                            # 迁移数据
                            db_new.query().name('warning_configurations').insert_all(
                                db_old.query().name('warning_configurations').select())

                            public.print_log('--主机告警规则迁移成功')

                        # 提交事务
                        db_new.commit()

                        public.print_log('--数据库迁移成功')

                    except BaseException as e:
                        # 回滚事务
                        db_new.rollback()

                        # 记录异常堆栈
                        public.print_exc_stack(e)

                        return

                # 删除monitor.db
                if os.path.exists(old_db_file):
                    os.remove(old_db_file)

    def v_1_0_6(self):
        '''
            @name 1.0.6版本补丁
            @author Zhj<2022-09-17>
            @return void
        '''
        if self.__is_patched('1.0.6'):
            return

        # 打补丁
        with self.__patching('1.0.6'):
            # 删除计划任务
            cron_task_obj = CronTask()

            # 删除更新服务器列表状态计划任务
            cron_task_obj.delete_task('update_servers')

            # 删除扫描告警规则计划任务
            cron_task_obj.delete_task('warn_task')

            # 删除端口测试计划任务
            cron_task_obj.delete_task('port_test_task')

            # 扫描数据库
            # monitor_db_manager._scan_files()

    def v_1_0_10(self):
        '''
            @name 1.0.10版本补丁
            @author Zhj<2022-11-12>
            @return void
        '''
        if self.__is_patched('1.0.10'):
            return

        # 打补丁
        with self.__patching('1.0.10'):
            # 修复默认模板异常
            with public.sqlite_easy('monitor_mgr') as db:
                package_id = db.query()\
                    .name('warning_template_packages')\
                    .order('id', 'asc')\
                    .value('id')

                if package_id is None:
                    return

                db.query()\
                    .name('warning_templates')\
                    .where('package_id=?', package_id)\
                    .where('type=?', 'log')\
                    .where('sub_type=?', 'ssh_login_logs')\
                    .where('watch_target=?', 'place_other')\
                    .where('watch_type=5')\
                    .where('is_push=1')\
                    .where('watch_value=?', 'on_off')\
                    .update({
                        'watch_value': 'on',
                    })

    def check_database_schema(self):
        '''
            @name 更新表结构
            @return void
        '''
        try:
            # 更新servers表结构
            # 需要确保存在的字段列表
            keep_columns = {
                "ssh_info": "INTEGER DEFAULT 0",
                "panel_info": "INTEGER DEFAULT 0",
                "group_id": "INTEGER NOT NULL DEFAULT 0",
            }

            with monitor_db_manager.db_mgr() as db:
                query = db.query().name('servers')

                for (col_name, col_prop) in keep_columns.items():
                    query.add_column(col_name, col_prop)

                # 更新表结构
                query.alter_table()

                # 更新warning_templates表结构
                query = db.query().name('warning_templates')

            # 更新ssh_login_logs表结构
            with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                query = db.query().name('ssh_login_logs')

                # 新增字段
                query.add_column('ip_place', "TEXT NOT NULL DEFAULT ''")

                # 更新表结构
                query.alter_table()

                # 新增索引
                query.add_index('sshLoginLogs_loginTime_ipPlace', ['login_time', 'ip_place'])

            # 更新safety.logs表结构
            with public.sqlite_easy('safety') as db:
                query = db.query().name('logs')

                # 新增索引
                query.add_index('logs_addtime_type', ['addtime', 'type'])
        except BaseException as e:
            public.print_log("数据库结构调整失败: {}".format(e))

            # 记录异常堆栈
            public.print_exc_stack(e)

    def adjust_process_db(self):
        """调整进程数据库适合按天存储"""
        with monitor_db_manager.db_mgr() as db:
            servers = db.query()\
            .name('servers')\
            .where_in('status', [0, 1])\
            .column('sid')
        
        import time, shutil
        ori_date = time.strftime('%Y%m')
        day = time.strftime('%Y%m%d')
        root_path = '{}/data/monitor_servers'.format(public.get_panel_path())
        for sid in servers:
            sid_md5 = public.md5(str(sid))
            target_db_path = '{}/{}/{}'.format(root_path, sid_md5, ori_date)            
            if not os.path.isdir(target_db_path):
                continue
            new_path = '{}/{}/{}'.format(root_path, sid_md5, day)
            if not os.path.exists(new_path):
                os.makedirs(new_path)
            for sfile in os.listdir(target_db_path):
                if not sfile.startswith("process_"): continue
                source_db = os.path.join(target_db_path, sfile)
                if not os.path.isfile(source_db): continue
                new_db = os.path.join(new_path, sfile)
                shutil.move(source_db, new_db)
                public.print_log("移动{} --> {} 完成。".format(sfile, new_db))
                # print("移动{} 完成。".format(sfile))

    def migrate_process_db(self):
        '''
            @name 删减并迁移进程数据库(调整为按天存储)
            @author Zhj<2022-09-21>
            @return void
        '''
        # 获取当前时间的时间元组
        now_time = time.localtime()

        # 获取本月日期
        cur_month = int(time.strftime('%Y%m', now_time))

        # 获取今天日期
        today = time.strftime('%Y%m%d', now_time)

        # 获取今天00:00:00时间戳
        today_time = int(time.mktime((now_time.tm_year, now_time.tm_mon, now_time.tm_mday, 0, 0, 0, 0, 0, 0)))

        # 获取昨天日期
        yesterday = time.strftime('%Y%m%d', time.localtime(today_time - 86400))

        # 获取前天日期
        before_yesterday = time.strftime('%Y%m%d', time.localtime(today_time - 172800))

        with monitor_db_manager.db_mgr('server_databases') as db:
            process_db_list = db.query()\
                .name('server_databases')\
                .where('sid>0')\
                .where('delete_time=0')\
                .where('db_date>=?', 202207)\
                .where('db_date<=?', 999999)\
                .where('table_name like ?', 'process_%')\
                .field('id', 'sid', 'db_name', 'table_name', 'db_date', 'db_path', 'archive_path', 'archive_time')\
                .select()

        if len(process_db_list) == 0:
            return

        public.print_log('|--开始迁移主机进程数据库')

        # 标记删除的ID列表
        remove_list = []

        # 即将删除的文件列表
        remove_files = []

        for process_db_info in process_db_list:
            db_file_exists = False
            shm_file = '{}.db-shm'.format(process_db_info['db_path'][:-3])
            wal_file = '{}.db-wal'.format(process_db_info['db_path'][:-3])

            # 删除db文件
            if os.path.exists(process_db_info['db_path']):
                remove_files.append(process_db_info['db_path'])
                db_file_exists = True

            # 删除shm文件
            if os.path.exists(shm_file):
                remove_files.append(shm_file)

            # 删除wal文件
            if os.path.exists(wal_file):
                remove_files.append(wal_file)

            # 删除归档文件
            if process_db_info['archive_time'] > 0 and os.path.exists(process_db_info['archive_path']):
                remove_files.append(process_db_info['archive_path'])

            # 标记删除
            remove_list.append(process_db_info['id'])

            # 不是本月数据或db文件不存在时 跳过
            if process_db_info['db_date'] < cur_month or not db_file_exists:
                continue

            log_content = '|--正在迁移数据库 {}'.format(process_db_info['db_name'])

            today_data = None
            yestoday_data = None
            before_yesterday_data = None

            # 迁移今天、昨天、前天数据
            with public.sqlite_easy(process_db_info['db_name']) as db:
                today_data = db.query()\
                    .name(process_db_info['table_name'])\
                    .where('create_time >= ?', today_time)\
                    .select()

                yesterday_data = db.query()\
                    .name(process_db_info['table_name'])\
                    .where('create_time >= ?', today_time - 86400)\
                    .where('create_time < ?', today_time)\
                    .select()

                before_yesterday_data = db.query()\
                    .name(process_db_info['table_name'])\
                    .where('create_time >= ?', today_time - 172800)\
                    .where('create_time < ?', today_time - 86400)\
                    .select()

            # 初始化数据库(今天)
            today_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(today))

            # 迁移今天数据
            if len(today_data) > 0:
                today_mgr.add(process_db_info['table_name'], today_data, option='ignore')

            # 释放内存
            today_data = None

            # 初始化数据库(昨天)
            yesterday_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(yesterday))

            # 迁移昨天数据
            if len(yesterday_data) > 0:
                yesterday_mgr.add(process_db_info['table_name'], yesterday_data, option='ignore')

            # 释放内存
            yesterday_data = None

            # 初始化数据库(前天)
            before_yesterday_mgr = monitor_db_manager.MonitorDbManager(process_db_info['sid'], int(before_yesterday))

            # 迁移昨天数据
            if len(before_yesterday_data) > 0:
                before_yesterday_mgr.add(process_db_info['table_name'], before_yesterday_data, option='ignore')

            # 释放内存
            before_yesterday_data = None

            public.print_log('{} >>> 完成'.format(log_content))

        # 删除文件
        for filename in remove_files:
            if os.path.exists(filename):
                os.remove(filename)

        # 获取当前时间戳
        cur_time = int(time.mktime(now_time))

        # 更新主数据
        with monitor_db_manager.db_mgr('server_databases') as db:
            db.query()\
                .name('server_databases')\
                .where_in('id', remove_list)\
                .update({
                    'delete_time': cur_time,
                })

        public.print_log('|--主机进程数据库迁移成功')

    def attempt_install_patches(self):
        '''
            @name 尝试安装版本补丁
            @author Zhj<2022-11-12>
            @return void
        '''
        for version in self.__PATCH_VERSIONS:
            # 获取方法名称
            func_name = 'v_{}'.format(version.replace('.', '_'))
            # 调用方法
            if hasattr(self, func_name):
                getattr(self, func_name)()

    def __is_patched(self, version = None):
        '''
            @name 检查是否已经打过补丁
            @author Zhj<2022-08-26>
            @param  version<?string> 版本号[可选]
            @return bool
        '''
        version = version or self.__CUR_VERSION
        try:
            with monitor_db_manager.db_mgr('version_patches') as db:
                return db.query()\
                    .name('version_patches')\
                    .where('version = ?', version)\
                    .where('create_time > 0')\
                    .field('id')\
                    .exists()
        except:
            return True

    def __patch_end(self, version = None):
        '''
            @name 补丁完成记录
            @author Zhj<2022-08-26>
            @param version<?string> 版本号[可选]
            @return void
        '''
        version = version or self.__CUR_VERSION
        with monitor_db_manager.db_mgr('version_patches') as db:
            try:
                # 关闭事务自动提交
                db.autocommit(False)

                db.query() \
                    .name('version_patches') \
                    .insert({
                        'version': version,
                    })

                # 提交事务
                db.commit()
            except BaseException as e:
                # 回滚事务
                db.rollback()

                # 记录异常堆栈
                public.print_exc_stack(e)

    @contextmanager
    def __patching(self, version = None):
        '''
            @name 基于上下文管理器的补丁程序
            @author Zhj<2022-09-08>
            @param  version<?string> 版本号[可选]
            @return generator
        '''
        yield
        self.__patch_end(version)

# if __name__ == "__main__":
#     mvp = MonitorVersionPatch()
#     mvp.check_database_schema()
    # mvp.adjust_process_db()