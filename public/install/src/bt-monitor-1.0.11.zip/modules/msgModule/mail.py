
from distutils.log import info
from importlib.resources import path
import json,time,re,os,requests,smtplib
import core.include.public as public
from flask import Response,request
from core import session
from email.mime.text import MIMEText
from email.utils import formataddr

import core.include.c_loader.PluginLoader as plugin_loader


main = plugin_loader.get_module('{}/modules/msgModule/main.py'.format(public.get_panel_path())).main

# from modules.msgModule.main import main

"""
@name 邮箱消息通道模块 
@author cjxin@bt.cn
"""

class mail(main):

    __info = None
    __msg_type = 'mail'
    
    def __init__(self):               
        self.__info = self.get_config(None)

  
    def get_config(self,get = None):
        """
        @name 获取配置
        @author cjxin
        """                      
        return self._get_base_config(self.__msg_type)

    def set_config(self,get):
        """
        @name 设置配置
        @author cjxin
        """
        data = {}
        if not self.__info:
            data = {'send':{},'receive':{}}

        if not hasattr(get, 'qq_mail') or not hasattr(get, 'qq_stmp_pwd') or not hasattr(get, 'hosts') or not hasattr(get, 'port') or not hasattr(get, 'mails'):
            return self._return_data(self.__msg_type,False, '信息配置失败，请填写完整信息!')

        data['send'] = {"qq_mail": get.get('qq_mail/s'), "qq_stmp_pwd": get.get('qq_stmp_pwd/s'), "hosts": get.get('hosts/s'), "port": get.get('port/d')}

        arrs = get.mails.strip().split('\n')
        if len(arrs) == 0 : 
            return self._return_data(self.__msg_type,False, '信息配置失败，请至少填写一个接收者邮箱(可以和发件者一致)!')

        data['receive'] = arrs       
        return self._set_base_config(self.__msg_type,data)

    def is_configured(self):
        '''
            @name 检查邮箱是否配置
            @author Zhj<2022-08-02>
            @return bool
        '''
        if self.__info is None\
                or not isinstance(self.__info, dict)\
                or 'send' not in self.__info\
                or not isinstance(self.__info['send'], dict):
            return False

        for k in ['qq_mail', 'qq_stmp_pwd', 'hosts', 'port']:
            if k not in self.__info['send']\
                or self.__info['send'][k] is None\
                or self.__info['send'][k] == '':
                return False

        return True

    def send_msg(self,minfo):
        """
        @name 发送消息
        @author cjxin
        @minfo dict  {
            msg:string(消息内容),
            title:string(消息标题)
            to_email:string(接收者邮箱,多个逗号隔开),不填则给所有配置用户发邮件
        }
        """
        if not self.__info :
             return self._return_data(self.__msg_type,False,'未正确配置信息。')
        
        receive_list = self.__info['receive']
        if 'to_email' in minfo: 
            receive_list = minfo['to_email'].split(',')

        for email in receive_list:
            try:
                data = MIMEText(minfo['msg'], 'html', 'utf-8')
                data['From'] = formataddr([self.__info['send']['qq_mail'], self.__info['send']['qq_mail']])
                data['To'] = formataddr([self.__info['send']['qq_mail'], email.strip()])
                data['Subject'] = minfo['title']
                if int(self.__info['send']['port']) == 465:
                    server = smtplib.SMTP_SSL(str(self.__info['send']['hosts']), str(self.__info['send']['port']))
                else:
                    server = smtplib.SMTP(str(self.__info['send']['hosts']), str(self.__info['send']['port']))

                server.login(self.__info['send']['qq_mail'], self.__info['send']['qq_stmp_pwd'])
                server.sendmail(self.__info['send']['qq_mail'], [email.strip(), ], data.as_string())
                server.quit()
         
                self._write_log(self.__msg_type,1,'发送成功，邮箱：' + email)  
            except :
                self._write_log(self.__msg_type,0,'发送失败，邮箱：' + email,public.get_error_info())       
    
        return self._return_data(self.__msg_type,True,'发送完成')      