# encoding: utf-8
import json, os, sys, re, time

os.chdir("/www/server/bt-monitor")
sys.path.insert(0, "/www/server/bt-monitor")

from core.include.monitor_helpers import basic_monitor_obj
from core import session
import core.include.public as public
from core.include.monitor_exceptions import BtMonitorException
from threading import Lock
import core.include.Locker as Locker
import core.include.monitor_status_codes as monitor_status_codes

# import core.include.monitor_db_manager as monitor_db_manager
# import core.include.c_loader.PluginLoader as plugin_loader

monitor_db_manager = public.import_via_loader('{}/core/include/monitor_db_manager.py'.format(public.get_panel_path()))

class main():
    '''
        @name 监控概览
        @author Zhj<2022-06-28>
    '''
    timeout = 60

    def get_login_logs(self, args):
        '''
            @name 获取服务端登录日志
            @author Zhj<2022-06-28>
            @arg    p<integer>      分页页码
            @arg    p_size<integer> 分页大小
            @return list
        '''
        with public.sqlite_easy('safety') as db:
            query = db.query() \
                .name('logs') \
                .where('`type`=?', '用户登录') \
                .field('log', 'addtime') \
                .order('addtime', 'desc')

            return public.success(public.simple_page(query, args))

    def get_servers_overview(self, args):
        '''
            @name 获取主机概览信息
            @author Zhj<2022-06-28>
            @return dict
        '''
        # 更新所有主机状态
        # basic_monitor_obj.update_servers()

        m = {
            '0': 'offline',
            '1': 'online',
            '2': 'maintenance',
        }

        ret = {
            'total': 0,
            'offline': 0,
            'online': 0,
            'maintenance': 0,
        }

        # 查询全部主机IP、备注
        servers = basic_monitor_obj.db_easy('servers')\
            .field('sid', 'status', 'ip', 'remark')\
            .select()

        # 统计主机数
        for server in servers:
            k = m.get(str(server['status']), 'total')

            if k != 'total':
                ret['total'] += 1

            ret[k] += 1

        ret['servers'] = servers

        return public.success(ret)

    def get_server_list(self, args):
        '''
            @name 获取主机列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    主机状态 0-离线 1-在线 2-维护(弃用) 3-未授权 4-已授权
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    group_id<?integer>  分组ID[可选]
            @return list
        '''
        # 更新所有主机状态
        # basic_monitor_obj.update_servers()

        # 从safety库中更新未授权的主机
        with public.sqlite_easy('safety') as db_safety, monitor_db_manager.db_mgr() as db:
            try:
                unauth_sid_list = db.query()\
                    .name('servers')\
                    .where('is_authorized=0')\
                    .column('sid')

                unauth_servers = db_safety.query()\
                    .name('server_list')\
                    .where('status=0')\
                    .where_not_in('sid', unauth_sid_list)\
                    .field(
                        'sid',
                        '`address` as `ip`',
                        'ifnull(`ps`,\'\') as `remark`',
                        '`addtime` as `create_time`'
                    )\
                    .select()

                if unauth_servers is not None and len(unauth_servers) > 0:
                    # 批量插入
                    db.query().name('servers').insert_all(unauth_servers)

            except BaseException as e:
                # 记录异常堆栈
                public.print_exc_stack(e)

        status = args.get('status', None)
        group_id = args.get('group_id', None)

        query = basic_monitor_obj.db_easy('servers')\
            .alias('s')\
            .join('server_group sg', 's.group_id=sg.id', 'left')

        if status is not None and int(status) in [0, 1, 2, 3, 4]:
            d = {
                3: ('is_authorized', 0),
                4: ('is_authorized', 1),
            }

            field = 'status'
            val = int(status)

            if val in d:
                field, val = d[val]

            query.where('`{}` = ?'.format(field), val)

        if group_id is not None and re.match(r'^\d+(?:,\d+)*$', str(group_id)):
            query.where_in('group_id', str(group_id).split(','))

        query.field(
            'sid',
            'group_id',
            'sg.name as group_name',
            'status',
            'is_authorized',
            'allow_notify',
            'ip',
            'remark',
            's.create_time',
            'last_active_time',
            "ssh_info",
            "panel_info"
        ).order('s.create_time',  'DESC')

        # 添加关键字查询
        def query_handler(query, keyword):
            k = '%{}%'.format(keyword)

            # 主机IP与主机备注模糊搜索
            query.where('remark like ? OR ip like ?', (k,k,))

        public.add_retrieve_keyword_query(query, args, query_handler)

        ret = public.simple_page(query, args)

        # 查询主机详细信息关联数据
        for item in ret['list']:
            item.update(basic_monitor_obj.cache_realtime_server_info(item['sid']))

        # 查询授权客户端数量/可授权的客户端数量
        # 获取允许授权的客户端数量
        auth_info = basic_monitor_obj.get_auth_info()

        if not auth_info:
            ret['available_auth_num'] = basic_monitor_obj.get_available_clients()

            # 获取当前已授权的客户端数量
            ret['cur_auth_num'] = basic_monitor_obj.db_easy('servers') \
                .where('is_authorized=1') \
                .where_in('status', [0, 1]) \
                .count()
        else:
            ret['available_auth_num'] = auth_info.get('clients', 0)
            ret['cur_auth_num'] = auth_info.get('cur_auth_num', 0)

        return public.return_data(True, ret)

    def get_server_detail(self, args):
        '''
            @name 获取主机监控信息
            @author Zhj<2022-07-08>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^\d+$', sid):
            return public.error('无效的参数：sid')

        server_info = basic_monitor_obj.db_easy('servers')\
            .where('sid=?', int(sid))\
            .field('sid', 'ip', 'remark', 'status')\
            .find()

        if basic_monitor_obj.is_empty_result(server_info):
            return public.return_error('未查询到主机信息')

        server_detail, err_msg = basic_monitor_obj.retrieve_server_detail(sid)
        
        if not server_detail:
            return public.error(err_msg)
        
        agent_version = public.cache_get("AGENT_VERSION_"+str(sid))
        if not agent_version:
            agent_version_file = '{}/data/monitor_servers/{}/{}'.format(public.get_panel_path(), public.md5(str(sid)), "agentversion.pl") 
            _str = public.readFile(agent_version_file)
            if _str:
                agent_version = _str
        if agent_version:
            server_info["agent_version"] = agent_version
        else:
            server_info["agent_version"] = ""
        server_info.update(server_detail)

        return public.success(server_info)
    
    def edit_server_auth_status(self, args):
        '''
            @name 修改主机授权状态
            @author Zhj<2022-07-05>
            @arg    sid<integer|string>     主机ID列表
            @arg    status<integer>         授权状态 0-未授权 1-已授权
            @arg    initialize<?integer>    是否重新分配，会将剩余主机授权状态重置<可选>
            @return dict
        '''
        sid = args.get('sid', None)
        status = args.get('status', None)
        is_init = args.get('initialize', 0)

        if sid is None:
            return public.error('缺少参数：sid')

        if not re.match(r'^\d+(?:,\d+)*$', str(sid)):
            return public.error('参数sid格式错误')

        if status is None:
            return public.error('缺少参数：status')

        if int(status) not in [0, 1]:
            return public.error('无效的参数：status')

        sid_list = str(sid).split(',')

        # 上锁
        with Locker.acquire(Lock()):
            # 查询主机信息
            server_list = basic_monitor_obj.db_easy('servers')\
                .where_in('sid', sid_list)\
                .field('ip', 'is_authorized', 'remark')\
                .select()

            if basic_monitor_obj.is_empty_result(server_list):
                return public.error('无效的参数：sid')

            # 筛选授权状态发生变化的主机
            server_list = list(filter(lambda x: int(x['is_authorized']) != int(status), server_list))

            server_num = len(server_list)

            if server_num == 0:
                return public.success('操作成功')

            # 获取允许授权的客户端数量
            available_auth_num = basic_monitor_obj.get_available_clients()

            if is_init:
                cur_auth_num = 0
            else:
                # 获取当前已授权的客户端数量
                cur_auth_num = basic_monitor_obj.db_easy('servers')\
                    .where('is_authorized=1')\
                    .where_in('status', [0, 1])\
                    .count()

            # 已达最大授权数量时，不允许继续授权客户端
            if int(status) == 1 and available_auth_num < cur_auth_num + len(server_list):
                return public.error('当前已达最大授权数量，请升级授权数量或者取消其它客户端授权', monitor_status_codes.auth_num_exceed)

            m = {
                '0': '未授权',
                '1': '已授权'
            }

            with public.sqlite_easy('safety') as db_safety, public.sqlite_easy('monitor_mgr') as db_monitor:
                # 关闭事务自动提交
                db_safety.autocommit(False)
                db_monitor.autocommit(False)

                # 更新主机授权状态
                db_safety.query() \
                    .name('server_list') \
                    .where_in('sid', sid_list) \
                    .update({
                        'status': int(status),
                    })

                update_data = {
                    'is_authorized': int(status),
                    'update_time': int(time.time()),
                }

                # 主机授权状态更新为 未授权
                # 更新主机状态为 离线
                if int(status) == 0:
                   update_data['status'] = 0

                db_monitor.query()\
                    .name('servers')\
                    .where_in('sid', sid_list)\
                    .update(update_data)

                if is_init:
                    db_safety.query()\
                        .name('server_list')\
                        .where_not_in('sid', sid_list)\
                        .update({
                            'status': 0,
                        })

                    db_monitor.query()\
                        .name('servers')\
                        .where_not_in('sid', sid_list)\
                        .update({
                            'is_authorized': 0,
                            'status': 0,
                            'update_time': update_data['update_time'],
                        })

                # 提交事务
                db_safety.commit()
                db_monitor.commit()

            for server_info in server_list:
                public.WriteLog('主机授权', '用户【%s】更改主机[%s（%s）]授权状态为【%s】' % (session.get('username', ''), server_info['ip'], server_info['remark'], m.get(str(status), '--')))

        # 更新缓存
        public.cache_set('BT_MONITOR_CACHE__CUR_AUTH_NUM', server_num if is_init else cur_auth_num + (server_num if int(status) == 1 else -1 * server_num), 120)

        return public.success('操作成功')

    def get_warning_tasks(self, args):
        '''
            @name 获取告警任务列表
            @author Zhj<2022-06-28>
            @arg    sid<?integer>       主机ID
            @arg    status<?integer>    告警任务状态 0-未处理 1-已处理
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @return list
        '''
        sid = args.get('sid', None)
        status = args.get('status', None)

        query = basic_monitor_obj.db_easy('warning_tasks')\
            .field('id', 'title', 'content', 'status', 'is_pushed', 'create_time')\
            .order('create_time', 'desc')

        if status is not None:
            query.where('status=?', int(status))

        if sid is not None:
            query.where('sid=?', int(sid))

        return public.success(public.simple_page(query, args))

    def get_ssh_login_logs(self, args):
        '''
            @name 获取SSH登录日志列表
            @author Zhj<2022-06-28>
            @arg    status<?integer>    SSH登录状态 0-登录失败 1-登录成功
            @arg    p<integer>          分页页码
            @arg    p_size<integer>     分页大小
            @arg    sid<?integer>       主机ID[可选]
            @arg    keyword<?string>    关键字[可选]
            @return list
        '''
        status = args.get('status', None)
        sid = args.get('sid', None)
        keyword = args.get('keyword', None)

        query = basic_monitor_obj.db_easy('ssh_login_logs')\
            .field('id', 'sid', 'user', 'ip as login_ip',
                'port', 'ip_place', 'success','login_time'
            ) \
            .order('login_time', 'desc')

        if status is not None:
            query.where('success=?', int(status))

        if sid is not None:
            query.where('sid=?', int(sid))

        if keyword is not None:
            tmp = '%{}%'.format(keyword)
            query.where('user like ? OR ip like ?', [tmp, tmp])

        ret = public.simple_page(query, args)

        servers = basic_monitor_obj.db_easy('servers')\
            .where_in('sid', list(map(lambda x: x['sid'], ret['list'])))\
            .field('sid', 'ip', 'remark')\
            .column(None, 'sid')

        login_ip_idx_map = {}
        i = 0

        for item in ret['list']:
            if item['ip_place'] == '' and item['login_ip'] != '':
                if item['login_ip'] not in login_ip_idx_map:
                    login_ip_idx_map[item['login_ip']] = []

                login_ip_idx_map[item['login_ip']].append(i)

            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['login_ip'] = '{}{}'.format(item['login_ip'], ':{}'.format(item['port']) if int(item['port']) > 0 else '')
            item['remark'] = server_info.get('remark', {})
            del(item['sid'])
            del(item['port'])

            i += 1

        # 查询IP信息
        if len(login_ip_idx_map.keys()) > 0:
            ip_info_dict = basic_monitor_obj.search_ip_info(list(login_ip_idx_map.keys()))

            with monitor_db_manager.db_mgr('ssh_login_logs') as db:
                try:
                    # 关闭自动提交事务
                    db.autocommit(False)

                    for (login_ip, idx_list) in login_ip_idx_map.items():
                        if login_ip not in ip_info_dict:
                            continue

                        ip_place = ip_info_dict[login_ip]['country']+ip_info_dict[login_ip]['province']

                        ids = []

                        for idx in idx_list:
                            ret['list'][idx]['ip_place'] = ip_place
                            ids.append(ret['list'][idx]['id'])

                        # 更新IP信息
                        db.query()\
                            .name('ssh_login_logs')\
                            .where_in('id', ids)\
                            .update({
                                'ip_place': ip_place,
                            })

                    # 提交事务
                    db.commit()
                except BaseException as e:
                    # 回滚事务
                    db.rollback()

                    # 记录异常堆栈信息
                    public.print_exc_stack(e)

        # 统计登录成功与失败次数
        query = basic_monitor_obj.db_easy('ssh_login_logs')\
            .field('SUM(CASE WHEN `success` = 1 THEN 1 ELSE 0 END) AS `success_cnt`', 'SUM(CASE WHEN `success` = 0 THEN 1 ELSE 0 END) AS `fail_cnt`')

        if sid is not None:
            query.where('sid=?', int(sid))

        statistics_info = query.find()

        if statistics_info is None:
            statistics_info = {
                'success_cnt': 0,
                'fail_cnt': 0,
            }

        ret.update(statistics_info)

        return public.success(ret)

        # # 打开数据库
        # with public.sqlite_easy('monitor') as db:
        #     try:
        #         query = db.query()\
        #             .name('ssh_login_logs sll')\
        #             .join('servers s', 'sll.sid=s.sid')\
        #             .field(
        #                 'sll.user',
        #                 'sll.ip as login_ip',
        #                 'sll.success',
        #                 'sll.login_time',
        #                 's.ip',
        #                 's.remark'
        #             )\
        #             .order('login_time', 'desc')
        #
        #         if status is not None:
        #             query.where('sll.success=?', int(status))
        #
        #         if sid is not None:
        #             query.where('sll.sid=?', int(sid))
        #
        #         if keyword is not None:
        #             tmp = '%{}%'.format(keyword)
        #             query.where('sll.user like ? OR sll.ip like ?', [tmp, tmp])
        #
        #         ret = public.simple_page(query, args)
        #
        #         return public.return_data(True, ret)
        #
        #     except BtMonitorException as e:
        #         return public.error(str(e))

    def get_ssh_login_logs_statistics(self, args):
        '''
            @deprecated 已废弃
            @name 获取SSH登录日志统计
            @author Zhj<2022-07-07>
            @arg    query_date<?string>  时间筛选关键字
            @arg    sid<?integer>        主机ID
            @arg    status<?integer>     登录状态 0-登录失败 1-登录成功
            @return dict
        '''
        query_date = args.get('query_date', 'l5')
        status = args.get('status', None)
        sid = args.get('sid', None)

        query_start, query_end = public.get_query_timestamp(query_date)

        where_str = '`login_time` BETWEEN ? AND ?'
        where_params = [query_start, query_end]

        if sid is not None:
            where_str += ' AND `sid` = ?'
            where_params.append(int(sid))

        if status is not None:
            if int(status) not in [0, 1]:
                return public.error('无效参数：status')

            where_str += ' AND `success` = ?'
            where_params.append(int(status))

        raw_sql = '''
            SELECT SUM(CASE `success` WHEN 1 THEN 1 ELSE 0 END) AS `success_num`, SUM(CASE `success` WHEN 0 THEN 1 ELSE 0 END) AS `fail_num`, STRFTIME('%m/%d', `login_time`, 'unixepoch') AS `day_date`
            FROM `bt_ssh_login_logs`
            WHERE {}
            GROUP BY `day_date`
            ORDER BY `day_date` ASC;
        '''.format(where_str)

        return public.success(list(map(lambda i:{ 'success_num': i[0], 'fail_num': i[1], 'day_date': i[2] }, public.db_monitor().query(raw_sql, where_params))))

    def get_dashboard_overview(self, args):
        '''
            @name 获取仪表盘信息
            @author Zhj<2022-06-29>
            @return dict
        '''
        # 更新主机状态
        # basic_monitor_obj.update_servers()

        # 获取所有在线主机ID
        sid_list = basic_monitor_obj.db_easy('servers')\
            .where('status=1')\
            .field('sid')\
            .column('sid')

        server_num = 0
        cpu_percent_total = 0
        mem_percent_total = 0
        ret = {
            'cpu_core_total': 0,
            'mem_total': 0,
            'cpu_avg_percent': 0,
            'mem_avg_percent': 0,
        }

        for sid in sid_list:
            server_info = basic_monitor_obj.cache_realtime_server_info(sid)
            server_num += 1
            cpu_info = server_info.get('cpu_info', {})
            mem_info = server_info.get('mem_info', {})
            ret['cpu_core_total'] += int(cpu_info.get('logical_cores', 1))
            ret['mem_total'] += int(mem_info.get('total', 0))
            cpu_percent_total += float(cpu_info.get('percent', 0))
            mem_percent_total += float(mem_info.get('used_percent', 0))

        ret['cpu_avg_percent'] = round(cpu_percent_total / server_num, 2) if server_num > 0 else 0
        ret['mem_avg_percent'] = round(mem_percent_total / server_num, 2) if server_num > 0 else 0

        return public.success(ret)

    def get_proc_traffic_top(self, args):
        '''
            @name 进程流量top10
            @author Zhj<2022-06-29>
            @return list
        '''
        ret = basic_monitor_obj.db_memory('processes')\
            .where('update_time > ?', int(time.time()) - 60)\
            .field(
                'sid',
                'name',
                '(net_sent_bytes_per_second + net_recv_bytes_per_second) as bytes',
                'net_sent_bytes_per_second as sent_bytes',
                'net_recv_bytes_per_second as recv_bytes',
                'boot_command'
            )\
            .order('bytes', 'desc')\
            .limit(10)\
            .select()

        servers = basic_monitor_obj.db_easy('servers')\
            .where_in('sid', list(map(lambda x: x['sid'], ret)))\
            .field('sid', 'ip', 'remark')\
            .column(None, 'sid')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del(item['sid'])

        return public.success(ret)

    def get_proc_connection_top(self, args):
        '''
            @name 进程连接数top10
            @author Zhj<2022-06-29>
            @return list
        '''
        ret = basic_monitor_obj.db_memory('processes') \
            .where('update_time > ?', int(time.time()) - 60) \
            .field(
                'sid',
                'name',
                'opened_connections as connections',
                'boot_command'
            ) \
            .order('connections', 'desc') \
            .limit(10) \
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['sid'])

        return public.success(ret)

    def get_proc_cpu_top(self, args):
        '''
            @name 获取进程CPU占用TOP10
            @authot Zhj<2022-07-19>
            @return dict
        '''
        ret = basic_monitor_obj.db_memory('processes')\
            .where('update_time > ?', int(time.time()) - 120)\
            .field(
                'sid',
                'name',
                'cpu_used_percent as used_percent',
                'boot_command'
            )\
            .order('cpu_used_percent', 'desc')\
            .limit(10)\
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['sid'])

        return public.success(ret)

    def get_proc_mem_top(self, args):
        '''
            @name 获取进程内存占用TOP10
            @authot Zhj<2022-07-19>
            @return dict
        '''
        ret = basic_monitor_obj.db_memory('processes')\
            .where('update_time > ?', int(time.time()) - 120)\
            .field(
                'id',
                'sid',
                'name',
                'mem_used_percent as used_percent',
                'boot_command'
            )\
            .order('mem_used_percent', 'desc')\
            .limit(10)\
            .select()

        servers = basic_monitor_obj.db_easy('servers') \
            .where_in('sid', list(map(lambda x: x['sid'], ret))) \
            .field('sid', 'ip', 'remark') \
            .column(None, 'sid')

        for item in ret:
            server_info = servers.get(item['sid'], {})
            item['ip'] = server_info.get('ip', '')
            item['remark'] = server_info.get('remark', '')
            del (item['sid'])

            real_info = basic_monitor_obj.cache_realtime_proc_info(item['id'])
            item['used'] = real_info['mem_used']
            del item['id']

        return public.success(ret)

    def get_proc_top(self, args):
        '''
            @name 获取主机进程TOP10
            @author Zhj<2022-07-07>
            @arg    sid<integer> 主机ID
            @return dict
        '''
        sid = args.get('sid', None)

        if sid is None:
            return public.error('缺少参数：sid')

        query = basic_monitor_obj.db_memory('processes')\
            .field(
                'id', 'sid', 'name', 'status', 'boot_time', 'boot_command', 'boot_user', \
                'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes', \
                'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes' \
            ).where('`sid` = ?', int(sid))\
            .where('`update_time` > ?', int(time.time()) - 120)\

        # 默认排序
        if 'sort' not in args:
            query.order('`cpu_used_percent` + `mem_used_percent`', 'DESC')

        # 添加排序条件
        public.add_retrieve_sort_query(query, args)

        ret = query.limit(10).select()

        if basic_monitor_obj.is_empty_result(ret):
            ret = []

        for p_item in ret:
            p_item.update(basic_monitor_obj.cache_realtime_proc_info(p_item['id']))

        return public.success(ret)

    def get_processes_list(self, args):
        """主机详情-进程监控列表

        Args:
            args (dict_obj): 查询参数对象
                sid<integer>            主机ID
                query_date<?string>     时间查询[可选]
                process_name<?string>   搜索关键字[可选]
                sort<?string>           排序[可选]
                p<?integer>             分页页码[可选 默认1]
                p_size<?integer>        分页大小[可选 默认20]
        """
        sid = args.get('sid', None)
        query_date = args.get('query_date', None)
        process_name = args.get('process_name', None)

        if sid is None:
            return public.error('缺少参数：sid')

        # s = time.time()
        query = basic_monitor_obj.db_memory('processes')\
            .field(
                'id', 'sid', 'status', 'boot_time', 'name', 'boot_command', 'boot_user',
                'opened_files', 'opened_connections', 'opened_threads', 'disk_read_bytes',
                'disk_write_bytes', 'net_sent_bytes', 'net_recv_bytes', 'create_time',
                'update_time'
            )\
            .where('`sid` = ?', int(sid))\
            .where('`update_time` > ?', int(time.time()) - 120)\

        if query_date is not None:
            query.where('`create_time` BETWEEN ? AND ?', public.get_query_timestamp(query_date))

        if process_name is not None:
            query.where('`name` like ?', '%{}%'.format(process_name))

        if 'sort' not in args:
            query.order('`cpu_used_percent` + `mem_used_percent`', 'desc')

        public.add_retrieve_sort_query(query, args)

        # print(query.fork().build_sql())

        # print('查询前cost: {}'.format(str(time.time() - s)))

        # raw_sql = query.build_sql()
        # print('SQL: %s' % raw_sql)
        # print('SQL EXPLAIN: %s' % query.explain_raw_sql(raw_sql))

        result = public.simple_page(query, args)
        # print('--获取主机进程列表-查询耗时: %s' % str(time.time() - s))

        # result = {
        #     'total': len(ret),
        #     'list': ret
        # }

        # print('查询后cost: {}'.format(str(time.time() - s)))

        for p_item in result['list']:
            p_item.update(basic_monitor_obj.cache_realtime_proc_info(p_item['id']))


        # print('总cost: {}'.format(str(time.time() - s)))

        return public.success(result)

    def get_process_cpu_info_list(self, args):
        """进程CPU占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_cpu_info_list',
            ['id', 'process_id', 'percent', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_mem_info_list(self, args):
        """进程MEM占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_mem_info_list',
            ['id', 'process_id', 'percent', 'used', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_disk_info_list(self, args):
        """进程磁盘占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_disk_io_info_list',
            ['id', 'process_id', 'read_bytes_per_second', 'write_bytes_per_second', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_network_io_info_list(self, args):
        """进程网络IO占用详情"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_network_io_info_list',
            ['id', 'process_id', 'recv_bytes_per_second', 'sent_bytes_per_second', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_opened_files_info_list(self, args):
        """进程打开文件数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_opened_files_info_list',
            ['id', 'process_id', 'opened_files', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_opened_connections_info_list(self, args):
        """进程网络连接数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_opened_connections_info_list',
            ['id', 'process_id', 'opened_connections', 'create_time'],
            'process_id=?',
            [int(pid)]
        ))

    def get_process_opened_threads_info_list(self, args):
        """进程打开线程数"""
        pid = args.get('pid', None)

        if pid is None:
            return public.error('缺少参数：pid')

        return public.success(basic_monitor_obj.process_statistics_helper(
            args,
            'process_opened_threads_info_list',
            ['id', 'process_id', 'opened_threads', 'create_time'],
            'process_id=?',
            [int(pid)],
            pad_el = { 'id': 0, 'process_id': 0, 'opened_threads': 1, 'create_time': 0 }
        ))

    def get_host_firewall_info(self, args):
        """获取主机系统防火墙信息

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        fields = ['firewall_info']
        where_str = "sid=?"
        where_val = (sid,)
        res = basic_monitor_obj.db_easy("server_details").field(*fields).where(where_str, where_val).select()
        if not res and not res[0]["firewall_info"]:
            d = {
                "total": 0,
                "list": []
            }
            return public.return_data(True, d)

        res_data = json.loads(res[0]["firewall_info"])

        page = int(args.get('p', 1))
        page_size = int(args.get('p_size', 20))

        total = len(res_data)
        page_start = (page-1)*page_size
        rules = res_data["rules"]

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 端口号
                if keyword.isdigit():
                    if int(keyword) > 0 and int(keyword) < 65536:
                        # 端口范围
                        if item['release_port'].find('-') > -1 or item['release_port'].find(':') > -1:
                            port_begin, port_end = re.split(r'\-|\:', item['release_port'], 1)

                            if not port_begin.isdigit() or not port_end.isdigit():
                                return False

                            return int(port_begin) <= int(keyword) and int(keyword) <= int(port_end)

                        return str(item['release_port']).isdigit() and int(item['release_port']) == int(keyword)
                    return False

                # 协议
                if re.match(r'^tcp|udp$', keyword, flags=re.IGNORECASE):
                    return item['protocol'].lower() == keyword.lower()

                # 规则
                if re.match(r'^allow|drop$', keyword, flags=re.IGNORECASE):
                    return item['access'].upper() == keyword.upper()

                return item['source'].find(keyword) > -1

            return True

        # 列表筛选
        rules = list(filter(filter_handler, rules))

        d = {
            "is_running": res_data["is_running"],
            "rule_change": res_data["rule_change"],
            "total": total,
            "list": rules[page_start:page_size]
        }
        return public.return_data(True, d)

    def get_host_port_info(self, args):
        """获取主机端口信息

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        fields = ['id', 'ip', 'port', 'protocol', 'process_name', 'process_path', 'test_connection']
        where_str = '`sid` = ? AND `status` = 1'
        where_val = (sid,)

        query = basic_monitor_obj.db_easy('server_ports')\
            .field(*fields)\
            .where(where_str, where_val)\
            .order('create_time', 'DESC')

        # 添加关键字查询
        def query_handler(query, keyword):
            # 端口号搜索
            if keyword.isdigit():
                if int(keyword) > 0 and int(keyword) < 65536:
                    query.where('port=?', keyword)
                return

            # 进程路径搜索
            if str(keyword).find('/') > -1:
                query.where('process_path like ?', '%{}%'.format(keyword))
                return

            # 进程名称模糊搜索
            query.where('process_name like ?', '%{}%'.format(keyword))

        public.add_retrieve_keyword_query(query, args, query_handler)

        return public.success(public.simple_page(query, args))

    def get_port_connection_logs(self, args):
        """
        @deprecated 已废弃
        获取端口连接测试记录

        Args:
            args (_type_): _description_

        Returns:
            _type_: _description_
        """
        return public.error('接口下线')
        sid = args.sid
        query_date = "today"
        if "query_date" in args:
            query_date = args.query_date
        query_start, query_end = public.get_query_timestamp(query_date)
        data_fields = "id,sid,ip,port,test_method,ok,create_time"
        query = public.db_monitor('port_connection_logs').field(data_fields).where(
            "sid=? and create_time>=? and create_time<=?",
            (sid, query_start, query_end,)).order('`create_time` DESC')
        result = public.simple_page(query, args)
        return public.return_data(True, result)

    def get_logs_path_list(self, get):
        """获取日志路径列表"""
        sid = get.sid

        syslog_paths = basic_monitor_obj.cache_server_syslog_paths(sid)

        if not basic_monitor_obj.is_empty_result(syslog_paths):
            return public.success(syslog_paths)

        server_id = public.get_serverid_bysid(sid)
        if not server_id:
            return public.return_data(False, {}, error_msg="主机不存在。")

        res = public.send_agent_msg(
            server_id, 
            'loganalysis', 
            'FetchLogByServer', 
            "recv/loganalysis/FetchLogByServer/"+server_id,
            pdata=public.g_pdata({}),
            timeout=self.timeout)
        data = public.get_agent_msg(res)

        if not isinstance(data, dict) or not isinstance(data.get('body', {}), dict):
            return public.success([])

        return public.success(
            basic_monitor_obj.cache_server_syslog_paths(sid, data.get('body', {}).get('sys_log', []))
        )

    def get_log_content(self, get):
        sid = get.sid
        lines = 100
        if "n" in get:
            lines = int(get.n)
        params = {
            'path': get.path,
            'n': str(lines)
        }
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(
            server_id, 
            'loganalysis', 
            'FetchLogContentByServer', 
            "recv/loganalysis/FetchLogContentByServer/"+server_id, 
            timeout=self.timeout, 
            pdata=public.g_pdata(params))
        # public.print_log("get res:")
        # public.print_log(res)
        data = public.get_agent_msg(res)
        if not data:
            return public.return_data(False, {}, error_msg="数据为空")
        return public.return_data(True, data)

    def get_ssh_users_info(self, args):
        """获取当前SSH在线用户

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        
        ssh_users = basic_monitor_obj.cache_server_ssh_users(sid)
        
        if not basic_monitor_obj.is_empty_result(ssh_users):
            return public.success(ssh_users)

        server_id = public.get_serverid_bysid(sid)
        if not server_id:
            return public.return_data(False, {}, error_msg="主机不存在。")

        res = public.send_agent_msg(
            server_id, 
            'systeminfo',
            'FetchSSHWhoByServer', 
            'recv/systeminfo/FetchSSHWhoByServer/'+server_id,
            pdata=public.g_pdata({}),
            timeout=self.timeout)
        data = public.get_agent_msg(res)

        if not isinstance(data, dict):
            return public.success([])

        return public.success(
            basic_monitor_obj.cache_server_ssh_users(sid, data.get('body', []))
        )

    def get_installed_soft_info(self, args):
        """获取当前软件安装列表

        Args:
            args (_type_): _description_
        """
        sid = args.sid
        
        installed_softs = basic_monitor_obj.cache_server_installed_softs(sid)
        
        if basic_monitor_obj.is_empty_result(installed_softs):
            server_id = public.get_serverid_bysid(sid)
            if not server_id:
                return public.return_data(False, {}, error_msg="主机不存在。")

            res = public.send_agent_msg(
                server_id,
                'systeminfo',
                'FetchSoftInstalledByServer',
                'recv/systeminfo/FetchSoftInstalledByServer/'+server_id,
                pdata=public.g_pdata({}),
                timeout=self.timeout)
            data = public.get_agent_msg(res)

            if not isinstance(data, dict):
                return public.success([])

            installed_softs = basic_monitor_obj.cache_server_installed_softs(sid, data.get('body', []))

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 软件名称\版本号\架构\描述
                return '|'.join([item['softname'], item['version'], item['architecture'], item['description']]).find(keyword) > -1

            return True

        # 列表筛选
        installed_softs = list(filter(filter_handler, installed_softs))

        # 分页
        if 'p' in args:
            p = int(args.get('p', 1))
            p_size = int(args.get('p_size', 20))
            return public.success({
                'total': len(installed_softs),
                'list': installed_softs[(p - 1) * p_size:p * p_size],
            })

        return public.success(installed_softs)

    def get_command_history(self, args):
        """获取命令历史记录

        Args:
            get (_type_): _description_
        """
        sid = args.sid
        
        command_history = basic_monitor_obj.cache_server_command_history(sid)
        
        if basic_monitor_obj.is_empty_result(command_history):
            server_id = public.get_serverid_bysid(sid)
            if not server_id:
                return public.return_data(False, {}, error_msg="主机不存在。")

            res = public.send_agent_msg(
                server_id,
                'sshandsoft',
                'FetchUserHistoryByServer',
                'recv/sshandsoft/FetchUserHistoryByServer/'+server_id,
                pdata=public.g_pdata({}),
                timeout=self.timeout)

            data = public.get_agent_msg(res)

            if not isinstance(data, dict):
                return public.success([])

            command_history = basic_monitor_obj.cache_server_command_history(sid, data.get('body', []))

        def filter_handler(item):
            # 关键字搜索
            if 'keyword' in args:
                keyword = args.get('keyword', '')

                if keyword == '':
                    return True

                # 软件名称\版本号\架构\描述
                return '|'.join([item['user'], item['command']]).find(keyword) > -1

            return True

        # 列表筛选
        command_history = list(filter(filter_handler, command_history))

        return public.success(command_history)

    def get_raid_info(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        result = basic_monitor_obj.db_easy('server_raid_info')\
            .field("check_result")\
            .where('sid=?', (sid,)).find()
        res = {
            "display": True,
            "check_res": ""
        }
        if not result:
            res["display"] = False
        else:
            res["display"] = True
            res["check_res"] = result["check_result"]    
        return public.success(res)

    def get_agent_info(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(
            server_id, 
            "agentinfo", 
            "GetAgentInfo",
            "recv/agentinfo/GetAgentInfo/"+server_id,
            pdata={},
            timeout=60
            )
        data = public.get_agent_msg(res)
        if not data or 'body' not in data:
            return public.error("获取信息失败。")
        return public.success(data["body"])

    def repair_agent(self, args):
        sid = args.get("sid", None)
        if not sid:
            return public.error("参数错误")
        server_id = public.get_serverid_bysid(sid)
        res = public.send_agent_msg(
            server_id, 
            "agentinfo", 
            "RepairAgent",
            "recv/agentinfo/RepairAgent/"+server_id,
            pdata={},
            timeout=60
            )
        # public.print_log("客户端回复信息："+str(res))
        return public.success("OK")
