#coding: utf-8
#-------------------------------------------------------------------
# 云监控代理面板请求
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: linxiao
# Author: hwliang
#-------------------------------------------------------------------
# HTTP代理模块
#------------------------------
from hmac import trans_36
import requests, os, re
import time
import core.include.public as public
from core import request,app 
from flask import Response
from http.cookies import SimpleCookie
from core.include.sqlite_easy import Db
from core.include.sqlite_easy import SqliteEasy

class main:

    # 主机被控面板版本号
    __PANEL_VERSIONS = {}

    def __init__(self):
        self.__SID = None  # 主机SID

    # 获取响应头
    def get_res_headers(self,p_res,panel,sid):
        '''
            @name 获取响应头
            @author hwliang<2022-01-19>
            @param p_res<Response> requests响应对像
            @return dict
        '''
        headers = {}
        for h in p_res.headers.keys():
            if h in ['Content-Encoding','Transfer-Encoding']: continue
            headers[h] = p_res.headers[h]
        headers["Host"] = panel
        return headers

    # 设置响应头
    def set_res_headers(self,res,p_res,panel,sid):
        '''
            @name 设置响应头
            @author hwliang<2022-01-19>
            @param res<Response> flask响应对像
            @param p_res<Response> requests响应对像
            @return res<Response>
        '''
        from datetime import datetime
        cookie_dict = p_res.cookies.get_dict()
        expires = datetime.utcnow() + app.permanent_session_lifetime
        for k in cookie_dict.keys():
            # if k in ['from_server']: httponly = True
            if k in ["from_server"]: continue
            v = cookie_dict[k]
            httponly = True
            res.set_cookie(k, v,
                                expires=expires, httponly=httponly,
                                path="/")
        # res.set_cookie("from_server", str(sid), expires=expires, 
        #     httponly=True, path="/")
        return res

    # 获取请求头
    def get_request_headers(self, sid, host):
        '''
            @name 获取请求头
            @author hwliang<2022-01-19>
            @return dict
        '''
        headers = {}
        from core import cache
        server_cookies = cache.get("SESSION_SERVER_{}".format(sid))

        for k in request.headers.keys():
            headers[k] = request.headers.get(k)
            # if k == 'Cookie':
            #     cookie_dict = SimpleCookie(headers[k])
            #     if server_cookies:
            #         for sk, sv in server_cookies.items():
            #             if sk != "request_token_head":
            #                 cookie_dict[sk] = sv
            #     headers[k] = cookie_dict.output(header='',sep=';').strip()

        if server_cookies:
            request_token_head = None

            if "request_token_head" in server_cookies:
                request_token_head = server_cookies["request_token_head"]
                del server_cookies["request_token_head"]
            cookie_dict = SimpleCookie(server_cookies)

            headers["Cookie"] = cookie_dict.output(header='', sep=";").strip()
            if "request_token" in server_cookies.keys():
                headers["x-cookie-token"] = server_cookies["request_token"]
            if request_token_head:
                headers["x-http-token"] = request_token_head

        return headers

    # 获取请求数据（根据版本号取本地static文件）
    def get_local_path(self, version=None):
        if not version:
            coll_hack_panel_dir = "/www/server/bt-monitor/static/panel/"
        else:
            coll_hack_panel_dir = "/www/server/bt-monitor/static/panel/{}".format(version)
        return coll_hack_panel_dir

    # 获取本地文件版本号
    def get_local_file_by_version(self, filename, version):
        return self.get_local_file(filename, version=version)

    #  面板数据写入本地文件
    def write_local_file(self, filename, content, content_type, version=None):

        coll_hack_panel_dir = self.get_local_path(version)
        if not os.path.exists(coll_hack_panel_dir):
            os.makedirs(coll_hack_panel_dir)
        local_file = os.path.join(coll_hack_panel_dir, filename)
        dir_name = os.path.dirname(local_file)
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
        write_mode = "w+"
        if type(content) == bytes:
            write_mode = "wb+"
            # print("缓存写入文件: {}".format(local_file))
            # print("缓存写入文件类型: {}".format(content_type))
            bytes_file = local_file+".bytes"
            public.writeFile(bytes_file, "1")
            # content = content.decode("utf-8")
        public.WriteFile(local_file, content, mode=write_mode)
        # print("write res:", )
        content_type_file = local_file+".ct"
        public.WriteFile(content_type_file, content_type)

        # 记录文件的对应的面板版本
        if self.__SID is not None:
            public.WriteFile('{}.ver'.format(local_file), '.'.join(map(lambda x: str(x), self.__PANEL_VERSIONS[self.__SID])))

    # 获取本地文件
    def get_local_file(self, filename, version=None):
        coll_hack_panel_dir = self.get_local_path(version)
        if not os.path.exists(coll_hack_panel_dir):
            os.makedirs(coll_hack_panel_dir)
        local_file = os.path.join(coll_hack_panel_dir, filename)

        _c = ""
        content_type = ""
        content_type_file = local_file + ".ct"
        if os.path.isfile(content_type_file):
            content_type = public.readFile(content_type_file)
        
        if os.path.isfile(local_file) and os.path.getsize(local_file) > 0:
            bytes_files = local_file +".bytes"
            if os.path.exists(bytes_files):
                read_mode = "rb"
            else:
                read_mode = "r"
            _c = public.readFile(local_file, mode=read_mode)

        # # 对比文件版本
        # # 当文件版本较低时，获取最新的文件
        # if not os.path.exists(local_file+'.ver') or tuple(map(lambda x: int(x), str(public.readFile(local_file+'.ver')).strip().split('.'))) < self.__PANEL_VERSIONS[self.__SID]:
        #     _c = ""
        #     content_type = ""

        return {
            "content": _c,
            "content_type": content_type
        }

    #  代理指定URL地址
    def proxy(self, args):
        '''
            @name 代理指定URL地址
            @author linxiao<2022-09-02>
            @param proxy_url<string> 被代理的URL地址
            @return Response

        面板防止跨站请求校验逻辑:
        1. 对比cookies和session中的request_token，以及headers中的x-cookie-token
        三者是否一致。每次通过api token登录成功之后,request_token都会生成一个新的
        值放置在响应cookies(res.request.cookies)中。
        2. 对比session中的request_token_head和headers中的x-http-token是否一致。
        request_token_head在用户登录时生成，并保存在session当中。后端在渲染前端文件
        时，嵌入到前端html(layout.html)内容中，从该前端页面发起的请求必须设置
        request_token_head在请求头x-http-token当中。

        缓存策略：
        1. 倾向于缓存所有的静态资源请求，缓存文件存储在/www/server/bt-monitor/
        static/panel目录下。缓存文件分按版本区分和不按版本区分两种，不按版本区分的是
        那些通用的静态文件，随云监控版本发布更新。按版本区分的静态文件会再创建一级版
        本子目录，比如panel/7.9.3。 
        2. 那些响应里面有带request_token_head的文件不能缓存。
        '''
        public.restore_allowed_gai_family()

        try:
            from core import cache

            sid = args.sid
            self.__SID = int(sid)
            path_full = args.path_full
            coll_server_id = sid
            
            server_info_cache_key = "SERVER_INFO_"+str(coll_server_id)
            _info = cache.get(server_info_cache_key)

            server_info = None
            if not _info:

            # if True:
                import core.loader as loader
                from flask import g
                g.module = "server"
                g.action = "get_panel_info"
                args = public.dict_obj()
                args.sid = sid
                module_obj = loader.loader("server", "get_panel_info")
                res = module_obj.run(args)

            # from modules.serverModule.main import main as serverModule
            # sm = serverModule()
            # res = sm.get_panel_info(args)

                if res and res["status"]:
                    server_info = res['data']
                    cache.set(server_info_cache_key, server_info, 3600)

            else:
                server_info = _info
            if not server_info:
                return public.error("面板信息不存在。")

            coll_server_panel  = server_info["panel_address"]
            if coll_server_panel[-1] != "/":
                coll_server_panel += "/"
            panel_version = server_info["panel_version"]

            full_path = request.full_path
            if full_path[-1] == "?":
                full_path = full_path[0:-1]
            proxy_path = re.sub("/cmproxy/\d+/", "", full_path)
            if proxy_path and proxy_path[0] == "/":
                proxy_path = proxy_path[1:]
            from_btwaf = False
            if proxy_path.startswith("btwaf"):
                from_btwaf = True
                if proxy_path.find("btwaf/btwaf") != -1:
                    proxy_path = proxy_path.replace("btwaf/", '')
            proxy_url = "{}{}".format(coll_server_panel, proxy_path)

            # 处理phpmyadmin跳转
            if proxy_path.startswith("phpmyadmin"):
                from flask import redirect
                return redirect(proxy_url)
            headers = {}
            requests.packages.urllib3.disable_warnings()
            cache_key = public.md5(proxy_path)

            sub_path = proxy_path
            if sub_path.find("?") > 0:
                sub_path = sub_path[0:sub_path.find("?")]

            from_cache = False
            response_content = ""
            content_type = None
            res_headers = {}
            p_res = None

            token = server_info["token"]
            s = requests.Session()
            if path_full and path_full == "login":
                pdata = {}
                pdata = public.get_panel_key_data(pdata, token)
                p_res = s.post(coll_server_panel + 'config?action=get_tmp_token', pdata, timeout=15, verify=False)
                post_res = p_res.json()

                if "status" not in post_res or not post_res["status"]:
                    return public.error("无法打开被控面板, 请检查配置信息和授权IP地址是否正确。")
                tmp_token = post_res["msg"]
                request_url = proxy_url+"&tmp_token={}".format(tmp_token)

                if proxy_url.find("?") > 0:
                    p_res = s.get(request_url, verify=False)
                else:
                    p_res = s.get(proxy_url+"?tmp_token={}".format(tmp_token), verify=False)

                # 获取被控面板版本号并保存
                m = re.search(r'id="btversion"[\s\S]+?(\d+\.\d+\.\d+)<', str(p_res.content))
                if m:
                    self.__PANEL_VERSIONS[int(sid)] = tuple(map(lambda x: int(x), str(m.group(1)).strip().split('.')))
                panel_version = '.'.join(str(temp) for temp in self.__PANEL_VERSIONS[int(sid)]) if int(sid) in self.__PANEL_VERSIONS else None

                server_info["panel_version"] = panel_version

                cache.set(server_info_cache_key, server_info, 3600)

                server_cookies = {}
                if "Cookie" in p_res.request.headers:
                    header_cookies = p_res.request.headers["Cookie"]
                    cks = header_cookies.split("; ")
                    server_cookies = {}
                    for c in cks:
                        k, v = c.split("=")
                        server_cookies[k] = v
                    cache.set("SESSION_SERVER_{}".format(sid), server_cookies, 30 * 86400)

            elif request.method == 'GET':
                # 优先从缓存读取
                # public.print_log("{} panel_version: {}".format(coll_server_panel, panel_version))

                if sub_path.find('ftp') > -1:
                    public.print_log('>>>>> {} {} {}'.format(sub_path, proxy_path, str(sub_path).split('/')[0]), _level='error')

                from_cache = True
                file_info = self.get_local_file(sub_path)

                if not file_info["content"]:
                    file_info = self.get_local_file_by_version(sub_path, version=panel_version)

                if not file_info["content"]:
                    # 转发GET请求
                    headers = self.get_request_headers(sid, coll_server_panel)
                    from_cache = False
                    try:
                        from urllib.parse import urlparse
                    except:
                        from urlparse import urlparse
                    host_parse = urlparse(coll_server_panel)
                    host = host_parse.netloc
                    headers["Host"] = host

                    # 转发请求
                    # 情况1 请求外部文件
                    if re.search(r'\.(?:com|cn|org|net|top)$', str(sub_path).split('/')[0]):

                        p_res = s.get('http://'+sub_path, verify=False, allow_redirects=True, timeout=120)


                    # 情况2 请求面板静态文件
                    else:
                        p_res = s.get(proxy_url,headers=headers,verify=False,allow_redirects=True)

                else:
                    response_content = file_info["content"]
                    content_type = file_info["content_type"]

            elif request.method == 'POST':
                headers = self.get_request_headers(sid, coll_server_panel)
                try:
                    from urllib.parse import urlparse
                except:
                    from urlparse import urlparse
                host_parse = urlparse(coll_server_panel)

                host = host_parse.netloc
                headers["Host"] = host


                # 转发POST请求
                if request.files: # 如果上传文件
                    tmp_path = '/www/server/bt-monitor/tmp'
                    if not os.path.exists(tmp_path): os.makedirs(tmp_path,384)
    
                    # 处理请求头
                    if 'Content-Type' in headers: del(headers['Content-Type'])
                    if 'Content-Length' in headers: del(headers['Content-Length'])
    
                    # 遍历form表单中的所有文件
                    files = {}
                    f_list = {}
                    for key in request.files:
                        upload_files = request.files.getlist(key)
                        filename = upload_files[0].filename
                        if not filename: filename = public.GetRandomString(12)
                        tmp_file = '{}/{}'.format(tmp_path,filename)
                        
                        # 保存上传文件到临时目录
                        with open(tmp_file,'wb') as f:
                            for tmp_f in upload_files:
                                f.write(tmp_f.read())
                            f.close()
    
                        # 构造文件上传对象
                        f_list[key] = open(tmp_file,'rb')
                        files[key] = (filename, f_list[key])
    
                        # 删除临时文件
                        if os.path.exists(tmp_file): os.remove(tmp_file)
    
                    # 转发上传请求
                    p_res = requests.post(proxy_url,request.form,headers=headers,files=files,verify=False,allow_redirects=False)
    
                    # 释放文件对象
                    for fkey in f_list.keys():
                        f_list[fkey].close()
                else:
                    p_res = s.post(proxy_url,request.form,headers=headers,verify=False,allow_redirects=False)
            else:
                return Response('不支持的请求类型',500)

            status_code = 200
            if from_cache:
                res_headers = {
                    "Host": coll_server_panel
                }
            else:
                res_headers = self.get_res_headers(p_res, coll_server_panel, sid)
                content_type = p_res.headers.get('content-type', "")

                status_code = p_res.status_code
                skip_search = False
                dont_cache = False
            
                if content_type.find("html") >= 0:
                    # 替换html响应文档中的链接为相对路径
                    response_content = p_res.text
                    if from_btwaf:
                        # print("proxy path:", proxy_url)
                        response_content = re.sub("href\s*=\s*\"(/[^\"]*)\"", r'href="/cmproxy/{}\1"'.format(sid), response_content)
                        response_content = re.sub("src\s*=\s*\"(/[^\"]*)\"", r'src="/cmproxy/{}\1"'.format(sid), response_content)
                        response_content = re.sub("src\s*=\s*'(/[^']*)'", r"src='/cmproxy/{}\1'".format(sid), response_content)
                        dont_cache = True
                    else:
                        response_content = re.sub("href\s*=\s*'(/[^']*)'", r"href='.\1'", response_content)
                        response_content = re.sub("href\s*=\s*\"(/[^\"]*)\"", r'href=".\1"', response_content)
                        response_content = re.sub("src\s*=\s*\"(/[^\"]*)\"", r'src=".\1"', response_content)
                        response_content = re.sub("src\s*=\s*'(/[^']*)'", r"src='.\1'", response_content)
                elif content_type.find("css") >= 0:
                    # 替换css文件中的引入资源链接为绝对路径
                    response_content = p_res.text
                    if True:
                        base_path = path_full
                        base_path = re.sub("cmproxy/\d+/", "", base_path)

                        if re.findall("url\(\.\./([^)]+)\)", response_content):

                            dir_name = os.path.dirname(base_path)
                            dir_name = os.path.dirname(dir_name)
                            if dir_name[0] != "/":
                                dir_name = "/"+dir_name
                            response_content = re.sub("url\(\.\./([^)]+)\)", r"url("+dir_name+"/\\1)", response_content)
                elif content_type.find("javascript") >= 0:
                    response_content = p_res.text
                else:
                    response_content = p_res.content
                    skip_search = True

                if sub_path in ["static/js/term.js"]:
                    response_content = re.sub("/webssh", "/cmproxy/{}/webssh".format(sid), p_res.text)
                    dont_cache = True
                if sub_path in ["static/js/public.js"]:
                    response_content = re.sub("/files", "./files", p_res.text)
                if sub_path == "static/js/files.js":
                    response_content = re.sub("download_url\s*=\s*(location\.origin\s*\+\s*'/down/')", "download_url = '{}down/'".format(coll_server_panel), p_res.text)
                    dont_cache = True
                
                if not skip_search:
                    token_head_searchor = re.search("<a[^>]+id=.request_token_head.[^>]+token=['\"]([^'\"]+)['\"]", p_res.text)
                    if token_head_searchor:
                        re.search("<a[^>]+id=.request_token_head.[^>]+token=['\"]([^'\"]+)['\"]", p_res.text)
                        request_token_head = token_head_searchor.group(1)

                        cache_cookies = cache.get("SESSION_SERVER_{}".format(sid))
                        if not cache_cookies:cache_cookies={}
                        cache_cookies.update({"request_token_head": request_token_head})
                        cache.set("SESSION_SERVER_{}".format(sid), cache_cookies, 30 * 86400)
                        dont_cache = True

                if not dont_cache and p_res.status_code==200 and sub_path.startswith("static/"):
                    self.write_local_file(
                        sub_path, 
                        response_content, 
                        content_type=content_type, 
                        version=panel_version
                    )

            #  替换加载的js文件
            if sub_path in "static/amd/main.js":
                public.print_log("static++++++++++++++start")
                response_content = re.sub(r"switch\s*\(location\.pathname\)\s*\{", "switch (location.pathname.replace('/cmproxy/"+str(sid)+"', '')) {", str(response_content))

            # 替换tools.js 面板路由   兼容面板版本 8.x.x
            if sub_path in "static/vite/js/tools.js":
                response_content = re.sub(r'path:"([^"]+)",\s*meta:',
                                          r'path: "cmproxy/{}/\1",meta:'.format(sid), str(response_content))

            res = Response(response_content,headers=res_headers,content_type=content_type,status=status_code)
            if p_res:
                res = self.set_res_headers(res, p_res, coll_server_panel, sid)
            return res
        except BaseException as ex:
            public.restore_allowed_gai_family()
            public.print_exc_stack(ex)
            from core import error_500
            return error_500(e=ex, title='访问被控面板失败，请检查配置信息是否正确！')