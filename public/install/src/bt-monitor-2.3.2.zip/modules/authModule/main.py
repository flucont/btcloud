import copy
import json, time, re, os, sys, binascii, urllib
import core.include.public as public
import core.include.aes as aes
from core.include.monitor_exceptions import BtMonitorException
from core.include.monitor_helpers import monitor_events
import core.include.Locker as Locker

"""
@name 授权主模块 
@author cjxin@bt.cn

"""


class main:
    __TRANSACTION_URL = 'http://www.example.com/api/v2/common_v1_authorization'
    __AUTH_URL = 'http://www.example.com/authorization'
    __AUTH_FILE = '{}/data/auth_info.json'.format(public.get_panel_path())
    __USER_PATH = '{}/data/user.json'.format(public.get_panel_path())
    __PLUGIN_NAME = 'cloud_monitor'
    __AUTH_RETRIES = 0
    __AUTH_NEXT_RETRY_TIME = 0

    __NPS_URL = 'http://www.example.com/api/v2/contact/nps'
    __NPS_PRODUCT_TYPE = 4

    def __init__(self):
        """
        @name 授权模块初始化
        """
        self.__PDATA = {}
        self.__USER_INFO = self._get_user_info()

        rdata = {}

        if self.__USER_INFO:
            rdata['secret_key'] = self.__USER_INFO['secret_key']
            self.__PDATA['access_key'] = self.__USER_INFO['access_key']
        else:
            rdata['secret_key'] = ''
            self.__PDATA['access_key'] = ''
        self.__PDATA['data'] = rdata

    # ******************************************************* 授权模块对外接口start *********************************************************

    def get_token(self, get):
        """
        @name 获取官网登录token
        @author cjxin
        @get dict 请求参数
            username:用户名
            password:密码
            code:验证码
        """
        data = {}
        data['username'] = get.get('username/s')
        data['password'] = public.md5(get.get('password/s', ''))
        data['serverid'] = self._get_serverid()

        if 'code' in get:
            data['code'] = get.get('code/xss')
        if 'token' in get:
            data['token'] = get.get('token/xss')

        pdata = {}
        pdata['data'] = self._decode(data)

        try:
            rdata = public.httpPost(self.__AUTH_URL + '/login', pdata)
            rdata = json.loads(rdata)
            rdata['data'] = self._encode(rdata['data'])
            if not rdata['status']:
                return public.error(rdata['msg'])

            if rdata['data']:
                # print(rdata['data'])
                if rdata['data']['server_id'] != data['serverid']:
                    public.writeFile('data/sid.pl', rdata['data']['server_id'])
                public.writeFile(self.__USER_PATH, json.dumps(rdata['data']))

                self._flush_auth_cache(True)
        except:
            self._write_error_log(rdata + "\n" + public.get_error_info())
            return public.error('连接服务器失败')

        # 触发堡塔账号绑定成功事件
        public.event(monitor_events.AccountBoundSuccess())

        return public.success('绑定成功')

    # 删除绑定token
    def del_token(self, get):
        """
        @name 删除绑定token
        @author cjxin
        @get dict 请求参数
        """
        if os.path.exists(self.__USER_PATH):
            os.remove(self.__USER_PATH)
        return public.success('解绑帐号成功.')

    # 获取验证码
    def get_bind_code(self, get):
        """
        @name 获取验证码
        @author cjxin
        @get dict 请求参数
            username:用户名
            token:本次验证码的token
        """
        if not hasattr(get, 'username') or not hasattr(get, 'token'):
            return public.error('参数错误.')

        data = {}
        pdata = {}
        data['username'] = get.get('username/s')
        data['token'] = get.get('token/xss')
        pdata['data'] = self._decode(data)
        try:
            rdata = public.httpPost(self.__AUTH_URL + '/get_bind_code', pdata)
            result = json.loads(rdata);
            return result
        except Exception as ex:
            self._write_error_log(rdata + "\n" + public.get_error_info())
            return public.error('连接服务器失败!')

    # 获取用户信息
    def get_userinfo(self, get):
        """
        @name 获取用户信息
        @author cjxin
        @get dict 请求参数
        """
        data = self.__USER_INFO
        if not data:
            data = self._get_user_info()

        result = {'status': False, 'msg': '请先绑定宝塔帐号'}
        if not data:
            result['data'] = ''
        else:
            result['status'] = True
            result['msg'] = '获取成功'

            result['data'] = {}
            keys = ['username', 'address', 'serverid', 'addtime']
            for key in keys:
                try:
                    if key in data: result['data'][key] = data[key]
                except:
                    pass
            result['data']['username'] = data['username'][0:3] + '****' + data['username'][-4:]
        return result

    # 获取未绑定授权
    def get_unbound_list(self, get):
        """
        @name 获取未绑定授权
        @author cjxin
        @get dict 请求参数
        """
        self.__PDATA['data']['product'] = self.__PLUGIN_NAME
        self.__PDATA['data'] = self._decode(self.__PDATA['data'])

        # print(self.__PDATA)
        result = public.httpPost(self.__AUTH_URL + '/unbound_list', self.__PDATA)
        try:
            result = json.loads(result)
        except:
            return public.return_data(False, result)

        if not result['status']:
            return public.error(result['msg'], result.get('err_no', 0))

        data = self._encode(result['data'])
        return public.success(data)

    # 绑定授权
    def bind(self, get):
        """
        @name 绑定授权
        @author cjxin
        @get dict 请求参数
        """
        authorization_id = get.get('id', None)

        if authorization_id is None:
            return public.error('缺少参数：id')

        pdata = {}
        pdata.update(self.__PDATA)

        if 'data' not in pdata:
            pdata['data'] = {}

        pdata['data'].update({
            'id': authorization_id,
            'serverid': self._get_serverid(),
        })
        pdata['data']['product'] = self.__PLUGIN_NAME
        pdata['data'] = self._decode(self.__PDATA['data'])

        result = public.httpPost(self.__AUTH_URL + '/bind', pdata)

        try:
            result = json.loads(result)
        except:
            return public.return_data(False, result)

        if not result['status']:
            return public.error(result['msg'])

        # 检查数据格式
        self._encode(result['data'])

        # 保存授权信息
        with Locker.acquire(timeout=15):
            public.writeFile(self.__AUTH_FILE, '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

        return public.success('扩容成功')

    # 刷新授权
    def flush_auth_list(self, get):
        '''
        @name 刷新授权
        @author cjxin
        '''
        force = get.get('force/d', 0)
        ret = self._flush_auth_cache(force)
        return ret

    # 检查是否购买权限
    def check_auth_status(self, get):
        """
        @name 检查是否购买权限
        @author cjxin
        @get dict 请求参数
        """
        ret = self.flush_auth_list(get)
        return ret

    # 获取价格列表
    def get_pricing(self, args):
        '''
            @name 获取价格列表
            @author Zhj<2022-10-27>
            @arg cycle<?integer> 授权周期数/年[可选]
            @return dict
        '''
        result = public.httpPost(self.__TRANSACTION_URL + '/get_pricing', {
            'product': 'cloud_monitor',
            # 'cycle': args.get('cycle', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        # 价格修改
        data = []
        for item in result['res']:
            new_item = {
                "product": item["product"],
                "charge_type": item["charge_type"],
                "cycle_unit": item["cycle_unit"],
                "cycle": item["cycle"],
                "market_price": item["market_price"],
                "price": item["price"],
                "weight": item["weight"],
                "discount_rate": item["_children"][0]["discount_rate_of_cycle"],
                "_children": item["_children"],
            }

            # 修改价格为折扣价 价格*折扣率
            year = '{}year'.format(item['cycle'])
            discount_rate = item["_children"][0]["discount_rate_of_cycle"][year]
            new_item['price'] = round(item["market_price"] * discount_rate, 2)
            data.append(new_item)

        return public.success(data)

    # 购买
    def create_order(self, args):
        '''
            @name 下单购买授权
            @author Zhj<2022-10-27>
            @arg cycle<?integer>    授权周期数/年[可选]
            @arg clients<?integer>  客户端数量[可选]
            @return dict
        '''
        # 用户未登录
        if self.__USER_INFO is None:
            return public.error('请先绑定堡塔账号')

        result = public.httpPost(self.__TRANSACTION_URL + '/create_by_user', {
            'uid': self.__USER_INFO.get('uid', 0),
            'server_id': self.__USER_INFO.get('server_id', ''),
            'src': 2,
            'product': 'cloud_monitor',
            'cycle': args.get('cycle', 1),
            'cycle_unit': args.get('cycle_unit', 'year'),
            'clients': args.get('clients', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    # 续费
    def renew_order(self, args):
        '''
            @name 续费--某订单延长时间
            @author Zhj<2022-10-27>
            @arg cycle<?integer>    授权周期数/年[可选]
            @arg clients<?integer>  客户端数量[可选]
            @return dict
        '''
        # 用户未登录
        if self.__USER_INFO is None:
            return public.error('请先绑定堡塔账号')

        result = public.httpPost(self.__TRANSACTION_URL + '/renew_by_user', {
            'id': args.get('id', ''),
            'uid': self.__USER_INFO.get('uid', 0),
            'server_id': self.__USER_INFO.get('server_id', ''),
            'src': 2,
            'product': 'cloud_monitor',
            'cycle': args.get('cycle', 1),
            'cycle_unit': args.get('cycle_unit', 'year'),
            'clients': args.get('clients', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    # 扩容
    def upgrade_order(self, args):
        # 用户未登录
        if self.__USER_INFO is None:
            return public.error('请先绑定堡塔账号')

        result = public.httpPost(self.__TRANSACTION_URL + '/upgrade_by_user', {
            'uid': self.__USER_INFO.get('uid', 0),
            'server_id': self.__USER_INFO.get('server_id', ''),
            'src': 2,
            'product': 'cloud_monitor',
            'cycle': args.get('cycle', 1),
            'cycle_unit': args.get('cycle_unit', 'year'),
            'clients': args.get('clients', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    # 检查支付状态
    def check_order_status(self, args):
        '''
            @name 检查支付状态
            @author Zhj<2022-10-27>
            @arg out_trade_no<string> 订单号
            @return dict
        '''
        result = public.httpPost('http://www.example.com/api/v2/order/product/detect', {
            'out_trade_no': args.get('out_trade_no', ''),
        })

        # print(result)

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        return public.success(result['res'])

    # 获取用户当前授权信息
    # def get_auth_list(self, force=0):
    #     # 每隔1天强制从云端同步授权信息
    #     if public.cache_get('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC') is None:
    #         force = 1
    #
    #     # 获取当前时间
    #     cur_time = int(time.time())
    #
    #     # 默认授权信息
    #     auth_info = [{
    #         'id': 0,
    #         'product': 'cloud_monitor',
    #         'status': 2,
    #         'clients': 5,
    #         'durations': 0,
    #         'end_time': int(time.time()) - 1,
    #         'type': 0,
    #         'cur_auth_num': 0,  # 当前购买的已授权数量
    #     }]
    #
    #     # 获取当前授权数量
    #     cache_key = 'BT_MONITOR_CACHE__CUR_AUTH_NUM'
    #
    #     cur_auth_num = public.cache_get(cache_key)
    #     if cur_auth_num is None:
    #         # 获取当前已授权的客户端数量
    #         with public.sqlite_easy('monitor_mgr') as db:
    #             cur_auth_num = db.query() \
    #                 .name('servers') \
    #                 .where('is_authorized=1') \
    #                 .where_in('status', [0, 1]) \
    #                 .count()
    #             # 缓存当前已授权的客户端数量2分钟
    #             public.cache_set(cache_key, cur_auth_num, 120)
    #
    #     auth_info[0]['cur_auth_num'] = cur_auth_num
    #
    #     # 用户未登录
    #     if self.__USER_INFO is None:
    #         return public.success(auth_info)
    #
    #     # 检查是否需要重试
    #     if self.__AUTH_NEXT_RETRY_TIME > 0 and self.__AUTH_NEXT_RETRY_TIME <= cur_time:
    #         force = 1
    #     auth_list = []  # 授权列表
    #     try:
    #         if force or not os.path.exists(self.__AUTH_FILE):
    #             # # 尝试获取授权ID
    #             # if os.path.exists(self.__AUTH_FILE):
    #             #     data = public.readFile(self.__AUTH_FILE)
    #             #
    #             #     if data:
    #             #         # 获取授权密文与签名
    #             #         parts = data.split('.', 1)
    #             #
    #             #         # 验证签名
    #             #         if len(parts) > 1 and parts[1] == self._sign_auth_info(parts[0]):
    #             #             data = self._encode(parts[0])
    #             #             # data改列表
    #             #             # 授权id变多个 不传
    #             #             if isinstance(data, list) and 'id' in data:
    #             #                 self.__PDATA['data']['id'] = data[0]['id']
    #
    #             self.__PDATA['data']['product'] = self.__PLUGIN_NAME
    #             self.__PDATA['data']['serverid'] = self._get_serverid()
    #             self.__PDATA['data'] = self._decode(self.__PDATA['data'])
    #             # 这里需要考虑多次重试，尽可能减少网络问题对授权的影响
    #             # 最多重试5次：5分钟、10分钟、30分钟、1小时
    #             result = public.httpPost(self.__AUTH_URL + '/info_v2', self.__PDATA)
    #             ok = True
    #             try:
    #                 result = json.loads(result)
    #             except:
    #                 ok = False
    #
    #             if not ok or not result['status']:
    #                 ok = False
    #
    #                 # 累计重试失败次数
    #                 self.__AUTH_RETRIES += 1
    #
    #                 if self.__AUTH_RETRIES > 4:
    #                     self.__AUTH_RETRIES = 0
    #                     self.__AUTH_NEXT_RETRY_TIME = 0
    #                     raise BtMonitorException('flush auth info failed: {}'.format(result))
    #
    #                 # 记录本次下一次重试时间，本次授权信息从本地读取
    #                 m = {
    #                     1: 5,
    #                     2: 10,
    #                     3: 30,
    #                     4: 60,
    #                 }
    #
    #                 self.__AUTH_NEXT_RETRY_TIME = cur_time + m.get(self.__AUTH_RETRIES, 5)
    #
    #             if ok:
    #                 # 缓存授权信息
    #                 public.writeFile(self.__AUTH_FILE, '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))
    #
    #             # 标记本次授权信息同步成功
    #             public.cache_set('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC', int(time.time()), 86400)
    #
    #         # 尝试读取授权信息
    #         data = public.readFile(self.__AUTH_FILE)
    #
    #         # 没有获取到授权信息时，初始化授权信息
    #         if not data:
    #             data = copy.deepcopy(auth_info)
    #             # data  list转dict
    #             data = {'{}'.format(i): value for i, value in enumerate(data)}
    #
    #             encoded_str = self._decode(data)
    #             # 初始化授权信息 加密存储
    #             public.writeFile(self.__AUTH_FILE, '{}.{}'.format(encoded_str, self._sign_auth_info(encoded_str)))
    #
    #         # 获取授权密文与签名
    #         parts = data.split('.', 1)
    #
    #         # 验证签名
    #         if len(parts) < 2 or parts[1] != self._sign_auth_info(parts[0]):
    #             raise BtMonitorException('flush auth info failed: 授权信息可能被篡改')
    #
    #         data = self._encode(parts[0])  # 解密
    #         # public.print_log('*********7---{} 类型{}'.format(data, type(data)))
    #         if isinstance(data, dict):
    #             data = [value for _, value in data.items()]
    #
    #         d = {
    #             'cloud_monitor': 1,         # 1-专业版
    #             'cloud_monitor_ltd': 2,     # 2-企业版
    #         }
    #         for i in data:
    #             auth_info = {}
    #             auth_info['id'] = i['id']
    #             auth_info['product'] = i['product']
    #             auth_info['status'] = i['status']
    #             auth_info['clients'] = i['clients']
    #             auth_info['durations'] = i['durations']
    #             auth_info['end_time'] = i['end_time']
    #             auth_info['type'] = d.get(auth_info['product'], 0)
    #             auth_list.append(auth_info)
    #
    #     except BaseException as e:
    #         public.print_log(str(e))
    #         public.print_exc_stack(e)
    #     # finally:
    #     #     for auth in auth_list:
    #     #         # 当超出最大授权数量时，重置超出的主机授权状态
    #     #         self._slice_exceed_auth_num(int(auth.get('cur_auth_num', 0)), int(auth.get('clients', 0)))
    #     return public.success(auth_list)

    # 获取用户授权对应价格信息
    def get_renew_info(self, args):
        """获取用户授权对应价格信息"""
        force = 0
        cur_time = int(time.time())
        # num = int(args.get('num', 1))
        # 检查是否需要重试
        if self.__AUTH_NEXT_RETRY_TIME > 0 and self.__AUTH_NEXT_RETRY_TIME <= cur_time:
            force = 1
        auth_list = []  # 授权列表
        try:
            if force or not os.path.exists(self.__AUTH_FILE):
                self.__PDATA['data']['product'] = self.__PLUGIN_NAME
                self.__PDATA['data']['serverid'] = self._get_serverid()
                self.__PDATA['data'] = self._decode(self.__PDATA['data'])
                # TODO 这里需要考虑多次重试，尽可能减少网络问题对授权的影响
                # 最多重试5次：5分钟、10分钟、30分钟、1小时
                result = public.httpPost(self.__AUTH_URL + '/info_v2', self.__PDATA)
                ok = True
                try:
                    result = json.loads(result)
                except:
                    ok = False

                if not ok or not result['status']:
                    ok = False

                    # 累计重试失败次数
                    self.__AUTH_RETRIES += 1

                    if self.__AUTH_RETRIES > 4:
                        self.__AUTH_RETRIES = 0
                        self.__AUTH_NEXT_RETRY_TIME = 0
                        raise BtMonitorException('flush auth info failed: {}'.format(result))

                    # 记录本次下一次重试时间，本次授权信息从本地读取
                    m = {
                        1: 5,
                        2: 10,
                        3: 30,
                        4: 60,
                    }

                    self.__AUTH_NEXT_RETRY_TIME = cur_time + m.get(self.__AUTH_RETRIES, 5)

                if ok:
                    # 缓存授权信息
                    public.writeFile(self.__AUTH_FILE,
                                     '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

                # 标记本次授权信息同步成功
                public.cache_set('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC', int(time.time()), 86400)

            # 尝试读取授权信息
            data = public.readFile(self.__AUTH_FILE)

            # 没有获取到授权信息时，初始化授权信息
            if not data:
                return public.error('获取授权信息失败，请稍后重试')
                # data = copy.deepcopy(auth_info)
                # # data  list转dict
                # data = {'{}'.format(i): value for i, value in enumerate(data)}
                #
                # encoded_str = self._decode(data)
                # # 初始化授权信息 加密存储
                # public.writeFile(self.__AUTH_FILE, '{}.{}'.format(encoded_str, self._sign_auth_info(encoded_str)))

            # 获取授权密文与签名
            parts = data.split('.', 1)

            # 验证签名
            if len(parts) < 2 or parts[1] != self._sign_auth_info(parts[0]):
                raise BtMonitorException('flush auth info failed: 授权信息可能被篡改')

            data = self._encode(parts[0])  # 解密
            # public.print_log('*********7---{} 类型{}'.format(data, type(data)))
            if isinstance(data, dict):
                data = [value for _, value in data.items()]

            d = {
                'cloud_monitor': 1,  # 1-专业版
                'cloud_monitor_ltd': 2,  # 2-企业版
            }
            for i in data:
                auth_info = {}
                auth_info['id'] = i['id']
                auth_info['product'] = i['product']
                auth_info['status'] = i['status']
                auth_info['clients'] = i['clients']
                auth_info['durations'] = i['durations']
                auth_info['end_time'] = i['end_time']
                auth_info['type'] = d.get(auth_info['product'], 0)
                auth_list.append(auth_info)

        except BaseException as e:
            public.print_log(str(e))
            public.print_exc_stack(e)

        auth_list = sorted(auth_list, key=lambda x: x['end_time'])
        num = auth_list[0]['clients']

        result = public.httpPost(self.__TRANSACTION_URL + '/get_pricing', {
            'product': 'cloud_monitor',
            # 'cycle': args.get('cycle', 1),
        })

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])
        data = []

        for item in result['res']:
            new_item = {
                "product": item["product"],
                "charge_type": item["charge_type"],
                "cycle_unit": item["cycle_unit"],
                "cycle": item["cycle"],
                "market_price": item["market_price"],
                "price": item["price"],
                "weight": item["weight"],
                "discount_rate": item["_children"][0]["discount_rate_of_cycle"],
                "_children": []
            }

            # 修改价格为折扣价 价格*折扣率
            year = '{}year'.format(item['cycle'])
            discount_rate = item["_children"][0]["discount_rate_of_cycle"][year]
            new_item['price'] = round(item["market_price"] * discount_rate, 2)

            children = item["_children"]
            new_children = []

            for child in children:
                if child["clients"] == num:
                    new_child = {
                        "clients": child["clients"],
                        "discount_rate": child["discount_rate"],
                        "discount_rate_of_cycle": child["discount_rate_of_cycle"],
                        "market_price": child["market_price"],
                        "price": child["price"],
                        "weight": child["weight"]
                    }
                    new_children.append(new_child)

            new_item["_children"] = new_children
            data.append(new_item)

        return public.success(data)

    # ******************************************************* 授权模块对外end *********************************************************

    def _write_error_log(self, msg):
        '''
        @name 写错误日志
        @author cjxin
        @msg string 错误信息
        '''
        public.writeFile('{}/logs/auth.error'.format(public.get_panel_path()), msg)

    def _flush_auth_cache_v2(self, force=0):
        '''
        @name 刷新授权缓存
        @author cjxin
        '''
        # 每隔1天强制从云端同步授权信息
        if public.cache_get('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC') is None:
            force = 1

        # 获取当前时间
        cur_time = int(time.time())

        # 默认授权信息
        auth_info = {
            'id': 0,
            'product': 'cloud_monitor',
            'status': 2,
            'clients': 5,
            'durations': 0,
            'end_time': int(time.time()) - 1,
            'type': 0,
            'cur_auth_num': 0,
        }

        # 获取当前授权数量
        cache_key = 'BT_MONITOR_CACHE__CUR_AUTH_NUM'

        cur_auth_num = public.cache_get(cache_key)

        if cur_auth_num is None:
            # 获取当前已授权的客户端数量
            with public.sqlite_easy('monitor_mgr') as db:
                cur_auth_num = db.query() \
                    .name('servers') \
                    .where('is_authorized=1') \
                    .where_in('status', [0, 1]) \
                    .count()

                # 缓存当前已授权的客户端数量2分钟
                public.cache_set(cache_key, cur_auth_num, 120)

        auth_info['cur_auth_num'] = cur_auth_num

        # 用户未登录
        if self.__USER_INFO is None:
            return public.success(auth_info)

        # 检查是否需要重试
        if self.__AUTH_NEXT_RETRY_TIME > 0 and self.__AUTH_NEXT_RETRY_TIME <= cur_time:
            force = 1

        try:
            if force or not os.path.exists(self.__AUTH_FILE):
                # 尝试获取授权ID
                if os.path.exists(self.__AUTH_FILE):
                    data = public.readFile(self.__AUTH_FILE)

                    if data:
                        # 获取授权密文与签名
                        parts = data.split('.', 1)

                        # 验证签名
                        if len(parts) > 1 and parts[1] == self._sign_auth_info(parts[0]):
                            data = self._encode(parts[0])
                            if isinstance(data, dict) and 'id' in data:
                                self.__PDATA['data']['id'] = data['id']

                self.__PDATA['data']['product'] = self.__PLUGIN_NAME
                self.__PDATA['data']['serverid'] = self._get_serverid()
                self.__PDATA['data'] = self._decode(self.__PDATA['data'])

                #  这里需要考虑多次重试，尽可能减少网络问题对授权的影响
                # 最多重试5次：5分钟、10分钟、30分钟、1小时
                result = public.httpPost(self.__AUTH_URL + '/info', self.__PDATA)
                ok = True
                try:
                    result = json.loads(result)
                except:
                    ok = False

                if not ok or not result['status']:
                    ok = False

                    # 累计重试失败次数
                    self.__AUTH_RETRIES += 1

                    if self.__AUTH_RETRIES > 4:
                        self.__AUTH_RETRIES = 0
                        self.__AUTH_NEXT_RETRY_TIME = 0
                        raise BtMonitorException('flush auth info failed: {}'.format(result))

                    # 记录本次下一次重试时间，本次授权信息从本地读取
                    m = {
                        1: 5,
                        2: 10,
                        3: 30,
                        4: 60,
                    }

                    self.__AUTH_NEXT_RETRY_TIME = cur_time + m.get(self.__AUTH_RETRIES, 5)

                if ok:
                    # 缓存授权信息
                    public.writeFile(self.__AUTH_FILE,
                                     '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

                # 标记本次授权信息同步成功
                public.cache_set('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC', int(time.time()), 86400)

            # 尝试读取授权信息
            data = public.readFile(self.__AUTH_FILE)

            # 没有获取到授权信息时，初始化授权信息
            if not data:
                data = copy.deepcopy(auth_info)
                encoded_str = self._decode(data)
                public.writeFile(self.__AUTH_FILE, '{}.{}'.format(encoded_str, self._sign_auth_info(encoded_str)))

            # 获取授权密文与签名
            parts = data.split('.', 1)

            # 验证签名
            if len(parts) < 2 or parts[1] != self._sign_auth_info(parts[0]):
                raise BtMonitorException('flush auth info failed: 授权信息可能被篡改')

            data = self._encode(parts[0])

            # type 授权类型
            # 0-免费版
            # 1-专业版
            # 2-企业版
            auth_info['id'] = data['id']
            auth_info['product'] = data['product']
            auth_info['status'] = data['status']
            auth_info['clients'] += data['clients']
            auth_info['durations'] = data['durations']
            auth_info['end_time'] = data['end_time']

            if auth_info['id'] != 0:
                d = {
                    'cloud_monitor': 1,
                    'cloud_monitor_ltd': 2,
                }
                auth_info['type'] = d.get(auth_info['product'], 0)
        except BaseException as e:
            public.print_log(str(e))
            public.print_exc_stack(e)
        finally:
            # 当超出最大授权数量时，重置超出的主机授权状态
            self._slice_exceed_auth_num(int(auth_info.get('cur_auth_num', 0)), int(auth_info.get('clients', 0)))
            return public.success(auth_info)

    def _flush_auth_cache(self, force=0):
        '''
        @name 刷新授权缓存
        @author cjxin
        '''
        # 每隔1天强制从云端同步授权信息
        if public.cache_get('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC') is None:
            force = 1

        # 获取当前时间
        cur_time = int(time.time())

        # 默认授权信息
        auth_info = [{
            'id': 0,
            'product': 'cloud_monitor',
            'status': 2,
            'clients': 5,
            'durations': 0,
            'end_time': int(time.time()) - 1,
            'type': 0,
            'cur_auth_num': 0,  # 当前购买的已授权数量
        }]

        # 获取当前授权数量
        cache_key = 'BT_MONITOR_CACHE__CUR_AUTH_NUM'

        cur_auth_num = public.cache_get(cache_key)
        if cur_auth_num is None:
            # 获取当前已授权的客户端数量
            with public.sqlite_easy('monitor_mgr') as db:
                cur_auth_num = db.query() \
                    .name('servers') \
                    .where('is_authorized=1') \
                    .where_in('status', [0, 1]) \
                    .count()
                # 缓存当前已授权的客户端数量2分钟
                public.cache_set(cache_key, cur_auth_num, 120)

        auth_info[0]['cur_auth_num'] = cur_auth_num if cur_auth_num else 0

        # 用户未登录
        if self.__USER_INFO is None:
            return public.success(auth_info)

        # 检查是否需要重试
        if self.__AUTH_NEXT_RETRY_TIME > 0 and self.__AUTH_NEXT_RETRY_TIME <= cur_time:
            force = 1
        auth_list = []  # 授权列表
        data_info = {}  # 返回数据
        total_auth_num = 5  # 返回数据
        try:
            if force or not os.path.exists(self.__AUTH_FILE):
                # # 尝试获取授权ID
                # if os.path.exists(self.__AUTH_FILE):
                #     data = public.readFile(self.__AUTH_FILE)
                #
                #     if data:
                #         # 获取授权密文与签名
                #         parts = data.split('.', 1)
                #
                #         # 验证签名
                #         if len(parts) > 1 and parts[1] == self._sign_auth_info(parts[0]):
                #             data = self._encode(parts[0])
                #             # todo data改列表
                #             # 授权id变多个 不传
                #             if isinstance(data, list) and 'id' in data:
                #                 self.__PDATA['data']['id'] = data[0]['id']

                self.__PDATA['data']['product'] = self.__PLUGIN_NAME
                self.__PDATA['data']['serverid'] = self._get_serverid()
                self.__PDATA['data'] = self._decode(self.__PDATA['data'])
                # TODO 这里需要考虑多次重试，尽可能减少网络问题对授权的影响
                # 最多重试5次：5分钟、10分钟、30分钟、1小时
                result = public.httpPost(self.__AUTH_URL + '/info_v2', self.__PDATA)
                ok = True
                try:
                    result = json.loads(result)
                except:
                    ok = False

                if not ok or not result['status']:
                    ok = False

                    # 累计重试失败次数
                    self.__AUTH_RETRIES += 1

                    if self.__AUTH_RETRIES > 4:
                        self.__AUTH_RETRIES = 0
                        self.__AUTH_NEXT_RETRY_TIME = 0
                        raise BtMonitorException('flush auth info failed: {}'.format(result))

                    # 记录本次下一次重试时间，本次授权信息从本地读取
                    m = {
                        1: 5,
                        2: 10,
                        3: 30,
                        4: 60,
                    }

                    self.__AUTH_NEXT_RETRY_TIME = cur_time + m.get(self.__AUTH_RETRIES, 5)

                if ok:
                    # 缓存授权信息
                    with Locker.acquire(timeout=15):
                        public.writeFile(self.__AUTH_FILE,
                                         '{}.{}'.format(result['data'], self._sign_auth_info(result['data'])))

                # 标记本次授权信息同步成功
                public.cache_set('BT_MONITOR_CACHE__LAST_AUTH_INFO_SYNC', int(time.time()), 86400)

            # 尝试读取授权信息
            with Locker.acquire(timeout=15):
                data = public.readFile(self.__AUTH_FILE)

            # 没有获取到授权信息时，初始化授权信息
            if not data:
                data = copy.deepcopy(auth_info)
                # data  list转dict
                data = {'{}'.format(i): value for i, value in enumerate(data)}

                encoded_str = self._decode(data)

                # 初始化授权信息 加密存储
                with Locker.acquire(timeout=15):
                    public.writeFile(self.__AUTH_FILE, '{}.{}'.format(encoded_str, self._sign_auth_info(encoded_str)))
                    data = public.readFile(self.__AUTH_FILE)

            # 获取授权密文与签名
            parts = data.split('.', 1)

            # 验证签名
            if len(parts) < 2 or parts[1] != self._sign_auth_info(parts[0]):
                raise BtMonitorException('flush auth info failed: 授权信息可能被篡改')

            data = self._encode(parts[0])  # 解密
            # public.print_log('*********7---{} 类型{}'.format(data, type(data)))
            if isinstance(data, dict):
                # data = [value for _, value in data.items()]
                data = [data]

            d = {
                'cloud_monitor': 1,  # 1-专业版
                'cloud_monitor_ltd': 2,  # 2-企业版
            }

            # public.print_log('>>>>>>>>> auth_info: {}'.format(data), _level='error')
            for i in data:
                auth_info = {}
                auth_info['id'] = i['id']
                auth_info['product'] = i['product']
                auth_info['status'] = i['status']
                auth_info['clients'] = i['clients']
                auth_info['durations'] = i['durations']
                auth_info['end_time'] = i['end_time']
                auth_info['type'] = 0 if i['id'] == 0 else d.get(auth_info['product'], 0)
                auth_list.append(auth_info)

            # 当前授权主机信息
            server_info = self._get_auth_server()

            # 没有购买过授权
            if auth_list is None or len(auth_list) == 0:
                # auth_list = auth_info
                # public.print_log('*********7---{} 类型{}'.format(auth_list, type(auth_list)), _level='error')
                min_end_time = int(time.time()) - 1
                not_expired_num = 5
                total_auth_num = 5
                expired_num = 0
                recently_expired_id = 0
                types = 0
            else:
                # 授权信息
                min_end_time, not_expired_num, total_auth_num, expired_num, recently_expired_id = self._get_auth_num(
                    auth_list)
                # 列表中授权类型 找最大的
                types = max([i['type'] for i in auth_list])

            if expired_num > 0 and server_info != {}:
                # 即将过期的机器
                recently_expired_server = [v for k, v in server_info.items() if int(k) <= expired_num]

            else:
                recently_expired_server = []

            data_info = {
                'total_auth_num': total_auth_num,
                'cur_auth_num': cur_auth_num,
                'min_end_time': min_end_time,
                'type': types,
                'auth_list': auth_list,  # 全部授权信息
                # 'recently_expired': recently_expired,  # 将过期的授权信息
                'recently_expired_num': expired_num,  # 将过期的授权数量
                'recently_expired_id': recently_expired_id,  # 将过期的授权id
                'recently_expired_server': recently_expired_server,  # 将过期的授权主机列表
            }
        except BaseException as e:
            public.print_log(str(e))
            public.print_exc_stack(e)
        finally:
            # total_auth_num = data_info.get('total_auth_num', 0)
            # public.print_log('3333333333333当前最大授权数量{}'.format(total_auth_num), _level='error')
            if cur_auth_num and cur_auth_num > total_auth_num:
                # 当超出最大授权数量时，重置超出的主机授权状态
                self._slice_exceed_auth_num(cur_auth_num, total_auth_num)

        return public.success(data_info)

    def _get_serverid(self, force=False):
        '''
        @name 获取服务器ID
        @author cjxin
        '''
        serverid_file = '{}/data/sid.pl'.format(public.get_panel_path())
        if os.path.exists(serverid_file) and not force:
            serverid = public.readFile(serverid_file)
            if re.match("^\w{64}$", serverid): return serverid
        s1 = self._get_mac_address() + self._get_hostname()
        s2 = self._get_hostname()
        serverid = public.md5(s1) + public.md5(s2)
        public.writeFile(serverid_file, serverid)
        return serverid

    def _get_mac_address(self):
        '''
        @name 获取MAC地址
        @author cjxin
        '''
        import uuid
        mac = uuid.UUID(int=uuid.getnode()).hex[-12:]
        return ":".join([mac[e:e + 2] for e in range(0, 11, 2)])

    def _get_hostname(self):
        """
        @name 获取主机名
        @author cjxin
        """
        import socket
        return socket.getfqdn(socket.gethostname())

    def _get_user_info(self):
        """
        @name 获取用户信息
        """
        data = None
        try:
            if os.path.exists(self.__USER_PATH):
                data = json.loads(public.readFile(self.__USER_PATH))
        except:
            pass
        return data

    # 加密数据
    def _decode(self, data):
        """
        @name 加密数据
        @author cjxin
        @data dict 加密数据
        """
        if sys.version_info[0] == 2:
            pdata = urllib.urlencode(data)
        else:
            pdata = urllib.parse.urlencode(data)
            if type(pdata) == str: pdata = pdata.encode('utf-8')
        return binascii.hexlify(pdata).decode('utf-8')

    # 解密数据
    def _encode(self, data):
        """
        @name 解密数据
        @author cjxin
        @data string 解密数据
        """
        if sys.version_info[0] == 2:
            result = urllib.unquote(binascii.unhexlify(data))
        else:
            if type(data) == str: data = data.encode('utf-8')
            tmp = binascii.unhexlify(data)
            if type(tmp) != str: tmp = tmp.decode('utf-8')
            result = urllib.parse.unquote(tmp)

        if type(result) != str: result = result.decode('utf-8')

        try:
            return json.loads(result)
        except:
            return [json.loads(item.split('=')[1].replace('+', ' ').replace("'", '"')) for item in result.split('&')]

    def _sign_auth_info(self, encrypted_auth_info):
        '''
            @name 对授权信息(密文)进行签名
            @author Zhj<2022-10-24>
            @param encrypted_auth_info:
            @return string
        '''
        return aes.aescrypt_py3('kv01kvasdoaksdkj', 'CBC', b'bvkf0ek0qwfovj92').aesencrypt(encrypted_auth_info)

    def _slice_exceed_auth_num(self, cur_auth_num, clients):
        '''
            @name 处理当前多出来的授权
            @author Zhj<2022-11-09>
            @param cur_auth_num<integer>    当前授权数
            @param clients<integer>         可授权数
            @return void
        '''
        if int(cur_auth_num) <= int(clients):
            return

        sid_list = []

        # 按添加时间倒序排列，查询出当前超出的已授权主机
        with public.sqlite_easy('monitor_mgr') as db:
            sid_list = db.query() \
                .name('servers') \
                .where('is_authorized=1') \
                .order('create_time', 'desc') \
                .limit(999999999, clients) \
                .column('sid')

            # 关闭事务自动提交
            db.autocommit(False)

            # 更新授权状态
            db.query() \
                .name('servers') \
                .where_in('sid', sid_list) \
                .update({
                'is_authorized': 0,
                'status': 0,
                'update_time': int(time.time()),
            })

            # 提交事务
            db.commit()

        # 缓存当前已授权的客户端数量2分钟
        public.cache_set('BT_MONITOR_CACHE__CUR_AUTH_NUM', clients, 120)

    # 获取授权的服务器信息 去掉前五个 默认授权的
    def _get_auth_server(self):
        """
            @name 获取授权服务器信息

            sid_list = {
            "1": {
                "remark": "",
                "sid": 11,
                "last_authorized_time": 0,
                "ip": "xxx.xxx.xxx.xxx"
            },
            "2": {
                "remark": "",
                "sid": 12,
                "last_authorized_time": 0,
                "ip": "xxx.xxx.xxx.xxx"
            },
            ...
        }

        """
        with public.sqlite_easy('monitor_mgr') as db:
            sid_list = db.query().name('servers') \
                .where('is_authorized=1') \
                .order('last_authorized_time', 'asc') \
                .field('sid', 'remark', 'ip', 'last_authorized_time', 'update_time') \
                .select()

            # public.print_log('服务器-------{}'.format(sid_list), _level='error')
            if not sid_list or len(sid_list) < 1:
                # public.print_log('无服务器-------xxx', _level='error')
                return {}

            # # 去掉前五个 默认授权
            # sid_list = sid_list[5:]
            # 给列表转换成字典 key为下标 下标从1开始
            sid_list = {k: v for k, v in enumerate(sid_list, start=1)}

        return sid_list

    # 获取授权数 即将过期的授权数(一月内)
    def _get_auth_num(self, auth_data):
        """
            @name 获取授权数 即将过期的授权数(一月内)
            @auth_data dict 授权信息
            @return tuple (最近过期时间, 不过期数量, 总授权数, 将过期数量, 将过期的授权id)
        """

        recently_expired = []  # 月内过期
        not_expired = []  # 不过期

        # 排序 根据end_time 升序 先过期的在前面
        auth_list = sorted(auth_data, key=lambda x: x['end_time'])
        # 总授权数量
        total_auth_num = 0
        # 最近将过期的授权时间
        min_end_time = auth_list[0]['end_time']
        recently_expired_id = auth_list[0]['id']
        # 最近将过期的授权数量 只显示最近一条授权的数量
        expired_num = 0 if auth_list[0]['id'] == 0 else auth_list[0]['clients']

        # min_end_time = float('inf')
        for auth in auth_list:
            if auth['id'] == 0:
                continue

            total_auth_num += int(auth.get('clients', 0))
            # # 最小的结束时间
            # if auth['end_time'] < min_end_time:
            #     min_end_time = auth['end_time']

            # 结束时间小于30天的 放到即将过期列表
            if 0 < auth['durations'] < 30 * 86400:
                recently_expired.append(auth)
            else:
                # 未过期列表
                not_expired.append(auth)

        # 不临近过期的授权数量  (未过期的授权数量 + 5 默认授权数量)
        not_expired_num = sum([i['clients'] for i in not_expired]) + 5
        # 总授权数量 + 默认授权数量
        total_auth_num += 5

        # # 即将过期的授权数量 (全部)
        # expired_num = sum([i['clients'] for i in recently_expired])

        return min_end_time, not_expired_num, total_auth_num, expired_num, recently_expired_id

    def ss_11(self, args):
        with public.sqlite_easy('monitor_mgr') as db:
            data = db.query().name('servers').field('sid', 'ip', 'type', 'status').select()
            count = len(data)

        from core.include.monitor_helpers import warning_obj
        all_server = warning_obj.db_easy('servers s') \
            .left_join('server_group sg', 's.group_id=sg.id') \
            .order('s.sid', 'desc') \
            .field('s.sid', 'sg.name as group_name', 's.ip', 's.remark', 'sg.id as group_id') \
            .select()
        count2 = len(all_server)

        aa = {
            'count1': count,
            'count2': count2,
            'data': data,
            'data2': all_server
        }
        return aa

    # ========== NPS ===============
    # 获取NPS问卷
    def nps_questions(self, args):
        cache_key = 'CACHED_NPS_QUESTIONS'

        # 优先从缓存中获取
        cached_questions = public.cache_get(cache_key)

        if cached_questions is not None:
            return public.success(cached_questions)

        data = {
            'uid': self.__USER_INFO.get('uid', 0),
            'serverid': self._get_serverid(),
            'product_type': self.__NPS_PRODUCT_TYPE,
        }
        data.update(self.__PDATA)
        result = public.httpPost(self.__NPS_URL + '/questions', data)

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        # 缓存NPS
        public.cache_set(cache_key, result['res'], 600)

        return public.success(result['res'])

    # 提交NPS
    def nps_submit(self, args):
        # 提交频率10分钟/次
        cache_key = 'NPS_SUBMIT_THROTTLE'

        if public.cache_get(cache_key) is not None:
            return public.error('请不要频繁提交问卷')

        data = {
            'uid': self.__USER_INFO.get('uid', 0),
            'serverid': self._get_serverid(),
            'product_type': self.__NPS_PRODUCT_TYPE,
            'rate': args.get('rate', 0),
            'feedback': args.get('feedback', ''),
            'phone_back': args.get('phone_back', 0),
            'questions': args.get('questions', ''),
            # 'reason_tags': args.get('reason_tags', ''),
            # 'panel_version': '',
        }

        data.update(self.__PDATA)
        result = public.httpPost(self.__NPS_URL + '/submit', data)

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        if not result['success']:
            return public.error(result['res'])

        public.cache_set(cache_key, 1, 600)

        return public.success(result['res'])

    # 检查是否提交过NPS
    def nps_check(self, args):
        data = {
            'uid': self.__USER_INFO.get('uid', 0),
            'serverid': self._get_serverid(),
            'product_type': self.__NPS_PRODUCT_TYPE,
        }

        data.update(self.__PDATA)
        result = public.httpPost(self.__NPS_URL + '/check', data)

        try:
            result = json.loads(result)
        except:
            return public.error(result)

        from core.include.monitor_helpers import basic_monitor_obj

        cur_time = int(time.time())

        # 获取首次登录时间
        first_login_time = basic_monitor_obj.db_easy('servers').value('min(create_time)')

        if not result['success']:
            return public.success({
                'submit_status': 0,
                'last_submit_time': 0,
                'installed_days': int((cur_time - first_login_time) / 86400),
            })

        return public.success({
            'submit_status': 1,
            'last_submit_time': result['res'],
            'installed_days': int((cur_time - first_login_time) / 86400),
        })
