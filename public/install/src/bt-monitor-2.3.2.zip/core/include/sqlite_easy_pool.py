# coding: utf-8

from genericpath import isfile
import sqlite3, os, time, traceback, queue
from threading import Lock, Thread

os.chdir('/www/server/bt-monitor')

from core.include.public import gen_password, print_exc_stack
# import core.include.public as public
import core.include.Locker as Locker

def _dict_factory(cursor, row):
    '''
        @name   将元组数据行转换为字典
        @author Zhj<2022-07-16>
        @param  cursor<sqlite3.Cursor>  游标对象
        @param  row<tuple>              数据行元组
        @return dict
    '''
    d = {}

    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]

    return d

# class Singleton(object):
#     def __init__(self, cls):
#         self._cls = cls
#         self._instance = {}
#
#     def __call__(self):
#         if self._cls not in self._instance:
#             self._instance[self._cls] = self._cls()
#         return self._instance[self._cls]
#
# @Singleton
class SqliteConnectionPool:

    def __init__(self, db_name, pool_size = 4, max_waiting_time = 5000):
        self.__LOCK = Lock()                                # 线程锁对象
        self.__DB_NAME = db_name                            # 数据库名称
        self.__POOL = queue.Queue(pool_size)                # 连接池
        self.__POOL_ID_SET = set()                          # 连接ID集合
        self.__POOL_SIZE = pool_size                        # 最大连接数 0-表示不限
        self.__MAX_WAITING_TIME = max_waiting_time          # 最大等待时间/毫秒
        self.__WAITTED_TIME = 0                             # 已等待时间

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()

    # def __del__(self):
    #     self.clear()

    def connection(self):
        '''
            @name 获取一个数据库连接 获取失败时返回None
            @return sqlite3.Connection|None
        '''
        pooled_conn = None

        while True:
            # 优先从连接池中获取
            try:
                pooled_conn = self.__POOL.get_nowait()
                with Locker.acquire(self.__LOCK):
                    if pooled_conn.id() in self.__POOL_ID_SET:
                        self.__POOL_ID_SET.remove(pooled_conn.id())
            except queue.Empty:
                pooled_conn = None

            if pooled_conn is None:
                try:
                    # 创建一个新的连接
                    # if self.__MAX_CONNECTIONS == 0 or self.__FREE_CONNECTIONS > 0:
                    db_path = 'data/{}.db'.format(self.__DB_NAME)

                    # 创建存储在内存中的数据库
                    if self.__DB_NAME == ':memory:':
                        db_path = ':memory:'

                    # 在/dev/shm目录中创建数据库
                    if str(self.__DB_NAME).startswith('/dev/shm'):
                        db_path = '{}.db'.format(self.__DB_NAME)

                    conn = sqlite3.connect(db_path, timeout=15)
                    conn.row_factory = _dict_factory
                    conn.text_factory = str
                    conn.isolation_level = 'IMMEDIATE'
                    pooled_conn = PooledSqliteConnection(conn, self)

                    # 无可用连接
                    # else:
                    #     raise Exception('Too many sqlite connections.')
                except BaseException as e:
                    print_exc_stack(e)

            if pooled_conn is None and self.__WAITTED_TIME < self.__MAX_WAITING_TIME:
                # 每隔20毫秒尝试获取一次数据库连接
                time.sleep(0.02)
                self.__WAITTED_TIME += 20
                continue

            break

        self.__WAITTED_TIME = 0

        # 获取不到数据库连接对象时
        # 抛出异常
        if pooled_conn is None:
            raise Exception('Too many sqlite connections.')

        return pooled_conn

    def putback(self, pooled_conn):
        '''
            @name 将连接放回连接池
            @author Zhj<2022-07-17>
            @param  pooled_conn<PooledSqliteConnection> 数据库连接对象
            @return bool
        '''
        if not isinstance(pooled_conn, PooledSqliteConnection):
            return False

        # 断开连接
        pooled_conn.release()
        return True

        if pooled_conn.is_closed():
            return False

        ok = True

        with Locker.acquire(self.__LOCK):
            if pooled_conn.id() in self.__POOL_ID_SET:
                ok = False

        if not ok:
            return False

        try:
            # 尝试放回连接池
            self.__POOL.put_nowait(pooled_conn)
            with Locker.acquire(self.__LOCK):
                self.__POOL_ID_SET.add(pooled_conn.id())
        except queue.Full:
            # 连接池满了，断开连接
            pooled_conn.release()
            ok = False
        except BaseException as e:
            print(traceback.format_exc())
            ok = False

        return ok

    def clear(self):
        '''
            @name 关闭所有连接
            @author Zhj<2022-07-17>
            @return bool
        '''
        ok = True

        while True:
            try:
                pooled_conn = self.__POOL.get_nowait()
                # 断开连接
                pooled_conn.release()
                with Locker.acquire(self.__LOCK):
                    if pooled_conn.id() in self.__POOL_ID_SET:
                        self.__POOL_ID_SET.remove(pooled_conn.id())
            except queue.Empty:
                break
            except BaseException as e:
                print(traceback.format_exc())
                ok = False

        return ok

class PooledSqliteConnection:
    '''
        @name Sqlite数据库连接包装类
        @author Zhj<2022-07-17>
    '''
    def __init__(self, conn, pool):
        self.__ID = gen_password(32) # 唯一ID
        self.__CONN = conn      # 数据库连接对象
        self.__CONN_POOL = pool # 连接池对象
        self.__LAST_ACTIVE_TIME = int(time.time()) # 上一次活动时间
        self.__IS_CLOSED = False # 连接是否已关闭

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # def __del__(self):
    #     self.close()

    def id(self):
        '''
            @name 获取ID
            @author Zhj<2022-08-18>
            @return int
        '''
        return self.__ID

    def last_active_time(self):
        '''
            @name 获取上一次活动时间
            @author Zhj<2022-08-17>
            @return int
        '''
        return self.__LAST_ACTIVE_TIME

    def cursor(self):
        '''
            @name 获取游标对象
            @return sqlite3.Cursor
        '''
        if not isinstance(self.__CONN, sqlite3.Connection):
            return None

        # 更新活动时间
        self.__LAST_ACTIVE_TIME = int(time.time())

        return self.__CONN.cursor()

    def close(self):
        '''
            @name 将连接放回连接池
            @author Zhj<2022-07-17>
            @return bool
        '''
        if not isinstance(self.__CONN, sqlite3.Connection):
            return False

        if not isinstance(self.__CONN_POOL, SqliteConnectionPool):
            return False

        # 放回连接池之前提交事务(如果开启了的话)
        self.commit()

        return self.__CONN_POOL.putback(self)
        # self.release()
        # return True

    def commit(self):
        '''
            @name 提交事务
            @author Zhj<2022-07-17>
            @return bool
        '''
        if isinstance(self.__CONN, sqlite3.Connection) \
                and self.__CONN.in_transaction:
            self.__CONN.commit()
            return True

        return False

    def rollback(self):
        '''
            @name 回滚事务
            @author Zhj<2022-07-17>
            @return bool
        '''
        if isinstance(self.__CONN, sqlite3.Connection) \
                and self.__CONN.in_transaction:
            self.__CONN.rollback()
            return True

        return False

    def release(self):
        '''
            @name 关闭数据库连接
            @author Zhj<2022-07-17>
            @return void
        '''
        if isinstance(self.__CONN, sqlite3.Connection):
            self.__CONN.close()

        self.__CONN_POOL = None

    def is_closed(self):
        '''
            @name 检查连接是否已关闭
            @author Zhj<2022-09-06>
            @return bool
        '''
        if self.__IS_CLOSED:
            return True

        try:
            if not isinstance(self.__CONN, sqlite3.Connection):
                self.__IS_CLOSED = True
                return True

            self.__CONN.executescript('select 1;')
        except sqlite3.ProgrammingError:
            self.__IS_CLOSED = True
            return True

        return False
