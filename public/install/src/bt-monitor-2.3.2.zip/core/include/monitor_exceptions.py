# -*- encoding: utf-8 -*-
#
# 云监控异常类模块
# @author Zhj<2022-07-21>

class BtMonitorException(Exception):
    '''
        @name 云监控异常类
        @author Zhj<2022-07-18>
    '''
    def __init__(self, val):
        self.__VALUE = val

    def __str__(self):
        return str(self.__VALUE)