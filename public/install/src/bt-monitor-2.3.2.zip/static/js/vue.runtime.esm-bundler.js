import{Z as o}from"./naive-ui.js";import{ag as r}from"./vue.js";const s=o(r);export{s as r};
