
import public
from projectModel.phpModel.base import phpBase

class main(phpBase):
    
    def run(self,args):
        return public.return_data(True,args.__dict__)
        





