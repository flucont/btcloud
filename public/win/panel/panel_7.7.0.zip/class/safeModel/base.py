#coding: utf-8
import public,re,time,sys,os
from datetime import datetime
import winreg


class safeBase:


    def __init__(self):
        pass





    def get_err_count(self, pid, day=0):
        """
        获取指定事件的数量
        """
        try:
            data = public.get_func('SetSshPort')

            stime = time.time() - (day * 86400)
            if data['time'] >= stime: stime = data['time']

            t = time.localtime(stime)
            start_time = time.strftime('%Y-%m-%dT%H:%M:%S', t)
        except :
            if day > 0:
                t = time.localtime(time.time() - (day * 86400))
            else:
                t = time.localtime(0)
            start_time = time.strftime('%Y-%m-%dT00:00:00', t)

        e_count = public.ExecShell('wevtutil qe Security "/q:*[System [(EventID={}) and  TimeCreated[@SystemTime >= \'{}\' ]]]" |find /c /v ""'.format(str(pid), start_time))[0]
        if not e_count: e_count = '0'
        return int(e_count);
