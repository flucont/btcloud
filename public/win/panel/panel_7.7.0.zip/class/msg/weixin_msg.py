#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2020 宝塔软件(http://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# | 消息通道邮箱模块
# +-------------------------------------------------------------------

import os, sys, public, base64, json, re,requests
import sys, os
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.insert(0,panelPath + "/class/")

class weixin_msg:

    conf_path = 'data/weixin.json'
    __weixin_info = None
    def __init__(self):
        try:
            self.__weixin_info = json.loads(public.readFile(self.conf_path))
            if not 'weixin_url' in self.__weixin_info or not 'isAtAll' in self.__weixin_info or not 'user' in self.__weixin_info:
                self.__weixin_info = None
        except :
            self.__weixin_info = None

    def get_version_info(self,get):
        """
        获取版本信息
        """
        data = {}
        data['ps'] = '宝塔微信消息通道，用于接收面板消息推送'
        data['version'] = '1.1'
        data['date'] = '2020-08-05'
        data['author'] = '宝塔'
        data['help'] = 'http://www.bt.cn'
        return data

    def get_config(self,get):
        """
        获取微信配置
        """
        data = {}
        if self.__weixin_info : data = self.__weixin_info

        return data

    def set_config(self,get):
        """
        设置微信配置
        @url 微信URL
        @atall 默认@全体成员
        @user
        """
        if not hasattr(get, 'url') or not hasattr(get, 'atall'): return public.returnMsg(False, '请填写完整信息')

        self.__weixin_info  = {"weixin_url": get.url.strip(), "isAtAll": True, "user":1 }

        try:
            info = public.get_push_info('消息通道配置提醒',['>配置状态：<font color=#20a53a>成功</font>\n\n'])
            ret = self.send_msg(info['msg'])
        except:
            ret = self.send_msg('宝塔告警测试')

        if ret['status']:
            public.writeFile(self.conf_path, json.dumps(self.__weixin_info))
            return public.returnMsg(True, '添加成功')
        else:
            return public.returnMsg(False, '添加失败,请查看URL是否正确')


    def get_send_msg(self,msg):
        """
        @name 处理md格式
        """
        try:
            if msg.find("####") >= 0:
                msg = msg.replace("\n\n","""
                """).strip()
        except:pass
        return msg

    def send_msg(self,msg):
        """
        @name 微信发送信息
        @msg string 消息正文(正文内容，必须包含
                1、服务器名称
                2、IP地址
                3、发送时间
            )

        """
        if not self.__weixin_info :
            return public.returnMsg(False,'未正确配置微信信息。')

        if msg.find('####') == -1:
            try:
                msg = public.get_push_info('消息通道配置提醒',['>发送内容：{}\n\n'.format(msg)])['msg']
            except:pass

        msg = self.get_send_msg(msg)
        data = {
            "msgtype": "markdown",
            "markdown": {
                "content": msg
            }
        }
        headers = {'Content-Type': 'application/json'}
        try:
            x = requests.post(url = self.__weixin_info['weixin_url'], data=json.dumps(data), headers=headers,verify=False)
            if x.json()["errcode"] == 0:
                return public.returnMsg(True,'微信消息发送成功。')
            else:
                return public.returnMsg(False,'微信消息发送失败。')
        except:
            return public.returnMsg(False,'微信消息发送失败。 --> {}'.format(public.get_error_info()))
        return public.returnMsg(True,'微信消息发送完成。')

    def push_data(self,data):
        return self.send_msg(data['msg'])