#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2020 宝塔软件(http://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# | 消息通道邮箱模块
# +-------------------------------------------------------------------

import os, sys, public, base64, json, re,requests
import sys, os
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.insert(0,panelPath + "/class/")

class dingding_msg:

    conf_path = 'data/dingding.json'
    __dingding_info = None
    def __init__(self):
        try:
            self.__dingding_info = json.loads(public.readFile(self.conf_path))
            if not 'dingding_url' in self.__dingding_info or not 'isAtAll' in self.__dingding_info or not 'user' in self.__dingding_info:
                self.__dingding_info = None
        except :
            self.__dingding_info = None

    def get_version_info(self,get):
        """
        获取版本信息
        """
        data = {}
        data['ps'] = '宝塔钉钉消息通道，用于接收面板消息推送'
        data['version'] = '1.1'
        data['date'] = '2020-08-05'
        data['author'] = '宝塔'
        data['help'] = 'http://www.bt.cn'
        return data

    def get_config(self,get):
        """
        获取钉钉配置
        """
        data = {}
        if self.__dingding_info : data = self.__dingding_info

        return data

    def set_config(self,get):
        """
        设置钉钉配置
        @url 钉钉URL
        @atall 默认@全体成员
        @user
        """
        if not hasattr(get, 'url') or not hasattr(get, 'atall'): return public.returnMsg(False, '请填写完整信息')

        self.__dingding_info  = {"dingding_url": get.url.strip(), "isAtAll": True, "user":1 }

        try:
            info = public.get_push_info('消息通道配置提醒',['>配置状态：<font color=#20a53a>成功</font>\n\n'])
            ret = self.send_msg(info['msg'])
        except:
            ret = self.send_msg('宝塔告警测试')

        if ret['status']:
            public.writeFile(self.conf_path, json.dumps(self.__dingding_info))
            return public.returnMsg(True, '添加成功')
        else:
            return ret

    def send_msg(self,msg):
        """
        @name 钉钉发送信息
        @msg string 消息正文(正文内容，必须包含
                1、服务器名称
                2、IP地址
                3、发送时间
            )

        """

        if not self.__dingding_info :
            return public.returnMsg(False,'未正确配置钉钉信息。')

        if msg.find('####') == -1:
            try:
                msg = public.get_push_info('消息通道配置提醒',['>发送内容：{}'.format(msg)])['msg']
            except:pass

        data = {
            "msgtype": "markdown",
            "markdown": {
                "title": "服务器通知",
                "text": msg
            },
            "at": {
                "atMobiles": [
                    self.__dingding_info['user']
                ],
                "isAtAll": self.__dingding_info['isAtAll']
            }
        }
        headers = {'Content-Type': 'application/json'}
        try:
            x = requests.post(url = self.__dingding_info['dingding_url'], data=json.dumps(data), headers=headers,verify=False)

            if x.json()["errcode"] == 0:
                return public.returnMsg(True,'钉钉消息发送成功。')
            else:
                return public.returnMsg(False,x.json()['errmsg'])
        except:
            return public.returnMsg(False,'钉钉消息发送失败。 --> {}'.format(public.get_error_info()))
        return public.returnMsg(True,'钉钉消息发送完成。')


    def push_data(self,data):

        return self.send_msg(data['msg'])
