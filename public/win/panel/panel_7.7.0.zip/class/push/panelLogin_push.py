#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2020 宝塔软件(http://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# +-------------------------------------------------------------------
import sys,os,time,json,re
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath);
sys.path.append("class/")
import public,db,time,html,panelPush

try:
    from BTPanel import cache
except :
    from cachelib import SimpleCache
    cache = SimpleCache()

class panelLogin_push:

    name = 'panelLogin' 
    __push = None
    def __init__(self):
        self.__push = panelPush.panelPush()
    
    """
    @ 获取插件版本信息   
    """
    def get_version_info(self,get):
        return self.__push.get_version_info()

    """
    @获取推送模块配置
    """
    def get_module_config(self,get):
        return []
