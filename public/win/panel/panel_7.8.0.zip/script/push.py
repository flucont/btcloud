 #coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2021 宝塔软件(https://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# | 消息推送模块
# +-------------------------------------------------------------------
import os,sys,json,threading
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.insert(0,panelPath + "/class/")
import public




if __name__ == '__main__':
    

    import panelPush
    push = panelPush.panelPush()
    push.push_msg_thread()

    

    #p = threading.Thread(target=push.push_msg_thread)
    #p.setDaemon(True)
    #p.start()
 
