try {
  if (bind_user == 1) new BindAccount().bindUserView()
} catch (error) {
  console.log(error)
}
$("select[name='network-io']").change(function () {
  var net_key = $(this).val();
  if (net_key == 'all') net_key = '';
  bt.set_cookie('network_io_key', net_key);
});

var interval_stop = false;
var index = {
  // 顾问服务弹窗
  consultancy_services: function (show) {
    var consultancy_cookies = bt.get_cookie('consultancy_cookies');
    if (consultancy_cookies) return false;
    if (show !== 0) return false;
    layer.open({
      type: 1,
      title: '免费顾问服务',
      closeBtn: false,
      area: ['600px', '470px'],
      btn: ['接受顾问服务', '放弃顾问服务'],
      content: '<div style="padding: 30px 35px;">\
                <div style="text-align: center;margin-bottom: 20px;font-size: 20px;height: 40px;line-height: 40px;">\
                <span style="vertical-align: middle;margin-left: 10px;font-size:21px;">感恩您使用宝塔，我们为您提供专属客服服务</span></div>\
                <div style="font-size: 14px;line-height: 27px;padding: 20px;border: 1px solid #ececec;border-radius: 5px;background: #fcfcfc;color: #555;text-indent:2em;">\
                    <div style="text-indent: 2em;margin-bottom: 10px;">我们提供给您<span style="font-weight: bold;">【免费的顾问服务】</span>，确保您在使用宝塔面板过程中遇到紧急或者棘手的问题能第一时间找到专人协助您处理，我们期待与您沟通。</div>\
                    <div style="text-indent: 2em;margin-bottom: 10px;">如果您点<span style="font-weight: bold;">【接受顾问服务】</span>，您无需再做什么，我们会有专人致电联系您并加您为好友，让您可以在有疑问的时候能第一时间联系到专员。</div>\
                    <div style="text-indent: 2em;margin-bottom: 10px;">同时您也可以<span style="font-weight: bold;">【放弃顾问服务】</span>，在遇到问题的时候可以在我们官网论坛发言，我们也有论坛值守人员协助您处理。</div></div>\
                </div>',
      yes: function (indexs, layero) {
        bt.send('set_user_adviser', 'auth/set_user_adviser ', { status: 1 }, function (res) {
          bt.set_cookie('consultancy_cookies', '1');
          layer.close(indexs);
          bt.msg(res)
        })
      },
      btn2: function (indexs, layero) {
        layer.confirm('是否放弃免费顾问服务，放弃后在遇到问题的时候可以在我们官网论坛发言，我们也有论坛值守人员协助您处理。', {
          title: '提示',
          area: '400px',
          btn: ['确认', '取消'],
          icon: 0,
          closeBtn: 2,
          yes: function () {
            bt.send('set_user_adviser', 'auth/set_user_adviser ', { status: -1 }, function (res) {
              bt.set_cookie('consultancy_cookies', '1');
              layer.close(indexs);
              bt.msg(res)
            })
          }
        })
        return false
      }
    })
  },
	warning_list: [],
  warning_num: null,
  series_option: {},// 配置项
  chart_json: {}, // 所有图表echarts对象
  chart_view: {}, // 磁盘echarts对象
  disk_view: [], // 释放内存标记
  chart_result: null,
  release: false,
	load_config: [{
    title: '运行堵塞',
    val: 90,
    color: '#dd2f00'
  }, {
    title: '运行缓慢',
    val: 80,
    color: '#ff9900'
  }, {
    title: '运行正常',
    val: 70,
    color: '#20a53a'
  }, {
    title: '运行流畅',
    val: 30,
    color: '#20a53a'
  }],
  show_recommend: function (show) {
    if (show !== 0) return;
    bt.soft.pro.get_product_discount_by('Windows企业版', function (enterpriseRes) {
      bt.soft.pro.get_product_discount_by('Windows专业版', function (proRes) {
        if (!enterpriseRes || !enterpriseRes[12]) return;
        if (!proRes || !proRes[12]) return;
        var pro_price = proRes[12].price;
        var pro_price_day = (proRes[12].price / 365).toFixed(2);
        var enterprise_price = enterpriseRes[12].price;
        var enterprise_price_day = (enterpriseRes[12].price / 365).toFixed(2);
        layer.open({
          type: 1,
          title: false,
          area: ['auto'],
          closeBtn: 1,
          shadeClose: false,
          content: '\
              <div class="recommend_list pd20">\
                  <div class="recommend_item active">\
                      <span class="recommend-pay-icon"></span>\
                      <div class="recommend_head">\
                          <div class="text">Windows企业版</div>\
                      </div>\
                      <div class="recommend_desc">适用于官网，电商、教育、医疗等企业用户</div>\
                      <div class="recommend_box">\
                          <div class="rows">\
                              <div class="text">网站防火墙</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">网站监控报表</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">驱动级防篡改</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">文件同步</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">堡塔APP</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">服务器防爆破</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">数据库运维工具</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">限制访问型证书</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">微信客服</div>\
                              <div class="icon right"></div>\
                          </div>\
                      </div>\
                      <div class="recommend_info">\
                          <div class="price">\
                              <div class="year">\
                                  <span>¥</span>\
                                  <span class="num">' + enterprise_price + '</span>\
                                  <span class="text">/年</span>\
                              </div>\
                              <div class="day">低至' + enterprise_price_day + '元/天</div>\
                          </div>\
                          <button class="btn btn-success pay_btn" data-type="company">立即开通</button>\
                          <a class="btlink service_buy_before">咨询优惠/试用</a>\
                      </div>\
                  </div>\
                  <div class="recommend_item">\
                      <div class="recommend_head">\
                          <div class="text">Windows专业版</div>\
                      </div>\
                      <div class="recommend_desc">适用于个人用户、个人项目</div>\
                      <div class="recommend_box">\
                          <div class="rows">\
                              <div class="text">网站防火墙</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">网站监控报表</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">驱动级防篡改</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">文件同步</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">堡塔APP</div>\
                              <div class="icon right"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">服务器防爆破</div>\
                              <div class="icon error"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">数据库运维工具</div>\
                              <div class="icon error"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">限制访问型证书</div>\
                              <div class="icon error"></div>\
                          </div>\
                          <div class="rows">\
                              <div class="text">微信客服</div>\
                              <div class="icon error"></div>\
                          </div>\
                      </div>\
                      <div class="recommend_info">\
                          <div class="price">\
                              <div class="year">\
                                  <span>¥</span>\
                                  <span class="num">' + pro_price + '</span>\
                                  <span class="text">/年</span>\
                              </div>\
                              <div class="day">低至' + pro_price_day + '元/天</div>\
                          </div>\
                          <button class="btn btn-success pay_btn" data-type="profession">立即开通</button>\
                      </div>\
                  </div>\
              </div>\
          ',
          success: function (obj) {
            var window_width = $(window).width();
            var width = obj.width();
            var left = (window_width - width) / 2;
            obj.css({
              left: left + 'px'
            });
            $('.pay_btn').click(function () {
              var type = $(this).attr('data-type');
              switch (type) {
                case 'company':
                  bt.soft.updata_ltd(undefined, 35);
                  break;
                case 'profession':
                  bt.soft.updata_pro(35);
                  break;
              }
            });
            $('.service_buy_before').click(function () {
              onChangeServiceMethod();
            })
            // 人工服务   带有参数为售前客服
            function onChangeServiceMethod() {
              layer.open({
                type: 1,
                area: ['300px', '290px'],
                title: false,
                closeBtn: 2,
                shift: 0,
                content: '<div class="service_consult">\
                        <div class="service_consult_title">请打开微信"扫一扫"</div>\
                        <div class="contact_consult" style="margin-bottom: 5px;"><div id="contact_consult_qcode"></div><i class="wechatEnterprise"></i></div>\
                        <div>【售前客服】</div>\
                        <ul class="help-info-text-info c7" style="margin-left:30px;text-align: left;">\
                            <li>工作时间：9:15 - 18:00</li>\
                        </ul>\
                    </div>',
                success: function () {
                  $('#contact_consult_qcode').qrcode({
                    render: "canvas",
                    width: 140,
                    height: 140,
                    text: 'https://work.weixin.qq.com/kfid/kfc72fcbde93e26a6f3'
                  });
                }
              })
            }
          },
          cancel: function () {
            $.post('/auth?action=set_user_rec');
          }
        });
      });
    });
  },
  interval: {
    limit: 10,
    count: 0,
    task_id: 0,
    start: function () {
      var _this = this;
      _this.count = 0;
      // _this.task_id = setInterval(function () {
      //   if (_this.count >= _this.limit) {
      //     _this.reload();
      //     return;
      //   }
      //   _this.count++;
      //   // if (!interval_stop) index.get_data_info();
			// 	console.log('----------',interval_stop);
			// 	if (!interval_stop){
			// 		interval_stop = true
			// 		// index.reander_system_info();
			// 	}
      // }, 3000)
			index.reander_system_info();
    },
    reload: function () {
      var _this = this;
      if (_this) clearInterval(_this.task_id);
      _this.start();
    }
  },
  net: {
    table: null,
    data: {
      uData: [],
      dData: [],
      aData: []
    },
    init: function () {
      //流量图表
      index.net.table = echarts.init(document.getElementById('NetImg'));
      var obj = {};
      obj.dataZoom = [];
      obj.unit = lan.index.unit + ':KB/s';
      obj.tData = index.net.data.aData;

      obj.list = [];
      obj.list.push({ name: lan.index.net_up, data: index.net.data.uData, circle: 'circle', itemStyle: { normal: { color: '#f7b851' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(255, 140, 0,0.5)' }, { offset: 1, color: 'rgba(255, 140, 0,0.8)' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
      obj.list.push({ name: lan.index.net_down, data: index.net.data.dData, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(30, 144, 255,0.5)' }, { offset: 1, color: 'rgba(30, 144, 255,0.8)' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
      option = bt.control.format_option(obj)

      index.net.table.setOption(option);
      window.addEventListener("resize", function () {
        index.net.table.resize();
      });
    },
    add: function (up, down) {
      var _net = this;
      var limit = 8;
      var d = new Date()

      if (_net.data.uData.length >= limit) _net.data.uData.splice(0, 1);
      if (_net.data.dData.length >= limit) _net.data.dData.splice(0, 1);
      if (_net.data.aData.length >= limit) _net.data.aData.splice(0, 1);

      _net.data.uData.push(up);
      _net.data.dData.push(down);
      _net.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
    }
  },
  mem: {
    status: 1,
    set_status: function (obj, status, val) {
      var _this = this;
      _this.status = status;
      var _div = $('<div><span style="display:none">1</span></div>')
      if (status == 2) {
        obj.find(".mem-re-con").animate({ "top": "-400px", opacity: 0 }); //动画
        var btlen = parseInt(obj.find('.occupy span').html());
        for (var i = 0; i < btlen; i++) {
          setTimeout(index.set_val(obj.parents('li'), { usage: btlen - i }), i * 30);
        };
        obj.addClass("mem-action");
        obj.find('.occupy').html(_div.append(lan.index.memre_ok_0 + ' <img src="/static/img/ings.gif">').html());
      }
      else if (status == 1) { //完成
        obj.removeClass('mem-action');
        obj.find('.occupy').removeClass('line').html("<span>" + val + "</span>%");
      }
      else {
        obj.find('.occupy').html(_div.append(status).html());
        if (bt.contains(status, '<br>')) obj.find('.occupy').addClass('line')
      }
    }
  },
		//生成表格
  /**
   * 表格生成器
   * @param {*} el 表格挂载节点
   * @param {*} data 表格挂载数据
   * @param config 表格配置
   */
  table_generation: function (el, data, config) {
    _this = this
    // 清理表格
    $(el).empty();
		
    bt_tools.table({
      data: data,
      el: el,
      height: '350px',
      minWidth: '290px',
      column: [
        {
          fid: 'username',
          title: '进程名',
          width: '100px',
          template: function (row, index) {
						var name = row.name.substring(0, $.inArray('.',row.name)===-1?row.name.length:$.inArray('.',row.name));
						var index = -1;
						for(var i=0;i<row.exe.length;i++){
							if(row.exe[i] == '\\'){
								index = i;
							}
						}
						var path = row.exe.substring(0,index);
            return '<div title="备注：' + (row.f_info&&row.f_info.FileDescription) + '\n启动路径：' + row.exe + '\n运行目录：' + (row.cwd||path) + '\n" style="overflow: hidden;text-overflow: ellipsis;">' + name + '</div>';
          },
        },
        {
          fid: config.fid[0],
          width: '80px',
          title: config.title[0],
        },
        // {
        //   fid: config.fid[1],
        //   width: '100px',
        //   title: config.title[1],
        // },
        {
          title: '操作',
          width: '40px',
          type: 'group',
          align: 'right',
          group: [
            {
              title: config.fid[0] == 'cpu_percent' ? '结束' : '释放',
              event: function (row, index, ev, key, that) {
                table_confirm_show = true;
                // var load;
								// python为系统进程，禁止结束
								if(row.name.indexOf && row.name.indexOf('python') !== -1){
									var s = config.fid[0] == 'cpu_percent' ? '结束' : '释放'
									layer.msg('该进程为系统进程，禁止' + s, {icon: 2});
									table_confirm_show = false;
									return;
								}
                if (row.important !== 1) {
									'真的要释放内存吗？', '<font style="color:red;">若您的站点处于有大量访问的状态，释放内存可能带来无法预测的后果，您确定现在就释放内存吗？</font>'
                  bt.compute_confirm({title:'结束【' + row.name + '】进程',msyStyle:'style="color:red;"',msg:'请检查【' + row.name + '】是否为系统进程，结束系统进程可能会导致'+'面板或服务器系统崩溃，是否结束?'}, function () {
                    bt_tools.send(
                      {
                        url: '/project/proc/kill_processes',
                        data: {
													data: JSON.stringify({ pid: row.pid.toString() }),
                          // pid: row.pid.toString(),
                        },
                      },
                      function (res) {
                        // load.close();
                        if (res.status) {
                          layer.msg(res.msg, {icon: 1});
                          table_confirm_show = false;
                        } else {
                          layer.msg(res.msg, {icon: 2});
                          table_confirm_show = false;
                        }
                      }
                    );
                    // load.close();
                  })
                  table_confirm_show = false;
                } else {
                  var s = config.fid[0] == 'cpu_percent' ? '结束' : '释放'
                  layer.msg('该进程为系统进程，禁止' + s, {icon: 2});
                  table_confirm_show = false;
                }
              },
            },
          ],
        },
      ],
    });
    $('.divtable').css('border', '0px');
    $('td').css({'word-break':'break-all','text-overflow': 'ellipsis'});
    $('table').css({'table-layout': 'fixed','white-space': 'nowrap'})
  },

  get_init: function () {
    var _this = this;

		var layer_id = 0;
    var layer_table_time = 0;
    var postion_time = 0;
    var time =0
    var mouseY, mouseX;
		var table_confirm_show = false;
    /**
     * 创建表格
     * @param el 表格挂载节点
     * @param type 渲染表格类型
     * @param config 表格配置
     */
    var create_data_table = function (el, type, config) {
			var url = '/project/proc/get_cpu_list'
			if(type == 'memory_high_occupancy_software_list') url = '/project/proc/get_mem_list'
      bt_tools.send({url}, function (res) {
				_this.isCorporat = (res.status === false);
				if(res.status === false){
					var item_CPU = {
						"name": "BT-****",
						"pid": '284**',
						"cpu_percent": "2.**%",
						"mem": "12.**",
						"proc_survive": "2*\u5206\u949f",
						"exe": "*******"
					}
					var item_CPU_x = {
						"name": "**-****",
						"pid": '*****',
						"cpu_percent": "*.**%",
						"mem": "*.**%",
						"proc_survive": "**\u5206\u949f",
						"exe": "*******"
					}
					res = [item_CPU,item_CPU_x,item_CPU_x,item_CPU_x,item_CPU_x]
					//显示开通企业版
					$('.un-profession').css('display','flex')
				} else{
					// $("#disk-header-fold-uncor").parent().addClass('active');
					// $("#disk-header-fold-uncor").find('span').text('收起');
					// $("#disk-header-fold-uncor").find('img').removeAttr('style');
					$('.load_tips .disk-item-footer').css('display','flex')
				}
				_this.table_generation(el, res || [], config);

			},{verify:false});
    }
    /**
     * 弹窗
     * @param config 格式
     * {
     * table:{
     *  type:'',
     *  table_title:[],
     *  table_fid:[],
     * },
     * html:{
     *   base_html:'',
     *   disk_title:'',
     *   table_id:'',
     *   position:'',
     *   newClass:'',
     * }
     * }
     */
    var float_box = function (config) {
      if (postion_time) {
        clearInterval(postion_time);
      }
      $('body').find('.layui-layer').remove()
      var is_other_active = bt.get_storage('LoadTips' + config.html.newClass+'_other_info'),
          is_top_active = bt.get_storage('LoadTips' + config.html.newClass+'_top5_info')
      var other_table_html = '',num = 0
      if(config.html.hasOwnProperty('cpu_times')){
        for (var i = 0; i < config.html.cpu_times.length; i++) {
          other_table_html += '<div class="disk-body-list">\
            <span>核心 '+ (i+1) + ' / ' + (i + 2) +' 占用：</span>\
            <span id="cpu_'+ (i+1) +'_num">'+ config.html.cpu_times[i] +'% / '+ config.html.cpu_times[i+1] +'%</span>\
          </div>'
          i++
        }
      } 
      layer_id = layer.open({
        type: 1,
        shade: 0,
        area: '400px',
        title: false,
        skin: 'load_tips ' + config.html.newClass,
        fixed: false,
        closeBtn: false,
        id: 'LoadTips' + config.html.newClass,
        offset: [($(config.html.position).offset().top + 140 - $(window).scrollTop()) + 'px', $(config.html.position).offset().left + 'px'],
        content:
				'<div class=" load_tips disk_cont" style="padding-bottom:0px;">\
				<div id="slot"></div>\
				<div class="disk-item-list active base_html" id="base_info">\
					<div class="disk-item-header">\
							<div class="disk-header-title">基础信息</div>\
					</div>\
					<div class="disk-item-body" id="base_info_html">' + config.html.base_html + '</div>\
					</div>' +
          (config.html.cpu_times ? '<div class="disk-item-list other_html '+ (is_other_active ? 'active' : '') +'" id="other_info">\
          <div class="disk-item-header">\
            <div class="disk-header-title">'+ config.html.title +'</div>\
            <div className="disk-header-fold"><span>'+ (is_other_active ? '折叠' : '展开') +'</span><img src="/static/img/arrow-down.svg" '+ (is_other_active ? 'style="transform: rotate(180deg);"' : '') +'></div>\
          </div>\
          <div class="disk-item-body cpu-core-body" id="other_info_html">'+ other_table_html +'</div></div>' : '') +
					'<div style="margin-bottom:10px" class="disk-item-list '+ (is_top_active ? 'active' : '') +'" id="top5_info">\
						<div id="disk-header-fold-uncor" class="disk-item-header" mark="cpu">\
							<div class="disk-header-title">' + config.html.disk_title + '</div>\
							<div class="disk-header-fold">\
								<span>'+ (is_top_active ? '折叠' : '展开') +'</span>\
								<img src="/static/img/arrow-down.svg" '+ (is_top_active ? 'style="transform: rotate(180deg);"' : '') +'>\
							</div>\
						</div>\
						<div class="disk-item-body disk-item-body-nottom" style="position:relative">\
							<div class="disk-body-list no-bg">\
							<div class = "load-list" id="' + config.html.table_id + '"></div>\
							<div class="un-profession" style="display:none;bottom: 24px;">\
							</div>\
							</div>\
              <div class="disk-item-footer '+ (config.html.isShow ? 'hide' : '') +'" style="text-align: center;">\
                <a id="task_manager_btn" style="margin:auto" title="立即购买" class="btlink"">立即购买</a>\
              </div>\
						</div>\
					</div>\
				</div>',
        success: function (layero, index) {
          // <div class="corporat-tip">\
					// 				<span  class="un-corporat-tip"></span>\
					// 				<span>此功能为企业版专享，</span>\
					// 				<button type="button" onclick="bt.soft.product_pay_view({ totalNum: 141, limit: \'ltd\', closePro: true })"></span>立即升级</button>\
					// 			</div>\
          //预渲染一个空表格占位
          _this.table_generation('#' + config.html.table_id, '', {
            fid: config.table.table_fid,
            title: config.table.table_title
          });
          //立即获取数据渲染真表格
          create_data_table('#' + config.html.table_id, config.table.type, {
            fid: config.table.table_fid,
            title: config.table.table_title,
          });
          //定时获取数据渲染真表格刷新新基础信息
          if (time) {
            clearInterval(time);
          }
          function layer_table_time_fun() {
            time = setTimeout(function (){
              create_data_table('#' + config.html.table_id, config.table.type, {
                fid: config.table.table_fid,
                title: config.table.table_title,
              });
              layer_table_time_fun()
            }, 5000);
          }
          layer_table_time_fun()
          $(window).resize(function () {
            var class_name = '.' + config.html.newClass
            if ($(class_name).length) {
              $(class_name).css({
                top: $(config.html.position).offset().top + 140 - $(window).scrollTop() + 'px',
                left: $(config.html.position).offset().left,
              });
            }
          });
          //判断是否有插入内容，将插入内容替换掉基础信息
          if (!config.html.base_html) {
            $('.base_html').remove();
            // $('.disk-item-list').addClass('active');
            config.html.slot ? $('#slot').html(config.html.slot) : '';
          }else{
            if(config.html.slot){
              $('#slot').html(config.html.slot)
            }
          }
          //获取鼠标isCisCoporary坐标
          $(document).mousemove(function (e) {
            mouseY = e.pageY;
            mouseX = e.pageX;
          });
          //内存释放
          $('#mem_scanning_btn').on('click', function () {
            var that = $(this);
            var data = _this.chart_result.mem;
            bt.show_confirm('真的要释放内存吗？', '<font style="color:red;">若您的站点处于有大量访问的状态，释放内存可能带来无法预测的后果，您确定现在就释放内存吗？</font>', function () {
              _this.release = true;
              var option = JSON.parse(JSON.stringify(_this.series_option));
              // 释放中...
              var count = '';
              var setInter = setInterval(function () {
                if (count == '...') {
                  count = '.';
                } else {
                  count += '.';
                }
                option.series[0].detail.formatter = '释放中' + count;
                option.series[0].detail.fontSize = 15;
                option.series[0].data[0].value = 0;
                _this.chart_view.mem.setOption(option, true);
                that.next().hide();
              }, 400);
              // 释放接口请求
              bt.system.re_memory(function (res) {
                that.next().show();
                clearInterval(setInter);
                var memory = data.memRealUsed - res.memRealUsed;
                option.series[0].detail = $.extend(option.series[0].detail, {
                  formatter: '已释放\n' + bt.format_size(memory > 0 ? memory : 0) + '',
                  lineHeight: 18,
                  padding: [5, 0],
                });
                _this.chart_view.mem.setOption(option, true);
                setTimeout(function () {
                  _this.release = false;
                  _this.chart_result.mem = res;
                  _this.chart_active('mem');
                }, 2000);
              });
            });
          });
					// 查看进程，下载任务管理器
					$('#task_manager_btn').on('click', function () {
            var ltd_end = bt.get_cookie('ltd_end') > 0;
						bt.soft.get_soft_find('task_manager',function(dataRes){
							// 打开其他弹窗前把当前弹窗关闭，防止弹窗重叠
							$('.'+config.html.newClass).remove();
              if(ltd_end) {
                if(dataRes.setup && dataRes.endtime > 0) {
                  bt.soft.set_lib_config(dataRes.name,dataRes.title,dataRes.version)
                }else{
                  bt.soft.install('task_manager')
                }
              }else{
                product_recommend.pay_product_sign('ltd', 141, 'ltd')
              }
							// if(dataRes.setup && dataRes.endtime > 0) {
							// 	bt.soft.set_lib_config(dataRes.name,dataRes.title,dataRes.version)
							// }else{
							// 	var item = {
							// 		name: 'task_manager',
							// 		pluginName: '堡塔任务管理器',
							// 		title: '堡塔任务管理器',
							// 		ps: '轻松管理进程、流量监控、启动项、用户、服务、计划任务、会话',
							// 		preview: false,
							// 		limit: 'ltd',
							// 		imgSrc:'/static/img/taskManager/index.png'
							// 	}
							// 	product_recommend.recommend_product_view(item, {
							// 		imgArea: ['783px', '718px']
							// 	})
							// 	var is_buy = dataRes.endtime < 0 && dataRes.pid > 0
							// 	$('.buyNow').text(is_buy ? '立即购买' : '立即安装').unbind('click').click(function () {
							// 		if(is_buy) {
							// 			bt.soft.product_pay_view({
							// 				name:dataRes.title,
							// 				pid:dataRes.pid,
							// 				type:dataRes.type,
							// 				plugin:true,
							// 				renew:-1,
							// 				ps:dataRes.ps,
							// 				ex1:dataRes.ex1,
							// 				totalNum: 141
							// 			})
							// 		}else{ 
							// 			bt.soft.install('task_manager')
							// 		}
							// 	})
							// }
					});})
          //展示收起
          $(layero)
            .find('.disk-item-header')
            .on('click', function () {
              if($(this).parent().hasClass('base_html')) return;
              if ($(this).parent().hasClass('active')) {
									$(this).parent().removeClass('active');
									$(this).find('span').text('展开');
									$(this).find('img').removeAttr('style');
              } else {
                $(this).parent().addClass('active');
								$(this).find('span').text('折叠');
                $(this).find('img').css('transform', 'rotate(180deg)');
              }
              var name = $(this).parents('.layui-layer-content').prop('id') + '_' + $(this).parents('.disk-item-list').prop('id')
              bt.set_storage(name, $(this).parent().hasClass('active') ? 1 : '')
            });
        },
			});
    }
    /**
     * 关于浮窗如何取消的一系列动作
     * @param dom_point
     * @param father_point
     * @param open
     */
    var cancel_float_box = function (dom_point, father_point) {
      if (postion_time) {
        clearInterval(postion_time);
      }
      //监听鼠标是否在浮窗内
			// return
      postion_time = setInterval(function () {
        if ($(dom_point).length != 0) {
          var diskX = $(dom_point).offset().left,
            diskY = $(dom_point).offset().top,
            diskW = $(dom_point).width(),
            diskH = $(dom_point).height();
          var diskChartY = $(father_point).offset().top,
            diskChartX = $(father_point).offset().left,
            diskChartW = $(father_point).width(),
            diskChartH = $(father_point).height();
          var is_move_disk = mouseX >= diskChartX && mouseX <= diskChartX + diskChartW && mouseY >= diskChartY && mouseY <= diskChartY + diskChartH;
          var is_move = mouseX >= diskX && mouseX <= diskX + diskW && mouseY >= diskY && mouseY <= diskY + diskH;
          if (!is_move && !is_move_disk && !table_confirm_show) {
            $(dom_point).remove();
            clearTimeout(time)
            clearInterval(layer_table_time)
          }
        } else {
          clearInterval(postion_time);
        }
      }, 200);
    }

		
    // _this.get_disk_list();
    // _this.get_server_info();
    if (bt.os != 'Linux') $(".loadbox").hide();
    $('.secCount').bind('click', '.secInfo', function () {
      layer.open({
        type: 1,
        title: '安全风险',
        area: ['800px', '712px'],
        shadeClose: false,
        closeBtn: 2,
        content: '<div class="secScanning"></div>',
        success: function (layers, index) {
          render_sec_list();
        }
      })
    })
    function render_sec_list(data) {
      bt_tools.send({url:'/panel_sec?action=start_san',data:data},function (res){
        var _head = '', _secConter = '', _data = res.list
        _head = '<div class="secHead"><div class="secHeadLeft"><p class="secHeadTitle">本次扫描共检测出 <font style="color:red">' + res.count + '</font> 个安全风险，请及时修复.</p><p class="secHeadTime">检测时间：' + bt.format_data(res.time) + '（如果已经修复，请重新检测）</p></div><div class="pull-right secRestart"><a href="javascript:void(0)" id="secRestart">重新检测</a></div></div>'
        _secConter = '<div class="secConter">'

        for (var i = 0; i < _data.length; i++) {
          var _child_list = _data[i].list;
          _secConter += '<div class="sec_list"><div class="sec_list_title"><span>' + (i + 1) + '.&nbsp;' + _data[i]['name'] + '【' + (_data[i].status == 0 ? '<span style="color:red">共 ' + _child_list.length + ' 项未处理</span>' : '<span style="color:#20a53a">已处理</span>') + '】</span><i class="pull_down"></i></div><dl class="sec_list_conter">';

          if (_data[i]['status'] == 0) {
            for (var j = 0; j < _child_list.length; j++) {
              _secConter += '<dd><span class="secOverflow">•&nbsp;&nbsp;&nbsp;&nbsp;' + _child_list[j]['title'] + '</span>' + _this.sec_switch(_child_list[j]['level']) + '</dd>'
            }
          } else {
            _secConter += '<dd style="color:#c0c0c0">【无安全风险】</dd>';
          }
          _secConter += '</dl></div>'
        }
        _secConter += '</div>'

        $('.secScanning').html(_head + _secConter);
        //设置前四个默认展开、背景颜色
        $(".secConter .sec_list_title i:lt(4)").addClass('active');
        $(".secConter .sec_list:gt(3)").find('.sec_list_conter').hide();

        $('.sec_list_title').click(function () {
          if ($(this).find('i').hasClass('active')) {
            $(this).find('i').removeClass('active');
            $(this).siblings('.sec_list_conter').hide();
          } else {
            $(this).find('i').addClass('active');
            $(this).siblings('.sec_list_conter').show();
          }
        })
        $('#secRestart').click(function () {
          render_sec_list({ force: 1 });
        })
      },{ load: '扫描文件' })
    }

		_this.reander_system_info(function (rdata,_this) {
      // cpu悬浮事件
      $('#cpuChart').hover(
        function () {
          float_box({
            table: {
              type: 'CPU_high_occupancy_software_list',
              table_title: ['CPU占用率', '运行时间'],
              table_fid: ['cpu_percent', 'run_time'],
            },
            html: {
              base_html:
                '\
                <div class="disk-body-list">\
                  <span>' + rdata.cpu[3] + '</span>\
                </div>\
                <div class="disk-body-list">\
                  <span>' + rdata.cpu[5] + '个物理CPU，' + rdata.cpu[4] * rdata.cpu[5] + '个物理核心，' + rdata.cpu[1] + '线程</br>' + '</span>\
								</div>',
              title: '核心使用率',
              disk_title: 'CPU占用TOP5的进程信息',
              cpu_times: rdata.cpu[2],
              isShow: bt.get_cookie('ltd_end') > 0,
							typeName: 'CPU',
              table_id: 'loadCPUTable',
              position: '#cpuChart',
              newClass: 'load_CPU_tips_point'
            }
          })
        },
        function () {
          cancel_float_box('.load_CPU_tips_point', '#cpuChart')
        }
      )
			$('#memChart').hover(
        function () {
					var mem = _this.chart_result.mem || rdata;
          float_box({
            table: {
              type: 'memory_high_occupancy_software_list',
              table_title: ['内存占用', '运行时间'],
              table_fid: ['mem', 'run_time'],
            },
            html: {
              base_html: '<div class="disk-body-list">\
                    <span>可用内存：</span>\
                    <span id="mem_Free">' + rdata.mem.memFree + 'MB</span>\
                </div>',
              slot: '<div id="mem-info-show" class="mem-title">\
              <span>检测到当前内存【<span class="mem_text ' +
              (((rdata.mem.memRealUsed / rdata.mem.memTotal) * 100).toFixed(2) >= 80 ? (((rdata.mem.memRealUsed / rdata.mem.memTotal) * 100).toFixed(2) >= 90 ? 'color-red' : 'color-org') : 'color-green') +
              '">' +
              (((rdata.mem.memRealUsed / rdata.mem.memTotal) * 100).toFixed(2) >= 80 ? '内存不足' : '内存充足') +
              '</span>】</span>\
                          <button type="button" title="立即清理" class="btn btn-success " id="mem_scanning_btn">立即清理</button></div>',
              disk_title: '内存占用TOP5的进程信息',
							typeName: '内存',
              table_id: 'loadMEMTable',
              position: '#memChart',
              newClass: 'load_MEM_tips_point'
            }
          })
        },
        function () {
          cancel_float_box('.load_MEM_tips_point', '#memChart')
        }
      )
			// 磁盘悬浮事件
			var is_remove_disk = [],idx = 0,taskStatus = []//扫描状态
			for (var i = 0; i < rdata.disk.length; i++) {
				is_remove_disk.push(true)
				taskStatus.push(false)
				var mouseX = 0, mouseY = 0;
				$(document).mousemove(function (e) {
					mouseY = e.pageY
					mouseX = e.pageX 
				})
				var diskInterval = null
				$('#diskChart' + i).data('disk',rdata.disk[i]).hover(function () {
					var disk = $(this).data('disk')
					clearInterval(diskInterval)
					var top = $(this).offset().top
					left = $(this).offset().left
					used_size = parseFloat(disk.size[3].substring(0, disk.size[3].lastIndexOf("%"))).toFixed(1);
					idx = $(this).prop('id').replace('diskChart', '')
					for(var i = 0;i < is_remove_disk.length;i++){
						if(i !== parseInt(idx) && is_remove_disk[i]) {
							$('.disk_scanning_tips'+ i).remove()
						}
					}
					
					if(!$('.disk_scanning_tips'+ idx).length) {
						layer.open({
							type: 1,
							closeBtn: 1,
							shade: 0,
							area: '340px',
							title: false,
							skin: 'disk_scanning_tips disk_scanning_tips'+ idx,
							content: '<div class="pd16 disk_scanning" data-index="'+ idx +'">\
													<div class="disk_cont">\
                            <div class="disk-title">\
                              <span>检测到当前磁盘【<span class="'+ ( used_size >= 80 ? used_size >= 90 ? 'color-red' : 'color-org' : 'color-green' ) +'">'+ ( used_size >= 80 ? '空间不足' : '空间充足' )  +'</span>】</span>\
                              <button type="button" data-path="'+ disk.path +'" title="立即清理" class="btn btn-success disk_scanning_btn">立即清理</button></div>\
                            <div class="disk-item-list active">\
															<div class="disk-item-header">\
																<div class="disk-header-title">基础信息</div>\
																<div class="disk-header-fold">\
																	<span>折叠</span>\
																	<img src="/static/img/arrow-down.svg">\
																</div>\
															</div>\
															<div class="disk-item-body">\
                                <div class="disk-body-list more_wrap"><div>挂载点：'+disk.path+'</div></div>\
																<div class="disk-body-list use_disk" style="margin-top: 6px;white-space: pre-line;">可用：'+ parseFloat(disk.size[2])+' ' + disk.size[2].replace(parseFloat(disk.size[2]),'') +'，共：'+ parseFloat(disk.size[0]) + ' ' + disk.size[0].replace(parseFloat(disk.size[0]),'')+'\n已用：'+ parseFloat(disk.size[1]) + ' ' +disk.size[1].replace(parseFloat(disk.size[1]),'') +'，磁盘已使用：'+disk.size[3]  +'</div>\
															</div>\
														</div>\
													</div>\
													<div class="disk_scan_cont hide">\
														<div class="disk-scan-header">\
															<button type="button" title="后退" class="btn btn-default disk_back_btn" data-index="'+ idx +'" ><span class="disk_back_icon"></span><span>后退</span></button>\
															<div>磁盘扫描</div>\
														</div>\
														<div class="disk-scan-view hide">\
															<pre id="scanProgress">正在获取扫描日志</pre>\
														</div>\
														<div class="disk-file-view hide">\
														<div class="disk-file-load" style="position:absolute;width: 100%;height: 100%;top: 0;left:0;display: none;z-index: 99999999;background:rgba(0,0,0,0.3);align-items:center;justify-content: center;">\
																<div class="pd15" style="background: #fff;">\
																	<img src="/static/img/loading.gif" class="mr10">\
																	<span>正在获取文件信息，请稍后...</span>\
																</div>\
															</div>\
															<div class="filescan-nav" id="fileScanPath"></div>\
															<div class="filescan-list" id="fileScanTable">\
																<div class="filescan-list-title">\
																	<div class="filescan-list-title-item text-left">文件名</div>\
																	<div class="filescan-list-title-item">大小</div>\
																	<div class="filescan-list-title-item text-right">操作</div>\
																</div>\
																<div class="filescan-list-body"></div>\
															</div>\
														</div>\
													</div>\
												</div>',
							success: function (layero, index) {
								is_remove_disk[idx] = true
								// $(layero).find('.layui-layer-close2').addClass('layui-layer-close1').removeClass('layui-layer-close2');
								$(layero).find('.layui-layer-close2').remove()
								$(layero).css({
									'top': (top+140 - $(window).scrollTop()) +'px',
									'left': left - 160,
								})
								$(window).resize(function () {
									for(var i = 0;i < is_remove_disk.length;i++){
										if($('.disk_scanning_tips'+ i).length){
												$('.disk_scanning_tips'+ i).css({
												'top': ($("#diskChart" + i).offset().top+140 - $(window).scrollTop()) +'px',
												'left': $("#diskChart" + i).offset().left - 160,
											})
										}
									}
								})
								$(window).scroll(function () {
									$(layero).css({
										'top': ($("#diskChart" + idx).offset().top+140 - $(window).scrollTop()) +'px',
										'left': $("#diskChart" + idx).offset().left - 160,
									})
								})
								var id = null, // 扫描id
										taskPath = '', // 扫描目录
										taskList = {}; // 扫描缓存列表
								// 后退
								$(layero).find('.disk_back_btn').on('click', function () {
									var path = $(this).data('path'),
											index = $(this).data('index')
									if(path !== undefined && path !== 'undefined'){
										if(path === '') {
											$(layero).find('.filescan-nav-item.present').click()
											$(this).data('path', 'undefined');
										}else{
											var rdata = taskList[path.replace('//','/')];
											renderFilesTable(rdata, path); // 渲染文件表格
											renderFilesPath(path); // 渲染文件路径
										}
									}else{
										if(taskStatus[index]) {
											layer.confirm(
												'取消扫描，将会中断当前扫描目录进程，是否继续？',
												{
													title: '取消扫描',
													closeBtn: 2,
													icon: 3,
												},
												function (indexs) {
													taskStatus[index] = false;
													layer.close(indexs);
													cancelScanTaskRequest(id, function (rdata) {
														if (!rdata.status) return bt_tools.msg(rdata);
														renderInitView();
													});
												}
											);
										}else{
											renderInitView();
										}
									}
								})
								$(layero)
								.find('.disk-item-header')
								.on('click', function () {
									if ($(this).parent().hasClass('active')) {
										// 普通用户不显示进程信息，样式不发生更改
											$(this).parent().removeClass('active');
											$(this).find('span').text('展开');
											$(this).find('img').removeAttr('style');
									} else {
										$(this).parent().addClass('active');
										$(this).find('span').text('折叠');
										$(this).find('img').css('transform', 'rotate(180deg)');
									}
								});
								/**
									* @description 渲染扫描初始化页面
									*/
								function renderInitView() {
									id = null
									taskStatus[idx] = false
									taskPath = ''
									taskList = {}
									$(layero).find('.disk_cont').removeClass('hide').siblings('.disk_scan_cont').addClass('hide');
									$(layero).find('.layui-layer-close1').show()
									$(layero).find('.disk-file-view,.disk-scan-view').addClass('hide');
									$(layero).find('.disk-file-load').css('display','none')
								}
								
								 // 扫描
								 $(layero).find('.disk_scanning_btn').unbind('click').on('click', function () {
                  // if(taskStatus.some(function (item){ return item === true })) {
                    // if(bt.get_cookie('taskStatus') === 'true') {
                    //   return layer.tips('有任务在执行，请稍后再操作！', $(this), {tips: [3, '#f00']});
                    // }
                    is_remove_disk[idx] = false;
                    var $path = $(this).data('path');
                    //判断是否安装插件
                    bt.soft.get_soft_find('disk_analysis',function(dataRes){
                      if(dataRes.setup && dataRes.endtime > 0) {
                        layer.closeAll()
                        bt.set_cookie('diskPath', $path)
                        bt.set_cookie('taskStatus', true)
                        bt.soft.set_lib_config(dataRes.name,dataRes.title,dataRes.version)
											}else{
												// var item = {
												// 	name: 'disk_analysis',
												// 	pluginName: '堡塔硬盘分析工具',
												// 	title:'堡塔硬盘分析工具',
												// 	ps: '急速分析磁盘/硬盘占用情况',
												// 	preview: false,
												// 	limit: 'ltd',
												// 	description:['检测硬盘空间','占用百分比显示'],
												// 	imgSrc:'https://www.bt.cn/Public/new/plugin/disk_analysis/1.png'
												// }
												// product_recommend.recommend_product_view(item, {
												// 	imgArea: ['783px', '718px']
												// },'ltd',120,item.name)
												var is_buy = dataRes.endtime < 0 && dataRes.pid > 0
												// $('.buyNow').text(is_buy ? '立即购买' : '立即安装').unbind('click').click(function () {
													if(is_buy) {
														// bt.soft.product_pay_view({
														// 	name:dataRes.title,
														// 	pid:dataRes.pid,
														// 	type:dataRes.type,
														// 	plugin:true,
														// 	renew:-1,
														// 	ps:dataRes.ps,
														// 	ex1:dataRes.ex1,
														// 	totalNum:120
														// })
                            bt.soft.updata_ltd(undefined,120)
													}else{ 
														bt.soft.install('disk_analysis')
													}
												// })
											}})
									})
							},
							cancel: function(index,layero){
									if(taskStatus[$(layero).find('.disk_scanning').data('index')]){
										layer.confirm(
											'取消扫描，将会中断当前扫描目录进程，是否继续？',
											{
												title: '取消扫描',
												closeBtn: 2,
												icon: 3,
											},
											function (indexs) {
												taskStatus[$(layero).find('.disk_scanning').data('index')] = false
												layer.close(indexs);
												layer.close(index)
												cancelScanTaskRequest($(layero).find('.disk_scanning').data('id'), function (rdata) {
													if (!rdata.status) return bt_tools.msg(rdata);
												});
											}
										);
										return false
								}
							}
						})
					}
					/**
						* @description 删除扫描任务
						* @param {string} id 任务id
						* @param {function} callback 回调函数
						*/
					function cancelScanTaskRequest(id, callback) {
						bt_tools.send(
							'task/remove_task',
							{
								id: id,
							},
							function (rdata) {
								if (callback) callback(rdata);
							},
							{
								load: '取消扫描任务',
							}
						);
					}
				},function () {
					diskInterval = setInterval(function () {
						if($('.disk_scanning_tips'+idx).length) {
							var diskX = $('.disk_scanning_tips'+idx).offset().left,diskY = $('.disk_scanning_tips'+idx).offset().top,
									diskW = $('.disk_scanning_tips'+idx).width(),diskH = $('.disk_scanning_tips'+idx).height()
							var diskChartY = $('#diskChart' + idx).offset().top,diskChartX = $('#diskChart' + idx).offset().left,
									diskChartW = $('#diskChart' + idx).width(),diskChartH = $('#diskChart' + idx).height()
							var is_move_disk = mouseX >= diskChartX && mouseX <= diskChartX + diskChartW && mouseY >= diskChartY && mouseY <= diskChartY + diskChartH
							var is_move = mouseX >= diskX && mouseX <= diskX + diskW && mouseY >= diskY && mouseY <= diskY + diskH
							if(!is_move && !is_move_disk) {
								$('.disk_scanning_tips'+ idx).remove()
							}
						}else{
							clearInterval(diskInterval)
						}
					}, 500)
				})
				if($('.disk_scanning_tips'+i).length){
					var disk =  $('#diskChart' + i).data('disk')
					var size3 = parseFloat(disk.size[3].substring(0, disk.size[3].lastIndexOf("%")))
					$('.disk_scanning_tips' + i +' .disk-body-list .progressBar span').text(disk.size[3]).css({
						left: (size3 < 12 ? (size3 + 2) : (size3 - 11)) +'%;',
						color: size3 < 12 ? '#666;' : '#fff'
					})
					var progressCss = {
						width: disk.size[3],
					}
					if(size3 === 100) progressCss.borderRadius = '2px'
					$('.disk_scanning_tips' + i +' .disk-body-list .progressBar .progress').css(progressCss)
					$('.disk_scanning_tips' + i +' .disk-body-list .progressBar .progress').removeClass('bg-red bg-org bg-green').addClass(size3 >= 80 ? size3 >= 90 ? 'bg-red' : 'bg-org' : 'bg-green')
					$('.disk_scanning_tips' + i +' .disk-body-list.use_disk').html(parseFloat(disk.size[2])+' ' + disk.size[2].replace(parseFloat(disk.size[2]),'') +'可用，'+ parseFloat(disk.size[1]) + ' ' +disk.size[1].replace(parseFloat(disk.size[1]),'') +'已用，共'+ parseFloat(disk.size[0]) + ' ' + disk.size[0].replace(parseFloat(disk.size[0]),''))
					$('.disk_scanning_tips' + i +' .disk-body-list.inodes0').html('Inode总数：'+ disk.inodes[0])
					$('.disk_scanning_tips' + i +' .disk-body-list.inodes1').html('Inode已用：'+ disk.inodes[1])
					$('.disk_scanning_tips' + i +' .disk-body-list.inodes2').html('Inode可用：'+ disk.inodes[2])
					$('.disk_scanning_tips' + i +' .disk-body-list.inodes3').html('Inode使用率：'+ disk.inodes[3])
				}
			}
			_this.get_server_info(rdata);
			if (rdata.installed === false) bt.index.rec_install();
			if (rdata.user_info.status) {
				var rdata_data = rdata.user_info.data;
				bt.set_cookie('bt_user_info', JSON.stringify(rdata.user_info));
				$(".bind-user").html(rdata_data.username + '<a href="javascript:bt.pub.bind_btname();" class="btlink" style="margin-left: 5px;">更换</a>');
			}
			else {
				$(".bind-weixin a").attr("href", "javascript:;");
				$(".bind-weixin a").click(function () {

					bt.msg({ msg: '请先绑定宝塔账号!', icon: 2 });
				})
			}
			
    })

    _this.interval.start();

    setTimeout(function () {
      _this.net.init();
      $.post('/panel_sec?action=start_san', function (res) {
        var _html = ''
        if (res.count > 0) {
          _html = '<a style="color:red" class="secInfo" href="javascript:void(0)">' + res.count + '</a>'
        } else {
          _html = '<a style="color:#20a53a" class="secInfo" href="javascript:void(0)">' + res.count + '</a>'
        }
        $('.secCount .val').html(_html);
      })
    }, 200);

    /*setTimeout(function () {
      bt.system.check_update(function (rdata) {
        index.consultancy_services(rdata.msg.adviser);
        index.show_recommend(rdata.msg.is_rec);
        if (rdata.status !== false) {
          var res = rdata.msg, beta = res.beta, is_beta = res.is_beta, ignore = res.ignore;
          if (ignore.indexOf(is_beta ? beta.version : res.version) == -1) index.check_update(true) // 判断自动升级
          $('#toUpdate a').html('更新<i style="display: inline-block; color: red; font-size: 40px;position: absolute;top: -35px; font-style: normal; right: -8px;">.</i>');
          $('#toUpdate a').css("position", "relative");
        }
        if (rdata.msg.is_beta === 1) {
          $('#btversion').prepend('<span style="margin-right:5px;">Beta</span>');
          $('#btversion').append('<a class="btlink" href="https://www.bt.cn/bbs/forum-39-1.html" target="_blank">  [找Bug奖宝塔币]</a>');
        }

      }, false)
    }, 1500)*/
  },

	/**
 * @description 渲染系统信息
 * @param rdata 接口返回值
 *
 */
	reander_system_info: function (callback) {
		var _this = this;
		var start_time = new Date().getTime();
		bt.system.get_net(function (net) {
			var res = net;
			_this.chart_result = res
			// 动态添加磁盘，并赋值disk_view
			if (_this.chart_view.disk == undefined) {
				for (var i = 0; i < res.disk.length; i++) {
					var diskHtml = "<li class='rank col-xs-6 col-sm-3 col-md-3 col-lg-2 mtb20 circle-box text-center'><div id='diskName" + i + "' class='diskName'></div><div class='chart-li' id='diskChart" + i + "'></div><div id='disk" + i + "'></div></li>";
					$("#systemInfoList").append(diskHtml);
					_this.disk_view.push(echarts.init(document.querySelector("#diskChart" + i)));
				}
			}

			// cpu
			var cpuCount = res.cpu[0];
			var cpuInfo = _this.chart_color_active(cpuCount);
			// if(_this.chart_result && _this.chart_result.cpu){
			// 	$("#disk-body-cpu-array").html((function(){
			// 		var data = _this.chart_result.cpu[2];
			// 		var crs = '';
			// 		var index = 0;
			// 		for (var i = 0; i < data.length; i++) {
			// 			index++;
			// 			crs += 'CPU-' + i + ": " +data[i] + '%' + (index % 4 == 0 ? '</br>' : ' | ');
			// 		}
			// 		return crs
			// 	})());
			// }
      //实时刷新cpu弹窗数据
      $('.cpu_text').text((cpuCount >= 80 ? '占用过高' : cpuCount+'%')).removeClass('color-red color-org color-green').addClass((cpuCount >= 80 ? (cpuCount >= 90 ? 'color-red' : 'color-org') : 'color-green'))
      for (var i = 0; i < res.cpu[2].length; i++) {
        $('#cpu_'+ (i+1) +'_num').text(res.cpu[2][i] + '% / ' + res.cpu[2][i+1] + '%')
        i++
      }

			// 内存
			var memCount = Math.round((res.mem.memRealUsed / res.mem.memTotal) * 1000) / 10; // 返回 memRealUsed 占 memTotal 的百分比
			var memInfo = _this.chart_color_active(memCount);
			bt.set_cookie('memSize', res.mem.memTotal)
      //实时刷新内存弹窗数据
      $('.mem_text').text((memCount >= 80 ? '内存不足' : '内存充足')).removeClass('color-red color-org color-green').addClass(memCount >= 80 ? memCount >= 90 ? 'color-red' : 'color-org' : 'color-green')
      $('#mem_Free').text(res.mem.memFree+ 'MB')
			
			$("#mem-info-show div").html(((res.mem.memRealUsed / res.mem.memTotal) * 100).toFixed(2) >= 80 ? '内存不足' : '内存充足')
			$("#mem-info-show div").attr('class',((res.mem.memRealUsed / res.mem.memTotal) * 100).toFixed(2) >= 80 ? (((res.mem.memRealUsed / res.mem.memTotal) * 100).toFixed(2) >= 90 ? 'bg-red' : 'bg-org') : 'bg-green')
			// 磁盘
			var diskList = res.disk;
			var diskJson = [];
			for (var i = 0; i < diskList.length; i++) {
				var ratio = diskList[i].size[3];
				ratio = parseFloat(ratio.substring(0, ratio.lastIndexOf("%")));
				var diskInfo = _this.chart_color_active(ratio)
				diskJson.push(diskInfo)
			}

			// chart_json存储最新数据
			_this.chart_json['cpu'] = cpuInfo;
			_this.chart_json['mem'] = memInfo;
			_this.chart_json['disk'] = diskJson
			// 初始化 || 刷新
			if (_this.chart_view.disk == undefined) {
				_this.init_chart_view()
			} else {
				_this.set_chart_data()
			}
			$('.rank .titles').show()

      var net_key = bt.get_cookie('network_io_key');
      if (net_key) {
        net.up = net.network[net_key].up;
        net.down = net.network[net_key].down;
        net.downTotal = net.network[net_key].downTotal;
        net.upTotal = net.network[net_key].upTotal;
        net.downPackets = net.network[net_key].downPackets;
        net.upPackets = net.network[net_key].upPackets;
        net.downAll = net.network[net_key].downTotal;
        net.upAll = net.network[net_key].upTotal;
      }

      var net_option = '<option value="all">全部</option>';
      $.each(net.network, function (k, v) {
        var act = (k == net_key) ? 'selected' : '';
        net_option += '<option value="' + k + '" ' + act + '>' + k + '</option>';
      });

      $('select[name="network-io"]').html(net_option);


      //刷新流量
      $("#upSpeed").html(net.up.toFixed(2) + ' KB');
      $("#downSpeed").html(net.down.toFixed(2) + ' KB');
      $("#downAll").html(bt.format_size(net.downTotal));
      $("#upAll").html(bt.format_size(net.upTotal));
      index.net.add(net.up, net.down);
      if (index.net.table) index.net.table.setOption({ xAxis: { data: index.net.data.aData }, series: [{ name: lan.index.net_up, data: index.net.data.uData }, { name: lan.index.net_down, data: index.net.data.dData }] });

    	//请求成功后，重新调用该方法
			if(res&&!callback) {
				var end_time = new Date().getTime();
				var timeout = end_time - start_time
				setTimeout(function () {
					_this.reander_system_info()
				},timeout > 3000 ? timeout : 3000)
			}
			if (callback){
				callback(res,_this)
			}
		});
	},

  sec_switch: function (str) {
    switch (str) {
      case 5:
        return '<sapn style="color:red;float: right;margin-right: 80px;">高危</span>'
      case 4:
        return '<sapn style="color:#ffc107;float: right;margin-right: 80px;">中危</span>'
      case 3:
        return '<sapn style="color:#ffeb3b;float: right;margin-right: 80px;">低危</span>'
      case 2:
        return '<sapn style="color:#666;float: right;margin-right: 80px;">警告</span>'
      case 0:
        return '<sapn style="color:#20a53a;float: right;margin-right: 80px;">健康</span>'
    }
  },

  get_server_info: function () {
    bt.system.get_total(function (info) {
      var memFree = info.memTotal - info.memRealUsed;
      if (memFree < 64) {
        $("#messageError").show();
        $("#messageError").append('<p><span class="glyphicon glyphicon-alert" style="color: #ff4040; margin-right: 10px;">' + lan.index.mem_warning + '</span> </p>')
      }

      if (info.isuser > 0) {
        $("#messageError").show();
        $("#messageError").append('<p><span class="glyphicon glyphicon-alert" style="color: #ff4040; margin-right: 10px;"></span>' + lan.index.user_warning + '<span class="c7 mr5" title="此安全问题不可忽略，请尽快处理" style="cursor:no-drop"> [不可忽略]</span><a class="btlink" href="javascript:setUserName();"> [立即修改]</a></p>')
      }
      var _system = info.system;

      var py_key = 'Py3.6.6'
      if (_system.indexOf(py_key) != -1) {
        _system = _system.replace(py_key, "<a class='py_version' style='color:red' href='javascript:;'>" + py_key + " - 版本过低</a>")
      }

      $("#info").html(_system);
      $("#running").html(info.time);
      if (_system.indexOf("Windows") != -1) {
        $(".ico-system").addClass("ico-windows");
      }
      else if (_system.indexOf("CentOS") != -1) {
        $(".ico-system").addClass("ico-centos");
      }
      else if (_system.indexOf("Ubuntu") != -1) {
        $(".ico-system").addClass("ico-ubuntu");
      }
      else if (_system.indexOf("Debian") != -1) {
        $(".ico-system").addClass("ico-debian");
      }
      else if (_system.indexOf("Fedora") != -1) {
        $(".ico-system").addClass("ico-fedora");
      }
      else {
        $(".ico-system").addClass("ico-linux");
      }

      $(".py_version").click(function () {
        var loading = bt.open({
          type: 1,
          area: '640px',
          title: '面板环境升级',
          skin: 'layui-layer-dialog',
          content: '<div class="setchmod bt-form" style="padding-top: 15px;">\
                            <div class="update_title" style="margin-bottom: 15px;">\
                                <i class="layui-layer-ico layui-layer-ico0" style="margin-left: 22px;margin-top: 15px;"></i>\
                                <span style="margin-left: 58px;font-size: 15px;font-weight: 500;color: #ec3939;">当前面板Python版本过低，部分功能将无法正常使用！</span></div>\
                            <div class="update_body" style="padding: 20px 30px;background: #fcfcfc;border: 1px solid #ececec;border-radius: 12px;width: 580px;margin: 0 auto;line-height:30px;">\
                                <div class="update_body_item" style="color: #ec3939;">由于现有环境 Py3.6.6 官方将于2021年底停止维护，需升级Python版本至 Py3.8.6<br>面板无法完成自动升级，请按照步骤升级：</div>\
                                <div class="update_body_item">1. 下载所需文件到远程服务器，<a href="javascript:;" class="btlink down_url" >立即下载文件</a></div>\
                                <div class="update_body_item">2. 通过远程桌面连接至服务器</div>\
                                <div class="update_body_item"><span>3. CMD命令行执行升级脚本</span><pre style="vertical-align: middle;padding:5px;margin: 0 6px;display:none"></pre></div>\
                            </div>\
                        </div>',
          success: function () {
            $('.down_url').click(function () {
              var loadT = layer.msg('正在执行下载至远程服务器，请稍后...', { icon: 16, time: 0, shade: .3 });
              bt.send('ajax', 'ajax/update_python', {}, function () {
                layer.close(loadT);
                $('.update_body_item pre').text(setup_path + '/update/update.bat').css('display', 'inline-block');
              });
            });
          }
        })
      })
    })
  },
  get_disk_list: function () {
    bt.system.get_disk_list(function (rdata) {
      if (rdata) {
        var data = { table: '#systemInfoList', items: [] };
        for (var i = 0; i < rdata.length; i++) {
          var item = rdata[i];
          var obj = {};
          obj.name = item.path;
          obj.title = item.size[1] + '/' + item.size[0];
          obj.rate = item.size[3].replace('%', '');
          obj.free = item.size[2];
          var arr = [];
          arr.push({ title: 'Inode信息', value: '' })
          arr.push({ title: '总数', value: item.inodes[0] })
          arr.push({ title: '已使用', value: item.inodes[1] })
          arr.push({ title: '可用', value: item.inodes[2] })
          arr.push({ title: 'Inode使用率', value: item.inodes[3] })

          if (bt.os == 'Linux') obj.masks = arr;
          data.items.push(obj)
        }
        index.render_disk(data);
      }
    })
  },
  render_disk: function (data) {
    if (data.items.length > 0) {
      var _tab = $(data.table);
      for (var i = 0; i < data.items.length; i++) {
        var item = data.items[i];
        var html = '';
        html += '<li class="col-xs-6 col-sm-3 col-md-3 col-lg-2 mtb20 circle-box text-center diskbox">';
        html += '<h3 class="c9 f15">' + item.name + '</h3>';
        html += '<div class="cicle">';
        html += '<div class="bar bar-left"><div class="bar-left-an bar-an"></div></div>';
        html += '<div class="bar bar-right"><div  class="bar-right-an bar-an"></div></div>';
        html += '<div class="occupy"><span>0</span>%</div>';
        html += '</div>';
        html += '<h4 class="c9 f15">' + item.title + '</h4>';
        html += '</li>';
        var _li = $(html);

        if (item.masks) {
          var mask = '';
          for (var j = 0; j < item.masks.length; j++) mask += item.masks[j].title + ': ' + item.masks[j].value + "<br>";
          _li.data('mask', mask);
          _li.hover(function () {
            var _this = $(this);
            layer.tips(_this.data('mask'), _this.find('.cicle'), { time: 0, tips: [1, '#999'] });
          }, function () {
            layer.closeAll('tips');
          })
        }
        var color = '#20a53a';
        if (parseFloat(item.rate) >= 80) color = '#ff9900';
        var size = parseFloat(item.free.substr(0, item.free.length - 1));
        var unit = item.free.substr(item.free.length - 1, 1);
        switch (unit) {
          case 'G':
            if (size < 1) color = '#dd2f00';
            break;
          case 'T':
            if (size < 0.1) color = '#dd2f00';
            break;
          default:
            color = '#20a53a'
            break;
        }
        index.set_val(_li, { usage: item.rate, color: color })
        _tab.append(_li);
      }
    }
  },
  set_val: function (_li, obj) {
    //obj.usage = parseInt(obj.usage)
    if (obj.usage > 50) {
      setTimeout(function () { _li.find('.bar-right-an').css({ "transform": "rotate(45deg)", "transition": "transform 750ms linear" }); }, 10)
      setTimeout(function () { _li.find('.bar-left-an').css({ "transform": "rotate(" + (((obj.usage - 50) / 100 * 360) - 135) + "deg)", "transition": "transform 750ms linear" }); }, 760);
    } else {
      if (parseInt(_li.find('.occupy span').html()) > 50) {
        setTimeout(function () { _li.find('.bar-right-an').css({ "transform": "rotate(" + ((obj.usage / 100 * 360) - 135) + "deg)", "transition": "transform 750ms linear" }) }, 760);
        setTimeout(function () { _li.find('.bar-left-an').css({ "transform": "rotate(-135deg)", "transition": "transform 750ms linear" }) }, 10)
      } else {
        setTimeout(function () { _li.find('.bar-right-an').css({ "transform": "rotate(" + ((obj.usage / 100 * 360) - 135) + "deg)", "transition": "transform 750ms linear" }); }, 10)
      }
    }
    if (obj.items) {
      var item = {};
      for (var i = 0; i < obj.items.length; i++) {
        if (obj.usage <= obj.items[i].val) {
          item = obj.items[i];
          continue;
        }
        break;
      }
      if (item.title) obj.title = item.title;
      if (item.color) obj.color = item.color;
    }
    if (obj.color) {
      _li.find('.cicle .bar-left-an').css('border-color', 'transparent transparent ' + obj.color + ' ' + obj.color);
      _li.find('.cicle .bar-right-an').css('border-color', obj.color + ' ' + obj.color + ' transparent transparent');
      _li.find('.occupy').css('color', obj.color);
    }
    if (obj.title) _li.find('h4').text(obj.title);
    _li.find('.occupy span').html(obj.usage);
  },
	  /**
   * @description 渲染画布视图
   *
   */
		init_chart_view: function () {
			// 所有图表对象装进chart_view
			this.chart_view['cpu'] = echarts.init(document.querySelector("#cpuChart"))
			this.chart_view['mem'] = echarts.init(document.querySelector("#memChart"))
			this.chart_view['disk'] = this.disk_view
	
			// 图表配置项
			this.series_option = {
				series: [{
					type: 'gauge',
					startAngle: 90,
					endAngle: -270,
					animationDuration: 1500,
					animationDurationUpdate: 1000,
					radius: '99%',
					pointer: {
						show: false
					},
					progress: {
						show: true,
						overlap: false,
						roundCap: true,
						clip: false,
						itemStyle: {
							borderWidth: 1,
							borderColor: '#20a53a'
						}
					},
					axisLine: {
						lineStyle: {
							width: 7,
							color: [[0, "rgba(204,204,204,0.5)"], [1, "rgba(204,204,204,0.5)"]]
						}
					},
					splitLine: {
						show: false,
						distance: 0,
						length: 10
					},
					axisTick: {
						show: false
					},
					axisLabel: {
						show: false,
						distance: 50
					},
					data: [{
						value: 0,
						detail: {
							offsetCenter: ['0%', '0%']
						},
						itemStyle: {
							color: '#20a53a',
							borderColor: '#20a53a'
						},
					}],
					detail: {
						width: 50,
						height: 15,
						lineHeight: 15,
						fontSize: 17,
						color: '#20a53a',
						formatter: '{value}%',
						fontWeight: 'normal'
					}
				}]
			};
			this.set_chart_data()
		},
		/**
		 * @description 赋值chart的数据
		 *
		 */
		set_chart_data: function () {
			this.chart_active("cpu")
			if (!this.release) {
				this.chart_active("mem")
			}
			for (var i = 0; i < this.chart_view.disk.length; i++) {
				this.series_option.series[0].data[0].value = this.chart_json.disk[i].val
				this.series_option.series[0].data[0].itemStyle.color = this.chart_json.disk[i].color
				this.series_option.series[0].data[0].itemStyle.borderColor = this.chart_json.disk[i].color
				this.series_option.series[0].progress.itemStyle.borderColor = this.chart_json.disk[i].color
				this.series_option.series[0].detail.color = this.chart_json.disk[i].color
				this.chart_view.disk[i].setOption(this.series_option, true)
				$("#disk" + i).text(this.chart_result.disk[i].size[1] + " / " + this.chart_result.disk[i].size[0])
				$("#diskName" + i).text(this.chart_result.disk[i].path).attr('title', this.chart_result.disk[i].path)
			}
		},
		/**
		 * @description 赋值chart的数据
		 *
		 */
		chart_active: function (name) {
			// 图表数据
			this.series_option.series[0].data[0].value = this.chart_json[name].val
			this.series_option.series[0].data[0].itemStyle.color = this.chart_json[name].color
			this.series_option.series[0].data[0].itemStyle.borderColor = this.chart_json[name].color
			this.series_option.series[0].progress.itemStyle.borderColor = this.chart_json[name].color
			this.series_option.series[0].detail.color = this.chart_json[name].color
	
			this.chart_view[name].setOption(this.series_option, true)
	
			// 文字
			var val = ""
			switch (name) {
				case 'load':
					val = this.chart_json[name].title
					break;
				case 'cpu':
					val = this.chart_result.cpu[1] + ' 核心'
					break;
				case 'mem':
					val = this.chart_result.mem.memRealUsed + " / " + this.chart_result.mem.memTotal + "(MB)"
					break;
			}
	
			$("#" + name).text(val)
		},
		/**
		 * @description 赋值chart的颜色
		 *
		 */
		chart_color_active: function (number) {
			var activeInfo = {};
			for (var i = 0; i < this.load_config.length; i++) {
				if (number >= this.load_config[i].val) {
					activeInfo = JSON.parse(JSON.stringify(this.load_config[i]));
					break;
				} else if (number <= 30) {
					activeInfo = JSON.parse(JSON.stringify(this.load_config[3]));
					break;
				}
			}
			activeInfo.val = number;
			return activeInfo;
		},
  get_index_list: function () {
    bt.soft.get_index_list(function (rdata) {
      $('.soft_masks').hide();
      var con = '';
      var icon = '';
      var rlen = rdata.length;
      var clickName = '';
      var setup_length = 0;
      var softboxsum = 12;
      var softboxcon = '';
      for (var i = 0; i < rlen; i++) {
        if (rdata[i].setup) {
          setup_length++;
          if (rdata[i].admin) {
            clickName = ' onclick="bt.soft.set_lib_config(\'' + rdata[i].name + '\',\'' + rdata[i].title + '\')"';
          }
          else {
            clickName = 'onclick="soft.set_soft_config(\'' + rdata[i].name + '\')"';
          }
          var icon = rdata[i].name;
          if (bt.contains(rdata[i].name, 'php')) {
            icon = 'php';
            rdata[i].version = '';
          }
          var status = '';
          if (rdata[i].status) {
            status = '<span style="color:#20a53a" class="glyphicon glyphicon-play"></span>';
          } else {
            status = '<span style="color:red" class="glyphicon glyphicon-pause"></span>'
          }
          con += '<div class="col-sm-3 col-md-3 col-lg-3" data-id="' + rdata[i].name + '">\
							<span class="spanmove"></span>\
							<div '+ clickName + '>\
							<div class="image"><img src="/static/img/soft_ico/ico-'+ icon + '.png"></div>\
							<div class="sname">'+ rdata[i].title + ' ' + rdata[i].version + status + '</div>\
							</div>\
						</div>'
        }
      }
      $("#indexsoft").html(con);
      // 推荐安装软件
      try {
        var recomConfig = product_recommend.get_recommend_type(1)
        if (recomConfig) {
          var pay_status = product_recommend.get_pay_status();
          for (var i = 0; i < recomConfig['list'].length; i++) {
            var item = recomConfig['list'][i];
            if (setup_length > softboxsum) break;
            if (pay_status.is_pay && item['install']) continue;
            softboxcon += '<div class="col-sm-3 col-md-3 col-lg-3">\
              <div class="recommend-soft recom-iconfont">\
                <div class="product-close hide">关闭推荐</div>\
                <div class="images"><img src="/static/img/soft_ico/ico-'+ item['name'] + '.png"></div>\
                <div class="product-name">'+ item['title'] + '</div>\
                <div class="product-pay-btn">\
                '+ ((item['isBuy'] && !item['install']) ?
                '<button class="btn btn-sm btn-success home_recommend_btn" style="margin-left:0;" onclick="bt.soft.install(\'' + item['name'] + '\')">立即安装</button>' :
                '<a class="btn btn-sm btn-default mr5 ' + (!item.preview ? 'hide' : '') + '" href="' + item.preview + '" target="_blank">预览</a><button type="submit" class="btn btn-sm btn-success home_recommend_btn" onclick=\"product_recommend.pay_product_sign(\'ltd\',' + item.pay + ',\'' + item.pluginType + '\')\">购买</button>') + '\
                </div>\
              </div>\
            </div>'
            setup_length++;
          }
        }
      } catch (error) {
        console.log(error)
      }
      //软件位置移动
      if (setup_length <= softboxsum) {
        for (var i = 0; i < softboxsum - setup_length; i++) {
          softboxcon += '<div class="col-sm-3 col-md-3 col-lg-3 no-bg"></div>'
        }
      }
      $("#indexsoft").append(softboxcon);
      //软件位置移动
      $("#indexsoft").dragsort({ dragSelector: ".spanmove", dragBetween: true, dragEnd: saveOrder, placeHolderTemplate: "<div class='col-sm-3 col-md-3 col-lg-3 dashed-border'></div>" });
      function saveOrder() {
        var data = $("#indexsoft > div").map(function () { return $(this).attr("data-id"); }).get();
        data = data.join('|');
        bt.soft.set_sort_index(data)
      };
    })
  },
  check_update: function (state) {
    if ($('.layui-layer-dialog').length > 0) return false;
    var loadT = bt.load();
    bt.system.check_update(function (rdata) {
      loadT.close();
      var data = rdata.msg, is_beta = data.is_beta, beta = data.beta, versionData = is_beta ? beta : data, versionType = is_beta ? '测试版' : '正式版'
      if (rdata.status) {
        if (versionData.update_py) {  // windows 平台
          bt.open({
            type: 1,
            area: '520px',
            title: '面板安全更新',
            skin: 'layui-layer-dialog',
            content: '<div class="setchmod bt-form" style="padding-top: 15px;">\
              <div class="update_title" style="margin-bottom: 15px;">\
                <i class="layui-layer-ico layui-layer-ico0" style="margin-left: 22px;margin-top: 15px;"></i>\
                <span style="margin-left: 58px;font-size: 15px;font-weight: 500;color: #ec3939;">当前面板Python版本过低，请立即升级！</span></div>\
              <div class="update_body" style="padding: 20px 30px;background: #fcfcfc;border: 1px solid #ececec;border-radius: 12px;width: 450px;margin: 0 auto;line-height:30px;">\
                <div class="update_body_item" style="color: #ec3939;">当前升级面板Python环境，无法自动升级，请按照步骤升级：</div>\
                <div class="update_body_item">1. 下载所需文件到远程服务器，<a href="javascript:;" class="btlink down_url" >立即下载文件</a></div>\
                <div class="update_body_item">2. 通过远程桌面连接至服务器</div>\
                <div class="update_body_item"><span>3. CMD命令行执行升级脚本</span><pre style="vertical-align: middle;padding:5px;margin: 0 6px;display:none"></pre></div>\
              </div>\
            </div>',
            success: function () {
              $('.down_url').click(function () {
                var loading = bt.load('正在执行下载至远程服务器，请稍后...')
                bt.send('ajax', 'ajax/update_python', {}, function () {
                  loading.close()
                  $('.update_body_item pre').text(setup_path + '/update/update.bat').css('display', 'inline-block')
                })
              })
            }
          })
          return false
        }
      }
      bt.open({
        type: 1,
        title: !rdata.status ? ' 版本更新-' + bt.os + '面板' + versionType : false,
        area: '480px',
        shadeClose: false,
        skin: 'layui-layer-dialog new-layer-update' + (!rdata.status ? '' : ' active'),
        closeBtn: 2,
        content: (!rdata.status ? '' : '<div class="update-title">版本更新-' + bt.os + '面板' + versionType + '</div>\
              <img class="update_bg" src="static/img/update_1.png" alt="" />') +
          '<div class="setchmod bt-form">\
                    <div class="update_title">\
                      <div class="sup_title">'+ (!rdata.status ? '<i class="layui-layer-ico layui-layer-ico' + (rdata.status ? 0 : 1) + '"></i>恭喜您，当前已经是最新版本' : '发现新的面板版本，是否立即更新？') + '</div>\
                  <div class="sub_title">'+ (!rdata.status ? '当前版本：' : '最新版本：') + '<a href="https://www.bt.cn/bbs/forum-36-1.html" target="_blank" class="btlink" title="查看版本更新日志">宝塔' + bt.os + versionType + ' ' + versionData.version + '</a>' + (!rdata.status ? '&nbsp;&nbsp;发布时间：' + versionData.uptime : '') + '</div>\
                </div>\
                <div class="update_conter">' +
          (rdata.status ? '<div class="update_logs">' + versionData.updateMsg + '</div><hr>' : '') +
          '<div class="update_tips">' + (is_beta ? '正式版' : '测试版') + '最新版本为：&nbsp;' + (is_beta ? data.version : beta.version) + '&nbsp;&nbsp;&nbsp;更新时间：&nbsp;' + (is_beta ? data.uptime : beta.uptime) + '&nbsp;&nbsp;&nbsp;\
                  '+ (!is_beta ? '<span>如需更新测试版请点击<a href="javascript:;" onclick="index.beta_msg()" class="btlink btn_update_testPanel">查看详情</a></span>' : '<span>如需切换回正式版请点击<a href="javascript:;" onclick="index.to_not_beta()" class="btlink btn_update_testPanel">切换到正式版</a></span>') + '\
                  '+ (is_beta ? data.btb : '') + '\
                  <span>有更新时提醒我：<span class="bt_switch" style="display:inline-block"><input class="btswitch btswitch-ios" id="updateTips" type="checkbox"><label class="btswitch-btn" for="updateTips"></label></span><a class="btlink setupdateconfig" style="margin-left: 15px;" href="javascript:;">提醒方式</a></span></span>\
                  </div>\
                </div>\
                <div class="bt-form-btn '+ (!rdata.status ? 'hide' : '') + '">\
                  <button type="button" class="btn ignore-renew">忽略本次更新</button>\
                  <button type="button" class="btn btn-success btn_update_panel" onclick="index.to_update()" >'+ lan.index.update_go + '</button>\
                </div>\
                </div>',
        success: function (layers, indexs) {
          $('.ignore-renew').on('click', function () {
            bt.send('ignore_version', 'ajax/ignore_version', { version: versionData.version }, function (rdata) {
              bt.msg(rdata);
              if (rdata.status) layer.close(indexs);
            })
          })
          var updateModule = ''
          // 更新提醒开关状态
          cacheModule(function (rdata1) {
            updateModule = rdata1.module   //已选择的告警方式
            $('#updateTips').attr('checked', rdata1.status)
          })
          // 设置告警通知
          $('#updateTips').on('click', function () {
            var _that = $(this);
            var isExpiration = $(this).is(':checked');
            var time = new Date().getTime();
            if (isExpiration) {
              alarmMode(_that)
            } else {
              var data = JSON.stringify({
                status: isExpiration,
                type: "panel_update",
                title: "面板更新提醒",
                module: updateModule,
                interval: 600,
                push_count: 1
              })
              bt.site.set_push_config({
                name: 'site_push',
                id: 'panel_update',
                data: data,
              }, function (rdata) {
                bt.msg(rdata)
              })
            }
          });
          // 告警方式
          $('.setupdateconfig').on('click', function () {
            alarmMode()
          });
          /**
           * 更新提醒
           * @param $check 更新提醒开关
           */
          function alarmMode($check) {
            cacheModule(function (rdata1) {
              var time = new Date().getTime();
              var isExpiration = rdata1.status;
              if ($check) isExpiration = $check.is(':checked');
              layer.open({
                type: 1,
                title: '面板更新提醒',
                area: '470px',
                closeBtn: 2,
                content: '\
                    <div class="pd15">\
                      <div class="bt-form plr15">\
                        <div class="line">\
                          <span class="tname">更新提醒</span>\
                          <div class="info-r line-switch">\
                            <input type="checkbox" id="dueAlarm" class="btswitch btswitch-ios" name="due_alarm" ' + (isExpiration ? 'checked="checked"' : '') + ' />\
                            <label class="btswitch-btn" for="dueAlarm"></label>\
                          </div>\
                        </div>\
                        <div class="line">\
                          <span class="tname">告警方式</span>\
                          <div class="info-r installPush"></div>\
                        </div>\
                        <ul class="help-info-text c7">\
                         <li>点击安装后状态未更新，尝试点击【<a class="btlink handRefresh">手动刷新</a>】</li>\
                        </ul>\
                      </div>\
                    </div>',
                btn: ['保存配置', '取消'],
                success: function ($layer) {
                  renderConfigHTML()
                  // 手动刷新
                  $('.handRefresh').click(function () {
                    renderConfigHTML()
                  })

                  // 获取配置
                  function renderConfigHTML() {
                    bt.site.get_msg_configs(function (rdata) {
                      var html = '', unInstall = ''
                      for (var key in rdata) {
                        var item = rdata[key], _html = '', accountConfigStatus = false;
                        if (key == 'sms') continue;
                        if (key === 'wx_account') {
                          if (!$.isEmptyObject(item.data) && item.data.res.is_subscribe && item.data.res.is_bound) {
                            accountConfigStatus = true   //安装微信公众号模块且绑定
                          }
                        }

                        _html = '<div class="inlineBlock module-check ' + ((!item.setup || $.isEmptyObject(item.data)) ? 'check_disabled' : ((key == 'wx_account' && !accountConfigStatus) ? 'check_disabled' : '')) + '">' +
                          '<div class="cursor-pointer form-checkbox-label mr10">' +
                          '<i class="form-checkbox cust—checkbox cursor-pointer mr5 ' + (rdata1.module.indexOf(item.name) > -1 ? ((!item.setup || $.isEmptyObject(item.data)) ? '' : ((key == 'wx_account' && !accountConfigStatus) ? '' : 'active')) : '') + '" data-type="' + item.name + '"></i>' +
                          '<input type="checkbox" class="form—checkbox-input hide mr10" name="' + item.name + '" ' + ((item.setup || !$.isEmptyObject(item.data)) ? ((key == 'wx_account' && !accountConfigStatus) ? '' : 'checked') : '') + '/>' +
                          '<span class="vertical_middle" title="' + item.ps + '">' + item.title + ((!item.setup || $.isEmptyObject(item.data)) ? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">点击安装</a>]' : ((key == 'wx_account' && !accountConfigStatus) ? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">未配置</a>]' : '')) + '</span>' +
                          '</div>' +
                          '</div>';
                        if (!item.setup) {
                          unInstall += _html;
                        } else {
                          html += _html;
                        }
                      }
                      $('.installPush').html(html + unInstall)
                    });
                  }
                  // 安装消息通道
                  $('.installPush').on('click', '.form-checkbox-label', function () {
                    var that = $(this).find('i')
                    if (!that.parent().parent().hasClass('check_disabled')) {
                      if (that.hasClass('active')) {
                        that.removeClass('active')
                        that.next().prop('checked', false)
                      } else {
                        that.addClass('active')
                        that.next().prop('checked', true)
                      }
                    }
                  });

                  $('.installPush').on('click', '.installNotice', function () {
                    var type = $(this).data('type')
                    openAlertModuleInstallView(type)
                  })
                },
                yes: function (index) {
                  var status = $('input[name="due_alarm"]').is(':checked');
                  var arry = [];
                  $('.installPush .active').each(function (item) {
                    var item = $(this).attr('data-type')
                    arry.push(item)
                  })
                  if (!arry.length) return layer.msg('请选择至少一种告警通知方式', { icon: 2 })

                  // 参数
                  var data = {
                    status: status,
                    type: "panel_update",
                    title: "面板更新提醒",
                    module: arry.join(','),
                  }

                  // 请求设置本站点告警配置
                  bt.site.set_push_config({
                    name: 'site_push',
                    id: 'panel_update',
                    data: JSON.stringify(data),
                  }, function (rdata) {
                    bt.msg(rdata)
                    if (rdata.status) {
                      $('#updateTips').prop('checked', data.status)
                      layer.close(index)
                    }
                  })
                },
                cancel: function () {
                  $check && $check.prop('checked', !isExpiration)
                },
                btn2: function () {
                  $check && $check.prop('checked', !isExpiration)
                }
              });
            })
          }
          function cacheModule(callback) {
            $.post('/push?action=get_push_config', { id: 'panel_update', name: 'site_push' }, function (rdata1) {
              if (typeof rdata1.code == 'undefined' && typeof rdata1.msg != 'undefined') return layer.msg(rdata1.msg, { icon: 2 })
              if (typeof rdata1.code != 'undefined' && rdata1.code == 100) rdata1 = { module: '', status: false }
              if (callback) callback(rdata1);
            });
          }
        },
        cancel: function () {
          if (rdata.status) bt.send('ignore_version', 'ajax/ignore_version', { version: versionData.version })
        }
      })
    })
  },
  to_update: function () {
    layer.closeAll();
    bt.system.to_update(function (rdata) {

      if (rdata.status) {
        bt.msg({ msg: lan.index.update_ok, icon: 1 })
        $("#btversion").html(rdata.version);
        $("#toUpdate").html('');
        bt.system.reload_panel();
        setTimeout(function () { window.location.reload(); }, 3000);
      }
      else {
        bt.msg({ msg: rdata.msg, icon: 5, time: 5000 });
      }
    });
  },
  to_not_beta: function () {
    bt.show_confirm('切换到正式版', '是否从测试版切换到正式版？', function () {

      bt.send('apple_beta', 'ajax/to_not_beta', {}, function (rdata) {
        if (rdata.status === false) {
          bt.msg(rdata);
          return;
        }
        bt.system.check_update(function (rdata) {
          index.to_update();
        });

      });
    });
  },
  beta_msg: function () {
    bt.send('get_beta_logs', 'ajax/get_beta_logs', {}, function (data) {
      var my_list = '';
      for (var i = 0; i < data.list.length; i++) {
        my_list += '<div class="item_list">\
                                            <span class="index_acive"></span>\
                                            <div class="index_date">'+ bt.format_data(data.list[i].uptime).split(' ')[0] + '</div>\
                                            <div class="index_title">'+ data.list[i].version + '</div>\
                                            <div class="index_conter">'+ data.list[i].upmsg + '</div>\
                                        </div>'
      }
      layer.open({
        type: 1,
        title: '申请' + bt.os + '测试版',
        area: '650px',
        shadeClose: false,
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: '<div class="bt-form pd20" style="padding-bottom:50px;padding-top:0">\
                            <div class="bt-form-conter">\
                                <span style="font-weight: 600;">申请内测须知</span>\
                                <div class="form-body">'+ data.beta_ps + '</div>\
                            </div>\
                            <div class="bt-form-conter">\
                                <span style="font-size:16px;">'+ bt.os + '测试版更新日志</span>\
                                <div class="item_box"  style="height:180px;overflow: auto;">'+ my_list + '</div>\
                            </div>\
                            <div class="bt-form-line"> <label for="notice" style="cursor: pointer;"><input id="notice" disabled="disabled" type="checkbox" style="vertical-align: text-top;margin-right:5px"></input><span style="font-weight:500">我已查看“<b>《申请内测须知》</b>”<i id="update_time"></i></span></label>\</div>\
                            <div class="bt-form-submit-btn">\
                                <button type="button" class="btn btn-danger btn-sm btn-title" onclick="layer.closeAll()">'+ lan['public'].cancel + '</button>\
                                <button type="button" class="btn btn-success btn-sm btn-title btn_update_panel" disabled>'+ lan.index.update_go + '</button>\
                            </div>\
                            <style>\
                                .bt-form-conter{padding: 20px 25px;line-height: 29px;background: #f7f7f7;border-radius: 5px;padding-bottom:30px;margin-bottom:20px;}\
                                .bt-form-conter span{margin-bottom: 10px;display: block;font-size: 19px;text-align: center;color: #333;}\
                                .form-body{color: #333;}\
                                #notice span{cursor: pointer;}\
                                #update_time{font-style:normal;color:red;}\
                                .item_list{margin-left:95px;border-left:5px solid #e1e1e1;position:relative;padding:5px 0 0 2px}.index_title{border-bottom:1px solid #ececec;margin-bottom:5px;font-size:15px;color:#20a53a;padding-left:15px;margin-top:7px;margin-left:5px}.index_conter{line-height:25px;font-size:12px;min-height:40px;padding-left:20px;color:#888}.index_date{position:absolute;left:-90px;top:13px;font-size:13px;color:#333}.index_acive{width:15px;height:15px;background-color:#20a53a;display:block;border-radius:50%;position:absolute;left:-10px;top:21px}.index_acive::after{position:relative;display:block;content:"";height:5px;width:5px;display:block;border-radius:50%;background-color:#fff;top:5px;left:5px}\
                            </style>\
                        </div>'
      });
      var countdown = 5;
      function settime(val) {
        if (countdown == 0) {
          val.removeAttr("disabled");
          $('#update_time').text('');
          return false;
        } else {
          $('#update_time').text('还剩' + countdown + '秒，可点击。');
          countdown--;
          setTimeout(function () {
            settime(val)
          }, 1000)
        }
      }
      settime($('#notice'));
      $('#notice').click(function () {
        if ($(this).prop('checked')) {
          $('.btn_update_panel').removeAttr('disabled');
        } else {
          $('.btn_update_panel').attr('disabled', 'disabled');
        }
      });
      $('.btn_update_panel').click(function () {
        bt.show_confirm('升级' + bt.os + '内测版', '请仔细阅读内测升级须知，是否升级' + bt.os + '内测版？', function () {
          bt.send('apple_beta', 'ajax/apple_beta', {}, function (rdata) {
            if (rdata.status === false) {
              bt.msg(rdata);
              return;
            }
            bt.system.check_update(function (rdata) {
              index.to_update();
            });
          });
        });
      })
    });
  },
  re_panel: function () {
    layer.confirm(lan.index.rep_panel_msg, { title: lan.index.rep_panel_title, closeBtn: 2, icon: 3 }, function () {
      bt.system.rep_panel(function (rdata) {
        if (rdata.status === true) {
          bt.msg({ msg: lan.index.rep_panel_ok, icon: 1 });
          bt.system.reload_panel();
          return;
        }
        bt.msg(rdata);
      })
    });
  },
  re_server: function () {
    bt.open({
      type: 1,
      title: '重启服务器或者面板',
      area: '330px',
      closeBtn: 2,
      shadeClose: false,
      content: '<div class="rebt-con"><div class="rebt-li"><a data-id="server" href="javascript:;">重启服务器</a></div><div class="rebt-li"><a data-id="panel" href="javascript:;">重启面板</a></div></div>'
    })
    setTimeout(function () {
      $('.rebt-con a').click(function () {
        var type = $(this).attr('data-id');
        switch (type) {
          case 'panel':
            layer.confirm(lan.index.panel_reboot_msg, { title: lan.index.panel_reboot_title, closeBtn: 2, icon: 3 }, function () {
              var loading = bt.load();
              interval_stop = true;
              bt.system.reload_panel(function (rdata) {
                loading.close();
                bt.msg(rdata);
              });
              setTimeout(function () { window.location.reload(); }, 3000);
            });
            break;
          case 'server':
            var rebootbox = bt.open({
              type: 1,
              title: lan.index.reboot_title,
              area: ['456px', '320px'],
              closeBtn: 2,
              shadeClose: false,
              content: "<div class='bt-form bt-window-restart'>\
                  <div class='pd15'>\
                  <p style='color:red; margin-bottom:10px; font-size:15px;'>"+ lan.index.reboot_warning + "</p>\
                  <div class='SafeRestart' style='line-height:26px'>\
                    <p>"+ lan.index.reboot_ps + "</p>\
                    <p>"+ lan.index.reboot_ps_1 + "</p>\
                    <p>"+ lan.index.reboot_ps_2 + "</p>\
                    <p>"+ lan.index.reboot_ps_3 + "</p>\
                    <p>"+ lan.index.reboot_ps_4 + "</p>\
									</div>\
									</div>\
									<div class='bt-form-submit-btn'>\
										<button type='button' class='btn btn-danger btn-sm btn-reboot'>"+ lan['public'].cancel + "</button>\
										<button type='button' class='btn btn-success btn-sm WSafeRestart' >"+ lan['public'].ok + "</button>\
									</div>\
								</div>"
            });
            setTimeout(function () {
              $(".btn-reboot").click(function () {
                rebootbox.close();
              })
              $(".WSafeRestart").click(function () {
                var body = '<div class="SafeRestartCode pd15" style="line-height:26px"></div>';
                $(".bt-window-restart").html(body);
                $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_1 + "</p>");
                bt.pub.set_server_status_by("name={{session['webserver']}}&type=stop", function (r1) {
                  $(".SafeRestartCode p").addClass('c9');
                  $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_2 + "...</p>");
                  bt.system.root_reload(function (rdata) {
                    $(".SafeRestartCode p").addClass('c9');
                    $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_4 + "...</p>");
                    var sEver = setInterval(function () {
                      bt.system.get_total(function () {
                        clearInterval(sEver);
                        $(".SafeRestartCode p").addClass('c9');
                        $(".SafeRestartCode").append("<p>" + lan.index.reboot_msg_5 + "...</p>");
                        setTimeout(function () {
                          layer.closeAll();
                        }, 3000);
                      })
                    }, 3000);
                  })
                })
              })
            }, 100)
            break;
        }
      })
    }, 100)
  },
  open_log: function () {
    bt.open({
      type: 1,
      area: '640px',
      title: lan.index.update_log,
      closeBtn: 2,
      shift: 5,
      shadeClose: false,
      content: '<div class="DrawRecordCon"></div>'
    });
    $.get('http://www.example.com/api/getUpdateLogs?type=' + bt.os, function (rdata) {
      var body = '';
      for (var i = 0; i < rdata.length; i++) {
        body += '<div class="DrawRecord DrawRecordlist">\
							<div class="DrawRecordL">'+ rdata[i].addtime + '<i></i></div>\
							<div class="DrawRecordR">\
								<h3>'+ rdata[i].title + '</h3>\
								<p>'+ rdata[i].body + '</p>\
							</div>\
						</div>'
      }
      $(".DrawRecordCon").html(body);
    }, 'jsonp');
  },
  /**
   * @description 获取当前的产品状态
  */
  get_product_status: function (callback) {
    bt.send('get_pd', 'ajax/get_pd', {}, function (res) {
      if (callback) callback(res)
      $('.btpro-gray').replaceWith($(res[0]));
      if (res[1] === 0) {
        $(".btpro span").click(function (e) {
          layer.confirm('切换回免费版可通过解绑账号实现', { icon: 3, btn: ['解绑账号'], closeBtn: 2, title: '是否取消授权' }, function () {
            $.post('/ssl?action=DelToken', {}, function (rdata) {
              layer.msg(rdata.msg);
              setTimeout(function () {
                window.location.reload();
              }, 2000);
            });
          });
          e.stopPropagation();
        });
      }
    })
  },
  /**
   * @description 推荐进阶版产品
  */
  recommend_paid_version: function () {
    try {
      var recomConfig = product_recommend.get_recommend_type(0)
      var pay_status = product_recommend.get_pay_status()
      var is_pay = pay_status.is_pay;
      var advanced = pay_status.advanced;
      var end_time = pay_status.end_time;
      var html = '', list_html = '';
      if (!is_pay) advanced = ''; //未购买的时候，使用推荐内容
      if (recomConfig) {
        var item = recomConfig;
        for (var j = 0; j < item['ps'].length; j++) {
          var element = item['ps'][j];
          list_html += '<div class="item">' + element + '</div>';
        }
        var pay_html = '';
        if (is_pay) {
          pay_html = '<div class="product-buy ' + (advanced || item.name) + '-type">到期时间：<span>' + (end_time === 0 ? '永久授权' : (end_time === -2 ? '已过期' : bt.format_data(end_time, 'yyyy-MM-dd')) + '&nbsp;&nbsp;<a class="btlink" href="javascript:;" onclick="product_recommend.pay_product_sign(\'' + advanced + '\',' + item.pay + ',\'' + advanced + '\')">续费</a>') + '</span></div>'
        } else {
          pay_html = '<div class="product-buy"><button type="button" class="btn btn-xs btn-success" onclick="product_recommend.pay_product_sign(\'' + (advanced || item.name) + '\',' + item.pay + ',\'ltd\')">立即购买</button></div>'
        }
        html = '<div class="conter-box bgw">\
          <div class="recommend-top pd15 '+ (is_pay ? (advanced + '-bg') : '') + '">' + (!is_pay ? pay_html : '') + '<div class="product-ico ' + (advanced || item.name) + '' + (!is_pay ? '-pay' : '') + '-ico"></div>' + (is_pay ? pay_html : '') + '\
            <div class="product-label">'+ list_html + '</div>\
          </div>\
        </div>'
        //交互优化------普通用户才显示横幅
        var day_not_display = bt.get_storage('home_day_not_display') //获取不再显示最终的时间戳
        if((day_not_display && parseInt(day_not_display) < new Date().getTime()) || !day_not_display) $('#home-recommend').html(html)
        $('#home-recommend').hover(function(){
          if(!$('#home-recommend .day-not-display').length) $(this).css('position','relative').append('<div class="day-not-display">近'+ (is_pay ? '3天' : '24小时') +'不再显示<span></span></div>')
          $('#home-recommend .day-not-display').fadeIn("1000")
          $('#home-recommend .day-not-display span').unbind('click').click(function(){
            bt.set_storage('home_day_not_display', (new Date().getTime() + 86400*1000*(is_pay ? 3 : 1)))  //设置3天不再显示最后的时间戳
            $('#home-recommend').empty()
          })
        },function(){
          $('#home-recommend .day-not-display').hide()
        })
        //交互优化------普通用户才显示横幅end
      }
    } catch (error) {
      console.log(error)
    }
  },
  /**
   * @description 推荐任务管理器
  */
  recommend_task_manager: function () {

  }
}

index.get_product_status(function (rdata) {
  bt.set_cookie('pro_end', rdata[1])
  bt.set_cookie('ltd_end', rdata[2])
})
var time = 0;

index.get_init()

product_recommend.init(function () {
  index.get_index_list();
})
var loginInfo = JSON.parse(bt.get_cookie('login_info'))
if(loginInfo != null){
  if (loginInfo.last_login.ip_info.city && (loginInfo.ip_info.city !== loginInfo.last_login.ip_info.city)) {
  var remoteLogin = bt_tools.open({
    title: '<img class="remote_login" src="/static/images/svg/remote-login.svg">面板登录提示',
    shade: 0,
    offset: ['auto', 'auto'],
    area: ['280px', '180px'],
    btn: false,
    content: '<div class="login_info">' +
      '<div class="info_list">'+
      '<span class="ip_info"></span>' +
      '<span class="last_login"></span>' +
      '<span class="last_login_time"></span>' +
      '</div>'+
      '<div class="prompt">如非本人操作请及时<a class="btlink changePassword">更改密码</a>/<a class="btlink binding_ip">绑定固定IP访问</a></div>' +
      '</div>',
    success: function (layero, indexs) {
      $('.login_info').parents('.layui-layer').css({'box-shadow':'rgba(0, 0, 0, 0.24) 0px 3px 8px','right':'80px','bottom':'100px'})
      $('.login_info').parent('.layui-layer-content').css('height', '138px')
      $('.remote_login').parent().css('margin-bottom', '12px')
      $('.remote_login').parents('.layui-layer-title').css({
        'background-image': 'url(/static/images/svg/remote-login-bg.svg)',
        'background-repeat': 'no-repeat',
        'background-position': 'bottom',
        'border': 'none',
      })
      $('.ip_info').html("本次登录：<strong>" + loginInfo.ip_info.ip + "-" + loginInfo.ip_info.city +'</strong>')
      $('.last_login').html("上次登录：<strong>" + loginInfo.last_login.ip_info.ip + "-" + loginInfo.last_login.ip_info.city +'</strong>')
	    var date = new Date(Math.trunc(loginInfo.login_time) * 1000);
	    var Y = date.getFullYear() + '-';
	    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
	    var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
	    var h = (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours()) + ':';
	    var m = (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes());
	    var strDate = Y + M + D + h + m;
	    $('.last_login_time').html("上次登录时间：<strong>" + strDate + '</strong>')

      $('.binding_ip').on('click', function () {
        window.location.href = window.location.href + 'config'
      })

      $('.changePassword').on('click', function () {
        bt_tools.open({
          title: '修改面板密码',
          area: ['380px', '238px'],
          btn: ['提交', '取消'],
          content: '<div class="bt-form pd25"><div class="public_key" style="display: block;" data="{{data["public_key"]}}"></div><div class="line" ><span class="tname" style="width: 75px;">密码</span><div class="info-r" style="margin-left: 75px;"><div class="group-box"> <input class="bt-input-text mr5 password1" name="password1" type="text" value="" style="width: 210px;"> <span class="glyphicon glyphicon-repeat cursor"></span></div></div></div><div class="line"><span class="tname" style="width: 75px;">重复</span><div class="info-r" style="margin-left: 75px;"><input class="bt-input-text mr5 password2 " name="password2" type="text" value="" style="width: 210px;"></div></div></div>',
          success: function() {
            var getRandom = function(len) {
              if (len === void 0) {
                len = 32;
              }
              var $chars = 'AaBbCcDdEeFfGHhiJjKkLMmNnPpRSrTsWtXwYxZyz2345678',
                maxPos = $chars.length;
              var password = '';
              for (var i = 0; i < len; i++) {
                password += $chars.charAt(Math.floor(Math.random() * maxPos));
              }
              return password;
            }
            $('.glyphicon-repeat').on('click', function() {
              var password = getRandom(10)
              $('.bt-form .password1').val(password)
              $('.bt-form .password2').val(password)
      
            })
          },
          yes: function(index) {
            var password1 = $('.bt-form .password1').val();
            var password2 = $('.bt-form .password2').val();
            if (password1 !== password2) {
              layer.msg('两次输入的密码不一致', {
                icon: 2,
                time: 2000
              });
            } else if (password1.length <= 5) {
              layer.msg('密码长度必须大于5位', {
                icon: 2,
                time: 2000
              });
            } else {
              password1 = encodeURIComponent(password1);
              password2 = encodeURIComponent(password2);
              bt.send('setPassword', 'config/setPassword', {
                password1: rsa.encrypt_public(password1),
                password2: rsa.encrypt_public(password2),
							}, function (res) {
								layer.close(index)
								layer.msg(res.msg, {icon:res.status?1:2} ,function(){
                 window.location.href = window.location.href + '/login?dologin=True'
                }); 
              })
            }
          }
      
        })
      
      })
    }
  })
} else { }
}