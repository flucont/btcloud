$('.database-pos .tabs-item').click(function () {
	var type = $(this).data('type');
	var index = $(this).index();
	bt.set_cookie('db_page_model', type);
	bt.data.db_tab_name = type
	$(this).addClass('active').siblings().removeClass('active');
	$('.db_table_view .tab-con .tab-con-block').eq(index).removeClass('hide').siblings().addClass('hide');
	if(type != 'mysql'){
		$('.info-title-tips').hide()
	}else{
		$('.info-title-tips').show()
	}
	if(type == 'sqlite'){
		$('.mask_layer').hide()
		sqlite.database_table_view();
	}else{
		var loadT = layer.msg('正在获取远程服务器列表,请稍候...', {
			icon: 16,
			time: 0,
			shade: [0.3, '#000']
		});
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/GetCloudServer',data:{data:JSON.stringify({type:bt.data.db_tab_name})}},function(cloudData){
			layer.close(loadT);
			cloudDatabaseList = cloudData
			//是否安装本地或远程服务器
			if(cloudData.length <= 0){
				var tips = '当前未安装本地服务器/远程服务器,<a class="btlink install_server">点击安装</a> | <a class="btlink" onclick="db_public_fn.get_cloud_server_list()">添加远程服务器</a>'
				$('.mask_layer').removeAttr('style');
				$('.prompt_description').html(tips)
	
				//安装数据库
				$('.install_server').click(function(){
					var db_type = bt.data.db_tab_name
					if(db_type == 'pgsql'){
						bt.soft.get_soft_find('pgsql_manager',function(rdata){   //判断是否安装插件
							for (var i = 0; i < rdata.versions.length; i++) {
								if (rdata.versions[i].setup == true) {  //判断是否安装版本
									bt.soft.set_lib_config('pgsql_manager','PostgreSQL管理器')
									break;
								}else{
									bt.soft.install('pgsql_manager')
									break;
								}
							}
						})
					}else{
						bt.soft.install(db_type)
					}
					$('.install_confirm .layui-layer-btn0').click(function(){
						messagebox()
					})
				})
			}else{
				$('.mask_layer').hide()
			}
			switch (type) {
				case 'mysql':
					database.database_table_view();
					break;
				case 'sqlserver':
					sql_server.database_table_view();
					break;
				case 'mongodb':
					bt_tools.send({url:'database/'+bt.data.db_tab_name+'/get_root_pwd'},function(_status){
						mongoDBAccessStatus = _status.auth
						mongodb.database_table_view();
					},'获取访问状态')
					break;
				case 'redis':
					redis.database_table_view();
					break;
				case 'pgsql':
					pgsql.database_table_view();
					break;
			}
		})
	}
});



var database_table = null,
	dbCloudServerTable = null,  //远程服务器视图
	cloudDatabaseList = [],    //远程服务器列表
	mongoDBAccessStatus = false;

var database = {
	database_table_view :function(search){
		var param = {
			table: 'databases',
			search: search || ''
		}
		$('#bt_database_table').empty();
		database_table = bt_tools.table({
			el: '#bt_database_table',
			url: 'database/'+bt.data.db_tab_name+'/get_list',
			param: param, //参数
			load: true,
			minWidth: '1000px',
			autoHeight: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			pageName: 'database',
			beforeRequest: function(beforeData){
				var db_type_val = $('.database_type_select_filter').val()
				switch(db_type_val){
					case 'all':
						delete param['db_type']
						delete param['sid']
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data']
					return { data: JSON.stringify($.extend(param,beforeData)) }
				}
				return {data:JSON.stringify(param)}
			},
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '数据库名',type:'text'},
				{fid: 'username',title: '用户名',type:'text',sort:true},
				{fid:'password',title:'密码',type:'password',copy:true,eye_open:true},
				{
					fid:'backup_count',
					title: '备份',
					sort:true,
					width: 130,
					template: function (row) {
						var backup = '点击备份',
							_class = "bt_warning";
						if (row.backup_count > 0) backup = lan.database.backup_ok, _class = "bt_success";
						return '<span><a href="javascript:;" class="btlink ' + _class + '" onclick="database.database_detail('+row.id+',\''+row.name+'\')">' + backup + (row.backup_count > 0 ? ('(' + row.backup_count + ')') : '') + '</a> | ' +
							'<a href="javascript:database.input_database(\''+row.name+'\')" class="btlink">'+lan.database.input+'</a></span>';
					}
				},
				{
					title:'数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-'
						switch(row.db_type){
							case 0:
								type_column = '本地数据库'
								break;
							case 1:
								type_column = ('远程库('+row.conn_config.db_host+':'+row.conn_config.db_port+')').toString()
								break;
							case 2:
								$.each(cloudDatabaseList,function(index,item){
									if(row.sid == item.id){
										if(item.ps !== ''){ // 默认显示备注
											type_column = item.ps
										}else{
											type_column = ('远程服务器('+item.db_host+':'+item.db_port+')').toString()
										}
									}
								})
								break;
						}
						return '<span class="flex" style="width:100px" title="'+type_column+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+type_column+'</span></span>'
					}
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps({
							id: row.id,
							table: 'databases',
							ps: ev.target.value
						}, function (res) {
							layer.msg(res.msg, (res.status ? {} : {
								icon: 2
							}));
						});
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					}
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '管理',
						tips: '数据库管理',
						hide:function(rows){return rows.db_type != 0},  // 远程数据库和远程服务器
						event: function (row) {
							bt.database.open_phpmyadmin(row.name, row.username, row.password);
						}
					}, {
						title: '权限',
						tips: '设置数据库权限',
						hide:function(rows){return rows.db_type == 1}, //远程数据库
						event: function (row) {
							bt.database.set_data_access(row.username);
						}
					}, {
						title: '工具',
						tips: 'MySQL优化修复工具',
						event: function (row) {
							database.rep_tools(row.name);
						}
					}, {
						title: '改密',
						tips: '修改数据库密码',
						hide:function(rows){return rows.db_type == 1}, //远程数据库
						event: function (row) {
							database.set_data_pass(row.id, row.username, row.password);
						}
					}, {
						title: '删除',
						tips: '删除数据库',
						event: function (row) {
							database.del_database(row.id, row.name,row, function (res) {
								if (res.status) database_table.$refresh_table_list(true);
								layer.msg(res.msg, {
									icon: res.status ? 1 : 2
								})
							});
						}
					}]
				}
			],
			sortParam: function (data) {
				return {
					'order': data.name + ' ' + data.sort
				};
			},
			tootls: [{ // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
					title: '添加数据库',
					active: true,
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var cloudList = []
						$.each(cloudDatabaseList,function(index,item){
							var _tips = item.ps != ''?(item.ps+' ('+item.db_host+')'):item.db_host
							cloudList.push({title:_tips,value:item.id})
						})
						bt.database.add_database(cloudList,function (res) {
							if (res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: 'root密码',
					event: function () {
						bt.database.set_root('root')
					}
				},{
					title: 'phpMyAdmin',
					event: function () {
						bt.database.open_phpmyadmin('','root', bt.config.mysql_root)
					}
				},{
					title:'远程服务器',
					event:function(){
						db_public_fn.get_cloud_server_list();
					}
				},{
					title: '同步所有',
					style:{'margin-left':'30px'},
					event: function () {
						database.sync_to_database({type:0,data:[]},function(res){
							if(res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: '从服务器获取',
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var _list = [];
						$.each(cloudDatabaseList,function (index,item){
							var _tips = item.ps != ''?(item.ps+' (服务器地址:'+item.db_host+')'):item.db_host
							_list.push({title:_tips,value:item.id})
						})
						bt_tools.open({
							title:'选择数据库位置',
							area:'450px',
							btn: ['确认','取消'],
							skin: 'databaseCloudServer',
							content: {
								'class':'pd20',
								form:[{
									label:'数据库位置',
									group:{
										type:'select',
										name:'sid',
										width:'260px',
										list:_list
									}
								}]
							},
							success:function(layers){
								$(layers).find('.layui-layer-content').css('overflow','inherit')
							},
							yes:function (form,layers,index){
								bt.database.sync_database(form.sid,function (rdata) {
									if (rdata.status){
										database_table.$refresh_table_list(true);
										layer.close(layers)
									}
								})
							}
						})
					}
				},{
					title: '回收站',
					icon:'trash',
					event: function () {
						bt.recycle_bin.open_recycle_bin(6)
					}
				}]
			},{
				type: 'batch', //batch_btn
				positon: ['left', 'bottom'],
				placeholder: '请选择批量操作',
				buttonValue: '批量操作',
				disabledSelectValue: '请选择需要批量操作的数据库!',
				selectList: [{
					title:'同步选中',
					url:'/database/'+bt.data.db_tab_name+'/SyncToDatabases',
					paramName: 'data', //列表参数名,可以为空
					th:'数据库名称',
					beforeRequest: function(list) {
						var arry = [];
						$.each(list, function (index, item) {
							arry.push(item.id);
						});
						return JSON.stringify({ids:JSON.stringify(arry),type:1})
					},
					success: function (res, list, that) {
						layer.closeAll();
						var html = '';
						$.each(list, function (index, item) {
							html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
						});
						that.$batch_success_table({
							title: '批量同步选中',
							th: '数据库名称',
							html: html
						});
					}
				},{
					title: "删除数据库",
					url: '/database/'+bt.data.db_tab_name+'/DeleteDatabase',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({
								id: row.id,
								name: row.name
							})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						var ids = [];
						for (var i = 0; i < that.check_list.length; i++) {
							ids.push(that.check_list[i].id);
						}
						database.del_database(ids,function(param){
							that.start_batch(param, function (list) {
								layer.closeAll()
								var html = '';
								for (var i = 0; i < list.length; i++) {
									var item = list[i];
									html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
								}
								database_table.$batch_success_table({
									title: '批量删除',
									th: '数据库名称',
									html: html
								});
								database_table.$refresh_table_list(true);
							});
						})
					}
				}]
			}, {
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入数据库名称/备注',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			}, { //分页显示
				type: 'page',
				positon: ['right', 'bottom'], // 默认在右下角
				pageParam: 'p', //分页请求字段,默认为 : p
				page: 1, //当前分页 默认：1
				numberParam: 'limit', //分页数量请求字段默认为 : limit
				number: 20, //分页数量默认 : 20条
				numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
				numberStatus: true, //　是否支持分页数量选择,默认禁用
				jump: true, //是否支持跳转分页,默认禁用
			}],
			success:function(config){
				//搜索前面新增数据库位置下拉
				if($('.database_type_select_filter').length == 0){
					var _option = '<option value="all">全部</option>'
					$.each(cloudDatabaseList,function(index,item){
						var _tips = item.ps != ''?item.ps:item.db_host
						_option +='<option value="'+item.id+'">'+_tips+'</option>'
					})
					$('#bt_database_table .bt_search').before('<select class="bt-input-text mr5 database_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')

					//事件
					$('.database_type_select_filter').change(function(){
						database_table.$refresh_table_list(true,function(data){
							if(parseInt($('#bt_database_table .page .Pcurrent').text()) !== 1) $('.Pstart').click()
						});
					})
				}
			}
		});
	},
	// 同步所有
	sync_to_database: function (obj,callback) {
		bt.database.sync_to_database({ type: obj.type, ids: JSON.stringify(obj.data) }, function (rdata) {
			if (callback) callback(rdata);
		});
	},
	// 同步数据库
	database_detail: function (id, dataname, page) {
		if (page == undefined) page = '1';
		if ($('#DataBackupList').length <= 0) {
			bt.open({
				type: 1,
				skin: 'demo-class',
				area: '700px',
				title: lan.database.backup_title,
				closeBtn: 2,
				shift: 5,
				shadeClose: false,
				content: "<div class='divtable pd15' style='padding-bottom: 30px'>\
					<button id='btn_data_backup' class='btn btn-success btn-sm' type='button' style='margin-bottom:10px'>" + lan.database.backup + "</button>\
					<div id='DataBackupList'></div>\
				</div>"
			});
		}
		setTimeout(function () {
			var _page = ''
            $('#DataBackupList').empty();
            var backTable = bt_tools.table({
                el: '#DataBackupList',
                url: '/data?action=getData&table=backup&search=' + id + '&limit=5&type=1&tojs=database.database_detail&p=' + page,
                default: "备份列表为空",
                dataFilter: function (res) {
                    _page = res.page.replace(/'/g, '"').replace(/database.database_detail\(/g, "database.database_detail(" + id + ",'" + dataname + "',");
                    return { data: res.data }
                },
                column: [
                    {
                        type: 'checkbox', class: '', width: 20
                    },{
                        fid: 'name',
                        title: '文件名称'
                    },
                    {
                        fid: 'size',
                        title: '文件大小',
                        template: function (item) {
                            return bt.format_size(item.size);
                        }
                    },
                    {
                        fid: 'addtime',
                        title: '备份时间'
                    },{
                        title: "操作",
                        type: 'group',
                        align: 'right',
                        group: [{
                            title: '恢复',
                            event: function (row, index, ev, key, that) {
								bt.database.input_sql(row.filename , dataname)
                            }
                        },{
                            title: '下载',
                            event: function (row, index, ev, key, that) {
                               window.location.href = '/download?filename=' + row.filename + '&amp;name=' + row.name;
                            }
                        },{
                            title: '删除',
                            event: function (row, index, ev, key, that) {
                                bt.database.del_backup(row.id, id, dataname,row.addtime )
                            }
                        }]
                    }
                ],
                tootls: [
                    {
                        type: 'batch',
                        positon: ['left', 'bottom'],
                        config: {
                          title: '删除',
                          url: '/database/mysql/DelBackup',
                          param: function (row) {
                            return { data: JSON.stringify({id:row.id}) }
                          },
                          load: true,
                          callback: function (that) {
                            bt.confirm({ title: '批量删除备份文件', msg: '批量删除选中的备份文件，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
                              layer.close(index);
                              that.start_batch({}, function (list) {
                                var html = '';
                                for (var i = 0; i < list.length; i++) {
                                  var item = list[i];
                                  html += '<tr><td><span class="text-overflow" title="' + item.name + '">' + item.name + '</span></td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
                                }
                                backTable.$batch_success_table({ title: '批量删除备份文件', th: '键', html: html });
                                backTable.$refresh_table_list(true);
                              });
                            });
                          }
                        }
                    },
                ],
                success: function () {
                    $('#DataBackupList .page').remove()
                    $('#DataBackupList .tootls_bottom .pull-right').html($(_page).addClass('page'))
                    $('#btn_data_backup').unbind('click').click(function () {
						bt.database.backup_data(id, dataname, function (rdata) {
							if (rdata.status) {
								backTable.$refresh_table_list(true);
								database_table.$refresh_table_list(true);
							}
						})
					})
                }
            })
		},100)
	},
	// 备份导入》本地导入
	upload_files: function (name) {
		var path = bt.get_cookie('backup_path') + "/database/";
		bt_upload_file.open(path, '.sql,.zip,.bak', lan.database.input_up_type, function () {
			database.input_database(name);
		});
	},
	// 备份导入
	input_database: function (name) {
		var path = bt.get_cookie('backup_path') + "/database";
		bt.files.get_files(path, '', function (rdata) {
			var data = [];
			for (var i = 0; i < rdata.FILES.length; i++) {
				if (rdata.FILES[i] == null) continue;
				var fmp = rdata.FILES[i].split(";");
				var ext = bt.get_file_ext(fmp[0]);
				if (ext != 'sql' && ext != 'zip' && ext != 'gz' && ext != 'tgz' && ext != 'bak') continue;
				data.push({ name: fmp[0], size: fmp[1], etime: fmp[2], })
			}
			if ($('#DataInputList').length <= 0) {
				bt.open({
					type: 1,
					skin: 'demo-class',
					area: ["600px", "500px"],
					title: lan.database.input_title_file,
					closeBtn: 2,
					shift: 5,
					shadeClose: false,
					content: '<div class="pd15"><button class="btn btn-default btn-sm" onclick="database.upload_files(\'' + name + '\')">' + lan.database.input_local_up + '</button><div class="divtable mtb15" style="max-height:300px; overflow:auto">'
						+ '<table id="DataInputList" class="table table-hover"></table>'
						+ '</div>'
						+ bt.render_help([lan.database.input_ps1, lan.database.input_ps2, (bt.os != 'Linux' ? lan.database.input_ps3.replace(/\/www.*\/database/, path) : lan.database.input_ps3)])
						+ '</div>'
				});
			}
			setTimeout(function () {
				bt.render({
					table: '#DataInputList',
					columns: [
						{ field: 'name', title: lan.files.file_name },
						{
							field: 'etime', title: lan.files.file_etime, templet: function (item) {
								return bt.format_data(item.etime);
							}
						},
						{
							field: 'size', title: lan.files.file_size, templet: function (item) {
								return bt.format_size(item.size)
							}
						},
						{
							field: 'opt', title: '操作', align: 'right', templet: function (item) {
								return '<a class="btlink" herf="javascrpit:;" onclick="bt.database.input_sql(\'' + bt.rtrim(rdata.PATH, '/') + "/" + item.name + '\',\'' + name + '\')">导入</a>  ';;
							}
						},
					],
					data: data
				});
			}, 100)
		})
	},
	// 工具
	rep_tools: function (db_name, res) {
		var loadT = layer.msg('正在获取数据,请稍候...', { icon: 16, time: 0 });
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/GetInfo',data:{data:JSON.stringify({db_name: db_name})}},function(rdata){
			layer.close(loadT)
			if (rdata.status === false) {
				layer.msg(rdata.msg, { icon: 2 });
				return;
			}
			var types = { InnoDB: "MyISAM", MyISAM: "InnoDB" };
			var tbody = '';
			for (var i = 0; i < rdata.tables.length; i++) {
				if (!types[rdata.tables[i].type]) continue;
				tbody += '<tr>\
                        <td><input value="dbtools_' + rdata.tables[i].table_name + '" class="check" onclick="database.selected_tools(null,\'' + db_name + '\');" type="checkbox"></td>\
                        <td><span style="width:220px;"> ' + rdata.tables[i].table_name + '</span></td>\
                        <td>' + rdata.tables[i].type + '</td>\
                        <td><span style="width:90px;"> ' + rdata.tables[i].collation + '</span></td>\
                        <td>' + rdata.tables[i].rows_count + '</td>\
                        <td>' + rdata.tables[i].data_size + '</td>\
                        <td style="text-align: right;">\
                            <a class="btlink" onclick="database.rep_database(\''+ db_name + '\',\'' + rdata.tables[i].table_name + '\')">修复</a> |\
                            <a class="btlink" onclick="database.op_database(\''+ db_name + '\',\'' + rdata.tables[i].table_name + '\')">优化</a> |\
                            <a class="btlink" onclick="database.to_database_type(\''+ db_name + '\',\'' + rdata.tables[i].table_name + '\',\'' + types[rdata.tables[i].type] + '\')">转为' + types[rdata.tables[i].type] + '</a>\
                        </td>\
                    </tr> '
			}

			if (res) {
				$(".gztr").html(tbody);
				$("#db_tools").html('');
				$("input[type='checkbox']").attr("checked", false);
				$(".tools_size").html('大小：' + rdata.data_size);
				return;
			}

			layer.open({
				type: 1,
				title: "MySQL工具箱【" + db_name + "】",
				area: ['780px', '580px'],
				closeBtn: 2,
				shadeClose: false,
				content: '<div class="pd15">\
                                <div class="db_list">\
                                    <span><a>数据库名称：'+ db_name + '</a>\
                                    <a class="tools_size">大小：'+ rdata.data_size + '</a></span>\
                                    <span id="db_tools" style="float: right;"></span>\
                                </div >\
                                <div class="divtable">\
                                <div  id="database_fix"  style="height:360px;overflow:auto;border:#ddd 1px solid">\
                                <table class="table table-hover "style="border:none">\
                                    <thead>\
                                        <tr>\
                                            <th><input class="check" onclick="database.selected_tools(this,\''+ db_name + '\');" type="checkbox"></th>\
                                            <th>表名</th>\
                                            <th>引擎</th>\
                                            <th>字符集</th>\
                                            <th>行数</th>\
                                            <th>大小</th>\
                                            <th style="text-align: right;">操作</th>\
                                        </tr>\
                                    </thead>\
                                    <tbody class="gztr">' + tbody + '</tbody>\
                                </table>\
                                </div>\
                            </div>\
                            <ul class="help-info-text c7">\
                                <li>【修复】尝试使用REPAIR命令修复损坏的表，仅能做简单修复，若修复不成功请考虑使用myisamchk工具</li>\
                                <li>【优化】执行OPTIMIZE命令，可回收未释放的磁盘空间，建议每月执行一次</li>\
                                <li>【转为InnoDB/MyISAM】转换数据表引擎，建议将所有表转为InnoDB</li>\
                            </ul></div>'
			});
			tableFixed('database_fix');
			//表格头固定
			function tableFixed(name) {
				var tableName = document.querySelector('#' + name);
				tableName.addEventListener('scroll', scrollHandle);
			}
			function scrollHandle(e) {
				var scrollTop = this.scrollTop;
				//this.querySelector('thead').style.transform = 'translateY(' + scrollTop + 'px)';
				$(this).find("thead").css({ "transform": "translateY(" + scrollTop + "px)", "position": "relative", "z-index": "1" });
			}
		});
	},
	selected_tools: function (my_obj, db_name) {
		var is_checked = false
		if (my_obj) is_checked = my_obj.checked;
		var db_tools = $("input[value^='dbtools_']");
		var n = 0;
		for (var i = 0; i < db_tools.length; i++) {
			if (my_obj) db_tools[i].checked = is_checked;
			if (db_tools[i].checked) n++;
		}
		if (n > 0) {
			var my_btns = '<button class="btn btn-default btn-sm" onclick="database.rep_database(\'' + db_name + '\',null)">修复</button><button class="btn btn-default btn-sm" onclick="database.op_database(\'' + db_name + '\',null)">优化</button><button class="btn btn-default btn-sm" onclick="database.to_database_type(\'' + db_name + '\',null,\'InnoDB\')">转为InnoDB</button></button><button class="btn btn-default btn-sm" onclick="database.to_database_type(\'' + db_name + '\',null,\'MyISAM\')">转为MyISAM</button>'
			$("#db_tools").html(my_btns);
		} else {
			$("#db_tools").html('');
		}
	},
	rep_database: function (db_name, tables) {
		dbs = database.rep_checkeds(tables)
		var loadT = layer.msg('已送修复指令,请稍候...', { icon: 16, time: 0 });
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/ReTable',data:{data:JSON.stringify({ db_name: db_name, tables: JSON.stringify(dbs) })}},function(rdata){
			layer.close(loadT)
			database.rep_tools(db_name, true);
			layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
		});
	},
	op_database: function (db_name, tables) {
		dbs = database.rep_checkeds(tables)
		var loadT = layer.msg('已送优化指令,请稍候...', { icon: 16, time: 0 });
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/OpTable',data:{data:JSON.stringify({ db_name: db_name, tables: JSON.stringify(dbs) })}},function(rdata){
			layer.close(loadT)

			database.rep_tools(db_name, true);
			layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
		});
	},
	to_database_type: function (db_name, tables, type) {
		dbs = database.rep_checkeds(tables)
		var loadT = layer.msg('已送引擎转换指令,请稍候...', { icon: 16, time: 0, shade: [0.3, "#000"] });
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/AlTable',data:{data:JSON.stringify({ db_name: db_name, tables:JSON.stringify(dbs), table_type: type })}},function(rdata){
			layer.close(loadT);

			database.rep_tools(db_name, true);
			layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
		});
	},
	rep_checkeds: function (tables) {
		var dbs = []
		if (tables) {
			dbs.push(tables)
		} else {
			var db_tools = $("input[value^='dbtools_']");
			for (var i = 0; i < db_tools.length; i++) {
				if (db_tools[i].checked) dbs.push(db_tools[i].value.replace('dbtools_', ''));
			}
		}

		if (dbs.length < 1) {
			layer.msg('请至少选择一张表!', { icon: 2 });
			return false;
		}
		return dbs;
	},
	// 改密
	set_data_pass: function (id, username, password) {
		var bs = bt.database.set_data_pass(function (rdata) {
			if (rdata.status) database_table.$refresh_table_list(true);
			bt.msg(rdata);
		})
		$('.name' + bs).val(username);
		$('.id' + bs).val(id);
		$('.password' + bs).val(password);
	},
	// 删除
	del_database: function (wid, dbname,obj, callback) {
		var rendom = bt.get_random_code(),
			num1 = rendom['num1'],
			num2 = rendom['num2'],
			title = '',
			tips = '是否确认【删除数据库】，删除后可能会影响业务使用！';
		if(obj && obj.db_type > 0) tips = '远程数据库不支持数据库回收站，删除后将无法恢复，请谨慎操作';
		title = typeof dbname === "function" ?'批量删除数据库':'删除数据库 [ '+ dbname +' ]';
		layer.open({
			type:1,
			title:title,
			icon:0,
			skin:'delete_site_layer',
			area: "530px",
			closeBtn: 2,
			shadeClose: true,
			content:"<div class=\'bt-form webDelete pd30\' id=\'site_delete_form\'>" +
				"<i class=\'layui-layer-ico layui-layer-ico0\'></i>" +
				"<div class=\'f13 check_title\' style=\'margin-bottom: 20px;\'>"+tips+"</div>" +
				"<div style=\'color:red;margin:18px 0 18px 18px;font-size:14px;font-weight: bold;\'>注意：数据无价，请谨慎操作！！！"+(!recycle_bin_db_open?'<br>风险操作：当前数据库回收站未开启，删除数据库将永久消失！':'')+"</div>" +
				"<div class=\'vcode\'>" + lan.bt.cal_msg + "<span class=\'text\'>"+ num1 +" + "+ num2 +"</span>=<input type=\'number\' id=\'vcodeResult\' value=\'\'></div>" +
				"</div>",
			btn:[lan.public.ok,lan.public.cancel],
			yes:function(indexs){
				var vcodeResult = $('#vcodeResult'),data = {id: wid,name: dbname};
				if(vcodeResult.val() === ''){
					layer.tips('计算结果不能为空', vcodeResult, {tips: [1, 'red'],time:3000})
					vcodeResult.focus()
					return false;
				}else if(parseInt(vcodeResult.val()) !== (num1 + num2)){
					layer.tips('计算结果不正确', vcodeResult, {tips: [1, 'red'],time:3000})
					vcodeResult.focus()
					return false;
				}
				if(typeof dbname === "function"){
					delete data.id;
					delete data.name;
				}
				layer.close(indexs)
				var arrs = wid instanceof Array ? wid : [wid]
				var ids = JSON.stringify(arrs), countDown = 9;
				if (arrs.length == 1) countDown = 4
				title = typeof dbname === "function" ?'二次验证信息，批量删除数据库':'二次验证信息，删除数据库 [ ' + dbname + ' ]';
				var loadT = bt.load('正在检测数据库数据信息，请稍后...')

				bt_tools.send({url:'database/'+bt.data.db_tab_name+'/check_del_data',data:{data:JSON.stringify({ids: ids})}},function(res){
					loadT.close()
					layer.open({
						type:1,
						title:title,
						closeBtn: 2,
						skin: 'verify_site_layer_info active',
						area: '740px',
						content: '<div class="check_delete_site_main pd30">' +
							'<i class="layui-layer-ico layui-layer-ico0"></i>' +
							'<div class="check_layer_title">堡塔温馨提示您，请冷静几秒钟，确认是否要删除以下数据。</div>' +
							'<div class="check_layer_content">' +
							'<div class="check_layer_item">' +
							'<div class="check_layer_site"></div>' +
							'<div class="check_layer_database"></div>' +
							'</div>' +
							'</div>' +
							'<div class="check_layer_error ' + (recycle_bin_db_open ? 'hide' : '') + '"><span class="glyphicon glyphicon-info-sign"></span>风险事项：当前未开启数据库回收站功能，删除数据库后，数据库将永久消失！</div>' +
							'<div class="check_layer_message">请仔细阅读以上要删除信息，防止数据库被误删，确认删除还有 <span style="color:red;font-weight: bold;">' + countDown + '</span> 秒可以操作。</div>' +
							'</div>',
						btn: ['确认删除(' + countDown + '秒后继续操作)', '取消删除'],
						success: function (layers) {
							var html = '', rdata = res.data;
							var filterData = rdata.filter(function(el){
								return  ids.indexOf(el.id) != -1
							})
							for (var i = 0; i < filterData.length; i++) {
								var item = filterData[i], newTime = parseInt(new Date().getTime() / 1000),
									t_icon = '<span class="glyphicon glyphicon-info-sign" style="color: red;width:15px;height: 15px;;vertical-align: middle;"></span>';

								database_html = (function(item){
									var is_time_rule = (newTime - item.st_time) > (86400 * 30)  && (item.total > 1024 * 10),
										is_database_rule = res.db_size <= item.total,
										database_time = bt.format_data(item.st_time, 'yyyy-MM-dd'),
										database_size = bt.format_size(item.total);

									var f_size = '<i ' + (is_database_rule ? 'class="warning"' : '') + ' style = "vertical-align: middle;" > ' + database_size + '</i> ' + (is_database_rule ? t_icon : '');
									var t_size = '注意：此数据库较大，可能为重要数据，请谨慎操作.\n数据库：' + database_size;

									return '<div class="check_layer_database">' +
										'<span title="数据库：' + item.name + '">数据库：' + item.name + '</span>' +
										'<span title="' + t_size+'">大小：' + f_size +'</span>' +
										'<span title="' + (is_time_rule && item.total != 0 ? '重要：此数据库创建时间较早，可能为重要数据，请谨慎操作.' : '') + '时间：' + database_time+'">创建时间：<i ' + (is_time_rule && item.total != 0 ? 'class="warning"' : '') + '>' + database_time + '</i></span>' +
										'</div>'
								}(item))
								if(database_html !== '') html += '<div class="check_layer_item">' + database_html +'</div>';
							}
							if(html === '') html = '<div style="text-align: center;width: 100%;height: 100%;line-height: 300px;font-size: 15px;">无数据</div>'
							$('.check_layer_content').html(html)
							var interVal = setInterval(function () {
								countDown--;
								$(layers).find('.layui-layer-btn0').text('确认删除(' + countDown + '秒后继续操作)')
								$(layers).find('.check_layer_message span').text(countDown)
							}, 1000);
							setTimeout(function () {
								$(layers).find('.layui-layer-btn0').text('确认删除');
								$(layers).find('.check_layer_message').html('<span style="color:red">注意：请仔细阅读以上要删除信息，防止数据库被误删</span>')
								$(layers).removeClass('active');
								clearInterval(interVal)
							}, countDown * 1000)
						},
						yes:function(indes,layers){
							if($(layers).hasClass('active')){
								layer.tips('请确认信息，稍后再尝试，还剩'+ countDown +'秒', $(layers).find('.layui-layer-btn0') , {tips: [1, 'red'],time:3000})
								return;
							}
							if(typeof dbname === "function"){
								dbname(data)
							}else{
								bt.database.del_database(data, function (rdata) {
									layer.closeAll()
									if (rdata.status) database_table.$refresh_table_list(true);
									if (callback) callback(rdata);
									bt.msg(rdata);
								})
							}
						}
					})
				})
			}
		})
	}
}

var sql_server ={
	database_table_view :function(search){
		var param = {
			table: 'databases',
			search: search || ''
		}
		$('#bt_sqldatabase_table').empty();
		database_table = bt_tools.table({
			el: '#bt_sqldatabase_table',
			url: 'database/'+bt.data.db_tab_name+'/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			pageName: 'database',
			beforeRequest:function(beforeData){
				var db_type_val = $('.sqlserver_type_select_filter').val()
				switch(db_type_val){
					case 'all':
						delete param['db_type']
						delete param['sid']
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data']
					return { data: JSON.stringify($.extend(param,beforeData)) }
				}
				return {data:JSON.stringify(param)}
			},
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '数据库名',type:'text'},
				{fid: 'username',title: '用户名',type:'text',sort:true},
				{fid:'password',title:'密码',type:'password',copy:true,eye_open:true},
				{
					fid:'backup_count',
					title: '备份',
					width: 130,
					sort:true,
					template: function (row) {
						var backup = '点击备份',
							_class = "bt_warning";
						if (row.backup_count > 0) backup = lan.database.backup_ok, _class = "bt_success";
						return '<span><a href="javascript:;" class="btlink ' + _class + '" onclick="database.database_detail('+row.id+',\''+row.name+'\')">' + backup + (row.backup_count > 0 ? ('(' + row.backup_count + ')') : '') + '</a> | ' +
							'<a href="javascript:database.input_database(\''+row.name+'\')" class="btlink">'+lan.database.input+'</a></span>';
					}
				},
				{
					title:'数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-'
						switch(row.db_type){
							case 0:
								type_column = '本地数据库'
								break;
							case 1:
								type_column = ('远程库('+row.conn_config.db_host+':'+row.conn_config.db_port+')').toString()
								break;
							case 2:
								$.each(cloudDatabaseList,function(index,item){
									if(row.sid == item.id){
										if(item.ps !== ''){ // 默认显示备注
											type_column = item.ps
										}else{
											type_column = ('远程服务器('+item.db_host+':'+item.db_port+')').toString()
										}
									}
								})
								break;
						}
						return '<span class="flex" style="width:100px" title="'+type_column+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+type_column+'</span></span>'
					}
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps({
							id: row.id,
							table: 'databases',
							ps: ev.target.value
						}, function (res) {
							layer.msg(res.msg, (res.status ? {} : {
								icon: 2
							}));
						});
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					}
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '改密',
						tips: '修改数据库密码',
						hide:function(rows){return rows.db_type == 1},
						event: function (row) {
							database.set_data_pass(row.id, row.username, row.password);
						}
					}, {
						title: '删除',
						tips: '删除数据库',
						event: function (row) {
							database.del_database(row.id, row.name,row, function (res) {
								if (res.status) database_table.$refresh_table_list(true);
								layer.msg(res.msg, {
									icon: res.status ? 1 : 2
								})
							});
						}
					}]
				}
			],
			sortParam: function (data) {
				return {
					'order': data.name + ' ' + data.sort
				};
			},
			tootls: [{ // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
					title: '添加数据库',
					active: true,
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var cloudList = []
						$.each(cloudDatabaseList,function(index,item){
							var _tips = item.ps != ''?(item.ps+' ('+item.db_host+')'):item.db_host
							cloudList.push({title:_tips,value:item.id})
						})
						bt.database.add_database(cloudList,function (res) {
							if (res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: 'sa密码',
					event: function () {
						bt.database.set_root('sa')
					}
				},{
					title:'远程服务器',
					event:function(){
						db_public_fn.get_cloud_server_list();
					}
				},{
					title: '同步所有',
					style:{'margin-left':'30px'},
					event: function () {
						database.sync_to_database({type:0,data:[]},function(res){
							if(res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: '从服务器获取',
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var _list = [];
						$.each(cloudDatabaseList,function (index,item){
							var _tips = item.ps != ''?(item.ps+' (服务器地址:'+item.db_host+')'):item.db_host
							_list.push({title:_tips,value:item.id})
						})
						bt_tools.open({
							title:'选择数据库位置',
							area:'450px',
							btn: ['确认','取消'],
							skin: 'databaseCloudServer',
							content: {
								'class':'pd20',
								form:[{
									label:'数据库位置',
									group:{
										type:'select',
										name:'sid',
										width:'260px',
										list:_list
									}
								}]
							},
							success:function(layers){
								$(layers).find('.layui-layer-content').css('overflow','inherit')
							},
							yes:function (form,layers,index){
								bt.database.sync_database(form.sid,function (rdata) {
									if (rdata.status){
										database_table.$refresh_table_list(true);
										layer.close(layers)
									}
								})
							}
						})
					}
				}]
			},{
				type: 'batch', //batch_btn
				positon: ['left', 'bottom'],
				placeholder: '请选择批量操作',
				buttonValue: '批量操作',
				disabledSelectValue: '请选择需要批量操作的数据库!',
				selectList: [{
					title:'同步选中',
					url:'/database/'+bt.data.db_tab_name+'/SyncToDatabases',
					paramName: 'data', //列表参数名,可以为空
					th:'数据库名称',
					beforeRequest: function(list) {
						var arry = [];
						$.each(list, function (index, item) {
							arry.push(item.id);
						});
						return JSON.stringify({ids:JSON.stringify(arry),type:1})
					},
					success: function (res, list, that) {
						layer.closeAll();
						var html = '';
						$.each(list, function (index, item) {
							html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
						});
						that.$batch_success_table({
							title: '批量同步选中',
							th: '数据库名称',
							html: html
						});
					}
				},{
					title: "删除数据库",
					url: '/database/'+bt.data.db_tab_name+'/DeleteDatabase',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({
								id: row.id,
								name: row.name
							})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						var ids = [];
						for (var i = 0; i < that.check_list.length; i++) {
							ids.push(that.check_list[i].id);
						}
						database.del_database(ids,function(param){
							that.start_batch(param, function (list) {
								layer.closeAll()
								var html = '';
								for (var i = 0; i < list.length; i++) {
									var item = list[i];
									html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
								}
								database_table.$batch_success_table({
									title: '批量删除',
									th: '数据库名称',
									html: html
								});
								database_table.$refresh_table_list(true);
							});
						})
					}
				}]
			}, {
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入数据库名称/备注',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			}, { //分页显示
				type: 'page',
				positon: ['right', 'bottom'], // 默认在右下角
				pageParam: 'p', //分页请求字段,默认为 : p
				page: 1, //当前分页 默认：1
				numberParam: 'limit', //分页数量请求字段默认为 : limit
				number: 20, //分页数量默认 : 20条
				numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
				numberStatus: true, //　是否支持分页数量选择,默认禁用
				jump: true, //是否支持跳转分页,默认禁用
			}],
			success:function(config){
				//搜索前面新增数据库位置下拉
				if($('.sqlserver_type_select_filter').length == 0){
					var _option = '<option value="all">全部</option>'
					$.each(cloudDatabaseList,function(index,item){
						var _tips = item.ps != ''?item.ps:item.db_host
						_option +='<option value="'+item.id+'">'+_tips+'</option>'
					})
					$('#bt_sqldatabase_table .bt_search').before('<select class="bt-input-text mr5 sqlserver_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')

					//事件
					$('.sqlserver_type_select_filter').change(function(){
						database_table.$refresh_table_list(true,function(data){
							if(parseInt($('#bt_sqldatabase_table .page .Pcurrent').text()) !== 1) $('.Pstart').click()
						});
					})
				}
			}
		});
	}
}

var mongodb = {
	database_table_view :function(search){
		var param = {
			table: 'databases',
			search: search || ''
		}
		$('#bt_mongodb_table').empty();
		database_table = bt_tools.table({
			el: '#bt_mongodb_table',
			url: 'database/'+bt.data.db_tab_name+'/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			pageName: 'database',
			beforeRequest:function(beforeData){
				var db_type_val = $('.mongodb_type_select_filter').val()
				switch(db_type_val){
					case 'all':
						delete param['db_type']
						delete param['sid']
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data']
					return { data: JSON.stringify($.extend(param,beforeData)) }
				}
				return {data:JSON.stringify(param)}
			},
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '数据库名',type:'text'},
				{fid: 'username',title: '用户名',type:'text',sort:true},
				{fid:'password',title:'密码',type:'password',copy:true,eye_open:true},
				{
					fid:'backup_count',
					title: '备份',
					width: 130,
					sort:true,
					template: function (row) {
						var backup = '点击备份',
							_class = "bt_warning";
						if (row.backup_count > 0) backup = lan.database.backup_ok, _class = "bt_success";
						return '<span><a href="javascript:;" class="btlink ' + _class + '" onclick="database.database_detail('+row.id+',\''+row.name+'\')">' + backup + (row.backup_count > 0 ? ('(' + row.backup_count + ')') : '') + '</a> | ' +
							'<a href="javascript:database.input_database(\''+row.name+'\')" class="btlink">'+lan.database.input+'</a></span>';
					}
				},
				{
					title:'数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-'
						switch(row.db_type){
							case 0:
								type_column = '本地数据库'
								break;
							case 1:
								type_column = ('远程库('+row.conn_config.db_host+':'+row.conn_config.db_port+')').toString()
								break;
							case 2:
								$.each(cloudDatabaseList,function(index,item){
									if(row.sid == item.id){
										if(item.ps !== ''){ // 默认显示备注
											type_column = item.ps
										}else{
											type_column = ('远程服务器('+item.db_host+':'+item.db_port+')').toString()
										}
									}
								})
								break;
						}
						return '<span class="flex" style="width:100px" title="'+type_column+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+type_column+'</span></span>'
					}
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps({
							id: row.id,
							table: 'databases',
							ps: ev.target.value
						}, function (res) {
							layer.msg(res.msg, (res.status ? {} : {
								icon: 2
							}));
						});
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					}
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '改密',
						tips: '修改数据库密码',
						hide:function(rows){return rows.db_type == 1},
						event: function (row) {
							database.set_data_pass(row.id, row.username, row.password);
						}
					}, {
						title: '删除',
						tips: '删除数据库',
						event: function (row) {
							database.del_database(row.id, row.name,row, function (res) {
								if (res.status) database_table.$refresh_table_list(true);
								layer.msg(res.msg, {
									icon: res.status ? 1 : 2
								})
							});
						}
					}]
				}
			],
			sortParam: function (data) {
				return {
					'order': data.name + ' ' + data.sort
				};
			},
			tootls: [{ // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
					title: '添加数据库',
					active: true,
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var cloudList = []
						$.each(cloudDatabaseList,function(index,item){
							var _tips = item.ps != ''?(item.ps+' ('+item.db_host+')'):item.db_host
							cloudList.push({title:_tips,value:item.id})
						})
						bt.database.add_database(cloudList,function (res) {
							if (res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: 'root密码',
					event: function () {
						if(mongoDBAccessStatus){
							bt.database.set_root('mongo')
						}else{
							layer.msg('请先开启安全认证',{icon:0})
						}
					}
				},{
					title: '安全认证',
					event: function () {
						layer.open({
							title:'安全认证开关',
							area:'250px',
							btn:false,
							content:'<div class="bt-form">\
								<div class="line">\
									<span class="tname">安全认证</span>\
									<div class="info-r">\
										<div class="inlineBlock mr50" style="margin-top: 5px;vertical-align: -6px;">\
											<input class="btswitch btswitch-ios" id="mongodb_access" type="checkbox" name="monitor">\
											<label class="btswitch-btn" for="mongodb_access" style="margin-bottom: 0;"></label>\
										</div>\
									</div>\
								</div>\
								<div class="line">\
									<div class="">\
									<div class="inlineBlock  ">\
									<ul class="help-info-text c7" style="margin-top:0;">\
										<li>安全认证：开启后访问数据需要使用帐号和密码</li>\
									</ul>\
								</div></div></div>\
							</div>',
							success:function(){
								$('#mongodb_access').attr('checked',mongoDBAccessStatus)

								$('#mongodb_access').click(function(){
									var _status = $(this).prop('checked')
									bt_tools.send({url:'database/'+bt.data.db_tab_name+'/set_auth_status',data:{data:JSON.stringify({status:_status?1:0})},verify: true},function(rdata){
										if(rdata.status){
											mongoDBAccessStatus = _status
											layer.msg(rdata.msg,{icon:1})
										}
									},'设置密码访问状态')
								})
							}
						})
					}
				},{
					title:'远程服务器',
					event:function(){
						db_public_fn.get_cloud_server_list();
					}
				},{
					title: '同步所有',
					style:{'margin-left':'30px'},
					event: function () {
						database.sync_to_database({type:0,data:[]},function(res){
							if(res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: '从服务器获取',
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var _list = [];
						$.each(cloudDatabaseList,function (index,item){
							var _tips = item.ps != ''?(item.ps+' (服务器地址:'+item.db_host+')'):item.db_host
							_list.push({title:_tips,value:item.id})
						})
						bt_tools.open({
							title:'选择数据库位置',
							area:'450px',
							btn: ['确认','取消'],
							skin: 'databaseCloudServer',
							content: {
								'class':'pd20',
								form:[{
									label:'数据库位置',
									group:{
										type:'select',
										name:'sid',
										width:'260px',
										list:_list
									}
								}]
							},
							success:function(layers){
								$(layers).find('.layui-layer-content').css('overflow','inherit')
							},
							yes:function (form,layers,index){
								bt.database.sync_database(form.sid,function (rdata) {
									if (rdata.status){
										database_table.$refresh_table_list(true);
										layer.close(layers)
									}
								})
							}
						})
					}
				}]
			},{
				type: 'batch', //batch_btn
				positon: ['left', 'bottom'],
				placeholder: '请选择批量操作',
				buttonValue: '批量操作',
				disabledSelectValue: '请选择需要批量操作的数据库!',
				selectList: [{
					title:'同步选中',
					url:'/database/'+bt.data.db_tab_name+'/SyncToDatabases',
					paramName: 'data', //列表参数名,可以为空
					th:'数据库名称',
					beforeRequest: function(list) {
						var arry = [];
						$.each(list, function (index, item) {
							arry.push(item.id);
						});
						return JSON.stringify({ids:JSON.stringify(arry),type:1})
					},
					success: function (res, list, that) {
						layer.closeAll();
						var html = '';
						$.each(list, function (index, item) {
							html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
						});
						that.$batch_success_table({
							title: '批量同步选中',
							th: '数据库名称',
							html: html
						});
					}
				},{
					title: "删除数据库",
					url: '/database/'+bt.data.db_tab_name+'/DeleteDatabase',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({
								id: row.id,
								name: row.name
							})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						var ids = [];
						for (var i = 0; i < that.check_list.length; i++) {
							ids.push(that.check_list[i].id);
						}
						database.del_database(ids,function(param){
							that.start_batch(param, function (list) {
								layer.closeAll()
								var html = '';
								for (var i = 0; i < list.length; i++) {
									var item = list[i];
									html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
								}
								database_table.$batch_success_table({
									title: '批量删除',
									th: '数据库名称',
									html: html
								});
								database_table.$refresh_table_list(true);
							});
						})
					}
				}]
			}, {
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入数据库名称/备注',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			}, { //分页显示
				type: 'page',
				positon: ['right', 'bottom'], // 默认在右下角
				pageParam: 'p', //分页请求字段,默认为 : p
				page: 1, //当前分页 默认：1
				numberParam: 'limit', //分页数量请求字段默认为 : limit
				number: 20, //分页数量默认 : 20条
				numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
				numberStatus: true, //　是否支持分页数量选择,默认禁用
				jump: true, //是否支持跳转分页,默认禁用
			}],
			success:function(config){
				//搜索前面新增数据库位置下拉
				if($('.mongodb_type_select_filter').length == 0){
					var _option = '<option value="all">全部</option>'
					$.each(cloudDatabaseList,function(index,item){
						var _tips = item.ps != ''?item.ps:item.db_host
						_option +='<option value="'+item.id+'">'+_tips+'</option>'
					})
					$('#bt_mongodb_table .bt_search').before('<select class="bt-input-text mr5 mongodb_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')

					//事件
					$('.mongodb_type_select_filter').change(function(){
						database_table.$refresh_table_list(true,function(data){
							if(parseInt($('#bt_mongodb_table .page .Pcurrent').text()) !== 1) $('.Pstart').click()
						});
					})
				}
			}
		});
	}
}
var redis = {
	redisDBList:[],
	cloudInfo:{
		sid:0,
		title:'本地服务器'
	},  //当前远程信息
	database_table_view:function(){
		var that = this;

		this.cloudInfo.sid = cloudDatabaseList.length == 0 ? 0 : cloudDatabaseList[0].id
		this.cloudInfo.title = cloudDatabaseList.length == 0 ? '本地数据库' : cloudDatabaseList[0].ps
		$('#bt_redis_view').empty()

		$('#bt_redis_view').html('<div class="pull-right redis_cloud_server"></div>')

		// 远程服务器列表
		var _option = ''
		$.each(cloudDatabaseList,function(index,item){
			var _tips = item.ps != ''?item.ps:item.db_host
			_option +='<option value="'+item.id+'">'+_tips+'</option>'
		})
		$('#bt_redis_view .redis_cloud_server').html('<span class="mr5" style="color:#f0ad4e"><span class="glyphicon glyphicon-info-sign"></span>当前所有操作项都关联至</span><select class="bt-input-text mr5 redis_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')

		//远程服务器列表点击事件
		$('.redis_type_select_filter').change(function(){
			that.cloudInfo.sid = $(this).val();
			that.cloudInfo.title = $(this).find('option:selected').text();
			that.render_redis_content()
			if(parseInt($('#bt_redis_view .page .Pcurrent').text()) !== 1) $('.Pstart').click()
		})


		// 渲染redis列表
		this.render_redis_content()
	},
	render_redis_content:function(id){
		$('.redis_content_view').remove()
		var that = this;
		$('#bt_redis_view').append('<div class="redis_content_view">\
		<button type="button" title="添加Key" class="btn btn-success btn-sm mr5 addRedisDB" style="margin-bottom:10px"><span>添加Key</span></button>\
		<button type="button" title="远程服务器" class="btn btn-default btn-sm mr5 RedisCloudDB" style="margin-bottom:10px"><span>远程服务器</span></button>\
		<button type="button" title="备份列表" class="btn btn-default btn-sm mr5 backupRedis" style="margin-bottom:10px;display:'+(this.cloudInfo.sid == 0?'inline-block':'none')+'"><span>备份列表</span></button>\
		<button type="button" title="清空数据库" class="btn btn-default btn-sm emptyRedisDB" style="margin:0 0 10px 30px"><span>清空数据库</span></button>\
		<div id="redis_content_tab"><div class="tab-nav"></div><div class="tab-con redis_table_content" style="padding:10px 0"></div></div></div>')
		var tabHTML = ''
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/get_list',data:{data:JSON.stringify({sid:that.cloudInfo.sid})}},function(rdata){
			that.redisDBList = rdata;
			$.each(rdata,function(index,item){
				tabHTML +='<span data-id="'+item.id+'">'+item.name+'('+item.keynum+')</span>'
			})
			$('#redis_content_tab .tab-nav').html(tabHTML)


			setTimeout(function(){
				if(id){
					$('#redis_content_tab .tab-nav span:contains(DB'+id+')').click()
				}else{
					if(rdata.length == 0){
						$('#redis_content_tab .tab-nav').remove()
						that.render_redis_table(0)
					}else{
						$('#redis_content_tab .tab-nav span:eq(0)').click()
					}
				}
			},50)

			$('.addRedisDB').click(function(){
				that.set_redis_library()
			})
			$('.backupRedis').click(function(){
				that.backup_redis_list()
			})
			$('.emptyRedisDB').click(function(){
				that.choose_redis_list()
			})
			$('.RedisCloudDB').click(function(){
				db_public_fn.get_cloud_server_list()
			})

			// redis数据库点击事件
			$('#redis_content_tab .tab-nav span').click(function(){
				var _id = $(this).data('id');
				$(this).addClass('on').siblings().removeClass('on')
				that.render_redis_table(_id)
			})
		})
	},
	render_redis_table:function(id){
		var that = this;
		$('.redis_table_content').empty();
		database_table = bt_tools.table({
			el: '.redis_table_content',
			url: 'database/redis/get_db_keylist',
			param: {db_idx:id}, //参数
			minWidth: '1000px',
			autoHeight: true,
			load: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			pageName: 'database',
			beforeRequest:function(beforeData){
				var db_type_val = that.cloudInfo.sid,param = {}
				switch(db_type_val){
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data']
					return { data: JSON.stringify($.extend(param,{db_idx:id},beforeData)) }
				}
				return {data:JSON.stringify($.extend(param,{db_idx:id,limit:beforeData.limit}))}
			},
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '键',type:'text'},
				{fid: 'val',title: '值',type:'text',template:function(row){
						var _val = $('<div></div>').text(row.val)
						return '<div class="flex" style="width:350px" title="'+_val.text().replace(/\"/g, '\&quot;')+'"><span class="size_ellipsis">'+_val.text()+'</span><span class="ico-copy cursor btcopy ml5" title="复制密码"></span></div>'
					},event:function(row,index,ev,key){
						if($(ev.target).hasClass('btcopy')){
							bt.pub.copy_pass(row.val);
						}
					}},
				{fid:'type',title:'数据类型',type:'text'},
				{fid:'len',title:'数据长度',type:'text'},
				{fid:'endtime',title:'有效期',type:'text',template: function (row) {
						return that.reset_time_format(row.endtime)
					}},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '编辑',
						tips: '编辑数据',
						event: function (row) {
							that.set_redis_library(row)
						}
					},{
						title: '删除',
						tips: '删除数据',
						event: function (row) {
							layer.confirm('是否删除【'+row.name+'】', {
								title: '删除key值', closeBtn: 2, icon: 0
							}, function (index) {
								bt_tools.send({url:'database/redis/del_redis_val',data:{data:JSON.stringify({db_idx:id,key:row.name,sid:that.cloudInfo.sid})}},function(rdata){
									if(rdata.status){
										that.render_redis_table(id);
									}
									bt_tools.msg(rdata)
									layer.close(index)
								})
							});
						}
					}]
				}
			],
			tootls: [{
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入键名称',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			},{ // 批量操作
				type:'batch',
				positon:['left','bottom'],
				config:{
					title:"删除",
					url:'/database/redis/del_redis_val',
					load:true,
					param:function(row){
						return {data:JSON.stringify({db_idx:id,key:row.name,sid:that.cloudInfo.sid})};
					},
					callback:function(that){
						bt.confirm({title:'批量删除',msg:'是否批量删除选中数据，是否继续？',icon:0},function(index){
							layer.close(index);
							that.start_batch({},function(list){
								var html = '';
								for(var i=0;i<list.length;i++){
									var item = list[i];
									html += '<tr><td>'+ item.name +'</td><td><div style="float:right;"><span style="color:'+ (item.request.status?'#20a53a':'red') +'">'+ item.request.msg +'</span></div></td></tr>';
								}
								database_table.$batch_success_table({title:'批量删除',th:'键名',html:html});
								database_table.$refresh_table_list(true);
							});
						});
					}
				}
			}, { //分页显示
				type: 'page',
				positon: ['right', 'bottom'], // 默认在右下角
				pageParam: 'p', //分页请求字段,默认为 : p
				page: 1, //当前分页 默认：1
				numberParam: 'limit', //分页数量请求字段默认为 : limit
				number: 20, //分页数量默认 : 20条
				numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
				numberStatus: true, //　是否支持分页数量选择,默认禁用
				jump: true, //是否支持跳转分页,默认禁用
			}],
			success: function () {
				var arry = [],maxWidth = ''
				for (var i = 0; i < $('.size_ellipsis').length; i++) {
					arry.push($('.size_ellipsis').eq(i).width())
				}
				maxWidth = Math.max.apply(null,arry)
				if(maxWidth > 100)$('.size_ellipsis').width(maxWidth)
			}
		});
	},
	// redis备份列表
	backup_redis_list:function(){
		var that = this,redisBackupTable = null;
		bt_tools.open({
			title:'Redis备份列表',
			area:['927px','633px'],
			btn: false,
			skin: 'redisBackupList',
			content: '<div id="redisBackupTable" class="pd20" style="padding-bottom:40px;"></div>',
			success:function(){
				redisBackupTable = bt_tools.table({
					el:'#redisBackupTable',
					default:'备份列表为空',
					height:478,
					url: 'database/redis/get_backup_list',
					column:[{
						fid:'name',
						title:'名称',
						width: 170,
						template: function (item) {
							return '<span class="flex" style="width:154px" title="'+item.name+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+item.name+'</span></span>'
						}},
						{
							fid:'filepath',
							title:'路径',
							template: function (item) {
								return '<span class="flex" style="width:280px" title="'+item.filepath+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+item.filepath+'</span></span>'
							}},
						{fid:'mtime',width:137,title:'备份时间',template:function(row){
							return '<span>'+bt.format_data(row.mtime)+'</span>'
						}},
						{fid:'size',title:'大小',template:function(row){
							return '<span>'+bt.format_size(row.size)+'</span>'
						}},
						{fid:'sid',width:78,title:'备份位置',template:function(row){
							var type_column = '-'
							switch(row.sid){
								case "0":
									type_column = '本地数据库'
									break;
								case "1":
									type_column = ('远程库('+row.conn_config.db_host+':'+row.conn_config.db_port+')').toString()
									break;
								case "2":
									$.each(cloudDatabaseList,function(index,item){
										if(row.sid == item.id){
											if(item.ps !== ''){ // 默认显示备注
												type_column = item.ps
											}else{
												type_column = ('远程服务器('+item.db_host+':'+item.db_port+')').toString()
											}
										}
									})
									break;
							}
							return '<span class="flex" style="width:100px" title="'+type_column+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+type_column+'</span></span>'
						}},
						{
							type: 'group',
							title: '操作',
							align: 'right',
							group: [{
								title:'恢复',
								event:function(row){
									bt.prompt_confirm('覆盖数据', '即将使用【'+row.name+'】对数据进行覆盖，是否继续?', function () {
										bt_tools.send({url:'database/redis/InputSql',data:{data:JSON.stringify({file:row.filepath,sid:0})}},function(rdata){
											if(rdata.status) that.render_redis_content();
											bt_tools.msg(rdata)
											layer.close(index)
										})
									})
								}
							},{
								title:'删除',
								event:function(row){
									layer.confirm('是否删除【'+row.name+'】备份', {
										title: '删除备份', closeBtn: 2, icon: 0
									}, function (index) {
										bt_tools.send({url:'database/redis/DelBackup',data:{data:JSON.stringify({file:row.filepath})}},function(rdata){
											if(rdata.status) redisBackupTable.$refresh_table_list(true);
											bt_tools.msg(rdata)
											layer.close(index)
										})
									});
								}
							}]
						}
					],
					tootls:[{
						type:'group',
						positon: ['left','top'],
						list:[{
							title:'立即备份',
							active: true,
							event:function(){
								bt_tools.send({url:'database/redis/ToBackup'},function(rdata){
									if(rdata.status) redisBackupTable.$refresh_table_list(true);
									bt_tools.msg(rdata)
								})
							}
						}]
					}]
				})
			}
		})
	},
	// 添加/编辑redis库
	set_redis_library:function(row){
		var that = this,
			redis_form = null,

			cloudList = []
		$.each(cloudDatabaseList,function(index,item){
			var _tips = item.ps != ''?(item.ps+' ('+item.db_host+')'):item.db_host
			cloudList.push({title:_tips,value:item.id})
		})
		bt_tools.open({
			title:(row?('编辑['+row.name+']'):'添加')+'Key'+(!row?('至【'+this.cloudInfo.title+'】'):''),
			area:'400px',
			btn:[(row?'保存':'添加'),'取消'],
			content: '<div class="ptb20" id="redis_library_form"></div>',
			success: function (layers) {
				redis_form = bt_tools.form({
					el:'#redis_library_form',
					form: [{
						label:'数据库',
						group:{
							type:'select',
							name:'db_idx',
							width:'260px',
							list:[
								{title:'DB0',value:0},
								{title:'DB1',value:1},
								{title:'DB2',value:2},
								{title:'DB3',value:3},
								{title:'DB4',value:4},
								{title:'DB5',value:5},
								{title:'DB6',value:6},
								{title:'DB7',value:7},
								{title:'DB8',value:8},
								{title:'DB9',value:9},
								{title:'DB10',value:10},
								{title:'DB11',value:11},
								{title:'DB12',value:12},
								{title:'DB13',value:13},
								{title:'DB14',value:14},
								{title:'DB15',value:15}
							],
							disabled:row?true:false,
						}
					},{
						label:'键',
						group:{
							type:'text',
							name:'name',
							width:'260px',
							placeholder:'请输入键(key)',
							disabled:row?true:false,
						}
					},{
						label:'值',
						group:{
							type:'textarea',
							name:'val',
							width:'260px',
							style: {
								'min-height': '100px',
								'line-height': '22px',
								'padding-top': '5px',
								'resize': 'both'
							},
							placeholder:'请输入值',
						}
					},{
						label:'有效期',
						group:{
							type:'number',
							name:'endtime',
							width:'235px',
							placeholder:'为空则永不过期',
							unit:'秒'
						}
					},{
						group: {
							type: 'help',
							style: { 'margin-left': '30px' },
							list: ['有效期为0表示永久']
						}
					}],
					data:row?$.extend(row,{db_idx:$('#redis_content_tab .tab-nav span.on').data('id')}):{db_idx:$('#redis_content_tab .tab-nav span.on').data('id')}
				})
			},
			yes:function(indexs){
				var formValue = redis_form.$get_form_value()
				if(formValue.name == '') return layer.msg('键不能为空')
				if(formValue.val == '') return layer.msg('值不能为空')
				if(formValue.endtime <= 0) delete formValue.endtime
				if(row){
					formValue['db_idx'] = $('#redis_content_tab .tab-nav span.on').data('id')
				}
				formValue['sid'] = that.cloudInfo.sid
				bt_tools.send({url:'database/redis/set_redis_val',data:{data:JSON.stringify(formValue)}},function(res){
					if(res.status){
						layer.close(indexs);
						that.render_redis_content(formValue.db_idx)
					}
					bt_tools.msg(res)
				},(row?'保存':'添加')+'redis数据中')
			}
		})
	},
	//选择需要清空的redis库
	choose_redis_list:function(){
		var that = this;
		layer.open({
			type:1,
			area:'400px',
			title:'清空【'+this.cloudInfo.title+'】数据库',
			shift: 5,
			closeBtn: 2,
			shadeClose: false,
			btn:['确认','取消'],
			content:'<div class="bt-form pd20" id="choose_redis_from">\
					<div class="line"><span class="tname">选择数据库</span>\
						<div class="info-r">\
							<div class="rule_content_list">\
								<div class="rule_checkbox_group" bt-event-click="checkboxMysql" bt-event-type="active_all"><input name="*" type="checkbox" style="display: none;">\
									<div class="bt_checkbox_groups active"></div>\
									<span class="rule_checkbox_title">全部选中</span></div>\
								<ul class="rule_checkbox_list"></ul>\
							</div>\
						</div>\
					</div>\
				</div>',
			success:function(layers,index){
				var rule_site_list = '';
				$.each(that.redisDBList,function(index,item){
					rule_site_list += '<li>'
						+'<div class="rule_checkbox_group" bt-event-click="checkboxMysql" bt-event-type="active">'
						+'<span class="glyphicon glyphicon-menu-right" style="display:none" aria-hidden="true" bt-event-click="checkboxMysql" bt-event-type="fold"></span>'
						+'<input name="'+ item.name +'" type="checkbox" data-id="'+item.id+'" checked=checked style="display: none;">'
						+'<div class="bt_checkbox_groups active"></div>'
						+'<span class="rule_checkbox_title">'+ item.name +'</span>'
						+'</div>'
						+'</li>'
					$('.rule_checkbox_list').html(rule_site_list);
					that.event_bind()
				});
			},
			yes:function(index,layers){
				var redisIDList = [];
				$('#choose_redis_from .rule_checkbox_list input').each(function(index,el){
					if($(this).prop('checked')){
						redisIDList.push($(this).data('id'))
					}
				});
				if(redisIDList.length == 0)return layer.msg('请选择需要删除的数据库',{icon:2})
				layer.confirm('清空后数据将无法恢复,是否继续?', {
					title: '清空数据库', closeBtn: 2, icon: 0
				}, function (index) {
					bt_tools.send({url:'database/redis/clear_flushdb',data:{data:JSON.stringify({ids:JSON.stringify(redisIDList),sid:that.cloudInfo.sid})}},function(rdata){
						if(rdata.status){
							that.render_redis_content();
							layer.closeAll()
						}
						bt_tools.msg(rdata)
					})
				});

			}
		})
	},

	event_bind:function(){
		$('.rule_checkbox_group').unbind('click').click(function(ev){
			var _type = $(this).attr('bt-event-type'), _checkbox = '.bt_checkbox_groups';
			switch (_type) {
				case 'active_all'://选中全部
					var thatActive = $(this).find(_checkbox), thatList = $(this).next();
					if (thatActive.hasClass('active')) {
						thatActive.removeClass('active').prev().prop('checked', false);
						thatList.find(_checkbox).removeClass('active').prev().prop('checked', false);
					} else {
						thatActive.addClass('active').prev().prop('checked', true);
						thatList.find(_checkbox).addClass('active').prev().prop('checked', true);
					}
					break;
				case 'active': //激活选中和取消
					var thatActive = $(this).find(_checkbox), thatList = $(this).next();
					if (thatActive.hasClass('active')) {
						thatActive.removeClass('active').prev().prop('checked', false);
						$('.mysql_content_list>.mysql_checkbox_group input').prop('checked', false).next().removeClass('active');
						if (thatList.length == 1) {
							thatList.find(_checkbox).removeClass('active').prev().prop('checked', false);
						} else {
							var nodeLength = $(this).parent().siblings().length + 1,
								nodeList = $(this).parent().parent();
							if (nodeList.find('.bt_checkbox_groups.active').length != nodeLength) {
								nodeList.prev().find(_checkbox).removeClass('active').prev().prop('checked', false);
							}
						}
					} else {
						thatActive.addClass('active').prev().prop('checked', true);
						if (thatList.length == 1) {
							thatList.find(_checkbox).addClass('active').prev().prop('checked', true);
						} else {
							var nodeLength = $(this).parent().siblings().length + 1,
								nodeList = $(this).parent().parent();
							if (nodeList.find('.bt_checkbox_groups.active').length == nodeLength) {
								nodeList.prev().find(_checkbox).addClass('active').prev().prop('checked', true);
							}
						}
					}
					break;
				case 'fold': //折叠数据库列表
					if ($(this).hasClass('glyphicon-menu-down')) {
						$(this).removeClass('glyphicon-menu-down').addClass('glyphicon-menu-right').parent().next().hide();
					} else {
						$(this).removeClass('glyphicon-menu-rigth').addClass('glyphicon-menu-down').parent().next().show();
					}
					break;
			}
			$('.rule_content_list').removeAttr('style');
			ev.stopPropagation();
		})
	},
	//重置时间格式
	reset_time_format:function(time){
		if(time == 0) return '永久'
		var theTime = parseInt(time);// 秒
		var middle= 0;// 分
		var hour= 0;// 小时

		if(theTime > 60) {
			middle= parseInt(theTime/60);
			theTime = parseInt(theTime%60);
			if(middle> 60) {
				hour= parseInt(middle/60);
				middle= parseInt(middle%60);
			}
		}
		var result = ""+parseInt(theTime)+"秒";
		if(middle > 0) {
			result = ""+parseInt(middle)+"分"+result;
		}
		if(hour> 0) {
			result = ""+parseInt(hour)+"小时"+result;
		}
		return result;
	}
}

var pgsql ={
	database_table_view :function(search){
		var param = {
			table: 'databases',
			search: search || ''
		}
		$('#bt_pgsql_table').empty();
		database_table = bt_tools.table({
			el: '#bt_pgsql_table',
			url: 'database/'+bt.data.db_tab_name+'/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			pageName: 'database',
			beforeRequest:function(beforeData){
				var db_type_val = $('.pgsql_type_select_filter').val()
				switch(db_type_val){
					case 'all':
						delete param['db_type']
						delete param['sid']
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data']
					return { data: JSON.stringify($.extend(param,beforeData)) }
				}
				return {data:JSON.stringify(param)}
			},
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '数据库名',type:'text'},
				{fid: 'username',title: '用户名',type:'text',sort:true},
				{fid:'password',title:'密码',type:'password',copy:true,eye_open:true},
				{
					fid:'backup_count',
					title: '备份',
					width: 130,
					sort:true,
					template: function (row) {
						var backup = '点击备份',
							_class = "bt_warning";
						if (row.backup_count > 0) backup = lan.database.backup_ok, _class = "bt_success";
						return '<span><a href="javascript:;" class="btlink ' + _class + '" onclick="database.database_detail('+row.id+',\''+row.name+'\')">' + backup + (row.backup_count > 0 ? ('(' + row.backup_count + ')') : '') + '</a> | ' +
							'<a href="javascript:database.input_database(\''+row.name+'\')" class="btlink">'+lan.database.input+'</a></span>';
					}
				},
				{
					title:'数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-'
						switch(row.db_type){
							case 0:
								type_column = '本地数据库'
								break;
							case 1:
								type_column = ('远程库('+row.conn_config.db_host+':'+row.conn_config.db_port+')').toString()
								break;
							case 2:
								$.each(cloudDatabaseList,function(index,item){
									if(row.sid == item.id){
										if(item.ps !== ''){ // 默认显示备注
											type_column = item.ps
										}else{
											type_column = ('远程服务器('+item.db_host+':'+item.db_port+')').toString()
										}
									}
								})
								break;
						}
						return '<span class="flex" style="width:100px" title="'+type_column+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+type_column+'</span></span>'
					}
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps({
							id: row.id,
							table: 'databases',
							ps: ev.target.value
						}, function (res) {
							layer.msg(res.msg, (res.status ? {} : {
								icon: 2
							}));
						});
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					}
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '改密',
						tips: '修改数据库密码',
						hide:function(rows){return rows.db_type == 1},
						event: function (row) {
							database.set_data_pass(row.id, row.username, row.password);
						}
					}, {
						title: '删除',
						tips: '删除数据库',
						event: function (row) {
							database.del_database(row.id, row.name,row, function (res) {
								if (res.status) database_table.$refresh_table_list(true);
								layer.msg(res.msg, {
									icon: res.status ? 1 : 2
								})
							});
						}
					}]
				}
			],
			sortParam: function (data) {
				return {
					'order': data.name + ' ' + data.sort
				};
			},
			tootls: [{ // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
					title: '添加数据库',
					active: true,
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var cloudList = []
						$.each(cloudDatabaseList,function(index,item){
							var _tips = item.ps != ''?(item.ps+' ('+item.db_host+')'):item.db_host
							cloudList.push({title:_tips,value:item.id})
						})
						bt.database.add_database(cloudList,function (res) {
							if (res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: '管理员密码',
					event: function () {
						bt.database.set_root('pgsql')
					}
				},{
					title:'远程服务器',
					event:function(){
						db_public_fn.get_cloud_server_list();
					}
				},{
					title: '同步所有',
					style:{'margin-left':'30px'},
					event: function () {
						database.sync_to_database({type:0,data:[]},function(res){
							if(res.status) database_table.$refresh_table_list(true);
						})
					}
				},{
					title: '从服务器获取',
					event: function () {
						if(cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库',{time:0,icon:2,closeBtn: 2, shade: .3})
						var _list = [];
						$.each(cloudDatabaseList,function (index,item){
							var _tips = item.ps != ''?(item.ps+' (服务器地址:'+item.db_host+')'):item.db_host
							_list.push({title:_tips,value:item.id})
						})
						bt_tools.open({
							title:'选择数据库位置',
							area:'450px',
							btn: ['确认','取消'],
							skin: 'databaseCloudServer',
							content: {
								'class':'pd20',
								form:[{
									label:'数据库位置',
									group:{
										type:'select',
										name:'sid',
										width:'260px',
										list:_list
									}
								}]
							},
							success:function(layers){
								$(layers).find('.layui-layer-content').css('overflow','inherit')
							},
							yes:function (form,layers,index){
								bt.database.sync_database(form.sid,function (rdata) {
									if (rdata.status){
										database_table.$refresh_table_list(true);
										layer.close(layers)
									}
								})
							}
						})
					}
				}]
			},{
				type: 'batch', //batch_btn
				positon: ['left', 'bottom'],
				placeholder: '请选择批量操作',
				buttonValue: '批量操作',
				disabledSelectValue: '请选择需要批量操作的数据库!',
				selectList: [{
					title:'同步选中',
					url:'/database/'+bt.data.db_tab_name+'/SyncToDatabases',
					paramName: 'data', //列表参数名,可以为空
					th:'数据库名称',
					beforeRequest: function(list) {
						var arry = [];
						$.each(list, function (index, item) {
							arry.push(item.id);
						});
						return JSON.stringify({ids:JSON.stringify(arry),type:1})
					},
					success: function (res, list, that) {
						layer.closeAll();
						var html = '';
						$.each(list, function (index, item) {
							html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
						});
						that.$batch_success_table({
							title: '批量同步选中',
							th: '数据库名称',
							html: html
						});
					}
				},{
					title: "删除数据库",
					url: '/database/'+bt.data.db_tab_name+'/DeleteDatabase',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({
								id: row.id,
								name: row.name
							})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						var ids = [];
						for (var i = 0; i < that.check_list.length; i++) {
							ids.push(that.check_list[i].id);
						}
						database.del_database(ids,function(param){
							that.start_batch(param, function (list) {
								layer.closeAll()
								var html = '';
								for (var i = 0; i < list.length; i++) {
									var item = list[i];
									html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
								}
								database_table.$batch_success_table({
									title: '批量删除',
									th: '数据库名称',
									html: html
								});
								database_table.$refresh_table_list(true);
							});
						})
					}
				}]
			}, {
				type: 'search',
				positon: ['right', 'top'],
				placeholder: '请输入数据库名称/备注',
				searchParam: 'search', //搜索请求字段，默认为 search
				value: '',// 当前内容,默认为空
			}, { //分页显示
				type: 'page',
				positon: ['right', 'bottom'], // 默认在右下角
				pageParam: 'p', //分页请求字段,默认为 : p
				page: 1, //当前分页 默认：1
				numberParam: 'limit', //分页数量请求字段默认为 : limit
				number: 20, //分页数量默认 : 20条
				numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
				numberStatus: true, //　是否支持分页数量选择,默认禁用
				jump: true, //是否支持跳转分页,默认禁用
			}],
			success:function(config){
				//搜索前面新增数据库位置下拉
				if($('.pgsql_type_select_filter').length == 0){
					var _option = '<option value="all">全部</option>'
					$.each(cloudDatabaseList,function(index,item){
						var _tips = item.ps != ''?item.ps:item.db_host
						_option +='<option value="'+item.id+'">'+_tips+'</option>'
					})
					$('#bt_pgsql_table .bt_search').before('<select class="bt-input-text mr5 pgsql_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')

					//事件
					$('.pgsql_type_select_filter').change(function(){
						database_table.$refresh_table_list(true,function(data){
							if(parseInt($('#bt_pgsql_table .page .Pcurrent').text()) !== 1) $('.Pstart').click()
						});
					})
				}
			}
		});
	}
}

var sqlite = {
	database_table_view: function () {
		var that = this;
		$('#bt_sqlite_table').empty();
		database_table = bt_tools.table({
			el: '#bt_sqlite_table',
			url: 'database/'+bt.data.db_tab_name+'/get_list',
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: "数据库列表为空", // 数据为空时的默认提示
			column:[
				{type: 'checkbox',width: 20},
				{fid: 'name',title: '数据库名',type:'text'},
				{
					fid:'backup_count',
					title: '备份',
					width: 130,
					// sort:true,
					template: function (row) {
						var backup = '点击备份',
							_class = "bt_warning";
						if (row.backup_count > 0) backup = lan.database.backup_ok, _class = "bt_success";
						return '<span><a href="javascript:;" class="btlink ' + _class + '" onclick="sqlite.database_detail(`'+ (row.path+'`,`'+row.name)  +'`)">' + backup + (row['backup_count'] && row.backup_count > 0 ? ('(' + row.backup_count + ')') : '') + '</a>' +
							'</span>';
					}
				},
				{
					fid:'path',
					title:'路径',
				},
				{fid:'size',title:'大小',template:function(row){
					return '<span>'+bt.format_size(row.size)+'</span>'
				}},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [{
						title: '管理',
						event: function (row) {
							that.table_management(row)
						}
					}, {
						title: '删除',
						tips: '删除数据库文件',
						event: function (row) {
							bt.confirm({title:'删除数据库文件【'+ row.name +'】',msg:'删除选中的数据库文件后，该数据库文件将不在列表中显示，是否继续操作？',icon:0},function(index){
								var loadT = bt.load('正在删除数据库文件...');
								bt_tools.send({url: 'database/sqlite/DeleteDatabase', data:{ data: JSON.stringify({path:row.path})}}, function (rdata) {
									loadT.close();
									if (rdata.status) {
										database_table.$refresh_table_list(true);
									}
									bt.msg(rdata);
								});
							})
						}
					}]
				}
			],
			// sortParam: function (data) {
			// 	return {
			// 		'order': data.name + ' ' + data.sort
			// 	};
			// },
			tootls: [{ // 按钮组
				type: 'group',
				positon: ['left', 'top'],
				list: [{
					title: '添加数据库文件',
					active: true,
					event: function () {
						that.addSqlite()
					}
				},
				]
			},{
				type: 'batch', //batch_btn
				positon: ['left', 'bottom'],
				placeholder: '请选择批量操作',
				buttonValue: '批量操作',
				disabledSelectValue: '请选择需要批量操作的数据库!',
				selectList: [{
					title: "备份数据库",
					url: '/database/'+bt.data.db_tab_name+'/ToBackup',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({path: row.path})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						that.start_batch({},function(list){
							var html = '';
							for(var i=0;i<list.length;i++){
								var item = list[i];
								html += '<tr><td>'+ item.name +'</td><td><div style="float:right;"><span style="color:'+ (item.request.status?'#20a53a':'red') +'">'+ item.request.msg +'</span></div></td></tr>';
							}
							database_table.$batch_success_table({title:'批量备份数据库',th:'数据库名',html:html});
							database_table.$refresh_table_list(true);
						});
					}
				},{
					title: "删除数据库",
					url: '/database/'+bt.data.db_tab_name+'/DeleteDatabase',
					load: true,
					param: function (row) {
						return {data:JSON.stringify({path: row.path})}
					},
					callback: function (that) { // 手动执行,data参数包含所有选中的站点
						bt.confirm({title:'批量删除数据库文件',msg:'删除选中的数据库文件后，该数据库文件将不在列表中显示，是否继续操作？',icon:0},function(index){
							layer.close(index);
							that.start_batch({},function(list){
								var html = '';
								for(var i=0;i<list.length;i++){
									var item = list[i];
									html += '<tr><td>'+ item.name +'</td><td><div style="float:right;"><span style="color:'+ (item.request.status?'#20a53a':'red') +'">'+ item.request.msg +'</span></div></td></tr>';
								}
								database_table.$batch_success_table({title:'批量删除',th:'数据库名',html:html});
								database_table.$refresh_table_list(true);
							});
						});
					}
				}]
			}]
			
		})
	},
	//管理
	table_management: function (row) {
		var that = this,managementTable = null;
		bt_tools.send({url: 'database/sqlite/get_table_list', data:{ data: JSON.stringify({path:row.path})}}, function (rdata) {
			bt_tools.open({
				title: '管理',
				area:['1140px','650px'],
				btn: false,
				content: '<div class="bt-w-man"><div class="man_l"><ul class="man_db"></ul></div><div class="man_r"><div class="ul_scroll"><ul></ul></div><div class="table_info pd15"></div><div class="nq_con"></div></div></div>',
				success:function(layers){
					setTimeout(function () { $(layers).css('top', ($(window).height() - $(layers).height()) / 2); }, 50)
					var  db_html = '',
						t_html = '<li class="new_query" title="新建查询"><i></i><span>新建查询</span></li>',
						db_arr = []
					db_arr.push(row)
					for (var i = 0; i < rdata.length; i++) {
						t_html += '<li title="'+ rdata[i].name + '（'+ rdata[i].count +'）' +'" data-tablename="'+ rdata[i].name +'"><i></i><span>'+ rdata[i].name + '（'+ rdata[i].count +'）' +'</span></li>'
					}
					for (var i = 0; i < db_arr.length; i++) {
						db_html += '<li class="active" title="'+ db_arr[i].path +'" data-path="'+ db_arr[i].path +'" data-databasename="'+ db_arr[i].name +'"><div class="man_db_li"><span class="glyphicon glyphicon-menu-down"></span><i></i><span class="db_title">'+ db_arr[i].name +'</span></div><ul class="man_t">'+ t_html +'</ul></li>'
					}
					$('.man_l .man_db').append(db_html);
					//左侧数据库点击事件
					$('.man_db_li').click(function () {
						var _parent = $(this).parent(),_icon = $(this).find('.glyphicon');
						if(_parent.hasClass('active')){
							_parent.removeClass('active')
							_icon.addClass('glyphicon-menu-right').removeClass('glyphicon-menu-down')
						}else{
							_parent.addClass('active')
							_icon.removeClass('glyphicon-menu-right').addClass('glyphicon-menu-down')
						}
					})
					setTimeout(function () { if($('.man_t li').length > 1) $('.man_db').find('[data-path="'+ db_arr[0].path +'"]').find('[data-tablename="'+ rdata[0].name +'"]').click();},50)
					//左侧表点击事件
					$('.man_l').on('click','.man_t li',function () {
					// $('.man_t li').click(function () {
						var _parent = $(this).parent(),_path = _parent.parent().data('path')
						$(this).addClass('active').siblings().removeClass('active')
						$('.man_r ul li').removeClass('active')
						if($(this).hasClass('new_query')){
							$('.table_info').hide().next().show()
							//渲染新建查询
							var _id = bt.get_random(8)
							$('.man_r ul').append('<li id="new_query_'+ _id +'" class="active new_query" title="新建查询"><div><i></i><span>新建查询</span><span class="glyphicon glyphicon-remove"></span></div></li>')
							$('.man_r .nq_con').append('<div class="nq_con_'+ _id +'"><div class="pd15">\
								<div class="bt-input-text ace_config_editor_scroll" style="height: 210px; line-height:18px;" id="nqConfigBody_'+ _id +'"></div>\
								<button class="btn btn-default btn-sm run_sql_btn" style="margin-top:10px;">运行</button></div><div class="run_result pd15"></div></div>')
							$('.nq_con_'+ _id).show().siblings().hide()
							var editor = bt.aceEditor({
								el: 'nqConfigBody_'+ _id,
								content: '',
								mode: 'html',
								saveCallback: function (val) {
									if(val == '') return layer.msg('运行sql语句不能为空')
									var _this = $('.nq_con_'+ _id).find('.run_sql_btn')
									_this.addClass('disabled').text('正在运行...')
									bt_tools.send({url:'database/sqlite/query_sql',data:{ data: JSON.stringify({ path: _path, sql_shell: val })}},function(result){
										_this.removeClass('disabled').text('运行')
										if(result.status){
											$('.nq_con_'+ _id).find('.run_result').css({'border-top':'1px solid #eee'}).html('<span>查询结果：</span><div class="mt10"><table border="1" class="result_table table" style="border: 1px solid #ddd;margin-bottom: 0;"></div></div>')
											var _html = ''
											for (var i = 0; i < result.list.length; i++) {
												_html += '<tr>'
												for (var j = 0; j < result.list[i].length; j++) {
													_html += '<td><span>\
														<span title="点击查看详情" class="event_details" style="overflow: hidden;white-space: nowrap;min-width: 30px;max-width: 200px;display: block;text-overflow: ellipsis;">'+ result.list[i][j] +'</span>\
														<textarea class="event_textarea" style="border: none;display:none;" readonly>'+ result.list[i][j] +'</textarea>\
													</span></td>'
												}
												_html += '</tr>'
											}
											$('.nq_con_'+ _id).find('.result_table').html(_html)
											$('.run_result .event_details').click(function () {
												$('.run_result .event_details').show()
												$('.run_result .event_textarea').hide()
												$(this).hide().next().show().css('width',$(this).width())
											})
										}
									})
								}
							});
							$('.nq_con_'+ _id).find('.run_sql_btn').click(function () {
								bt.saveEditor(editor);
							})
							if($(".ul_scroll ul").width() >= $(".ul_scroll").width()) $(".ul_scroll").scrollLeft($("#new_query_"+ _id).position().left);
						}else{
							$('.table_info').show().next().hide()
							var _tablename = $(this).data('tablename'),_databasename = _parent.parent().data('databasename')
							//右侧是否存在该表
							var r_li = $('.man_r ul').find('[data-path="'+ _path +'"][data-tablename="'+ _tablename +'"]'),scroll_width = 0
							if(r_li.length) {
								r_li.click()
								scroll_width = r_li.position().left
							}else{
								$('.man_r ul').append('<li class="active" title="'+ _tablename +'" data-tablename="'+ _tablename +'" data-path="'+ _path +'"><div><i></i><span>'+ _tablename +'</span><span class="glyphicon glyphicon-remove"></span></div></li>')
								render_man_r(_path,_tablename)
								scroll_width = $('.man_r ul').find('[data-path="'+ _path +'"][data-tablename="'+ _tablename +'"]').position().left
							}
							if($(".ul_scroll ul").width() >= $(".ul_scroll").width()) $(".ul_scroll").scrollLeft(scroll_width)
						}
						
						//右侧表tab切换事件
						$('.man_r').on('click','ul li',function () {
						// $('.man_r ul li').click(function () {
							if($(this).hasClass('new_query')){
								$('.table_info').hide().next().show()
								$('.man_db .new_query').addClass('active').siblings().removeClass('active')
								$('.nq_con_'+ $(this).attr('id').split('_')[2]).show().siblings().hide()
							}else{
								$('.table_info').show().next().hide()
								var _tName = $(this).data('tablename'), path = $(this).data('path')
								render_man_r(path,_tName)
								$('.man_db').find('[data-path="'+ path +'"]').find('[data-tablename="'+ _tName +'"]').addClass('active').siblings().removeClass('active')
							}
							$(this).addClass('active').siblings().removeClass('active')
						})
						//右侧表tab关闭事件
						$('.man_r ul li .glyphicon').click(function () {
							var _li = $(this).parent().parent(),_ul = _li.parent()
							if (_li.next().length != 0) {
								if(_li.hasClass('active')) _li.next().click();
							} else if (_li.prev().length) {
								if(_li.hasClass('active')) _li.prev().click();
							}
							_li.remove();
							if(_li.hasClass('new_query')){
								$('.nq_con_'+ _li.attr('id').split('_')[2]).remove()
							}
							if(!$('.man_r ul li').length){
								$('.table_info').empty()
							}
							return false
						})
					})
					//横向滚动
					var scroll_width = 33; // 设置每次滚动的长度，单位 px
					var scroll_events = "mousewheel DOMMouseScroll MozMousePixelScroll"; // 鼠标滚轮滚动事件名
					$('.ul_scroll').hover(function () {
					$(this).on(scroll_events, function (e) {
						var delta = e.originalEvent.wheelDelta; // 鼠标滚轮滚动度数
						if (delta > 0) {
							$(this).scrollLeft($(this).scrollLeft() - scroll_width);
						}else {
							$(this).scrollLeft($(this).scrollLeft() + scroll_width);
						}
					});
					},function () {
						$(".ul_scroll").unbind(scroll_events);
					});
					//渲染表格
					function render_man_r(_path,_tablename,_p,_search) {
						var _columns = [{type: 'checkbox',width: 20}],_pkname = ''
						//获取表结构
						bt_tools.send({url: 'database/sqlite/get_keys_bytable', data:{ data: JSON.stringify({path:_path,table:_tablename})}}, function (res) {
							for (var i = 0; i < res.length; i++) {
								if(res[i].pk == 1) _pkname = res[i].name
								_columns.push({
									fid: res[i].name, 
									title: res[i].name,
									template: function (row) {
										return '<span title="点击查看详情">'+ row[this.fid+''] +'</span>'
									},
									event: function (row, index, ev, key, _that) {
										if(key.indexOf('textarea') > -1) return
										$('.textarea').prev().show()
										$('.textarea').remove()
										var con = $('.'+key).eq(index).html(),_width = $('.'+key).eq(index).width()

										$('.'+key).eq(index).parent().append('<textarea class="textarea textarea_'+key+'" style="border: none;width:'+_width+'px;" readonly>'+con+'</textarea>')
										$('.textarea').prev().hide()
									}
								})
							}
							_columns.push({
								type: 'group',
								title: '操作',
								width:100,
								align: 'right',
								group: [
									{
										title:'更改',
										event:function(row, index, ev, key, _that){
											_that.editData(row)
										}
									},
									{
										title:'删除',
										event:function(row){
											bt.confirm({title:'删除表数据',msg:'删除选中的表数据后，该条数据将彻底消失，是否继续操作？',icon:0},function(index){
												var loadT = bt.load('正在删除表数据...');
												bt_tools.send({url: 'database/sqlite/delete_table_data', data:{ data: JSON.stringify({path:_path,table:_tablename,where_data:row})}}, function (rdata) {
													loadT.close();
													if (rdata.status) {
														render_man_r(_path,_tablename,1)
													}
													bt.msg(rdata);
												});
											})
										}
									}
								]
							})
							$('.table_info').empty()
							//渲染表格
							managementTable = bt_tools.table({
								el:'.table_info',
								default:'数据列表为空',
								height:'450',
								url: 'database/sqlite/get_table_info',
								param: {
									data: JSON.stringify({path:_path,table:_tablename,p: _p ? _p : 1,search:_search ? _search : ''}),
								},
								dataFilter: function (res) {
									var data = typeof res.data == 'string' ? [] : res.data
									//渲染条件搜索
									$('.table_info .tootls_top .pull-right .bt_search').remove()
									$('.table_info .tootls_top .pull-right').append('<div class="bt_search">\
										<input type="text" class="search_input" style="" placeholder="搜所有字段" value="'+ (_search ? _search : '') +'">\
										<span class="glyphicon glyphicon-search" aria-hidden="true"></span></div>')
									$('.table_info .tootls_top .pull-right .glyphicon').click(function () {
										render_man_r(_path,_tablename,1,$('.table_info .tootls_top .pull-right .search_input').val())
									})
									$('.table_info .tootls_top .pull-right .search_input').keyup(function (e) {
										if (e.keyCode == 13) {
											render_man_r(_path,_tablename,1,$(this).val())
										}
									})
									//渲染分页
									$('.table_info .tootls_bottom .pull-right .page').remove()
									$('.table_info .tootls_bottom .pull-right').append($(res.page).addClass('page').css({'float':'right'}))
									$('.table_info .tootls_bottom .pull-right .page').on('click','a',function(e){
										var p = $(this).prop('href').split('p=')[1]
										render_man_r(_path,_tablename,p,$('.table_info .tootls_top .pull-right .search_input').val())
										e.preventDefault();
									})
									return {
										data: data,
									}
								},
								column: _columns,
								methods: {
									//添加
									editData: function (row) {
										var _form = [],_row = {}
										for (var i = 0; i < res.length; i++) {
											if(res[i].pk != 1){
												_form.push({
													label: res[i].name,
													group: {
														type: res[i].type === "integer" ? 'number' : 'text',
														name: res[i].name,
														width: '300px',
													}
												})
											}
										}
										bt_tools.open({
											title: ( row ? '更改' : '添加' ) + '数据',
											area:'580px',
											btn: ['确认','取消'],
											content: {
												'class':'pd20 add_data_form',
												formLabelWidth: '150px',
												form:_form,
												data: row ? row : {},
											},
											success:function(layers){
												$(layers).find('.layui-layer-content').css('overflow','inherit')
												$('.bt-input-text').eq(0).focus()
												if(row) {
													for (var i = 0; i < res.length; i++) {
														if(res[i].pk != 1){
															console.log(999)
															$('.add_data_form').find('[name="'+ res[i].name +'"]').val(row[res[i].name])
														}
													}
												}
											},
											yes:function (form,indexs, layero){
												for (var i = 0; i < res.length; i++) {
													if(res[i].pk === 1){
														if(row) form[res[i].name] = row[res[i].name]
														else form[res[i].name] = ''
													}
												}
												var param = {
													path:_path,
													table:_tablename,
													new_data:form
												}
												if(row) param['where_data'] = row
												var loadT = bt.load('正在'+ (row ? '更改' : '添加' )+'数据...');
												bt_tools.send({url: 'database/sqlite/'+ (row ? 'update_table_info' : 'create_table_data') ,data: {data: JSON.stringify(param)}},function(res){
													loadT.close();
													if(res.status){
														layer.close(indexs);
														render_man_r(_path,_tablename,1,$('.table_info .tootls_top .pull-right .search_input').val())
														layer.msg(res.msg,{icon:1})
													}else{
														layer.msg(res.msg,{icon:2})
													}
												})
											}
										})
									}
								},
								tootls:[{
									type:'group',
									positon: ['left','top'],
									list:[{
										title: '添加数据',
										active: true,
										event: function (ev, _that){
											_that.editData()
										}
									}]
								},{
									type: 'batch', //batch_btn
									positon: ['left', 'bottom'],
									config: {
										title: "删除数据",
										url: '/database/'+bt.data.db_tab_name+'/delete_table_data',
										load: true,
										param: function (row) {
											return {data:JSON.stringify({path:_path,table:_tablename,where_data:row})}
										},
										callback: function (_that) {
											bt.confirm({title:'批量删除表数据',msg:'删除选中的表数据后，该条数据将彻底消失，是否继续操作？',icon:0},function(index){
												layer.close(index);
												_that.start_batch({},function(list){
													var html = '';
													for(var i=0;i<list.length;i++){
														var item = list[i];
														html += '<tr><td>'+ item[_pkname] +'</td><td><div style="float:right;"><span style="color:'+ (item.request.status?'#20a53a':'red') +'">'+ item.request.msg +'</span></div></td></tr>';
													}
													managementTable.$batch_success_table({title:'批量删除',th:_pkname,html:html});
													render_man_r(_path,_tablename,1,$('.table_info .tootls_top .pull-right .search_input').val())
												});
											})
										}
									}
								}],
								success: function () {
									var data_number = $('.table_info .page .Pcount').text().replace(/[^0-9]/g,'')
									//实时更新左侧数量
									if(data_number) $('.man_db').find('[data-path="'+ _path +'"]').find('[data-tablename="'+ _tablename +'"]').prop('title',_tablename + '（' + data_number + '）').find('span').text(_tablename + '（' + data_number + '）')
									$('.table_info .divtable .table thead tr th span span span,.table_info .divtable .table tbody tr td span span').css({'overflow': 'hidden','white-space':'nowrap','max-width':'200px','display':'block','text-overflow': 'ellipsis'})
									$('.table_info .divtable .table thead tr th:last-child span span,.table_info .divtable .table tbody tr td:last-child span').css({'width':'100px','display':'block'})
								}
							})
						})
					}
				}
			})
		})
	},
	//数据库备份详情
	database_detail: function (path, name) {
		var that = this,sqliteBackupTable = null;
		bt_tools.open({
			title: lan.database.backup_title+'【'+name+'】',
			area:'700px',
			btn: false,
			content: '<div id="DataBackupList" class="pd20" style="padding-bottom:40px;"></div>',
			success:function(layers){
				setTimeout(function () { $(layers).css('top', ($(window).height() - $(layers).height()) / 2); }, 50)
				sqliteBackupTable = bt_tools.table({
					el:'#DataBackupList',
					default:'备份列表为空',
					height:200,
					url: 'database/sqlite/get_backup_list',
					param: {
						data: JSON.stringify({path:path})
					},
					column:[{
						fid:'name',
						title:'名称',
						template: function (item) {
							return '<span class="flex" style="width:280px" title="'+item.name+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+item.name+'</span></span>'
						}},
						{fid:'mtime',width:137,title:'备份时间',template:function(row){
							return '<span>'+bt.format_data(row.mtime)+'</span>'
						}},
						{fid:'size',title:'大小',template:function(row){
							return '<span>'+bt.format_size(row.size)+'</span>'
						}},
						{
							type: 'group',
							title: '操作',
							width:130,
							align: 'right',
							group: [{
								title:'下载',
								event:function(row){
									window.open('/download?filename=' + row.filepath + '&amp;name=' + row.name)
								}
							},{
								title:'删除',
								event:function(row){
									layer.confirm('是否删除【'+row.name+'】备份', {
										title: '删除备份', closeBtn: 2, icon: 0
									}, function (index) {
										bt_tools.send({url:'database/sqlite/DelBackup',data:{data:JSON.stringify({file:row.filepath})}},function(rdata){
											if(rdata.status) {
												sqliteBackupTable.$refresh_table_list(true);
												database_table.$refresh_table_list(true);
											}
											bt_tools.msg(rdata)
											layer.close(index)
										})
									});
								}
							}]
						}
					],
					tootls:[{
						type:'group',
						positon: ['left','top'],
						list:[{
							title:'备份',
							active: true,
							event:function(){
								bt_tools.send({url:'database/sqlite/ToBackup',data:{data:JSON.stringify({path:path})}},function(rdata){
									if(rdata.status) {
										sqliteBackupTable.$refresh_table_list(true);
										database_table.$refresh_table_list(true);
									}
									bt_tools.msg(rdata)
								})
							}
						}]
					}]
				})
			}
		})
	},
	//添加数据库文件
	addSqlite: function () {
		bt_tools.open({
			title:'添加数据库文件',
			area:'480px',
			btn: ['确认','取消'],
			content: {
				'class':'pd20',
				form:[{
					label:'路径',
					group:{
						type:'text',
						name:'path',
						width:'260px',
						icon: { type: 'glyphicon-folder-open', event: function (ev) { }, select: 'file' },
						placeholder: '请选择数据库文件路径',
						verify: function (value, element) {
							if (value == '') {
								bt_tools.$verify_tips(element, '数据库文件路径不能为空！');
								return false;
							}
							return value;
						}
					}
				},{
					label:'名称',
					group:{
						type:'text',
						name:'name',
						width:'260px',
						placeholder: '可以不填写，默认为数据库文件名',
					}
				}]
			},
			success:function(layers){
				$(layers).find('.layui-layer-content').css('overflow','inherit')
			},
			yes:function (form,indexs, layero){
				if(!form.path) return layer.msg('请选择数据库文件路径',{icon:2});
				var loadT = bt.load('正在添加数据库文件...');
				bt_tools.send({url: 'database/sqlite/AddDatabase',data: {data: JSON.stringify(form)}},function(res){
					loadT.close();
					if(res.status){
						layer.close(indexs);
						database_table.$refresh_table_list(true);
						layer.msg(res.msg,{icon:1})
					}else{
						layer.msg(res.msg,{icon:2})
					}
				})
			}
		})
	}
}

var db_public_fn = {
	// 远程服务器列表
	get_cloud_server_list:function(){
		var that = this;
		bt_tools.open({
			title:bt.data.db_tab_name+'远程服务器列表',
			area:'860px',
			btn: false,
			skin: 'databaseCloudServer',
			content: '<div id="db_cloud_server_table" class="pd20" style="padding-bottom:40px;"></div>',
			dataFilter: function(res) { cloudDatabaseList = res},
			success:function(){
				var tdHTML = [{
					fid:'db_host',
					title:'服务器地址',
					width: 170,
					template: function (item) {
						return '<span class="flex" style="width:154px" title="'+item.db_host+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+item.db_host+'</span></span>'
					}
				},
					{fid:'db_port',width:80,title:'数据库端口'},
					{fid:'db_type',width:80,title:'数据库类型'},
					{
						fid:'db_user',
						width:100,
						title:'管理员名称'
					},
					{fid:'db_password',type: 'password',title:'管理员密码',copy: true,eye_open: true},
					{fid:'ps',title:'备注',width:160,template: function (item) {
							return '<span class="flex" style="width:144px" title="'+item.ps+'"><span class="size_ellipsis" style="width: 0; flex: 1;">'+item.ps+'</span></span>'
						}},
					{
						type: 'group',
						width: 100,
						title: '操作',
						align: 'right',
						group: [{
							title:'编辑',
							hide:function (row) {
								return row.id == 0
							},
							event:function(row){
								that.render_db_cloud_server_view(row,true);
							}
						},{
							title:'删除',
							hide:function (row) {
								return row.id == 0
							},
							event:function(row){
								that.del_db_cloud_server(row)
							}
						}]
					}
				]
				if(bt.data.db_tab_name == 'redis') tdHTML.splice(3,1)
				dbCloudServerTable = bt_tools.table({
					el:'#db_cloud_server_table',
					default:'服务器列表为空',
					data: [],
					column:tdHTML,
					tootls:[{
						type:'group',
						positon: ['left','top'],
						list:[{
							title:'添加远程服务器',
							active: true,
							event:function(){that.render_db_cloud_server_view()}
						}]
					}]
				})
				that.render_cloud_server_table();
			}
		})
	},
	// 重新渲染远程服务器
	render_cloud_server_table: function (callback) {
		bt_tools.send({url:'database/'+bt.data.db_tab_name+'/GetCloudServer',data:{data:JSON.stringify({type:bt.data.db_tab_name})}},function(rdata){
			var arry = []
			for (var i = 0; i < rdata.length; i++) {
				var element = rdata[i];
				if(element.id == 0) continue
				arry.push(element)
			}
			dbCloudServerTable.$reader_content(arry);
			if(callback) callback(rdata)
		});
	},
	// 添加/编辑远程服务器视图
	render_db_cloud_server_view:function(config,is_edit){
		var that = this,_type = bt.data.db_tab_name;
		if(!config){
			config = {db_host:'',db_port:'3306',db_user:'',db_password:'',db_user:'root',ps:''}
			if(_type == 'sqlserver'){
				config['db_port'] = 1433
				config['db_user'] = 'sa'
			}else if(_type == 'redis'){
				config['db_port'] = 6379
				config['db_user'] = ''
			}else if(_type == 'mongodb'){
				config['db_port'] = 27017
			}else if(_type == 'pgsql'){
				config['db_port'] = 5432
				config['db_user'] = 'postgres'
			}
		}
		bt_tools.open({
			title: (is_edit?'编辑':'添加')+bt.data.db_tab_name+'远程服务器',
			area:'450px',
			btn:['保存','取消'],
			skin:'addCloudServerProject',
			content:{
				'class':'pd20',
				form:[{
					label:'服务器地址',
					group:{
						type:'text',
						name:'db_host',
						width:'260px',
						value:config.db_host,
						placeholder:'请输入服务器地址',
						event:function(){
							$('[name=db_host]').on('input blur',function(e){
								switch(e.type){
									case 'input':
										$('[name=db_ps]').val($(this).val())
										break;
									case 'blur':
										if($(this).val().indexOf(':') != -1){
											var reg = /:(\d+)/,_post = $(this).val().match(reg)
											$('[name=db_port]').val(_post[1])
											$(this).val($(this).val().replace(reg,''))
										}
										break;
								}
							})
						}
					}
				},{
					label:'数据库端口',
					group:{
						type:'number',
						name:'db_port',
						width:'260px',
						value:config.db_port,
						placeholder:'请输入数据库端口'
					}
				},{
					label:'管理员名称',
					hide:bt.data.db_tab_name == 'redis'?true:false,
					group:{
						type:'text',
						name:'db_user',
						width:'260px',
						value:config.db_user,
						placeholder:'请输入管理员名称',
					}
				},{
					label:'管理员密码',
					group:{
						type:'text',
						name:'db_password',
						width:'260px',
						value:config.db_password,
						placeholder:'请输入管理员密码'
					}
				},{
					label:'备注',
					group:{
						type:'text',
						name:'db_ps',
						width:'260px',
						value:config.ps,
						placeholder:'服务器备注'
					}
				},{
					group:{
						type:'help',
						style:{'margin-top':'0'},
						list:[
							'支持MySQL5.5、MariaDB10.1及以上版本',
							'支持阿里云、腾讯云等云厂商的云数据库',
							'注意1：请确保本服务器有访问数据库的权限',
							'注意2：请确保填写的管理员帐号具备足够的权限'
						]
					}
				}]
			},
			success:function(){
				if(bt.data.db_tab_name != 'mysql') $('.addCloudServerProject .help-info-text li').eq(0).remove();
			},
			yes:function(form,indexs){
				var interface = is_edit?'ModifyCloudServer':'AddCloudServer'
				if(form.db_host == '') return layer.msg('请输入服务器地址',{icon:2})
				if(form.db_port == '') return layer.msg('请输入数据库端口',{icon:2})
				if(form.db_user == '' && bt.data.db_tab_name != 'redis') return layer.msg('请输入管理员名称',{icon:2})
				if(form.db_password == '') return layer.msg('请输入管理员密码',{icon:2})

				if(is_edit) form['id'] = config['id'];
				form['type'] = bt.data.db_tab_name
				that.layerT = bt.load('正在'+(is_edit?'修改':'创建')+'远程服务器,请稍候...');
				bt_tools.send({url:'database/'+bt.data.db_tab_name+'/'+interface,data:{data:JSON.stringify(form)}},function(rdata){
					that.layerT.close();
					if(rdata.status){
						that.reset_server_config()
						layer.close(indexs)
						layer.msg(rdata.msg, {icon:1})
					}else{
						layer.msg(rdata.msg,{time:0,icon:2,closeBtn: 2, shade: .3,area: '650px'})
					}
				})
			}
		})
	},
	// 删除远程服务器管理关系
	del_db_cloud_server: function(row){
		var that = this;
		layer.confirm('仅删除管理关系以及面板中的数据库记录，不会删除远程服务器中的数据', {
			title: '删除【'+row.db_host+'】远程服务器',
			icon: 0,
			closeBtn: 2
		}, function () {
			bt_tools.send({url:'database/'+bt.data.db_tab_name+'/RemoveCloudServer',data:{data:JSON.stringify({id:row.id})}},function(rdata){
				if(rdata.status) that.reset_server_config()
				layer.msg(rdata.msg, {
					icon: rdata.status ? 1 : 2
				})
			})
		})
	},
	// 重新加载服务
	reset_server_config:function(){
		this.render_cloud_server_table(function(){
			if(bt.data.db_tab_name == 'redis') redis.cloudInfo.sid = 0  //redis恢复默认是本地服务器
			$('.database-pos .tabs-item[data-type="' + bt.data.db_tab_name + '"]').trigger('click');
		});
	}
}
$('.database-pos .tabs-item[data-type="' + (bt.get_cookie('db_page_model') || 'mysql') + '"]').trigger('click');