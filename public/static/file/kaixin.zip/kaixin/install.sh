#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/kaixin

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始

	#\cp -f $install_path/json_init.py /www/server/panel/pyenv/lib/python3.7/json/__init__.py

	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成，请手动进入SSH界面执行命令重启面板：bt restart'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
