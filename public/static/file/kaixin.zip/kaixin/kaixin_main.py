#!/usr/bin/python
# coding: utf-8
#+--------------------------------------------------------------------
#|   宝塔第三方云端接口插件
#+--------------------------------------------------------------------
import sys,os,json,requests,time,base64,shutil

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

class kaixin_main:
    __plugin_path = "/www/server/panel/plugin/kaixin/"
    __config = None
    __tmp_path = '/tmp/plugins'

    #构造方法
    def  __init__(self):
        pass

    #获取已登录用户信息
    def get_user_info(self, args):
        return public.get_user_info()

    #从云端获取插件列表
    def get_plugin_list(self, args):
        from pluginAuth import Plugin
        softList = Plugin(False).get_plugin_list(True)
        return softList

    #下载插件包，返回文件路径
    def download_plugin(self, args):
        if 'plugin_name' not in args or not args.plugin_name: return {'status':False,'msg':'插件名不能为空'}
        if 'version' not in args or not args.version: return {'status':False,'msg':'插件版本不能为空'}
        pdata = public.get_user_info()
        pdata['name'] = args.plugin_name
        pdata['version'] = args.version
        pdata['os'] = 'Linux'
        filename = '{}/{}_{}.zip'.format(self.__tmp_path,args.plugin_name,args.version)
        if not os.path.exists(self.__tmp_path): os.makedirs(self.__tmp_path,384)
        if os.path.exists(filename): os.remove(filename)
        download_url = 'https://api.miku.ci/down/download_plugin'
        try:
            download_res = requests.post(download_url,pdata,headers=public.get_requests_headers(),timeout=30,stream=True)
        except Exception as ex:
            return {'status':False,'msg':public.error_conn_cloud(str(ex))}

        try:
            headers_total_size = int(download_res.headers['File-size'])
        except:
            if download_res.text.find('<html>') != -1:
                return {'status':False,'msg':public.error_conn_cloud(download_res.text)}
            return {'status':False,'msg':download_res.text}
        res_chunk_size = 8192
        with open(filename,'wb+') as with_res_f:
            for download_chunk in download_res.iter_content(chunk_size=res_chunk_size):
                if download_chunk:
                    with_res_f.write(download_chunk)
            with_res_f.close()
        if public.FileMd5(filename) != download_res.headers['Content-md5']:
            return {'status':False,'msg':'插件包文件MD5校验失败'}
        return {'status':True,'filename':filename}

    #下载插件主程序文件，返回文件路径
    def download_plugin_main(self, args):
        if 'plugin_name' not in args or not args.plugin_name: return {'status':False,'msg':'插件名不能为空'}
        if 'version' not in args or not args.version: return {'status':False,'msg':'插件版本不能为空'}
        filename = '{}/temp.py'.format(self.__tmp_path)
        if not os.path.exists(self.__tmp_path): os.makedirs(self.__tmp_path,384)
        if os.path.exists(filename): os.remove(filename)
        download_d_main_url = 'https://api.miku.ci/down/download_plugin_main'
        pdata = public.get_user_info()
        pdata['name'] = args.plugin_name
        pdata['version'] = args.version
        pdata['os'] = 'Linux'
        try:
            download_res = requests.post(download_d_main_url,pdata,timeout=30,headers=public.get_requests_headers())
        except Exception as ex:
            return {'status':False,'msg':public.error_conn_cloud(str(ex))}
        try:
            headers_total_size = int(download_res.headers['File-size'])
        except:
            if download_res.text.find('<html>') != -1:
                return {'status':False,'msg':public.error_conn_cloud(download_res.text)}
            return {'status':False,'msg':download_res.text}
        with open(filename,'wb+') as save_script_f:
            save_script_f.write(download_res.content)
            save_script_f.close()
        if public.Md5(download_res.content) != download_res.headers['Content-md5']:
            return {'status':False,'msg':'插件主程序文件MD5校验失败'}
        return {'status':True,'filename':filename}
    
    #下载插件其他文件，返回文件路径
    def download_plugin_other(self, args):
        if 'fname' not in args or not args.fname: return {'status':False,'msg':'文件名不能为空'}
        filename = '{}/temp.zip'.format(self.__tmp_path)
        if not os.path.exists(self.__tmp_path): os.makedirs(self.__tmp_path,384)
        if os.path.exists(filename): os.remove(filename)
        apiurl = 'https://www.miku.ci/api/Pluginother/get_file?fname='
        is_btsy = int(public.ExecShell("cat /www/server/panel/task.py | grep '//download.miku.ci/' | wc -l")[0])
        if is_btsy > 0:
            apiurl = 'https://www.miku.ci/api/Pluginother/get_file?fname='
        public.downloadFile(apiurl + args.fname,filename)
        return {'status':True,'filename':filename}

    #返回文件base64
    def get_file(self, args):
        if 'filename' not in args or not args.filename: return {'status':False,'msg':'文件名不能为空'}
        if not os.path.exists(args.filename): return {'status':False,'msg':'文件不存在'}
        with open(args.filename, 'rb') as f1:
            base64_str = base64.b64encode(f1.read())
            data = base64_str.decode('utf-8')
        return {'status':True,'data':data}

    #解密插件主文件py代码
    def decode_plugin_main(self, args):
        if 'plugin_name' not in args or not args.plugin_name: return {'status':False,'msg':'插件名不能为空'}
        if 'version' not in args or not args.version: return {'status':False,'msg':'插件版本不能为空'}

        is_btsy = int(public.ExecShell("cat /www/server/panel/task.py | grep '//download.miku.ci/' | wc -l")[0])
        if is_btsy > 0:
            return self.__get_plugin_main(args.plugin_name, args.version)
        
        result = self.download_plugin_main(args)
        if not result['status']: return result
        filename = result['filename']

        src = public.readFile(filename)
        if src.find("import ") != -1:
            return {'status':True,'decode':False,'filename':filename}
        
        user = public.get_user_info()
        uid = str(user['uid'])
        serverid = user['serverid']

        try:
            keysrc = serverid[10:26]+uid+serverid
            key = public.Md5(keysrc)
            iv = public.Md5(key+serverid)
            key = key[8:24]
            iv = iv[8:24]

            en_arr = src.split('\n')
            de_text = ''
            for data in en_arr:
                data = str.strip(data)
                if not data or len(data)==24: continue
                de_text += self.__aes_decrypt(data, key, iv)
            
            if not de_text: return {'status':False,'msg':'文件解密失败'}
            public.writeFile(filename, de_text)
        except:
            return {'status':False,'msg':'文件解密失败'}

        return {'status':True,'decode':True,'filename':filename}
    
    def __aes_decrypt(self, ciphertext, key, iv):
        from Crypto.Cipher import AES
        cipher = base64.decodebytes(ciphertext.encode('utf-8'))
        aes = AES.new(key.encode('utf-8'),AES.MODE_CBC,iv.encode('utf-8'))
        de_text = aes.decrypt(cipher)
        unpad = lambda s: s[0:-s[-1]]
        de_text = unpad(de_text)
        return de_text.decode('utf-8')

    def __get_plugin_main(self, plugin_name, version):
        url = 'https://api.miku.ci/api/plugin/?plugin={}&version={}'.format(plugin_name, version)
        pdata = public.get_pdata()
        try:
            pluginInfo = json.loads(public.httpPost(url,pdata))
            if not pluginInfo: return {'status':False,'msg':'从云端获取失败'}
        except:
            return {'status':False,'msg':'从云端获取失败'}
        if pluginInfo['status'] == 0: return {'status':False,'msg':pluginInfo['text']}

        filename = '{}/temp.py'.format(self.__tmp_path)
        public.writeFile(filename, pluginInfo['text'])
        
        return {'status':True,'decode':True,'filename':filename}

    #从云端获取一键部署列表
    def get_deplist(self, args):
        downloadUrl = 'https://www.miku.ci/api/panel/get_deplist'
        pdata = public.get_pdata()
        pdata["version"] = "v2"
        try:
            tmp = json.loads(public.httpPost(downloadUrl,pdata))
            if not tmp: return {'status':False,'msg':'从云端获取失败'}
            return tmp
        except:
            return {'status':False,'msg':'从云端获取失败'}
        
    #BTWAF-获取蜘蛛列表
    def btwaf_getspiders(self, args):
        url = 'https://www.miku.ci/api/bt_waf/getSpiders'
        userInfo = public.get_user_info()
        data22 = {"access_key": userInfo['access_key'], "uid": userInfo['uid']}
        try:
            data_list = json.loads(public.httpPost(url, data22, timeout=3))
            if not data_list: return {'status':False,'msg':'获取失败'}
            return {'status':True,'data':data_list}
        except:
            return {'status':False,'msg':'获取失败'}
        
    #BTWAF-获取恶意情报IP库
    def btwaf_getmalicious(self, args):
        url = 'https://www.miku.ci/api/bt_waf/get_malicious'
        userInfo = public.get_user_info()
        data = {"x_bt_token": "SksBSpWhJE7oVRixKCAZVEsN3QDnfQBU", "page": 1, "uid": userInfo["uid"],
                "access_key": userInfo["access_key"], "serverid": userInfo["serverid"]}
        try:
            result = json.loads(public.httpPost(url, data, timeout=6))
            if not result: return {'success':False,'res':'获取失败'}
            return result
        except:
            return {'success':False,'res':'获取失败'}

